import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (file) => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('employer offer section presents transparent, non-contractual pricing hypotheses', () => {
  const html = read('public/index.html');
  assert.match(html, /id="for-recruiters"/);
  assert.match(html, /119 €/);
  assert.match(html, /349 € /);
  assert.match(html, /Aucun paiement ni abonnement n’est activé dans cette version/);
  assert.match(html, /id="pricingJoin"/);
});

test('employer offer copy is available in both interface languages and CTA uses existing signup', () => {
  const dictionary = read('public/i18n.js');
  const app = read('public/app.js');
  assert.match(dictionary, /SPECIALIST RECRUITMENT · EMPLOYER OFFER/);
  assert.match(dictionary, /Indicative pricing to validate in pilot/);
  assert.match(app, /pricingJoin.*joinOpen/);
});

test('commercial packaging does not claim that billing is implemented', () => {
  const docs = read('RELEASE_MANIFEST.md') + read('README.md');
  assert.match(docs, /no payment processor or live subscription is enabled/i);
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
});
