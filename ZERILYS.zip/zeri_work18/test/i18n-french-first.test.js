import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("French-first language layer supports browser detection, persistent choice and dynamic content",()=>{
  const html=read("public/index.html"),i18n=read("public/i18n.js");
  assert.match(html,/<html lang="fr">/);
  assert.match(html,/id="languageSelect"/);
  assert.match(html,/<option value="fr">Français<\/option>/);
  assert.match(html,/<option value="en">English<\/option>/);
  assert.match(html,/\/i18n\.js/);
  assert.match(i18n,/French is the product launch language/);
  assert.match(i18n,/return "fr";/);
  assert.match(i18n,/zerihlink\.language\.v1/);
  assert.match(i18n,/MutationObserver/);
  assert.match(i18n,/attributeFilter: attrs/);
  assert.match(i18n,/"Your identity\.":"Votre identité\."/);
  assert.match(i18n,/"Create your identity":"Créer mon profil"/);
  assert.match(i18n,/supported: \[\.\.\.supported\]/);
});

test("French legal beta documents are native-language drafts and preserve the legal warning",()=>{
  const terms=read("public/beta-terms.html"),privacy=read("public/privacy-notice.html");
  for(const doc of [terms,privacy]){
    assert.match(doc,/<html lang="fr">/);
    assert.match(doc,/PROJET DE DOCUMENT — NON VALIDÉ JURIDIQUEMENT/);
    assert.match(doc,/À COMPLÉTER/);
  }
  assert.match(terms,/aucune invitation n’est nécessaire/i);
  assert.match(privacy,/tous les membres connectés/i);
});

test("release metadata is aligned at 1.9.0-alpha.20 and invitation-free registration keeps its legal lock",()=>{
  const pkg=JSON.parse(read("package.json")),version=read("VERSION").trim(),server=read("src/server.js"),qa=read("docs/QA_0_62.md");
  assert.equal(pkg.version,"1.9.0-alpha.20");
  assert.equal(version,"1.9.0-alpha.20");
  assert.match(server,/const VERSION = "1\.9\.0-alpha\.20"/);
  assert.match(server,/inviteRequired:false/);
  assert.match(server,/if\(!BETA_LEGAL_APPROVED\) return json\(res,503/);
  assert.match(qa,/61 automated unit tests/);
});


test("date and time presentation follows the selected interface language",()=>{
  const app=read("public/app.js"),i18n=read("public/i18n.js");
  assert.match(i18n,/get locale\(\) \{ return language === "fr" \? "fr-FR" : "en-GB"/);
  assert.match(app,/Intl\.DateTimeFormat\(currentLocale\(\)/);
  assert.doesNotMatch(app,/toLocaleDateString\(\)|toLocaleString\(\)/);
  assert.match(app,/zerihlink:languagechange/);
  assert.match(i18n,/"Describe the issue \(at least 20 characters\)\. This report will be sent to the moderation team\.":"Décrivez le problème/);
});
