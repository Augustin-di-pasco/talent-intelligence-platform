import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
test('member discovery supports validated cursor pagination and total counts',()=>{
  assert.match(server,/requestedLimit=url\.searchParams\.has\("limit"\)\?Number/);
  assert.match(server,/cursorToken=url\.searchParams\.get\("cursor"\)/);
  assert.match(server,/INVALID_DISCOVERY_PAGE/);
  assert.match(server,/afterIndex=after\?allUsers\.findIndex/);
  assert.match(server,/afterIndex<0\?total:afterIndex/);
  assert.match(server,/Buffer\.from\(JSON\.stringify\(\{score:last\.matchScore,name:last\.name,id:last\.id\}\)\)\.toString\("base64url"\)/);
  assert.match(server,/hasMore:!!nextCursor/);
});
