import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL(`../${p}`,import.meta.url),'utf8');

test('0.95 translates common dynamic authentication, discovery and network interface copy',()=>{
 const source=read('public/i18n.js');
 const pairs=[
  ['Create your identity','Créer mon profil'],
  ['Registration is paused until the beta legal review is complete.','Les inscriptions sont suspendues'],
  ['Searching the member network…','Recherche dans le réseau…'],
  ['No matching profiles. Try another name, skill or location.','Aucun profil correspondant.'],
  ['Load next profiles ↓','Afficher les profils suivants ↓'],
  ['Explore collaboration ↗','Découvrir la collaboration ↗'],
  ['Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.','Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.'],
  ['Connections are temporarily unavailable.','Le réseau est momentanément indisponible.'],
  ['You are all caught up.','Vous êtes à jour.'],
  ['Add projects, credentials or work that demonstrates your capabilities.','Ajoutez des projets, certifications ou réalisations']
 ];
 for(const [en,fr] of pairs){assert.ok(source.includes(`'${en}'`),`Missing source phrase: ${en}`);assert.ok(source.includes(fr),`Missing translation: ${fr}`)}
});

test('0.95 preserves member-authored content and only translates known interface strings',()=>{
 const source=read('public/i18n.js');
 assert.match(source,/const translated = language === "fr" \? fr\[trimmed\] : en\[trimmed\]/);
 assert.match(source,/if \(!translated\) return text/);
 assert.match(source,/const originalText = new WeakMap\(\)/);
});

test('0.95 release metadata and legal launch gate remain aligned',()=>{
 assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(read('src/server.js'),/BETA_LEGAL_APPROVED/);
});
