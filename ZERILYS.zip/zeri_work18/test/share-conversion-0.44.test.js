import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('anonymous visitors can join directly from a shared public profile',()=>{
  assert.match(js,/id="joinPublic"/);
  assert.match(js,/\$\("#joinPublic"\)\.classList\.toggle\("hidden",!!me\)/);
  assert.match(js,/pendingProfileId=uid;openAuth\("register"\)/);
  assert.match(css,/\.join-public-cta/);
});
test('shared public profiles are opened before unrelated discovery requests',()=>{
  assert.match(js,/else if\(profileId\)\{await openPublicIdentity\(profileId\)\}await Promise\.all/);
  assert.match(js,/if\(pendingProfileId\)\{const target=pendingProfileId/);
});
