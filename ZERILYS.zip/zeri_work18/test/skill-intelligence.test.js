import test from "node:test";
import assert from "node:assert/strict";
import { profileMatchesQuery, semanticTerms, semanticSkillOverlap } from "../src/skill-intelligence.js";

test("specialist vocabulary expands common finance and technology synonyms", () => {
  assert.ok(semanticTerms("quant").includes("quantitative finance"));
  assert.ok(semanticTerms("LLM").includes("artificial intelligence"));
  assert.ok(semanticTerms("credit risk").includes("risk modelling"));
});

test("discovery finds equivalent specialist skills without exact wording", () => {
  const profile = { name: "Camille", headline: "Research engineer", skills: [{ name: "Quantitative Research" }] };
  assert.equal(profileMatchesQuery(profile, "quant"), true);
  assert.equal(profileMatchesQuery(profile, "quantitative finance"), true);
  assert.equal(profileMatchesQuery(profile, "supply chain"), false);
});

test("semantic overlap groups equivalent skills transparently", () => {
  const matches = semanticSkillOverlap({ skills: [{ name: "LLM applications" }] }, { skills: [{ name: "Generative AI" }] });
  assert.ok(matches.includes("artificial intelligence"));
});
