import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');

test('0.94 mobile workspace prevents horizontal clipping and preserves readable identity controls',()=>{
  assert.match(css,/0\.94 — mobile Human Orbit: predictable sizing/);
  assert.match(css,/@media \(max-width:760px\)\{[\s\S]*?\.identity-workspace\{width:100%;min-width:0;padding-inline:12px/);
  assert.match(css,/\.orbit-node\{box-sizing:border-box;min-width:0;max-width:calc\(50vw - 18px\)/);
  assert.match(css,/\.identity-progress\{min-width:0;width:100%\}/);
});

test('390px and 340px devices receive dedicated compact layouts without scaling the entire orbit',()=>{
  assert.match(css,/@media \(max-width:390px\)\{[\s\S]*?\.identity-core\{width:232px;height:232px/);
  assert.match(css,/@media \(max-width:340px\)\{[\s\S]*?\.identity-core\{width:216px;height:216px/);
  assert.doesNotMatch(css,/@media \(max-width:390px\)\{[^}]*transform:scale/);
});
