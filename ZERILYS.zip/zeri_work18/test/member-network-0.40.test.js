import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('member explorer progressively reveals every loaded profile in batches',()=>{
  assert.match(js,/visible=7,loading=false/);
  assert.match(js,/visible=Math\.min\(users\.length,visible\+7\)/);
  assert.match(js,/orbit-network-more/);
  assert.match(js,/tr\("Load"\).*tr\("more profiles ↓"\)/);
});
test('load-more control follows the compact premium orbit styling',()=>{
  assert.match(css,/\.orbit-network-more/);
  assert.match(css,/\.orbit-network-more:hover/);
});

test('member explorer requests further server pages instead of stopping at the first cohort',()=>{
  assert.match(js,/limit:"50"/);
  assert.match(js,/cursor:nextCursor/);
  assert.match(js,/users\.push\(\.\.\.page\.users\)/);
  assert.match(js,/orbitNetworkRequestId/);
});
