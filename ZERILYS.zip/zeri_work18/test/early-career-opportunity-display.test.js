import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const integrity=fs.readFileSync(new URL('../src/data-integrity.js',import.meta.url),'utf8');

test('public company opportunities expose the complete early-career facts without private fields',()=>{
  assert.match(server,/map\(\(\{id,title,description,type,targetStudyLevels,startDate,duration,rhythm,compensation,supervision,location,workMode,aiPolicy,aiPolicyNote,skills,createdAt\}\)=>\(\{id,title,description,type,targetStudyLevels,startDate,duration,rhythm,compensation,supervision,location,workMode,aiPolicy,aiPolicyNote,skills,createdAt\}\)\)/);
  assert.doesNotMatch(server,/map\(\(\{[^}]*password[^}]*\}\)/i);
});

test('candidate and company views render transparent internship and apprenticeship metadata',()=>{
  for(const field of ['startDate','duration','rhythm','compensation','supervision','targetStudyLevels']) assert.match(app,new RegExp(`o\\.${field}`));
  assert.match(app,/function opportunityDetailsMarkup\(o\)/);
  assert.match(app,/Rémunération/);
  assert.match(app,/Niveau indicatif/);
});

test('data integrity accepts all published opportunity families',()=>{
  for(const type of ['job','internship','apprenticeship','collaboration','graduate_program','vie','research_project']) assert.ok(integrity.includes(`"${type}"`),`missing ${type}`);
});
