import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('public member profile uses a compact mobile orbit and readable inspector',()=>{
  assert.match(css,/@media\(max-width:760px\)\{[\s\S]*?\.public-stage\{height:300px;min-height:300px/);
  assert.match(css,/\.public-stage-core\{width:118px;height:118px\}/);
  assert.match(css,/\.public-inspector\{min-height:150px;max-height:260px/);
});
test('member profile actions wrap on mobile and fit extra-small screens',()=>{
  assert.match(css,/\.public-identity-footer \.connection-action\{display:flex;flex-wrap:wrap/);
  assert.match(css,/@media\(max-width:420px\)/);
  assert.match(css,/\.public-satellite\{max-width:82px/);
});
