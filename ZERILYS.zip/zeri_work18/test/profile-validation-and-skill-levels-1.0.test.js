import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const server = read('src/server.js');
const app = read('public/app.js');

test('profile API validates website URLs as HTTPS and rejects embedded credentials', () => {
  const route = server.slice(server.indexOf('if(method==="PATCH" && p==="/api/me")'), server.indexOf('if(method==="POST" && p==="/api/me/skills")'));
  assert.match(route, /parsed\.protocol!=="https:"/);
  assert.match(route, /parsed\.username\|\|parsed\.password/);
  assert.match(route, /INVALID_PROFILE_WEBSITE/);
  assert.match(route, /if\(website\)/); // an empty website remains a valid removal action
});

test('profile API rejects unknown availability and visibility values before mutating the user', () => {
  const route = server.slice(server.indexOf('if(method==="PATCH" && p==="/api/me")'), server.indexOf('if(method==="POST" && p==="/api/me/skills")'));
  assert.match(route, /\["open","selective","not_now"\]\.includes\(b\.availability\)/);
  assert.match(route, /\["public","private"\]\.includes\(b\.visibility\)/);
  assert.ok(route.indexOf('INVALID_PROFILE_AVAILABILITY') < route.indexOf('for(const k of'));
  assert.ok(route.indexOf('INVALID_PROFILE_VISIBILITY') < route.indexOf('for(const k of'));
});

test('skill presentation maps the exact levels accepted by the API into native French labels', () => {
  for (const level of ['learning','practitioner','advanced','expert']) assert.ok(server.includes(`"${level}"`));
  const panel = app.slice(app.indexOf('function selectSkill('), app.indexOf('\nfunction ', app.indexOf('function selectSkill(') + 10));
  for (const label of ['learning','practitioner','advanced','expert','En apprentissage','Opérationnel','Avancé']) assert.ok(panel.includes(label), `skill level label ${label}`);
  assert.doesNotMatch(panel, /beginner:|intermediate:/);
});

test('skill constellation evidence labels follow the selected interface language', () => {
  const start = app.indexOf('function renderSkillConstellation');
  const end = app.indexOf('\nfunction selectSkill', start);
  const view = app.slice(start, end);
  assert.match(view, /preuves associées/);
  assert.match(view, /"evidence":"preuve\(s\)"/);
});

test('release metadata is aligned for the 1.0 release candidate', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(server, /const VERSION = "1\.9\.0-alpha\.20"/);
});
