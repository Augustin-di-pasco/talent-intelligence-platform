import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const remote=fs.readFileSync(path.join(root,'scripts/remote-beta-check.mjs'),'utf8');
const local=fs.readFileSync(path.join(root,'scripts/remote-beta-smoke.mjs'),'utf8');
test('remote acceptance check validates deployed version, HTTPS headers and open registration config',()=>{
  for(const marker of ['/api/health','strict-transport-security','frame-ancestors','inviteRequired','personalInvitationsEnabled','anonymous_discovery_privacy'])assert.ok(remote.includes(marker),`missing ${marker}`);
  assert.match(remote,/config.inviteRequired,false/);
});
test('remote acceptance supports public/private profile checks without credentials',()=>{
  assert.match(remote,/ZERIHLINK_REMOTE_PUBLIC_PROFILE_ID/);
  assert.match(remote,/ZERIHLINK_REMOTE_PRIVATE_PROFILE_ID/);
  assert.match(remote,/Public profile photo should be used in the social preview/);
  assert.match(remote,/unknown_profile_denial/);
  assert.match(local,/NODE_ENV:'production'/);
});
