import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("the 50-member launch cohort can register without any invitation token",()=>{
 const script=read("scripts/open-cohort-50-smoke.mjs"),pkg=JSON.parse(read("package.json"));
 assert.match(script,/length:50/);
 assert.match(script,/inviteRequired,false/);
 assert.match(script,/\/api\/auth\/register/);
 assert.doesNotMatch(script,/betaInvitationToken|inviteCode/);
 assert.match(script,/49\/49 other private profiles/);
 assert.match(pkg.scripts["test:release"],/smoke:open-cohort50/);
});
