import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const app = read('public/app.js');

test('0.99 refreshes the canonical profile and all dependent views after profile mutations', () => {
  const start = app.indexOf('async function syncProfileSurfaces');
  const end = app.indexOf('\nfunction selectSignal', start);
  assert.ok(start >= 0 && end > start, 'profile synchronization helper exists');
  const helper = app.slice(start, end);
  for (const call of ['refreshMe()', 'renderEvidence()', 'renderIdentity()', 'loadReadiness()', 'loadOpportunityOrbit()', 'loadCandidateApplications()', 'loadNetwork()', 'loadProjects()', 'loadOffers()']) {
    assert.ok(helper.includes(call), `refreshes ${call}`);
  }
  assert.match(app, /profileForm"\)\.onsubmit[\s\S]*?syncProfileSurfaces\(\)/);
  assert.match(app, /addSkill"\)\.onclick[\s\S]*?syncProfileSurfaces\(\)/);
  assert.match(app, /addEvidence"\)\.onclick[\s\S]*?syncProfileSurfaces\(\)/);
});

test('0.99 profile image changes refresh profile cards and discovery surfaces', () => {
  assert.match(app, /avatarFile"\)\.onchange[\s\S]*?syncProfileSurfaces\(\)/);
  assert.match(app, /avatarRemove"\)\.onclick[\s\S]*?syncProfileSurfaces\(\)/);
});

test('0.99 release metadata is aligned', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
