import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('NETWORK orbit node opens a searchable member explorer in the identity inspector',()=>{
  assert.match(html,/class="orbit-node node-network" data-panel="network"/);
  assert.match(js,/async function loadOrbitNetwork\(q=""\)/);
  assert.match(js,/id="orbitNetworkSearch"/);
  assert.match(js,/id="orbitNetworkSearchButton"/);
  assert.match(js,/data-member-profile=/);
  assert.match(js,/if\(key==="network"\)/);
});
test('member explorer displays real portraits and opens the selected profile',()=>{
  assert.match(js,/u\.avatarUrl\?`<img src="\$\{esc\(u\.avatarUrl\)\}"/);
  assert.match(js,/openPublicIdentity\(b\.dataset\.memberProfile\)/);
  assert.match(css,/\.orbit-network-member/);
  assert.match(css,/\.orbit-network-avatar img/);
});
