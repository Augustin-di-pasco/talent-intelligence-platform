import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const preflight=fs.readFileSync(path.join(root,'scripts/preflight-beta.mjs'),'utf8');
const render=fs.readFileSync(path.join(root,'render.yaml'),'utf8');
const env=fs.readFileSync(path.join(root,'.env.production.example'),'utf8');
const runbook=fs.readFileSync(path.join(root,'docs/BETA_LAUNCH_RUNBOOK_0_47.md'),'utf8');
const tester=fs.readFileSync(path.join(root,'docs/BETA_TESTER_GUIDE_0_47.md'),'utf8');
test('release preflight checks media integrity, writable avatar storage and canonical public origin',()=>{
  assert.match(preflight,/avatar_media_directory/);
  assert.match(preflight,/avatar_media_integrity/);
  assert.match(preflight,/public_origin/);
  assert.match(preflight,/mediaCountValid/);
  assert.match(preflight,/ZERIHLINK_PERSISTENT_DATA_ACK/);
});
test('Render and production environment templates expose all manual release gates',()=>{
  for(const key of ['ZERIHLINK_PUBLIC_URL','ZERIHLINK_DEPLOYMENT_URL','ZERIHLINK_BROWSER_QA_ACK','ZERIHLINK_LEGAL_REVIEW_ACK','ZERIHLINK_REVIEWER_COVERAGE_ACK','ZERIHLINK_OFFSITE_BACKUP_ACK'])assert.ok(render.includes(key),`missing ${key} in render.yaml`);
  assert.match(env,/ZERIHLINK_BETA_LEGAL_APPROVED=false/);
  assert.match(env,/ZERIHLINK_SESSION_SECRET=REPLACE/);
  assert.doesNotMatch(env,/ZERIHLINK_INVITE_CODE=/);
  assert.match(runbook,/readyForClosedBeta: true/);
  assert.match(tester,/Private.*signed-in members/);
});
