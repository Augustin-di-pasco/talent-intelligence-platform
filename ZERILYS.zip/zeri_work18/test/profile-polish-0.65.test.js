import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const app=readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const css=readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
const i18n=readFileSync(new URL('../public/i18n.js',import.meta.url),'utf8');
const pkg=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('0.65 central identity includes skills, interests and declared contributions',()=>{
 assert.match(app,/me\.skills\|\|\[\]\)\.slice\(0,2\)/);
 assert.match(app,/me\.canOffer\|\|""/);
 assert.match(app,/me\.interests\|\|""/);
});
test('0.65 orbit core remains readable on desktop and mobile',()=>{
 assert.match(css,/\.identity-core\{width:276px;height:276px/);
 assert.match(css,/@media\(max-width:760px\)\{\.identity-core\{width:clamp\(190px/);
 assert.doesNotMatch(css,/@media\(max-width:760px\)\{[^}]*\.core-facts\{display:none/);
});
test('0.65 adds French labels for profile editing and member discovery',()=>{
 for(const phrase of ['Ajouter ou modifier la photo','Présentation professionnelle','Compétences','Proposer une mise en relation','Recherche dans le réseau…']) assert.ok(i18n.includes(phrase),`Missing French phrase: ${phrase}`);
});
test('release metadata is aligned at 1.9.0-alpha.20',()=>{
 assert.equal(pkg.version,'1.9.0-alpha.20');
 assert.equal(readFileSync(new URL('../VERSION',import.meta.url),'utf8').trim(),'1.9.0-alpha.20');
 assert.match(readFileSync(new URL('../src/server.js',import.meta.url),'utf8'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
