import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('0.78 covers the visible Human Orbit panels and member interaction states in native French', () => {
  const i18n = read('public/i18n.js');
  const required = [
    'YOUR CORE SIGNAL', 'VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'CAPABILITY FIELD', 'CHAMP DE COMPÉTENCES',
    'PROOF LAYER', 'RÉALISATIONS',
    'INTENT FIELD', 'ASPIRATIONS',
    'MEMBER NETWORK', 'RÉSEAU DE MEMBRES',
    'IMPACT SIGNAL', 'SIGNAL D’IMPACT',
    'Search members, skills or places', 'Rechercher des membres, des compétences ou des lieux',
    'Connection response saved.', 'Réponse à la demande enregistrée.',
    'Your connection field is empty.', 'Votre espace de relations est encore vide.'
  ];
  for (const phrase of required) assert.ok(i18n.includes(phrase), `Missing 0.78 French coverage: ${phrase}`);
  assert.equal((i18n.match(/translateElement\(document\.body\);/g) || []).length, 1, 'initial translation should run once');
});

test('0.78 release metadata is aligned', () => {
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('package.json'), /"version": "1\.9\.0-alpha\.20"/);
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
