import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('0.74 adds French translations for dynamically rendered admin and account states', () => {
  const i18n = read('public/i18n.js');
  for (const phrase of [
    'FILE DE MODÉRATION', 'FICHIER DE DONNÉES', 'Aucune demande de vérification d’entreprise.',
    'Aucun signalement en attente.', 'Aucune réalisation en attente d’examen.',
    'Aucun retour de testeur en attente.', 'Saisissez de 1 à 50 adresses e-mail, à raison d’une par ligne.',
    'La confirmation par e-mail n’est pas encore configurée sur ce service.',
    'Quel projet souhaitez-vous construire ?', 'Supprimer définitivement votre compte ZERILYS et les données opérationnelles associées ?'
  ]) assert.ok(i18n.includes(phrase), `Missing French translation: ${phrase}`);
});
test('0.74 release metadata is aligned', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
