import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();

test('0.75 adds consistent keyboard focus and reduced-motion support', () => {
  const css = readFileSync(join(root, 'public/styles.css'), 'utf8');
  assert.match(css, /:where\(button,a,input,select,textarea,\[role="button"\],\[tabindex\]\):focus-visible/);
  assert.match(css, /@media\s*\(prefers-reduced-motion:\s*reduce\)/);
  assert.match(css, /@media\s*\(pointer:\s*coarse\)/);
});

test('0.75 release metadata is aligned', () => {
  const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
  const version = readFileSync(join(root, 'VERSION'), 'utf8').trim();
  const server = readFileSync(join(root, 'src/server.js'), 'utf8');
  assert.equal(pkg.version, '1.9.0-alpha.20');
  assert.equal(version, '1.9.0-alpha.20');
  assert.match(server, /const VERSION = "1\.9\.0-alpha\.20";/);
});
