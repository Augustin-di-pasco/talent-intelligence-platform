import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
test('0.90 translates the full candidate identity and public profile experience',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['YOUR CORE SIGNAL','CAPABILITY FIELD','PROOF LAYER','TRAJECTORY','INTENT FIELD','MEMBER NETWORK','OPPORTUNITY CONSTELLATION','IMPACT SIGNAL','Share this identity','Block this member?','Profile photo updated.','Evidence submitted for independent review.']) assert.ok(i18n.includes(phrase),`missing source phrase: ${phrase}`);
 for(const phrase of ['VOTRE IDENTITÉ EN UN COUP D’ŒIL','UNIVERS DES COMPÉTENCES','RÉALISATIONS','PARCOURS','ASPIRATIONS','RÉSEAU DES MEMBRES','CONSTELLATION DES OPPORTUNITÉS','SIGNAL D’IMPACT','Partager ce profil','Bloquer ce membre ?','Photo de profil mise à jour.','Réalisation transmise pour examen indépendant.']) assert.ok(i18n.includes(phrase),`missing French translation: ${phrase}`);
});
test('0.90 keeps profile edits server-confirmed and refreshes every dependent view',()=>{
 const app=read('public/app.js');
 assert.match(app,/const d=await api\("\/me",\{method:"PATCH"/);
 assert.match(app,/if\(!d\?\.user\)throw new Error/);
 assert.match(app,/async function syncProfileSurfaces[\s\S]*?refreshMe\(\)[\s\S]*?renderEvidence\(\)[\s\S]*?renderIdentity\(\)[\s\S]*?loadReadiness\(\)[\s\S]*?loadOpportunityOrbit\(\)[\s\S]*?loadCandidateApplications\(\)[\s\S]*?loadNetwork\(\)[\s\S]*?loadProjects\(\)[\s\S]*?loadOffers\(\)/);
});
test('0.90 preserves explicit English selection and French-first default',()=>{
 const i18n=read('public/i18n.js');
 assert.match(i18n,/return "fr";/);
 assert.match(i18n,/const next = exact\(source\)/);
});
