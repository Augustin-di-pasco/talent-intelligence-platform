import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../public/styles.css',import.meta.url),'utf8');
test('candidate Human Orbit exposes the assessment library and submits reusable attempts',()=>{
 assert.match(html,/data-panel="assessment"/);assert.match(app,/api\("\/assessments\/catalog"\)/);assert.match(app,/\/me\/assessments\/\$\{slug\}\/attempt/);assert.match(app,/ZERIH ASSESS/);
});
test('employer can review and customize assessment recommendations for each offer',()=>{
 assert.match(app,/assessmentCatalogData\.assessments\.map/);assert.match(app,/data-offer-plan/);assert.match(app,/assessmentSlugs:selected/);assert.match(app,/Enregistrer le plan d’évaluation/);
});
test('candidate opportunity cards show two separate match dimensions',()=>{
 assert.match(app,/MATCH PARCOURS/);assert.match(app,/MATCH TECHNIQUE/);assert.match(app,/Deux indicateurs indépendants/);assert.match(css,/\.dual-match/);
});

test('candidate profile supports structured education and experience records',()=>{
 assert.match(html,/id="addExperience"/);assert.match(html,/id="addEducation"/);assert.match(app,/api\("\/me\/trajectory"/);assert.match(app,/renderTrajectory\(\)/);
});

test('platform scope includes engineering, finance, commerce, research and early-career opportunity details',()=>{
 assert.match(html,/value="internship">Stage/);
 assert.match(html,/value="apprenticeship">Alternance/);
 assert.match(html,/name="startDate"/);assert.match(html,/name="duration"/);assert.match(html,/name="compensation"/);
 const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
 assert.match(server,/EARLY_CAREER_OFFER_DETAILS_REQUIRED/);
 assert.match(server,/graduate_program/);assert.match(server,/research_project/);
});

test('candidate assessment space exposes individualized practical cases with human review',()=>{
 assert.match(app,/api\("\/assessments\/practical-cases"\)/);assert.match(app,/startPracticalCase/);assert.match(app,/Aucun score automatique n'a été attribué/);
 const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');assert.match(server,/assessment\.practical_submitted/);assert.match(server,/getPracticalCase\(p\.split/);
});
