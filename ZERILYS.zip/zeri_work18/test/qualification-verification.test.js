import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
test('qualification badge is exposed only from verified diploma/equivalence decisions',()=>{
 assert.match(server,/some\(x=>x\.status===\"verified\"\)/);
 assert.match(server,/qualificationBadge/);
 assert.match(server,/qualificationVerifications/);
});
test('qualification documents are private and reviewer-only with human reasoned decisions',()=>{
 assert.match(server,/REVIEWERS\.has\(u\.email\)/);
 assert.match(server,/qualification-documents/);
 assert.match(server,/QUALIFICATION_REVIEW_NOTE_REQUIRED/);
 assert.match(server,/qualification\.verification\.\$\{b\.status\}/);
 assert.match(server,/documentSha256/);
});
test('candidate UI requires a supporting document and does not claim AI verification',()=>{
 assert.match(html,/qualificationDocument/);
 assert.match(app,/documentDataUrl:reader\.result/);
 assert.match(app,/Le badge sera attribué après vérification/);
});
