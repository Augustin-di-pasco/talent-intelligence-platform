import test from 'node:test';
import assert from 'node:assert/strict';
import { reviewPracticalCase } from '../src/assessment-engine.js';

const attempt={evidenceType:'practical_case',status:'submitted_for_human_review',review:{rubric:[{criterion:'Méthode'},{criterion:'Communication'}]}};
const valid={criteria:[{criterion:'Méthode',score:3,comment:'Démarche structurée et hypothèses explicites.'},{criterion:'Communication',score:4,comment:'Synthèse claire et adaptée au décideur.'}],decision:'validated',summary:'Le candidat démontre une maîtrise cohérente des attendus.'};

test('human review accepts complete criterion-level evidence and stores reviewer attribution',()=>{
 const result=reviewPracticalCase(attempt,valid,'reviewer-1',new Date('2026-11-13T12:00:00Z'));
 assert.equal(result.status,'reviewed');assert.equal(result.review.reviewedBy,'reviewer-1');assert.equal(result.review.method,'human_review');assert.equal(result.review.criteria.length,2);
});
test('human review rejects missing criterion commentary',()=>{
 const body={...valid,criteria:[...valid.criteria,{criterion:'extra',score:4,comment:'Extra comment.'}]};
 assert.equal(reviewPracticalCase(attempt,body,'reviewer').error,'PRACTICAL_REVIEW_RUBRIC_REQUIRED');
});
test('human review rejects invalid score and short summary',()=>{
 const bad={...valid,criteria:[{criterion:'Méthode',score:5,comment:'Invalid score.'},valid.criteria[1]]};
 assert.equal(reviewPracticalCase(attempt,bad,'reviewer').error,'PRACTICAL_REVIEW_CRITERIA_INVALID');
 assert.equal(reviewPracticalCase(attempt,{...valid,summary:'Trop court'},'reviewer').error,'PRACTICAL_REVIEW_SUMMARY_REQUIRED');
});
test('human review prevents a second decision',()=>{
 assert.equal(reviewPracticalCase({...attempt,status:'reviewed'},valid,'reviewer').error,'PRACTICAL_ATTEMPT_ALREADY_REVIEWED');
});

test('blind review projection hides candidate identity and AI declaration', async()=>{
 const {blindPracticalReviewPayload}=await import('../src/assessment-engine.js');
 const source={...attempt,id:'attempt-12345678',evidenceType:'practical_case',status:'submitted_for_human_review',title:'Finance case',domain:'Finance',version:'1.0.0',variant:{clientDays:62},response:'Analyse anonymisée',completedAt:'2026-11-13T12:00:00.000Z',aiUseDeclaration:'used',candidateId:'candidate-secret',candidateName:'Alice Example',candidateHeadline:'Directrice financière'};
 const blind=blindPracticalReviewPayload(source);
 assert.equal(blind.blindReference,'DOSSIER-'+(await import('node:crypto')).default.createHash('sha256').update(source.id).digest('hex').slice(0,8).toUpperCase());
 for(const forbidden of ['candidateId','candidateName','candidateHeadline','aiUseDeclaration']) assert.equal(Object.hasOwn(blind,forbidden),false);
 assert.equal(blind.response,source.response);
 assert.equal(blindPracticalReviewPayload({...source,status:'reviewed'}),null);
});
