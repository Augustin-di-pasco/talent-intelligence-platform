import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('0.76 covers the static Human Orbit shell and profile editor in native French',()=>{
  const i18n=read('public/i18n.js');
  for(const source of [
    'Your professional universe.','IDENTITY CONFIGURATION','Shape your signal.',
    'Professional headline','Profile visibility','What can you bring?',
    'What are you looking for?','Interests and themes','Evidence of your work',
    'A CONNECTION WITH INTENT','Why should your paths cross?',
    'IDENTITY CONSOLE','PRIVATE TO YOU','SELECT A SIGNAL OR CAPABILITY TO EXPLORE'
  ]) assert.ok(i18n.includes(source),`missing source label: ${source}`);
  for(const translated of [
    'Votre univers professionnel.','CONFIGURATION DE L’IDENTITÉ','Donnez forme à votre identité.',
    'Intitulé professionnel','Visibilité du profil','Ce que vous pouvez apporter',
    'Ce que vous recherchez','Centres d’intérêt et thématiques','Réalisations et justificatifs',
    'UNE RENCONTRE QUI A DU SENS','Pourquoi vos chemins devraient-ils se croiser ?',
    'ESPACE IDENTITÉ','VISIBLE PAR VOUS SEUL','SÉLECTIONNEZ UN ÉLÉMENT POUR L’EXPLORER'
  ]) assert.ok(i18n.includes(translated),`missing French translation: ${translated}`);
});

test('0.76 release metadata is consistent',()=>{
  const pkg=JSON.parse(read('package.json'));
  assert.equal(pkg.version,'1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
  assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
