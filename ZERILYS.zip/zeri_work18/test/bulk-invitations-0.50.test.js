import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
test('bulk invitation API validates the complete cohort before writing any invitation',()=>{
  assert.ok(server.includes('p==="/api/review/invitations/bulk"'));
  assert.match(server,/rawEmails\.length>50/);
  assert.match(server,/DUPLICATE_EMAILS/);
  assert.match(server,/INVITATION_CONFLICTS/);
  assert.match(server,/tokenHash:crypto\.createHash\("sha256"\)/);
  assert.match(server,/beta\.invitation\.created/);
  assert.match(server,/i<created\.length;i\+=5/);
  assert.match(server,/delivery==="email"\?\{\}:\{invitationToken:raw\}/);
});
test('bulk invitation administration is not exposed in the public page',()=>{
  assert.doesNotMatch(html,/reviewBulkInviteForm|reviewInviteForm|reviewInvitationSummary|reviewConsole/);
  assert.ok(server.includes('p==="/api/review/invitations/bulk"'));
  assert.match(js,/copyBulkInviteTokens/);
});
