import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
test('public landing presents the broader qualified talent proposition',()=>{
  assert.match(html,/INGÉNIERIE · SCIENCES · FINANCE · COMMERCE · RECHERCHE/);
  assert.match(html,/Les compétences réelles/);
  assert.match(html,/Révélez vos compétences, trouvez un stage, une alternance/);
  assert.doesNotMatch(html,/The specialist network for finance, AI and data/);
  assert.match(html,/id="discover"/);
  assert.match(html,/id="opportunities"/);
  assert.match(html,/id="projects"/);
  assert.match(html,/id="global-pulse"/);
  assert.match(html,/data-talent-query="quantitative finance"/);
  assert.match(css,/main>section:not\(\.candidate-hero\)\{display:block!important\}/);
  assert.doesNotMatch(css,/main>section:not\(\.candidate-hero\)\{display:none!important\}/);
});
test('specialist quick filters call the existing live talent discovery endpoint',()=>{
  assert.match(html,/data-talent-query=/);
  assert.match(js,/document\.querySelectorAll\("\[data-talent-query\]"\)/);
  assert.match(js,/loadNetwork\(query\)/);
});
test('signed-in users have an explicit profile control wired to the identity modal',()=>{
  assert.match(html,/id="userMenu"/);
  assert.match(js,/profile-menu-label/);
  assert.match(js,/\$\("#userMenu"\)\.onclick=openProfile/);
  assert.match(js,/async function openProfile\(\)/);
});
