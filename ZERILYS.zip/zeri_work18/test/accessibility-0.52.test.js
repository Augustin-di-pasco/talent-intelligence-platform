import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
test('modal manager exposes dialog semantics, restores focus and traps keyboard navigation',()=>{
  assert.match(js,/modalFocusReturn/);
  assert.match(js,/setAttribute\("aria-hidden","false"\)/);
  assert.match(js,/setAttribute\("aria-modal","true"\)/);
  assert.match(js,/e\.key==="Tab"/);
  assert.match(js,/e\.key==="Escape"/);
  assert.match(js,/if\(open\.id==="legalConsentModal"\)return/);
});
test('orbit controls expose their selected state and photo status is announced',()=>{
  assert.match(js,/n\.setAttribute\("aria-pressed",String\(active\)\)/);
  assert.match(html,/id="avatarStatus" aria-live="polite" role="status"/);
  assert.match(html,/aria-label="Member professional identity"/);
});
test('keyboard focus is visible and motion-sensitive users receive reduced animation',()=>{
  assert.match(css,/:focus-visible/);
  assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);
});
