import test from "node:test";
import assert from "node:assert/strict";
import { hashPassword, verifyPassword, cleanText, emailValid } from "../src/security.js";
test("password hashes verify and do not expose the password",()=>{const h=hashPassword("a-very-strong-password");assert.notEqual(h.hash,"a-very-strong-password");assert.equal(verifyPassword("a-very-strong-password",h.salt,h.hash),true);assert.equal(verifyPassword("wrong",h.salt,h.hash),false)});
test("text cleaning bounds length and strips angle brackets",()=>{assert.equal(cleanText("<hello>",4),"hell");assert.equal(cleanText("abc",2),"ab")});
test("email validation accepts ordinary address and rejects malformed",()=>{assert.equal(emailValid("member@example.com"),true);assert.equal(emailValid("not-an-email"),false)});

import { complementarity } from "../src/matching.js";
test("complementarity explains mutual fit from intent and capabilities",()=>{const a={name:"A",skills:[{name:"Climate finance"}],lookingFor:"Product design",interests:"climate, education"};const b={name:"B",skills:[{name:"Product design"}],canOffer:"Product design",lookingFor:"Climate finance",interests:"climate, open source"};const m=complementarity(a,b);assert.ok(m.matchScore>0);assert.equal(m.matchReasons.length,3);assert.match(m.matchReasons.join(" "),/product design/i);});
test("complementarity does not invent a match without intent overlap",()=>{const m=complementarity({skills:[{name:"Cooking"}]},{skills:[{name:"Accounting"}]});assert.equal(m.matchScore,0);assert.equal(m.matchReasons.length,0);});

import fs from "node:fs";
test("candidate editor closes only its own modal and preserves Professional Universe context",()=>{const app=fs.readFileSync(new URL("../public/app.js",import.meta.url),"utf8");assert.match(app,/const owner=x\.closest\("\.modal"\)/);assert.match(app,/selectSignal\(editorReturnSignal\|\|activeSignal\|\|"overview"\)/);assert.doesNotMatch(app,/modal\("profileModal",false\);modal\("editModal",false\)/);});

test("company accounts are separated from candidate discovery and offer matching stays explainable", () => {
  const candidate = { skills: [{name:"JavaScript"}], lookingFor:"remote product role", interests:"accessibility" };
  const offer = { skills:["JavaScript","SQL"], description:"Build accessible products with a remote team" };
  const matched = offer.skills.filter(s => candidate.skills.some(x => x.name.toLowerCase() === s.toLowerCase()));
  assert.deepEqual(matched, ["JavaScript"]);
  assert.equal(matched.length > 0, true);
});

test("store migrates legacy accounts to candidate identities", async () => {
  const { Store } = await import("../src/store.js");
  const fs = await import("node:fs");
  const os = await import("node:os");
  const path = await import("node:path");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "zerihlink-migration-"));
  try {
    fs.writeFileSync(path.join(dir, "zerihlink.json"), JSON.stringify({users:[{id:"legacy-user",email:"legacy@example.test"}]}));
    const store = new Store(dir);
    assert.equal(store.state.users[0].accountType, "candidate");
    assert.equal(store.state.users[0].companyName, "");
  } finally { fs.rmSync(dir, {recursive:true,force:true}); }
});


test("store migrates embedded 0.35 profile photos to separate media files", async () => {
  const { Store } = await import("../src/store.js");
  const fs = await import("node:fs");
  const os = await import("node:os");
  const path = await import("node:path");
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "zerihlink-avatar-migration-"));
  try {
    const bytes=Buffer.alloc(140);bytes.set([0xff,0xd8,0xff,0xe0],0);
    fs.writeFileSync(path.join(dir,"zerihlink.json"),JSON.stringify({users:[{id:"legacy-avatar",email:"legacy-avatar@example.test",avatarDataUrl:`data:image/jpeg;base64,${bytes.toString("base64")}`}]}));
    const store=new Store(dir),user=store.state.users[0];
    assert.match(user.avatarFile,/^[a-f0-9-]{36}\.jpg$/);
    assert.equal(user.avatarDataUrl,undefined);
    assert.deepEqual(fs.readFileSync(path.join(dir,"avatars",user.avatarFile)),bytes);
  } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});
