import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const backup=fs.readFileSync(path.join(root,'scripts/backup.mjs'),'utf8');
const verify=fs.readFileSync(path.join(root,'scripts/verify-backup.mjs'),'utf8');
test('backups have bounded configurable retention and preserve verified backup pairs',()=>{
  assert.match(backup,/ZERIHLINK_BACKUP_RETENTION\|\|"14"/);
  assert.match(backup,/retention<2\|\|retention>100/);
  assert.match(backup,/const complete=candidates\.filter/);
  assert.match(backup,/keep=new Set\(complete\.slice\(0,retention\)\)/);
  assert.match(verify,/mediaBytes/);
});
