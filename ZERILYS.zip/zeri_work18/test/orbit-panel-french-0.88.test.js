import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const i18n=fs.readFileSync(path.join(root,'public/i18n.js'),'utf8');
const app=fs.readFileSync(path.join(root,'public/app.js'),'utf8');

test('0.88 translates the complete Human Orbit dynamic panel vocabulary into native French',()=>{
  for(const phrase of [
    'YOUR CORE SIGNAL','CAPABILITY FIELD','PROOF LAYER','TRAJECTORY','INTENT FIELD','MEMBER NETWORK','OPPORTUNITY CONSTELLATION','IMPACT SIGNAL',
    'Your identity at a glance.','What can you actually do?','Show the work behind the claim.','Where have you been — where next?',
    'What do you want to make possible?','Discover the people around your orbit.','What is orbiting your next move?',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.',
    'Your professional profile has been shared with this company for this opportunity.'
  ]) assert.ok(i18n.includes(JSON.stringify(phrase)),`Missing translation mapping: ${phrase}`);
});

test('0.88 retains dynamic translation observer and user-content escaping in orbit panels',()=>{
  assert.match(i18n,/new MutationObserver/);
  assert.match(app,/function selectSignal\(key\)/);
  assert.match(app,/esc\(me\.about/);
  assert.match(app,/esc\(s\.name\)/);
});

test('0.88 Human Orbit panel index is a consistent eight-part sequence',()=>{
  for(const index of ['01 / 08','02 / 08','03 / 08','04 / 08','05 / 08','06 / 08','07 / 08','08 / 08']) assert.ok(app.includes(index),`Missing Human Orbit index ${index}`);
});
