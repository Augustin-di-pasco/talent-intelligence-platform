import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { cleanupExpiredData } from '../src/data-retention.js';

const read = file => fs.readFileSync(path.resolve(file), 'utf8');
test('account export contains private assessment history and user-provided qualification files', () => {
  const source = read('src/server.js');
  assert.match(source, /privateAssessmentHistory:u\.assessments\|\|\[\]/);
  assert.match(source, /qualificationVerifications:/);
  assert.match(source, /qualificationDocuments:/);
  assert.match(source, /dataBase64:fs\.readFileSync\(file\)\.toString\("base64"\)/);
});

test('startup retention cleanup is conservative and documented', () => {
  const source = read('src/server.js');
  assert.match(source, /const retentionCleanup = cleanupExpiredData\(store\)/);
  assert.match(source, /if \(retentionCleanup\.changed\) await store\.save\(\)/);
  const policy = read('docs/DATA_RETENTION_ALPHA17.md');
  assert.match(policy, /ne sont pas purgés automatiquement/);
  assert.match(policy, /90 jours/);
});

test('retention cleanup is idempotent after expired invitation secrets are redacted', () => {
  const now = Date.now();
  const store = { state: { sessions: [], emailVerificationTokens: [], passwordResets: [], companyInvitations: [], betaInvitations: [{ id: 'old', status: 'pending', createdAt: new Date(now - 2 * 86400000).toISOString(), expiresAt: now - 1, tokenHash: 'secret' }] } };
  assert.equal(cleanupExpiredData(store, { now }).changed, true);
  assert.equal(cleanupExpiredData(store, { now }).changed, false);
});
