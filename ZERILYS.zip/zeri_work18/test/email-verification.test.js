import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("email verification uses hashed one-time tokens and sends only when transactional email is configured",()=>{
 const server=read("src/server.js"),store=read("src/store.js"),smoke=read("scripts/email-webhook-smoke.mjs");
 assert.match(server,/emailVerificationTokens\.push\(\{id:id\(\),userId:user\.id,tokenHash:crypto\.createHash\("sha256"\)/);
 assert.match(server,/expiresAt:now\+24\*60\*60\*1000/);
 assert.match(server,/if\(!config\.configured\)return \{enabled:false,sent:false/);
 assert.match(server,/api\/auth\/email-verification\/confirm/);
 assert.match(server,/api\/auth\/email-verification\/request/);
 assert.match(store,/emailVerificationTokens: \[\]/);
 assert.match(smoke,/replayVerification\.status,400/);
 assert.match(smoke,/emailVerification\.sent,false/);
});

test("email verification metadata remains private and account deletion removes pending tokens",()=>{
 const server=read("src/server.js"),app=read("public/app.js"),html=read("public/index.html");
 assert.match(server,/emailVerifiedAt,assessments,qualificationVerifications,\.\.\.profile/);
 assert.match(server,/emailVerified:!!u\.emailVerifiedAt/);
 assert.match(server,/emailVerificationTokens=store\.state\.emailVerificationTokens\.filter\(v=>v\.userId!==uid\)/);
 assert.match(app,/confirmEmailFromLink/);
 assert.match(app,/resendEmailVerification/);
 assert.match(html,/id="emailVerificationStatus"/);
});

test("release metadata and email verification launch behavior are documented",()=>{
 const pkg=JSON.parse(read("package.json")),server=read("src/server.js"),qa=read("docs/QA_0_62.md");
 assert.equal(pkg.version,"1.9.0-alpha.20");
 assert.match(server,/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(qa,/email verification/i);
 assert.match(qa,/does not block account creation/);
});
