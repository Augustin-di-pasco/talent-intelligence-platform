import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const script = path.resolve('scripts/import-json-to-postgres.mjs');

test('PostgreSQL importer refuses to run without DATABASE_URL', () => {
  const result = spawnSync(process.execPath, [script, '--apply'], { encoding: 'utf8', env: { ...process.env, DATABASE_URL: '' } });
  assert.equal(result.status, 1);
  assert.match(result.stderr, /DATABASE_URL est absent/);
});

test('PostgreSQL importer performs a dry preflight without --apply', () => {
  const result = spawnSync(process.execPath, [script], { encoding: 'utf8', env: { ...process.env, DATABASE_URL: 'postgres://invalid', ZERIHLINK_DATA_DIR: '/path/that/does/not/exist' } });
  assert.equal(result.status, 1); // missing source is detected before any connection
  assert.match(result.stderr, /fichier source introuvable/);
});

test('PostgreSQL schema has a migration ledger and import is transaction guarded', () => {
  const schema = fs.readFileSync(path.resolve('db/schema.postgresql.sql'), 'utf8');
  const importer = fs.readFileSync(script, 'utf8');
  assert.match(schema, /CREATE TABLE migration_import_log/);
  assert.match(importer, /await client\.query\('BEGIN'\)/);
  assert.match(importer, /await client\.query\('ROLLBACK'\)/);
  assert.match(importer, /ZERIHLINK_EXPECT_DATABASE/);
});
