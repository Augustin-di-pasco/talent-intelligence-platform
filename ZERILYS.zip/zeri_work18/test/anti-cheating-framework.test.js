import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const framework = readFileSync(new URL('../ANTI_CHEATING_FRAMEWORK.md', import.meta.url), 'utf8');

test('anti-cheating framework defines explicit AI assistance policies', () => {
  for (const policy of ['closed_book', 'ai_allowed', 'open_resources']) assert.ok(framework.includes(policy));
});

test('anti-cheating framework prevents automatic guilt and requires human review', () => {
  assert.match(framework, /Aucun signal isolé[\s\S]*?entraîner automatiquement une exclusion/);
  assert.match(framework, /décision défavorable par une personne compétente/);
  assert.match(framework, /possibilité de contestation/);
});

test('anti-cheating framework includes privacy and accessibility safeguards', () => {
  assert.match(framework, /Collecte minimale et proportionnée/);
  assert.match(framework, /alternatives accessibles/);
  assert.match(framework, /consentement explicite/);
});
