import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
test('public profiles have crawler-readable share pages with profile metadata',()=>{
  assert.match(server,/const shareMatch=pathname\.match\(\/\^\\\/p\\\/\(\[a-f0-9-\]\{36\}\)\$\/i\)/);
  assert.match(server,/property="og:title"/);
  assert.match(server,/property="og:description"/);
  assert.match(server,/property="og:image"/);
  assert.match(server,/name="twitter:card"/);
  assert.match(server,/x\.visibility==="public"/);
});
test('share links respect public and member-only profile visibility',()=>{
  assert.match(js,/function identityShareUrl\(user\)\{return user\?\.visibility==="public"\?/);
  assert.match(js,/\/p\/\$\{encodeURIComponent\(user\.id\)\}/);
  assert.match(js,/\?profile=\$\{encodeURIComponent\(user\?\.id\|\|""\)\}/);
  assert.match(js,/pendingProfileId=memberProfileId/);
  assert.match(js,/if\(pendingProfileId\)\{const target=pendingProfileId/);
});
