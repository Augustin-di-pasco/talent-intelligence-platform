import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

test('0.81 operator runbook covers every human launch gate and forbids treating local tests as production approval',()=>{
  const root=process.cwd();
  const runbook=fs.readFileSync(path.join(root,'docs/RECETTE_BETA_0_81.md'),'utf8');
  for(const phrase of ['npm run test:release','npm run launch:check','ZERIHLINK_BETA_LEGAL_APPROVED=false','sauvegarde hors site','restauration','tests humains','validation juridique','permanence de modération','ne vaut pas validation de production']) assert.ok(runbook.toLowerCase().includes(phrase.toLowerCase()),`Missing runbook requirement: ${phrase}`);
  const render=fs.readFileSync(path.join(root,'render.yaml'),'utf8');
  assert.match(render,/key: ZERIHLINK_BETA_LEGAL_APPROVED\s+value: "false"/);
});
