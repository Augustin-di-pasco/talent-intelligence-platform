import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const i18n = readFileSync(new URL('../public/i18n.js', import.meta.url), 'utf8');
const app = readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');

test('0.77 translates dynamically rendered network, collaboration and skill states into French', () => {
  const required = [
    "'My profile':'Mon profil'",
    "'The network is taking shape. Be among the first to create a profile.'",
    "'Searching the member network…':'Recherche dans le réseau…'",
    "'No matching profiles. Try another name, skill or location.'",
    "'Load next profiles ↓':'Afficher les profils suivants ↓'",
    "'Explore collaboration ↗':'Découvrir la collaboration ↗'",
    "'YOUR CAPABILITIES':'VOS COMPÉTENCES'",
    "'SELF-DESCRIBED CAPABILITY':'COMPÉTENCE DÉCLARÉE'",
    "'Link evidence ↗':'Associer une réalisation ↗'"
  ];
  for (const entry of required) assert.ok(i18n.includes(entry), `Missing French translation: ${entry}`);
  assert.ok(app.includes('loadOrbitNetwork'));
  assert.ok(app.includes('renderSkillConstellation'));
});

test('0.77 release metadata is aligned', () => {
  assert.match(readFileSync(new URL('../VERSION', import.meta.url), 'utf8'), /^1\.9\.0-alpha\.20\s*$/);
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "1\.9\.0-alpha\.20"/);
  assert.match(readFileSync(new URL('../src/server.js', import.meta.url), 'utf8'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
