import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(file)=>fs.readFileSync(new URL(`../${file}`,import.meta.url),'utf8');
const i18n=read('public/i18n.js');
const app=read('public/app.js');

test('0.89 public identity and evidence panels have French-first interface copy',()=>{
  for(const phrase of [
    'CAPABILITY SIGNAL','Independently verified','Self-described',
    'No evidence has been linked publicly to this capability yet.',
    'This identity is still taking shape. Its next signals will appear here.',
    'ZERILYS / LIVING IDENTITY','A professional identity is not a list. It is a field of capabilities, proof and possibilities.',
    'HUMAN SIGNAL','Join to connect ↗','Connect with intent','Share public profile','Member-only link shared.'
  ]) assert.ok(i18n.includes(phrase),`Missing public identity translation: ${phrase}`);
  assert.match(app,/async function openPublicIdentity/);
});

test('0.89 connection states, actions and feedback have French-first interface copy',()=>{
  for(const phrase of [
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.',
    'INCOMING SIGNAL','OUTGOING SIGNAL','Accept','Decline','Connected','Awaiting response',
    'Connection response saved.','Connections are temporarily unavailable.',
    'Your intentional connection request has been sent.','Member blocked.','Member unblocked.',
    'COMPANY UNIVERSE','VERIFIED COMPANY','NOT VERIFIED · OPPORTUNITIES HIDDEN',
    'Published opportunities','No published opportunities at the moment.','YOUR NETWORK',
    'Mark read','You are all caught up.','No published opportunities yet. Company opportunities will appear here when they are available.'
  ]) assert.ok(i18n.includes(phrase),`Missing network translation: ${phrase}`);
  assert.match(app,/async function loadConnections/);
});

test('0.89 keeps user-generated profile and evidence content escaped',()=>{
  assert.match(app,/esc\(sk\.name\)/);
  assert.match(app,/esc\(e\.title\)/);
  assert.match(app,/esc\(e\.description\|\|""\)/);
  assert.match(app,/esc\(u\.headline\|\|"Human potential in motion"\)/);
});

test('0.89 release metadata is aligned',()=>{
  assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
  assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
