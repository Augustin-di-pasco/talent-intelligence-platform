import test from 'node:test';
import assert from 'node:assert/strict';
import { assessmentCatalog, gradeAssessment } from '../src/assessment-engine.js';

test('catalog exposes questions and options but never answer keys',()=>{
 const catalog=assessmentCatalog(); assert.equal(catalog.length,9);
 for(const item of catalog){assert.equal(item.questionCount,3);assert.equal(item.format,'questionnaire_de_connaissances');assert.ok(item.audiences.includes('alternants'));for(const q of item.questions){assert.ok(q.options.length>=2);assert.equal('answer' in q,false)}}
});
test('grading validates answers and returns versioned platform evidence',()=>{
 const result=gradeAssessment('sql-foundations-v1',[{questionId:'q1',optionId:'b'},{questionId:'q2',optionId:'c'},{questionId:'q3',optionId:'a'}],new Date('2026-11-13T12:00:00Z'));
 assert.equal(result.score,100);assert.equal(result.status,'completed');assert.equal(result.version,'1.0.0');assert.equal(result.evidenceType,'platform_assessment');
});
test('grading rejects missing, duplicate and unknown answers',()=>{
 assert.equal(gradeAssessment('sql-foundations-v1',[]).error,'ANSWERS_INCOMPLETE');
 assert.equal(gradeAssessment('sql-foundations-v1',[{questionId:'q1',optionId:'b'},{questionId:'q1',optionId:'b'},{questionId:'q3',optionId:'a'}]).error,'ANSWERS_INVALID');
 assert.equal(gradeAssessment('not-real',[]).error,'ASSESSMENT_NOT_FOUND');
});

test('role skills generate an editable assessment recommendation set',async()=>{
 const {recommendAssessments}=await import('../src/assessment-engine.js');
 assert.deepEqual(recommendAssessments(['Python','SQL']).map(x=>x.slug),['sql-foundations-v1','python-data-v1']);
});

test('assessment evidence preserves candidate reasoning and transparent AI-use disclosure without scoring prose',()=>{
 const result=gradeAssessment('sql-foundations-v1',[{questionId:'q1',optionId:'b'},{questionId:'q2',optionId:'c'},{questionId:'q3',optionId:'a'}],new Date('2026-11-13T12:00:00Z'),{rationale:'Je filtre les lignes avant le regroupement, puis je conserve les lignes de gauche avec LEFT JOIN.',aiUseDeclaration:'used'});
 assert.equal(result.score,100);assert.equal(result.reasoningEvidence.scored,false);assert.equal(result.reasoningEvidence.evaluation,'human_review_required');assert.match(result.reasoningEvidence.text,/LEFT JOIN/);assert.equal(result.aiUseDeclaration,'used');
});

test('practical cases are individualized, versioned and never automatically scored',async()=>{
 const {practicalCaseCatalog,getPracticalCase,submitPracticalCase}=await import('../src/assessment-engine.js');
 const catalog=practicalCaseCatalog();assert.equal(catalog.length,6);assert.equal(catalog.filter(x=>x.submissionMode==='written').length,4);assert.equal(catalog.filter(x=>x.submissionMode==='code').length,2);
 const a=getPracticalCase('finance-cashflow-case','candidate-a'),b=getPracticalCase('finance-cashflow-case','candidate-b');
 assert.equal(a.version,'1.0.0');assert.equal(a.scoring,'human_review_only');assert.notDeepEqual(a.variant,b.variant);
 const result=submitPracticalCase('finance-cashflow-case','candidate-a',{response:'Diagnostic détaillé. '.repeat(10),aiUseDeclaration:'used'},new Date('2026-11-13T12:00:00Z'));
 assert.equal(result.status,'submitted_for_human_review');assert.equal(result.score,null);assert.equal(result.review.scored,false);assert.equal(result.aiUseDeclaration,'used');
 assert.equal(submitPracticalCase('finance-cashflow-case','candidate-a',{response:'trop court',aiUseDeclaration:'not_used'}).error,'PRACTICAL_RESPONSE_TOO_SHORT');
 assert.equal(submitPracticalCase('finance-cashflow-case','candidate-a',{response:'Une réponse suffisamment longue '.repeat(5),aiUseDeclaration:'unknown'}).error,'AI_DISCLOSURE_REQUIRED');
});
