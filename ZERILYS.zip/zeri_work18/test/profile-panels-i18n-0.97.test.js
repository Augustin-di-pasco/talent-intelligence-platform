import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('0.97 translates all static Human Orbit panel copy at render time', () => {
  const app = read('public/app.js');
  const start = app.indexOf('function selectSignal(key)');
  const end = app.indexOf('\nfunction openEditor', start);
  assert.ok(start >= 0 && end > start, 'Human Orbit renderer is present');
  const panel = app.slice(start, end);
  for (const source of [
    'Your identity at a glance.',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.'
  ]) {
    const translated = panel.includes(`tr("${source}")`) || panel.includes(`tr('${source}')`) || panel.includes(`\${tr('${source}')}`);
    assert.ok(translated, `Panel copy is translated at render time: ${source}`);
  }
  assert.match(panel, /tr\(x\[2\]\)/);
  assert.match(panel, /tr\(x\[3\]\)/);
});

test('0.97 translates editor section headings without translating member-authored content', () => {
  const app = read('public/app.js');
  assert.match(app, /textContent=tr\(titles\[section\]\|\|titles\.identity\)/);
  assert.match(app, /esc\(me\.about\|\|/);
  assert.match(app, /esc\(me\.canOffer\|\|/);
  assert.match(app, /esc\(me\.lookingFor\|\|/);
});

test('0.97 release metadata is aligned', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
