import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const css = await readFile(new URL('../public/styles.css', import.meta.url), 'utf8');

test('homepage lower sections use compact spacing and restrained heading sizes', () => {
  assert.match(css, /1\.9\.0-alpha\.16 — compact, denser public discovery experience/);
  assert.match(css, /main>#discover[\s\S]*?padding-top:48px!important/);
  assert.match(css, /font-size:clamp\(30px,3\.1vw,42px\)!important/);
  assert.match(css, /main>#global-pulse \.pulse-grid article\{min-height:140px\}/);
  assert.match(css, /@media\(max-width:760px\)/);
});
