import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.71 translates the public member identity and connection journey into French',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['IDENTITÉ VIVANTE','SIGNAL DE COMPÉTENCE','Vérifiée indépendamment','Une identité professionnelle ne se résume pas à une liste.','Rejoindre pour échanger ↗','Demande de mise en relation','Envoyer la demande','Lieu non communiqué','Entrer en relation']) assert.ok(i18n.includes(phrase),`Missing French translation: ${phrase}`);
});
test('0.71 public profile keeps evidence and connection actions wired to the profile view',()=>{
 const app=read('public/app.js');
 assert.match(app,/async function openPublicIdentity/);
 assert.match(app,/data-public-skill/);
 assert.match(app,/connectPublic/);
 assert.match(app,/joinPublic/);
});
test('0.71 runtime metadata is aligned',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
