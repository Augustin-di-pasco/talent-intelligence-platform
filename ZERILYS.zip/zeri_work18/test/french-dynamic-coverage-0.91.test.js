import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
test('0.94 covers the visible Human Orbit, discovery, connection and company copy in French', () => {
  const source = read('public/i18n.js');
  const pairs = [
    ['Building their next chapter', 'Prépare la suite de son parcours'],
    ['The network is taking shape. Be among the first to create a profile.', 'Le réseau se construit. Soyez parmi les premiers à créer votre profil.'],
    ['Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.', 'Votre univers de compétences est vide.'],
    ['Search members, skills or places', 'Rechercher des membres, des compétences ou des lieux'],
    ['No opportunity signals are orbiting your identity yet.', 'Aucune opportunité ne gravite encore autour de votre profil.'],
    ['Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.', 'Votre réseau est encore vide.'],
    ['COMPANY UNIVERSE', 'UNIVERS DE L’ENTREPRISE'],
    ['Published opportunities', 'Opportunités publiées'],
    ['Open my candidate profile', 'Ouvrir mon profil']
  ];
  for (const [english, french] of pairs) {
    assert.ok(source.includes(english), `source copy missing: ${english}`);
    assert.ok(source.includes(french), `French copy missing: ${french}`);
  }
});
test('0.94 retains French-first selection, explicit English and safe text-node translation', () => {
  const source = read('public/i18n.js');
  assert.match(source, /return "fr";/);
  assert.match(source, /const next = exact\(source\)/);
  assert.match(source, /document\.createTreeWalker\(root, NodeFilter\.SHOW_TEXT\)/);
  assert.match(source, /const originalText = new WeakMap\(\)/);
});
test('0.94 release metadata and launch legal lock remain aligned', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
  assert.match(read('src/server.js'), /BETA_LEGAL_APPROVED/);
  assert.match(read('scripts/launch-report-fr.mjs'), /legal/i);
});
