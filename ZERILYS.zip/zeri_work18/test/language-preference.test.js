import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("language preference is saved to the member account and restored on another device",()=>{
 const app=read("public/app.js"),server=read("src/server.js"),store=read("src/store.js"),script=read("scripts/language-preference-smoke.mjs"),pkg=JSON.parse(read("package.json"));
 assert.match(app,/api\("\/me\/preferences"/);
 assert.match(app,/me\.preferredLanguage/);
 assert.match(app,/setLanguage\(me\.preferredLanguage,true,false\)/);
 assert.match(server,/PATCH.*\/api\/me\/preferences/);
 assert.match(server,/!\["fr","en"\]\.includes\(language\)/);
 assert.match(server,/preferredLanguage:u\.preferredLanguage\|\|null/);
 assert.match(server,/preferredLanguage,emailVerifiedAt,assessments,qualificationVerifications,\.\.\.profile/);
 assert.match(store,/user\.preferredLanguage \?\?= null/);
 assert.match(script,/server restart/);
 assert.match(read("public/i18n.js"),/function setLanguage\(next, persist = true, manual = persist\)/);
 assert.match(pkg.scripts["test:release"],/smoke:language-preference/);
});

test("language preference is excluded from public member profiles",()=>{
 const server=read("src/server.js");
 assert.match(server,/const \{legalConsent,companyVerification,preferredLanguage,emailVerifiedAt,assessments,qualificationVerifications,\.\.\.profile\}=store\.publicUser\(u\)/);
 assert.match(server,/preferences:\{preferredLanguage:u\.preferredLanguage\|\|null\}/);
});


test("language switch offers a compact UK flag and translates both French and English copy",()=>{
 const html=read("public/index.html"),i18n=read("public/i18n.js"),css=read("public/styles.css");
 assert.match(html,/id="languageToggle"/);
 assert.match(html,/🇬🇧/);
 assert.match(i18n,/Object\.assign\(en, Object\.fromEntries/);
 assert.match(i18n,/getElementById\("languageToggle"\)/);
 assert.match(i18n,/const next = exact\(source\)/);
 assert.match(i18n,/Find the right people/);
 assert.match(i18n,/INGÉNIERIE · SCIENCES · FINANCE · COMMERCE · RECHERCHE/);
 assert.match(i18n,/"VOTRE PROFIL": "YOUR PROFILE"/);
 assert.match(i18n,/Already a member\? Connexion.*Already a member\? Log in/s);
 assert.match(i18n,/Verified qualifications/);
 assert.match(css,/\.language-toggle/);
});
