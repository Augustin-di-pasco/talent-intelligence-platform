import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const script=fs.readFileSync(path.join(root,'scripts/cohort-50-smoke.mjs'),'utf8');
test('beta cohort validation creates 50 members and verifies access to all 49 other profiles',()=>{
  assert.match(script,/length:50/);
  assert.match(script,/pageOne\.total,49/);
  assert.match(script,/allIds\.length,49/);
  assert.match(script,/profileResults\.length,49/);
  assert.match(script,/pages,3/);
});
test('cohort validation checks member-only photo delivery and separate media storage',()=>{
  assert.match(script,/members\.slice\(0,10\)/);
  assert.match(script,/memberMedia\.status,200/);
  assert.match(script,/anonymousMedia\.status,404/);
  assert.match(script,/mediaFiles\.length,10/);
});
