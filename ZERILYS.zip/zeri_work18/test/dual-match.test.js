import test from 'node:test';
import assert from 'node:assert/strict';
import {matchParcours,matchTechnique,matchOpportunity} from '../src/dual-match.js';

test('parcours evaluates declared skills and relevant background without hard years gate',()=>{
 const result=matchParcours({skills:[{name:'Python'},{name:'SQL'}],experiences:[{title:'Data analyst',description:'Analyse de données'}],education:[{title:'Master data science'}]}, {skills:['Python','SQL','Machine learning'],experienceKeywords:['data analyst']});
 assert.equal(result.score,Math.round((2/3*.45*100+100*.25)/(0.45+0.25)));
 assert.equal(result.status,'indicatif');
});

test('missing parcours information is unknown, not zero',()=>assert.equal(matchParcours({},{}).score,null));

test('technical score only uses completed assessments and validated missions',()=>{
 const result=matchTechnique({assessments:[{skill:'Python',score:90,status:'completed',completedAt:'2026-11-01'}],missions:[{skills:['SQL'],score:80,status:'validated',completedAt:'2026-11-01'}]}, {skills:['Python','SQL','Risk']},{now:'2026-11-13'});
 assert.equal(result.coverage,67); assert.equal(result.status,'partiel'); assert.equal(result.skills[2].score,null);
});

test('technical missing evidence is not zero',()=>assert.equal(matchTechnique({}, {skills:['Python']},{now:'2026-11-13'}).score,null));

test('opportunity match keeps two independent scores and no blended score',()=>{
 const result=matchOpportunity({skills:['Python'],assessments:[{skill:'Python',score:95,status:'completed'}]}, {skills:['Python']},{now:'2026-11-13'});
 assert.equal(result.combinedScore,null); assert.equal(result.parcours.score,100); assert.equal(result.technique.score,95); assert.equal(result.decision,'human_review_required');
});

test('platform assessments with multiple skills contribute to technical match',()=>{
 const result=matchTechnique({assessments:[{skills:['Python','Data analysis'],score:90,status:'completed',completedAt:'2026-11-12'}]}, {skills:['Python','Data analysis']},{now:'2026-11-13'});
 assert.equal(result.score,90);assert.equal(result.coverage,100);
});

test('parcours considers structured education and experience evidence',()=>{
 const result=matchParcours({skills:[],experiences:[{title:'Risk Analyst',company:'Bank',description:'Market risk modelling'}],education:[{title:'Master Finance',institution:'University',field:'Quantitative finance'}]}, {experienceKeywords:['risk analyst'],educationKeywords:['quantitative finance']});
 assert.equal(result.score,100);assert.equal(result.status,'indicatif');
});

test('study level is contextual and never an automatic exclusion gate',()=>{
 const result=matchOpportunity({education:[{level:'Bac+5',title:'Master ingénierie'}],skills:[{name:'Python'}]}, {skills:['Python'],targetStudyLevels:['Bac+5']});
 assert.ok(result.parcours.dimensions.some(x=>x.key==='study_level'&&x.score===100));
 assert.equal(result.combinedScore,null);
});
