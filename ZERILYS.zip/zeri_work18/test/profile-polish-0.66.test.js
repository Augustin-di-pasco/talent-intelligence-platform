import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.66 provides French labels for the complete profile editor surface',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['PERSONNALISATION DU PROFIL','Présentation professionnelle','À l’écoute d’opportunités','Ce que vous pouvez apporter','Ce que vous recherchez','Associer une réalisation']) assert.ok(i18n.includes(phrase),`Missing French translation: ${phrase}`);
});
test('0.66 enlarges the Human Orbit identity anchor and preserves mobile profile facts',()=>{
 const css=read('public/styles.css');
 assert.match(css,/0\.66 — Human Orbit/);
 assert.match(css,/\.identity-core\{width:clamp\(292px,27vw,336px\)/);
 assert.match(css,/\.core-facts\{display:flex;max-width:190px/);
});
test('0.66 keeps server-side legal registration lock and local-only test mode',()=>{
 const server=read('src/server.js');
 assert.match(server,/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(server,/process\.env\.NODE_ENV !== "production" && process\.env\.ZERIHLINK_LOCAL_BETA_TEST_MODE === "true"/);
 assert.match(server,/BETA_LEGAL_APPROVED/);
});
test('Windows launcher enables only the local beta test switch for a local run',()=>{
 const bat=read('START_ZERILYS.bat');
 assert.match(bat,/set ZERIHLINK_LOCAL_BETA_TEST_MODE=true/);
 const server=read('src/server.js');
 assert.match(server,/process\.env\.NODE_ENV !== "production"/);
});
