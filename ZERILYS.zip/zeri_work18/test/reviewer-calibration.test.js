import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const guide=fs.readFileSync(new URL('../public/reviewer-calibration.html',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../public/index.html',import.meta.url),'utf8');
test('reviewer calibration guide covers all four practical cases and sixteen criteria',()=>{
 for(const label of ['Finance — diagnostic de trésorerie','Commerce — lancement sur un nouveau marché','Recherche — critique d\'un protocole','Ingénierie — analyse d\'une défaillance'])assert.ok(guide.includes(label));
 for(const criterion of ['Diagnostic','Méthode','Priorisation','Communication','Segmentation','Validation','Mesure','Décision','Validité','Analyse','Transparence','Reproductibilité','Sécurité','Prévention'])assert.ok(guide.includes(criterion));
});
test('calibration guide explains score anchors, blind-review conduct and its validation limits',()=>{
 for(const phrase of ['1 — Insuffisant','2 — À renforcer','3 — Maîtrisé','4 — Très bien maîtrisé','Ne pas chercher à identifier','pas été validé par une étude psychométrique'])assert.ok(guide.includes(phrase));
});
test('reviewer calibration guide is not linked from the public landing page',()=>assert.doesNotMatch(html,/reviewer-calibration\.html|reviewConsole/));
