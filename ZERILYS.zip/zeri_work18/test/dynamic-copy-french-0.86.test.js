import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(file)=>fs.readFileSync(new URL(`../${file}`,import.meta.url),'utf8');

test('0.86 translates high-traffic dynamic network and account copy into native French',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['The network is taking shape. Be among the first to create a profile.','Location not shared','evidence item','Connect with intent','No open collaborations yet. Be the first to start one.','Create your identity','Registration is paused until the beta legal review is complete.','Your collaboration is live.']) assert.ok(i18n.includes(phrase),`missing source phrase: ${phrase}`);
 for(const phrase of ['Le réseau se construit. Soyez parmi les premiers à créer votre profil.','Localisation non communiquée','réalisation associée','Proposer une mise en relation','Aucune collaboration ouverte pour le moment.','Créer mon profil','Les inscriptions sont suspendues dans l’attente de la validation juridique de la bêta.','Votre collaboration est publiée.']) assert.ok(i18n.includes(phrase),`missing French translation: ${phrase}`);
 assert.ok(i18n.includes('language === "fr" ? fr[trimmed] : en[trimmed]'),'translations remain conditional on French selection');
});

test('0.86 release metadata is aligned',()=>{
 assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.ok(read('src/server.js').includes('const VERSION = "1.9.0-alpha.20"'));
});
