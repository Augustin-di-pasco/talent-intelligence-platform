import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("open registration has a per-client rate limit",()=>{
 const server=read("src/server.js"),smoke=read("scripts/signup-rate-limit-smoke.mjs"),pkg=JSON.parse(read("package.json"));
 assert.match(server,/key\.includes\("\/auth\/"\).*\? 8 : 120/);
 assert.match(server,/if \(bucket\.count > /);
 assert.match(smoke,/i<20/);
 assert.match(smoke,/blocked\.status,429/);
 assert.match(pkg.scripts["test:release"],/smoke:signup-rate-limit/);
});

test("the open signup throttle is scoped to the client address and registration endpoint",()=>{
 const server=read("src/server.js");
 assert.match(server,/const key = `\$\{clientAddress\(req\)\}:\$\{req\.method\}:\$\{new URL\(req\.url,"http:\/\/localhost"\)\.pathname\}`/);
 assert.match(server,/ZERIHLINK_TRUST_PROXY==="true"/);
});
