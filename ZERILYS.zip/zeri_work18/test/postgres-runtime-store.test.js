import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Store } from '../src/store.js';

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zerihlink-store-'));
  const store = new Store(dir);
  return { dir, store, cleanup: () => fs.rmSync(dir, { recursive: true, force: true }) };
}

test('PostgreSQL-backed save awaits the database write and advances revision', async () => {
  const { store, cleanup } = fixture();
  const writes = [];
  store.revision = 1;
  store.pool = { query: async (sql, params) => { writes.push({ sql, state: JSON.parse(params[0]), expectedRevision: params[1] }); return { rowCount: 1, rows: [{ revision: writes.length + 1 }] }; } };
  store.state.users.push({ id: 'u-1', email: 'candidate@example.test' });
  await store.save();
  assert.equal(writes.length, 1);
  assert.equal(writes[0].state.users[0].id, 'u-1');
  assert.equal(writes[0].expectedRevision, 1);
  assert.match(writes[0].sql, /AND revision=\$2/);
  assert.equal(store.revision, 2);
  assert.equal(JSON.parse(fs.readFileSync(store.file, 'utf8')).users.length, 1);
  cleanup();
});

test('PostgreSQL-backed save fails closed when the runtime snapshot row is missing', async () => {
  const { store, cleanup } = fixture();
  store.pool = { query: async () => ({ rowCount: 0, rows: [] }) };
  await assert.rejects(store.save(), /revision changed/);
  cleanup();
});

test('PostgreSQL save queue preserves write order', async () => {
  const { store, cleanup } = fixture();
  const revisions = [];
  store.revision = 1;
  store.pool = { query: async (_sql, params) => { revisions.push({ count: JSON.parse(params[0]).users.length, expected: params[1] }); return { rowCount: 1, rows: [{ revision: revisions.length + 1 }] }; } };
  store.state.users.push({ id: 'u-1' });
  const first = store.save();
  store.state.users.push({ id: 'u-2' });
  const second = store.save();
  await Promise.all([first, second]);
  assert.deepEqual(revisions, [{ count: 1, expected: 1 }, { count: 2, expected: 2 }]);
  cleanup();
});

test('preflight accurately labels the PostgreSQL adapter as an opt-in snapshot runtime', async () => {
  const source = fs.readFileSync(path.resolve('scripts/preflight-beta.mjs'), 'utf8');
  assert.match(source, /ZERIHLINK_STORAGE===\"postgres\"&&!!process\.env\.DATABASE_URL/);
  assert.match(source, /not yet a normalized relational repository/);
});


test('PostgreSQL save queue can recover after a transient database error', async () => {
  const { store, cleanup } = fixture();
  let attempts = 0;
  store.revision = 1;
  store.pool = { query: async (_sql, params) => { attempts++; if (attempts === 1) throw new Error('temporary database outage'); assert.equal(params[1], 1); return { rowCount: 1, rows: [{ revision: 2 }] }; } };
  await assert.rejects(store.save(), /temporary database outage/);
  await store.save();
  assert.equal(attempts, 2);
  cleanup();
});

test('PostgreSQL compare-and-swap refuses to overwrite a snapshot written by another instance', async () => {
  const { store, cleanup } = fixture();
  store.revision = 4;
  let persisted = JSON.stringify({ users: [{ id: 'newer-instance' }] });
  store.pool = { query: async (_sql, params) => { assert.equal(params[1], 4); return { rowCount: 0, rows: [] }; } };
  store.state.users.push({ id: 'stale-instance' });
  await assert.rejects(store.save(), /refusing to overwrite a newer snapshot/);
  assert.equal(JSON.parse(persisted).users[0].id, 'newer-instance');
  assert.equal(store.revision, 4);
  cleanup();
});
