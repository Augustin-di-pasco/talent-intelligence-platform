import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('the central Human Orbit portrait opens the photo picker directly',()=>{
  const profileModal=html.slice(html.indexOf('id="profileModal"'),html.indexOf('id="editModal"'));
  assert.match(profileModal,/id="avatarFile" type="file"/);
  assert.match(profileModal,/id="identityInitials"[^>]*aria-label="Add or change your profile photo"/);
  assert.match(js,/\$\("#identityInitials"\)\.onclick=\(\)=>\$\("#avatarFile"\)\.click\(\)/);
});
test('members without a portrait receive a restrained add-photo cue',()=>{
  assert.match(js,/classList\.toggle\("photo-missing",!me\.avatarUrl\)/);
  assert.match(css,/\.core-avatar\.photo-missing::after\{content:"ADD PHOTO"/);
  assert.match(css,/\.core-avatar:not\(\.photo-missing\):hover::after\{content:"CHANGE"/);
});
