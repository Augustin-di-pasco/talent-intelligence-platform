import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.70 translates the full identity editor and dynamically rendered orbit panels into native French',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['Façonnez votre identité professionnelle.','Intitulé professionnel','Visibilité du profil','À propos de votre activité','Réalisations et preuves de votre travail','VOTRE IDENTITÉ EN UN COUP D’ŒIL','RÉSEAU DES MEMBRES','CONSTELLATION DES OPPORTUNITÉS','Mode concentration','Données et confidentialité']) assert.ok(i18n.includes(phrase),`Missing French translation: ${phrase}`);
});
test('0.70 keeps the identity core readable on narrow phones without global orbit shrinking',()=>{
 const css=read('public/styles.css');
 assert.match(css,/0\.70 — mobile-first identity clarity/);
 assert.match(css,/\.identity-universe\{transform:none;height:auto;min-height:540px/);
 assert.match(css,/\.identity-core\{width:clamp\(238px,68vw,276px\)/);
});
test('0.70 aligns runtime release metadata',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
