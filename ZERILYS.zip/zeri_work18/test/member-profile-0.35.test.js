import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
const js=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
test('members can add, replace and remove a real profile portrait',()=>{
  assert.match(html,/id="avatarFile" type="file" accept="image\/jpeg,image\/png,image\/webp"/);
  assert.match(html,/id="avatarChoose"/);
  assert.match(html,/id="avatarRemove"/);
  assert.match(js,/api\("\/me\/avatar",\{method:"POST"/);
  assert.match(js,/api\("\/me\/avatar",\{method:"DELETE"/);
  assert.match(server,/AVATAR_CONTENT_MISMATCH/);
  assert.match(server,/api\/media\/avatars/);
  assert.match(server,/AVATAR_SIZE_LIMIT/);
});
test('real portraits render in personal and other member profile surfaces',()=>{
  assert.match(js,/identityInitials.*avatarUrl/);
  assert.match(js,/person-avatar has-photo/);
  assert.match(js,/public-avatar has-photo/);
  assert.match(css,/\.core-avatar img/);
});
test('every signed-in member can discover and open private candidate profiles',()=>{
  assert.match(server,/u \? \(x\.id!==u\.id && !blockedIds\.has\(x\.id\)\) : x\.visibility==="public"/);
  assert.ok(server.includes("viewer=currentUser(req)"));
  assert.ok(server.includes("x.visibility===\"public\" || !!viewer"));
  assert.match(server,/const \{legalConsent,companyVerification,preferredLanguage,emailVerifiedAt,assessments,qualificationVerifications,\.\.\.profile\}=store\.publicUser\(u\)/);
});
