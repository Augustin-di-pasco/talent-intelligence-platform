import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanupExpiredData } from '../src/data-retention.js';

const day = 86400000;
test('retention cleanup removes expired authentication material and preserves live sessions', () => {
  const now = Date.now();
  const store = { state: {
    sessions: [{ id: 'old', expiresAt: now - 1 }, { id: 'live', expiresAt: now + day }],
    emailVerificationTokens: [{ id: 'expired', expiresAt: now - 1 }, { id: 'valid', expiresAt: now + day }],
    passwordResets: [{ id: 'expired', expiresAt: now - 1 }],
    companyInvitations: [], betaInvitations: [],
    users: [{ id: 'u', assessments: [{ id: 'assessment' }] }],
    audit: [{ id: 'audit' }], evidence: [{ id: 'evidence' }]
  } };
  const result = cleanupExpiredData(store, { now });
  assert.deepEqual(store.state.sessions.map(x => x.id), ['live']);
  assert.deepEqual(store.state.emailVerificationTokens.map(x => x.id), ['valid']);
  assert.equal(store.state.passwordResets.length, 0);
  assert.equal(result.removed.sessions, 1);
  assert.equal(store.state.users[0].assessments.length, 1);
  assert.equal(store.state.audit.length, 1);
  assert.equal(store.state.evidence.length, 1);
});

test('retention cleanup redacts expired invitation secrets and removes old invitation metadata', () => {
  const now = Date.now();
  const store = { state: {
    sessions: [], emailVerificationTokens: [], passwordResets: [],
    companyInvitations: [
      { id: 'expired-recent', status: 'pending', createdAt: new Date(now - day).toISOString(), expiresAt: now - 1, tokenHash: 'secret' },
      { id: 'old-expired', status: 'pending', createdAt: new Date(now - 100 * day).toISOString(), expiresAt: now - day, tokenHash: 'secret' }
    ],
    betaInvitations: [{ id: 'accepted', status: 'accepted', createdAt: new Date(now - day).toISOString(), expiresAt: now + day, tokenHash: 'secret' }]
  } };
  const result = cleanupExpiredData(store, { now });
  assert.equal(store.state.companyInvitations.length, 1);
  assert.equal(store.state.companyInvitations[0].id, 'expired-recent');
  assert.equal('tokenHash' in store.state.companyInvitations[0], false);
  assert.equal(store.state.betaInvitations.length, 1);
  assert.equal('tokenHash' in store.state.betaInvitations[0], false);
  assert.equal(result.removed.companyInvitations, 1);
});
