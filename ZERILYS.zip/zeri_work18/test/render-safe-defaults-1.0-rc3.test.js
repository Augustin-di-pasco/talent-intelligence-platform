import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const blueprint = fs.readFileSync(new URL('../render.yaml', import.meta.url), 'utf8');
const guide = fs.readFileSync(new URL('../GO_LIVE_50_TESTERS.md', import.meta.url), 'utf8');
const readme = fs.readFileSync(new URL('../README.md', import.meta.url), 'utf8');

test('Render Blueprint keeps self-service registration disabled by default', () => {
  assert.match(blueprint, /key: ZERIHLINK_ALLOW_SIGNUP\s+value: "false"/);
});

test('Render Blueprint keeps legal approval disabled independently', () => {
  assert.match(blueprint, /key: ZERIHLINK_BETA_LEGAL_APPROVED\s+value: "false"/);
});

test('Render Blueprint persists application data and exposes health check', () => {
  assert.match(blueprint, /healthCheckPath: \/api\/health/);
  assert.match(blueprint, /mountPath: \/opt\/render\/project\/src\/data/);
  assert.match(blueprint, /key: ZERIHLINK_DATA_DIR\s+value: \/opt\/render\/project\/src\/data/);
});

test('deployment guide requires cost review and keeps registration closed', () => {
  assert.match(guide, /vérifier le coût du service et du disque/i);
  assert.match(guide, /garder les inscriptions fermées/i);
  assert.match(readme, /ZERIHLINK_ALLOW_SIGNUP=false/);
});
