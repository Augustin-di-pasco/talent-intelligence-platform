import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.67 adds French coverage for dynamically rendered member profile and orbit panels',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['Créer mon profil','Mon profil','RÉSEAU DES MEMBRES','CHAMP DES COMPÉTENCES','CONSTELLATION DES OPPORTUNITÉS','Votre profil en quelques étapes','Aucune réalisation pour le moment']) assert.ok(i18n.includes(phrase),`Missing French translation: ${phrase}`);
});
test('0.67 preserves server-confirmed profile save and refreshes all dependent profile views',()=>{
 const app=read('public/app.js');
 assert.match(app,/if\(!d\?\.user\)throw new Error/);
 assert.match(app,/me=\{\.\.\.me,\.\.\.d\.user\};await syncProfileSurfaces\(\)/);
});
test('0.67 strengthens Human Orbit core dimensions while retaining compact mobile rules',()=>{
 const css=read('public/styles.css');
 assert.match(css,/0\.67 — French-first dynamic surfaces/);
 assert.match(css,/\.identity-core\{width:clamp\(316px,30vw,360px\)/);
 assert.match(css,/@media\(max-width:480px\)\{\.identity-universe\{transform:scale\(\.84\)/);
});
test('0.67 retains production legal registration lock',()=>{
 const server=read('src/server.js');
 assert.match(server,/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(server,/BETA_LEGAL_APPROVED/);
});
