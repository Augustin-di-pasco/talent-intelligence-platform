import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.72 provides native French for every Human Orbit dynamic panel and its empty states',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['VOTRE IDENTITÉ','Votre identité professionnelle en un regard.','Que savez-vous concrètement faire ?','Montrez ce qui illustre votre expérience.','D’où venez-vous et où souhaitez-vous aller ?','Que souhaitez-vous rendre possible ?','Découvrez les personnes qui gravitent autour de votre univers.','Quelles opportunités accompagnent votre prochaine étape ?','Rendez vos contributions visibles.','Votre espace de compétences est vide.','Aucune réalisation pour le moment.','Vous gardez le contrôle de votre visibilité.']) assert.ok(i18n.includes(phrase),`Missing French panel text: ${phrase}`);
});
test('0.72 aligns the release metadata and retains French as the initial language',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(read('public/i18n.js'),/return "fr"/);
});
