import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const version=fs.readFileSync(path.join(root,'VERSION'),'utf8').trim();

test('0.83 improves Human Orbit centre and satellite readability on narrow phones',()=>{
  assert.match(css,/0\.83 — Human Orbit/);
  assert.match(css,/\.identity-core\{width:clamp\(246px,72vw,276px\);height:clamp\(246px,72vw,276px\);/);
  assert.match(css,/\.core-headline\{font-size:12px;max-width:220px;line-height:1\.4\}/);
  assert.match(css,/\.orbit-node b\{font-size:9px;letter-spacing:\.06em/);
  assert.match(css,/\.universe-hint\{font-size:8px;letter-spacing:\.07em;max-width:90%;text-align:center;white-space:normal\}/);
  assert.match(html,/id="identityCoreFacts"/);
});

test('0.83 release metadata is aligned',()=>{
  assert.equal(pkg.version,'1.9.0-alpha.20');
  assert.equal(version,'1.9.0-alpha.20');
  assert.match(fs.readFileSync(path.join(root,'src/server.js'),'utf8'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
