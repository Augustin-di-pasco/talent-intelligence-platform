import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('dynamic Human Orbit values pass enum labels through the language layer', () => {
  const app = read('public/app.js');
  assert.match(app, /const tr=value=>window\.ZERIHLINK_I18N\?\.translate\(value\)\|\|value/);
  assert.match(app, /tr\(s\.verified\?"verified":"self-declared"\)/);
  assert.match(app, /tr\(e\.kind\)/);
  assert.match(app, /tr\(o\.type\)/);
});

test('French dictionary covers dynamic skill, evidence and opportunity enums', () => {
  const i18n = read('public/i18n.js');
  for (const phrase of ["'Practitioner': 'Opérationnel'", "'Learning': 'En apprentissage'", "'work_sample': 'exemple de travail'", "'interest_sent': 'intérêt envoyé'", "'internship': 'stage'", "'remote': 'à distance'"]) assert.ok(i18n.includes(phrase), phrase);
});

test('0.94 release metadata stays aligned and legal launch lock remains explicit', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
  assert.match(read('src/server.js'), /BETA_LEGAL_APPROVED/);
});
