import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('0.73 translates key action feedback across member, company and account journeys',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['Votre signalement a été transmis à l’équipe de modération.','Votre demande de mise en relation a été envoyée.','Votre réponse à la demande a été enregistrée.','Votre réalisation a été transmise pour examen indépendant.','Le statut de l’opportunité a été mis à jour.','Votre mot de passe a été modifié.','Votre adresse e-mail est confirmée.','La photo de profil a été mise à jour.','Votre projet collaboratif est publié.']) assert.ok(i18n.includes(phrase),`Missing French feedback: ${phrase}`);
});
test('0.73 runtime version is consistent',()=>{
 assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
