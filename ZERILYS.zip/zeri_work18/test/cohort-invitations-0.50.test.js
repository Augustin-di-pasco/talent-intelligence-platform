import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const script=fs.readFileSync(path.join(root,'scripts/cohort-50-smoke.mjs'),'utf8');
test('optional 50-member research cohort still supports reviewer-issued one-time invitations alongside open signup',()=>{
  assert.match(script,/ZERIHLINK_REVIEWER_EMAILS:'beta-reviewer@cohort\.test'/);
  assert.match(script,/api\/review\/invitations\/bulk/);
  assert.match(script,/api\/review\/invitations\/bulk/);
  assert.match(script,/batch\.created,50/);
  assert.match(script,/betaInvitationToken:invitationTokens\[index\]/);
  assert.match(script,/\.invitations\.length,0/);
});
