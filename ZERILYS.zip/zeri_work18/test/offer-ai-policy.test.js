import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const server=readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
const app=readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../public/index.html',import.meta.url),'utf8');

test('offer AI policy supports allowed, prohibited and expected modes',()=>{
  for(const policy of ['allowed','prohibited','expected']) assert.ok(server.includes(`"${policy}"`));
  assert.match(server,/const aiPolicy=\["allowed","prohibited","expected"\]/);
  assert.match(server,/INVALID_AI_POLICY/);
});

test('AI policy and employer guidance are persisted and exposed to candidates',()=>{
  assert.match(server,/aiPolicy,aiPolicyNote/);
  assert.match(server,/aiPolicyAtApplication:offer\.aiPolicy\|\|\"allowed\"/);
  assert.match(server,/workMode,aiPolicy,aiPolicyNote,skills,createdAt/);
  assert.match(app,/function aiPolicyMarkup\(o\)/);
  assert.match(app,/aiPolicyMarkup\(o\)/);
});

test('company offer form explains scope and lets employer choose a policy',()=>{
  assert.match(html,/name="aiPolicy"/);
  assert.match(html,/value="allowed"/);
  assert.match(html,/value="prohibited"/);
  assert.match(html,/value="expected"/);
  assert.match(html,/avant sa candidature/);
});
