import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(file)=>fs.readFileSync(new URL(`../${file}`,import.meta.url),'utf8');

test('0.85 skill detail panel uses native French for every dynamic state',()=>{
 const app=read('public/app.js');
 const start=app.indexOf('function selectSkill(');
 const end=app.indexOf('\nfunction ',start+10);
 assert.ok(start>=0&&end>start,'selectSkill function exists');
 const panel=app.slice(start,end);
 for(const text of ['COMPÉTENCE / SIGNAL','ÉTAYÉE PAR DES PREUVES','COMPÉTENCE DÉCLARÉE','Niveau','éléments associés','Aucune preuve associée','Ajouter une preuve']) assert.ok(panel.includes(text),`missing French copy: ${text}`);
 assert.ok(panel.includes('window.ZERIHLINK_I18N?.language!=="en"'),'English remains an explicit user-selected alternative');
 assert.ok(panel.includes('escape')===false,'the panel continues to escape user-provided content with esc()');
});

test('0.85 release metadata is aligned',()=>{
 assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.ok(read('src/server.js').includes('const VERSION = "1.9.0-alpha.20"'));
});
