import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");

test("French launch report explains blockers and keeps invitation-free registration distinct from legal approval",()=>{
 const script=read("scripts/launch-report-fr.mjs"),docs=read("docs/MISE_EN_LIGNE_FR_0_62.md"),pkg=JSON.parse(read("package.json"));
 assert.match(script,/Configuration des inscriptions sans invitation/);
 assert.match(script,/Inscription effective/);
 assert.match(script,/BLOQUÉE PAR LE VERROU JURIDIQUE/);
 assert.match(script,/Le verrou juridique bloque effectivement/);
 assert.match(script,/session_secret/);
 assert.match(script,/legal_review_ack/);
 assert.match(docs,/ZERIHLINK_BETA_LEGAL_APPROVED=false/);
 assert.match(docs,/npm run check:remote/);
 assert.match(pkg.scripts["launch:check"],/launch-report-fr/);
});

test("launch report never prints environment secret values",()=>{
 const script=read("scripts/launch-report-fr.mjs");
 assert.match(script,/labels\[item\.name\]\|\|item\.detail/);
 assert.doesNotMatch(script,/process\.env\.ZERIHLINK_SESSION_SECRET/);
});
