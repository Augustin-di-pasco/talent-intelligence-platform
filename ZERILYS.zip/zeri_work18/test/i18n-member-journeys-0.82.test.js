import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const i18n=fs.readFileSync(path.join(root,'public/i18n.js'),'utf8');
const app=fs.readFileSync(path.join(root,'public/app.js'),'utf8');

test('0.82 provides native French for member profile, connection and opportunity feedback',()=>{
  for(const phrase of [
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.',
    'Your intentional connection request has been sent.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.',
    'No published opportunities yet. Company opportunities will appear here when they are available.',
    'Your interest was withdrawn and access to your profile for this application was revoked.',
    'Your opportunity journey will appear here.'
  ]) assert.ok(i18n.includes(JSON.stringify(phrase)),`Missing French mapping for: ${phrase}`);
});

test('0.82 retains French-first dynamic translation and does not alter server-confirmed profile refresh',()=>{
  assert.match(i18n,/return "fr"/);
  assert.match(i18n,/new MutationObserver/);
  assert.match(app,/await refreshMe\(\)/);
  assert.match(app,/renderIdentity\(\)/);
});
