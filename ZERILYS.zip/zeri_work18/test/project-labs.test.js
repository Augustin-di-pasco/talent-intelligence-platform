import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeProjectInput, canAcceptProjectApplication, normalizeProjectTask, canManageProjectTask } from '../src/project-labs.js';

const base = { title: 'Analyse énergétique', description: 'Construire une analyse et une recommandation opérationnelle détaillée pour un cas réel.' };

test('project lab normalizes project metadata and bounds team size and duration', () => {
  const result = normalizeProjectInput({ ...base, projectType: 'research', maxTeamSize: 99, durationWeeks: 0, skills: [' Python ', 'Python', '<SQL>'], deliverables: ['Rapport'] }, { accountType: 'candidate' });
  assert.equal(result.project.projectType, 'research');
  assert.equal(result.project.maxTeamSize, 20);
  assert.equal(result.project.durationWeeks, 1);
  assert.deepEqual(result.project.skills, ['Python', 'SQL']);
  assert.equal(result.project.ownerType, 'member');
});

test('only a company account can publish a company challenge', () => {
  const result = normalizeProjectInput({ ...base, projectType: 'company_challenge', compensation: 'paid' }, { accountType: 'candidate' });
  assert.equal(result.error, 'COMPANY_ACCOUNT_REQUIRED');
});

test('commercial company challenges must declare compensation', () => {
  const result = normalizeProjectInput({ ...base, projectType: 'company_challenge' }, { accountType: 'company' });
  assert.equal(result.error, 'COMMERCIAL_CHALLENGE_MUST_BE_COMPENSATED');
  const paid = normalizeProjectInput({ ...base, projectType: 'company_challenge', compensation: 'paid' }, { accountType: 'company' });
  assert.equal(paid.project.compensation, 'paid');
});

test('team capacity counts the project owner and prevents over-acceptance', () => {
  const project = { id: 'p', maxTeamSize: 3 };
  const applications = [{ id: 'a', projectId: 'p', status: 'accepted' }, { id: 'b', projectId: 'p', status: 'accepted' }];
  assert.equal(canAcceptProjectApplication(project, applications, 'c'), false);
  assert.equal(canAcceptProjectApplication(project, applications.slice(0, 1), 'c'), true);
});

test('project creation UI collects type, compensation, duration, team capacity and deliverables', async () => {
  const fs = await import('node:fs');
  const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  const translations = fs.readFileSync(new URL('../public/i18n.js', import.meta.url), 'utf8');
  for (const field of ['projectType', 'compensation', 'durationWeeks', 'maxTeamSize', 'deliverables']) assert.match(app, new RegExp(field));
  for (const phrase of ['Que souhaitez-vous construire ?', 'Type de projet', 'Taille maximale de l’équipe']) assert.ok(translations.includes(phrase));
});


test('project tasks are assigned only to accepted team members and start as todo', () => {
  const result = normalizeProjectTask({ title: 'Préparer le prototype', assigneeId: 'member-1', dueDate: '2026-12-01' }, { id: 'p' }, 'owner', ['owner', 'member-1']);
  assert.equal(result.task.status, 'todo');
  assert.equal(result.task.assigneeId, 'member-1');
  assert.equal(normalizeProjectTask({ title: 'Task', assigneeId: 'outsider' }, {}, 'owner', ['owner']).error, 'TASK_ASSIGNEE_NOT_IN_TEAM');
  assert.equal(normalizeProjectTask({ title: 'x' }, {}, 'owner', ['owner']).error, 'TASK_TITLE_REQUIRED');
});

test('project task permissions allow owner, creator or assignee only', () => {
  const task = { createdBy: 'member-1', assigneeId: 'member-2' };
  assert.equal(canManageProjectTask(task, 'owner', 'owner'), true);
  assert.equal(canManageProjectTask(task, 'member-1', 'owner'), true);
  assert.equal(canManageProjectTask(task, 'member-2', 'owner'), true);
  assert.equal(canManageProjectTask(task, 'outsider', 'owner'), false);
});

test('project task API enforces team membership and never exposes task board in public listings', async () => {
  const fs = await import('node:fs');
  const server = fs.readFileSync(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.match(server, /PROJECT_TEAM_ACCESS_REQUIRED/);
  assert.match(server, /project\.tasks=project\.tasks\|\|\[\]/);
  assert.match(server, /map\(\(\{tasks,...x\}\)/);
});

test('project workspace exposes owner-only application review and a private task board UI', async () => {
  const fs = await import('node:fs');
  const server = fs.readFileSync(new URL('../src/server.js', import.meta.url), 'utf8');
  const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  assert.match(server, /PROJECT_OWNER_REQUIRED/);
  assert.match(server, /store\.state\.applications\.filter\(a=>a\.projectId===project\.id\)/);
  assert.match(app, /openProjectWorkspace/);
  assert.match(app, /projectTaskForm/);
  assert.match(app, /project-decision/);
  assert.match(app, /project-task-status/);
});

test('project workspace escapes member content and requires authenticated team access for tasks', async () => {
  const fs = await import('node:fs');
  const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  const server = fs.readFileSync(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.match(app, /esc\(project\.title\)/);
  assert.match(app, /esc\(a\.message/);
  assert.match(app, /esc\(t\.title\)/);
  assert.match(server, /PROJECT_TEAM_ACCESS_REQUIRED/);
});

test('project creation uses a structured bilingual form instead of a sequence of browser prompts', async () => {
  const fs = await import('node:fs');
  const app = fs.readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  const translations = fs.readFileSync(new URL('../public/i18n.js', import.meta.url), 'utf8');
  assert.match(app, /projectCreateForm/);
  assert.match(app, /projectCompensationField/);
  assert.match(app, /PROJECT LABS/);
  assert.match(translations, /Créer un projet/);
  assert.match(translations, /Publier le projet/);
});
