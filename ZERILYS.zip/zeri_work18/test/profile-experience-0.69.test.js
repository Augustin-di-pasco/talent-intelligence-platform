import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('0.69 defaults first-time visitors to French while preserving explicit language choice',()=>{
 const i18n=read('public/i18n.js');
 assert.match(i18n,/if \(supported\.has\(saved\)\) return saved;/);
 assert.match(i18n,/French is the product launch language/);
 assert.match(i18n,/return "fr";/);
});

test('0.69 profile save remains server-confirmed and refreshes profile, evidence, readiness and orbit',()=>{
 const app=read('public/app.js');
 assert.match(app,/api\("\/me",\{method:"PATCH",body:JSON\.stringify\(body\)\}\)/);
 assert.match(app,/if\(!d\?\.user\)throw new Error/);
 assert.match(app,/syncProfileSurfaces\(\)/);
 assert.match(app,/Your identity at a glance\./);
 assert.match(app,/identity-overview-grid/);
});

test('0.69 Human Orbit exposes readable professional facts and responsive centre sizing',()=>{
 const app=read('public/app.js'),css=read('public/styles.css');
 for(const field of ['me.headline','me.location','me.interests','me.canOffer','me.lookingFor']) assert.ok(app.includes(field),`Missing profile field ${field}`);
 assert.match(css,/0\.69 — premium identity cockpit/);
 assert.match(css,/\.identity-core\{width:clamp\(350px,32vw,390px\)/);
 assert.match(css,/\.identity-overview-grid/);
 assert.match(css,/@media\(max-width:760px\)/);
});

test('0.69 replaces the plain activation checklist with responsive, accessible action tiles',()=>{
 const app=read('public/app.js'),css=read('public/styles.css');
 assert.match(app,/data-readiness-action/);
 assert.match(css,/\.readiness-item:before/);
 assert.match(css,/\.readiness-items\{grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
 assert.match(css,/prefers-reduced-motion:reduce/);
});

test('0.69 French vocabulary covers the professional identity and editor surfaces',()=>{
 const i18n=read('public/i18n.js');
 for(const phrase of ['VOTRE ESPACE IDENTITÉ','Votre univers professionnel.','Modifier mon profil','Réalisations et preuves','CHAMP DES COMPÉTENCES','RÉSEAU DES MEMBRES','Votre profil en quelques étapes']) assert.ok(i18n.includes(phrase),`Missing French phrase: ${phrase}`);
});
