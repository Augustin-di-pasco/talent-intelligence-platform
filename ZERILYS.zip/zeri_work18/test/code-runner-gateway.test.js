import test from 'node:test';
import assert from 'node:assert/strict';
import { runnerConfiguration, validateCodeRun, executeInIsolatedRunner } from '../src/code-runner-gateway.js';

const token='x'.repeat(40);
test('runner is disabled by default and fails closed', async()=>{
  assert.deepEqual(runnerConfiguration({}),{enabled:false,reason:'RUNNER_NOT_CONFIGURED'});
  const result=await executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',env:{}});
  assert.equal(result.error,'RUNNER_NOT_CONFIGURED');assert.equal(result.status,503);
});
test('runner configuration requires HTTPS and a long secret',()=>{
  assert.equal(runnerConfiguration({ZERIHLINK_RUNNER_URL:'http://runner.internal',ZERIHLINK_RUNNER_TOKEN:token}).enabled,false);
  assert.equal(runnerConfiguration({ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:'short'}).enabled,false);
  assert.equal(runnerConfiguration({ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:token}).enabled,true);
});
test('code validation limits exercises, language and source length',()=>{
  assert.equal(validateCodeRun({slug:'unknown',language:'python',source:'print(1)'}).error,'CODE_EXERCISE_NOT_FOUND');
  assert.equal(validateCodeRun({slug:'python-data-cleaning-code',language:'sql',source:'select 1'}).error,'CODE_LANGUAGE_MISMATCH');
  assert.equal(validateCodeRun({slug:'python-data-cleaning-code',language:'python',source:'x'.repeat(12001)}).error,'CODE_TOO_LONG');
  assert.equal(validateCodeRun({slug:'python-data-cleaning-code',language:'python',source:'print(1)'}).error,undefined);
});
test('SQL gateway rejects write and administrative statements',()=>{
  for(const source of ['DELETE FROM orders','DROP TABLE orders','WITH x AS (SELECT 1) INSERT INTO t SELECT * FROM x','PRAGMA table_info(users)']) {
    assert.equal(validateCodeRun({slug:'sql-analytics-query-code',language:'sql',source}).error,'SQL_READ_ONLY_POLICY');
  }
  assert.equal(validateCodeRun({slug:'sql-analytics-query-code',language:'sql',source:'SELECT region, COUNT(*) FROM customers GROUP BY region'}).error,undefined);
});
test('runner receives only the exercise payload and response fields are bounded',async()=>{
  let sent;
  const fetchImpl=async(url,options)=>{sent={url,options};const body=JSON.parse(options.body);return new Response(JSON.stringify({jobId:body.jobId,status:'completed',stdout:'o'.repeat(17000),stderr:'',durationMs:4500,tests:[{name:'ok',passed:true}]}),{status:200,headers:{'content-type':'application/json'}});};
  const result=await executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',variant:{rowCount:120},env:{ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:token},fetchImpl});
  assert.equal(sent.url,'https://runner.example/v1/execute');
  const payload=JSON.parse(sent.options.body);assert.equal(payload.source,'print(1)');assert.equal(Object.hasOwn(payload,'candidateId'),false);assert.equal(payload.limits.network,false);
  assert.equal(result.result.stdout.length,16384);assert.equal(result.result.durationMs,3000);assert.equal(result.result.tests[0].passed,true);
});
test('runner rejects mismatched job response and maps network failures safely',async()=>{
  const env={ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:token};
  const invalid=await executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',env,fetchImpl:async()=>new Response(JSON.stringify({jobId:'wrong',status:'completed'}),{status:200,headers:{'content-type':'application/json'}})});
  assert.equal(invalid.error,'RUNNER_INVALID_RESPONSE');
  const offline=await executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',env,fetchImpl:async()=>{throw new Error('offline')}});
  assert.equal(offline.error,'RUNNER_UNAVAILABLE');
});

test('runner rejects oversized, non-JSON and malformed responses without parsing unbounded bodies',async()=>{
  const env={ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:token};
  const call=fetchImpl=>executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',env,fetchImpl});
  const oversized=await call(async()=>new Response('x'.repeat(70_000),{status:200,headers:{'content-type':'application/json'}}));
  assert.equal(oversized.error,'RUNNER_INVALID_RESPONSE');
  const wrongType=await call(async()=>new Response('<html>error</html>',{status:200,headers:{'content-type':'text/html'}}));
  assert.equal(wrongType.error,'RUNNER_INVALID_RESPONSE');
  const malformed=await call(async()=>new Response('{bad json',{status:200,headers:{'content-type':'application/json'}}));
  assert.equal(malformed.error,'RUNNER_INVALID_RESPONSE');
});

test('runner requests never follow redirects with the bearer credential',async()=>{
  let options; const env={ZERIHLINK_RUNNER_URL:'https://runner.example',ZERIHLINK_RUNNER_TOKEN:token};
  await executeInIsolatedRunner({slug:'python-data-cleaning-code',language:'python',source:'print(1)',env,fetchImpl:async(_url,opts)=>{options=opts;return new Response(JSON.stringify({jobId:JSON.parse(opts.body).jobId,status:'completed'}),{status:200,headers:{'content-type':'application/json'}});}});
  assert.equal(options.redirect,'error');
});
