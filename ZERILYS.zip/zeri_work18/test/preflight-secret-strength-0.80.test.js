import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const root=process.cwd();
function run(secret){
  const data=mkdtempSync(path.join(os.tmpdir(),"zerihlink-preflight-secret-"));
  try{
    const result=spawnSync(process.execPath,["scripts/preflight-beta.mjs"],{cwd:root,encoding:"utf8",env:{...process.env,NODE_ENV:"production",ZERIHLINK_DATA_DIR:data,ZERIHLINK_PERSISTENT_DATA_ACK:"true",ZERIHLINK_SESSION_SECRET:secret,ZERIHLINK_REVIEWER_EMAILS:"reviewer@example.test"}});
    const json=result.stdout.slice(result.stdout.indexOf("{"));
    return JSON.parse(json).checks.find(item=>item.name==="session_secret");
  }finally{rmSync(data,{recursive:true,force:true});}
}

test("0.80 preflight rejects long but predictable session secrets",()=>{
  assert.equal(run("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").status,"blocked");
  assert.equal(run("0123456789abcdef0123456789abcdef").status,"pass");
});
