import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const app = read('public/app.js');
const i18n = read('public/i18n.js');

test('candidate opportunity timeline uses localized status labels and withdrawal controls', () => {
  const start = app.indexOf('async function loadCandidateApplications');
  const end = app.indexOf('\nasync function ', start + 10);
  const view = app.slice(start, end);
  for (const label of ['Interest sent','Under review','Interview stage','Not selected','Withdraw','Updated']) assert.ok(view.includes(`tr("${label}")`), `localized ${label}`);
  assert.match(view, /tr\("Withdraw your interest\?/);
  assert.match(view, /tr\("Your interest was withdrawn and access to your profile/);
});

test('company recruitment workspace localizes application statuses and internal-note controls', () => {
  const start = app.indexOf('async function setupCompanyStudio');
  const end = app.indexOf('\nasync function ', start + 10);
  const view = app.slice(start, end);
  for (const label of ['Interest sent','Under review','Interview stage','Not selected','Add an internal note…','Save internal note','No candidate interest yet.']) assert.ok(view.includes(`tr("${label}")`), `localized ${label}`);
  assert.match(view, /tr\("PRIVATE COMPANY NOTES · only visible to your team"\)/);
  for (const phrase of ['NOTES INTERNES','Ajouter une note interne','Enregistrer la note interne','Aucun candidat ne s’est encore manifesté']) assert.ok(i18n.includes(phrase), phrase);
});
