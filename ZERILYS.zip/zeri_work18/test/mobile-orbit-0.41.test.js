import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const css=fs.readFileSync(path.join(root,'public/styles.css'),'utf8');
test('mobile Human Orbit has compact geometry for narrow viewports',()=>{
  assert.match(css,/@media\(max-width:600px\)\{[\s\S]*?\.identity-universe\{width:100%;max-width:390px;height:390px;min-height:390px;overflow:hidden/);
  assert.match(css,/\.universe-ring\.ring-c\{width:350px;height:350px\}/);
  assert.match(css,/\.node-opportunities\{top:50%;right:0;transform:translateY\(-50%\)\}/);
  assert.match(css,/\.skill-constellation\{display:none\}/);
});
test('extra-small viewport receives an additional orbit size reduction',()=>{
  assert.match(css,/@media\(max-width:360px\)\{[\s\S]*?\.identity-universe\{height:370px;min-height:370px\}/);
});
