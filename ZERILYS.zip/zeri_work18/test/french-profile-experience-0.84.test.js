import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const pkg=JSON.parse(read('package.json'));

test('0.84 provides French-first copy for the complete dynamic profile journey',()=>{
  const i18n=read('public/i18n.js');
  const required=[
    'YOUR CORE SIGNAL','VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'CAPABILITY FIELD','UNIVERS DES COMPÉTENCES',
    'PROOF LAYER','RÉALISATIONS',
    'TRAJECTORY','PARCOURS',
    'INTENT FIELD','ASPIRATIONS',
    'MEMBER NETWORK','RÉSEAU DES MEMBRES',
    'OPPORTUNITY CONSTELLATION','CONSTELLATION DES OPPORTUNITÉS',
    'IMPACT SIGNAL','SIGNAL D’IMPACT',
    'Loading member profiles…','Chargement des profils…',
    'Connection response saved.','Réponse à la demande enregistrée.'
  ];
  for(const phrase of required) assert.ok(i18n.includes(phrase),`Missing French-first translation: ${phrase}`);
});

test('0.84 retains French-first initial language and dynamic DOM translation',()=>{
  const i18n=read('public/i18n.js');
  assert.match(i18n,/return "fr";/);
  assert.match(i18n,/new MutationObserver/);
  assert.match(i18n,/translateElement\(node\)/);
});

test('0.84 release metadata is aligned',()=>{
  assert.equal(pkg.version,'1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
  assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
