import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
const candidate=fs.readFileSync(path.join(root,'docs/RELEASE_CANDIDATE_0_62.md'),'utf8');
const checklist=fs.readFileSync(path.join(root,'docs/BETA_RELEASE_CHECKLIST_0_62.md'),'utf8');
test('release metadata is consistent across package, version file and server',()=>{
  assert.equal(pkg.version,'1.9.0-alpha.20');
  assert.equal(fs.readFileSync(path.join(root,'VERSION'),'utf8').trim(),pkg.version);
  assert.ok(server.includes(`const VERSION = "${pkg.version}";`));
});
test('open registration does not bypass the independent legal launch lock',()=>{
  assert.match(server,/inviteRequired:false/);
  assert.doesNotMatch(server,/INVITE_REQUIRED/);
  assert.match(server,/if\(!BETA_LEGAL_APPROVED\)/);
  assert.match(candidate,/Open registration remains available/);
  assert.match(candidate,/legal launch gate remains active/);
  assert.match(checklist,/BETA_LEGAL_APPROVED=true/);
  assert.match(checklist,/npm run check:remote/);
});
