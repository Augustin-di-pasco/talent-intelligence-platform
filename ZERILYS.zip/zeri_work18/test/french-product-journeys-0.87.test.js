import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(file)=>fs.readFileSync(new URL(`../${file}`,import.meta.url),'utf8');
const i18n=read('public/i18n.js');
const html=read('public/index.html');
const app=read('public/app.js');

test('0.87 French-first copy covers discovery, opportunities and company journeys',()=>{
  for(const phrase of [
    'Discover people by what they know, what they have built, and what they want to make possible next.',
    'Structured opportunities from companies. Relevant signals, explained through skills and intent — never an opaque hiring score.',
    'Expressing interest shares your professional profile with that company for this opportunity only. You can withdraw at any time.',
    'Company verification request submitted.',
    'Submit for verification ↗','Publish opportunity ↗','Candidate interests'
  ]) assert.ok(i18n.includes(JSON.stringify(phrase)),`Missing source phrase: ${phrase}`);
});

test('0.87 French-first copy covers identity editing, evidence and privacy controls',()=>{
  for(const phrase of [
    'Shape your signal.','Professional headline','Profile visibility','What can you bring?',
    'What are you looking for?','Evidence of your work','Connect to a capability (optional)',
    'Data & privacy.','Manage active sign-in sessions. A maximum of ten active sessions is allowed per account.',
    'Update password'
  ]) assert.ok(i18n.includes(JSON.stringify(phrase)),`Missing source phrase: ${phrase}`);
});

test('0.87 keeps translation reactive for dynamically rendered content and explicit English choice',()=>{
  assert.match(i18n,/new MutationObserver/);
  assert.match(i18n,/const next = exact\(source\)/);
  assert.match(i18n,/window\.ZERIHLINK_I18N/);
  assert.match(app,/await refreshMe\(\)/);
  assert.match(app,/renderIdentity\(\)/);
});

test('0.87 keeps dialogs semantically labelled and key feedback regions announced',()=>{
  assert.match(html,/id="publicIdentityModal"[^>]*>[\s\S]*?role="dialog" aria-modal="true" aria-label="Member professional identity"/);
  assert.match(html,/id="avatarStatus" aria-live="polite" role="status"/);
  assert.doesNotMatch(html,/reviewBulkInviteResult|reviewConsole/);
});

test('0.87 release metadata is aligned',()=>{
  assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
  assert.ok(read('src/server.js').includes('const VERSION = "1.9.0-alpha.20"'));
});
