import test from 'node:test';
import assert from 'node:assert/strict';
import { practicalCaseCatalog, getPracticalCase, submitPracticalCase } from '../src/assessment-engine.js';

test('Python and SQL code exercises are catalogued as human-reviewed text submissions', () => {
  const catalog = practicalCaseCatalog();
  const python = catalog.find(x => x.slug === 'python-data-cleaning-code');
  const sql = catalog.find(x => x.slug === 'sql-analytics-query-code');
  assert.equal(python?.submissionMode, 'code');
  assert.equal(python?.language, 'python');
  assert.equal(sql?.submissionMode, 'code');
  assert.equal(sql?.language, 'sql');
  assert.equal(catalog.filter(x => x.submissionMode === 'code').length, 2);
});

test('code exercise details declare execution disabled and provide a starter snippet', () => {
  const exercise = getPracticalCase('python-data-cleaning-code', 'candidate-123');
  assert.equal(exercise.submissionMode, 'code');
  assert.equal(exercise.execution.enabled, false);
  assert.match(exercise.execution.notice, /jamais exécuté/);
  assert.match(exercise.starterCode, /def clean_records/);
  assert.equal(exercise.scoring, 'human_review_only');
});

test('code submissions remain pending human review and are never scored automatically', () => {
  const result = submitPracticalCase('sql-analytics-query-code', 'candidate-123', {
    response: 'SELECT c.region, DATE_TRUNC(\'month\', o.order_date) AS month, SUM(o.amount) AS revenue, COUNT(DISTINCT c.id) AS active_customers, AVG(o.amount) AS average_basket FROM customers c JOIN orders o ON o.customer_id = c.id WHERE o.status = \'validated\' GROUP BY 1, 2;\n\nExplanation: I aggregate by month and region and count distinct customers to avoid duplicate counting.',
    aiUseDeclaration: 'not_used'
  });
  assert.equal(result.status, 'submitted_for_human_review');
  assert.equal(result.score, null);
  assert.equal(result.review.scored, false);
});
