import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
const app=fs.readFileSync(path.join(root,'public/app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
test('review invitation API reports batch and redemption status without exposing token hashes',()=>{
  assert.match(server,/batchId=id\(\)/);
  assert.match(server,/batches,recent,summary/);
  assert.match(server,/group\[status\]\+\+/);
  assert.match(server,/group\[status\]\+\+/);
  assert.match(server,/tokenHash/);
});
test('invitation administration is not embedded in the public page',()=>{
  assert.doesNotMatch(html,/reviewInvitationSummary|reviewInvitationBatches|reviewConsole/);
  assert.match(app,/reviewInvitationBatches/);
  assert.match(app,/registered/);
  assert.match(app,/pending/);
});
