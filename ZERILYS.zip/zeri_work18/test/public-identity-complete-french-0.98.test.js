import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');
const app = read('public/app.js');
const i18n = read('public/i18n.js');

test('0.98 public identity translates its live labels and actions at render time', () => {
  const start = app.indexOf('async function openPublicIdentity');
  const end = app.indexOf('\n', start);
  const view = app.slice(start, end);
  for (const key of [
    'CAPABILITY SIGNAL', 'LIVING IDENTITY', 'A professional identity is not a list. It is a field of capabilities, proof and possibilities.',
    'HUMAN SIGNAL', 'CAPABILITY FIELD', 'Signals will appear here', 'capabilities', 'evidence records',
    'Independently verified', 'Self-described', 'linked evidence record(s)', 'Join to connect ↗',
    'Connect with intent', 'Report', 'Block', 'Share public profile', 'Share member link'
  ]) assert.ok(view.includes(`tr("${key}")`) || view.includes(`tr(${key}`) || view.includes(`tr(u.visibility===`), `public identity localizes ${key}`);
  for (const key of [
    'A professional identity is not a list. It is a field of capabilities, proof and possibilities.',
    'Signals will appear here', 'evidence records', 'linked evidence record(s)', 'Member blocked.',
    'Member unblocked.', 'Report sent to the moderation team.'
  ]) assert.ok(i18n.includes(key), `French dictionary includes ${key}`);
});

test('0.98 keeps member-authored identity and evidence content escaped', () => {
  const start = app.indexOf('async function openPublicIdentity');
  const end = app.indexOf('\n', start);
  const view = app.slice(start, end);
  assert.match(view, /esc\(u\.name\)/);
  assert.match(view, /esc\(u\.headline\|\|"Human potential in motion"\)/);
  assert.match(view, /esc\(sk\.name\)/);
  assert.match(view, /esc\(e\.title\)/);
  assert.match(view, /esc\(e\.description\|\|""\)/);
});

test('0.98 connection and notification actions use the active language layer', () => {
  const start = app.indexOf('async function loadConnections');
  const end = app.indexOf('\n', start);
  const view = app.slice(start, end);
  assert.match(view, /tr\(incoming\?"Incoming signal":"Outgoing signal"\)/);
  assert.match(view, /tr\("Accept"\)/);
  assert.match(view, /tr\("Decline"\)/);
  assert.match(view, /tr\(c\.status===/);
  assert.match(view, /tr\("Connection response saved\."\)/);
  assert.match(app, /tr\("Notifications"\)/);
  assert.match(app, /tr\("Mark read"\)/);
});

test('0.98 release metadata is aligned', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(), '1.9.0-alpha.20');
  assert.match(read('src/server.js'), /const VERSION = "1\.9\.0-alpha\.20"/);
});
