import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=(file)=>fs.readFileSync(new URL(`../${file}`,import.meta.url),'utf8');
const i18n=read('public/i18n.js');

test('language switching restores original English text instead of leaving stale French translations',()=>{
  assert.match(i18n,/function translateElement\(root\)\s*\{/);
  assert.doesNotMatch(i18n,/function translateElement\(root\)\s*\{\s*if\s*\(language\s*===\s*"en"\)\s*return/);
  assert.match(i18n,/const next = exact\(source\)/);
});

test('language switching restores source attributes and keeps translated dynamic content observable',()=>{
  assert.match(i18n,/const after = exact\(source\)/);
  assert.match(i18n,/new MutationObserver/);
  assert.match(i18n,/translateElement\(document\.body\)/);
});

test('release metadata is consistently aligned at 1.9.0-alpha.20',()=>{
  assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
  assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
  assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
});
