import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=file=>readFileSync(new URL(`../${file}`,import.meta.url),'utf8');
const app=read('public/app.js'),i18n=read('public/i18n.js');

test('0.96 discovery cards translate interface copy while preserving member-authored text',()=>{
 const fn=app.slice(app.indexOf('async function loadNetwork(q="")'),app.indexOf('async function loadOrbitNetwork'));
 for(const phrase of ['tr("Building their next chapter")','tr("Location not shared")','tr((u.evidenceCount||0)===1?"evidence item":"evidence items")','tr("Profile in progress")','tr("COMPLEMENTARITY SIGNAL")','tr("connection potential")','tr("Discover this identity")','tr("Connect with intent")']) assert.ok(fn.includes(phrase),`Missing translated discovery label: ${phrase}`);
 assert.match(fn,/esc\(u\.name\)/); assert.match(fn,/esc\(u\.headline\|\|tr\(/); assert.match(fn,/esc\(skill\.name\)/);
});

test('0.96 collaboration cards translate metadata, empty and error states',()=>{
 const fn=app.slice(app.indexOf('async function loadProjects(){'),app.indexOf('function esc('));
 for(const phrase of ['tr("No open collaborations yet. Be the first to start one.")','tr("interested")','tr("By")','tr("ZERILYS member")','tr("Explore collaboration ↗")','tr("Collaborations are temporarily unavailable.")']) assert.ok(fn.includes(phrase),`Missing translated project label: ${phrase}`);
 assert.match(fn,/esc\(project\.title\)/); assert.match(fn,/esc\(project\.description\)/);
});

test('0.96 network pagination uses localized counters and actions',()=>{
 const fn=app.slice(app.indexOf('async function loadOrbitNetwork'),app.indexOf('async function loadProjects'));
 for(const phrase of ['tr("Searching the member network…")','tr("No matching profiles. Try another name, skill or location.")','tr("of")','tr("profiles")','tr("Load")','tr("more profiles ↓")','tr("Load next profiles ↓")']) assert.ok(fn.includes(phrase),`Missing translated pagination label: ${phrase}`);
 assert.match(i18n,/"of":"sur"/); assert.match(i18n,/"interested":"personnes intéressées"/);
});

test('0.96 release metadata is aligned and legal launch gate remains intact',()=>{
 assert.equal(JSON.parse(read('package.json')).version,'1.9.0-alpha.20');
 assert.equal(read('VERSION').trim(),'1.9.0-alpha.20');
 assert.match(read('src/server.js'),/const VERSION = "1\.9\.0-alpha\.20"/);
 assert.match(read('src/server.js'),/BETA_LEGAL_APPROVED/);
});
