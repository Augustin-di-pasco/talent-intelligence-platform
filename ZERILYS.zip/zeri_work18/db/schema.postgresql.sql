-- ZERILYS PostgreSQL target schema (0.13 draft)
-- Not applied by the current runtime. Review before production migration.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id uuid PRIMARY KEY,
  email text NOT NULL UNIQUE,
  account_type text NOT NULL CHECK (account_type IN ('candidate','company')),
  password_hash text NOT NULL,
  password_salt text NOT NULL,
  profile jsonb NOT NULL DEFAULT '{}'::jsonb,
  visibility text NOT NULL DEFAULT 'public' CHECK (visibility IN ('public','private')),
  legal_consent jsonb NOT NULL DEFAULT '{}'::jsonb,
  company_verification jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_user_idx ON sessions(user_id);
CREATE TABLE skills (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name text NOT NULL,
  level text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, name)
);
CREATE TABLE evidence (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE offers (
  id uuid PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status text NOT NULL CHECK (status IN ('draft','published','closed')),
  offer_type text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX offers_public_idx ON offers(status, created_at DESC);
CREATE INDEX offers_company_idx ON offers(company_id, status);
CREATE TABLE offer_applications (
  id uuid PRIMARY KEY,
  offer_id uuid NOT NULL REFERENCES offers(id) ON DELETE RESTRICT,
  candidate_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status text NOT NULL CHECK (status IN ('interest_sent','reviewing','interview','declined','withdrawn')),
  consent_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  withdrawn_at timestamptz,
  UNIQUE(offer_id, candidate_id)
);
CREATE INDEX applications_candidate_idx ON offer_applications(candidate_id, updated_at DESC);
CREATE INDEX applications_offer_idx ON offer_applications(offer_id, status, created_at DESC);
CREATE TABLE application_events (
  id uuid PRIMARY KEY,
  application_id uuid NOT NULL REFERENCES offer_applications(id) ON DELETE CASCADE,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  actor_type text NOT NULL CHECK (actor_type IN ('candidate','company','system')),
  event_type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX application_events_timeline_idx ON application_events(application_id, created_at);
CREATE TABLE application_private_notes (
  id uuid PRIMARY KEY,
  application_id uuid NOT NULL REFERENCES offer_applications(id) ON DELETE CASCADE,
  company_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  note text NOT NULL CHECK (length(note) BETWEEN 3 AND 1000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX application_notes_idx ON application_private_notes(application_id, created_at);
CREATE TABLE notifications (
  id uuid PRIMARY KEY,
  recipient_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  notification_type text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_inbox_idx ON notifications(recipient_id, read_at, created_at DESC);
CREATE TABLE blocks (
  blocker_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(blocker_id, blocked_id),
  CHECK(blocker_id <> blocked_id)
);
CREATE TABLE reports (
  id uuid PRIMARY KEY,
  reporter_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  target_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE audit_events (
  id uuid PRIMARY KEY,
  actor_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL,
  target_type text NOT NULL,
  target_id text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  previous_hash text,
  event_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_target_idx ON audit_events(target_type, target_id, created_at);

-- Company workspace roles (0.14). Invitations are single-use and token hashes only.
CREATE TABLE company_members (
  id uuid PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('recruiter','viewer')),
  status text NOT NULL CHECK (status IN ('active','removed')),
  invited_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(company_id,user_id),
  CHECK(company_id <> user_id)
);
CREATE INDEX company_members_user_idx ON company_members(user_id,status);
CREATE TABLE company_invitations (
  id uuid PRIMARY KEY,
  company_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL CHECK (role IN ('recruiter','viewer')),
  token_hash text UNIQUE,
  status text NOT NULL CHECK (status IN ('pending','accepted','revoked','expired')),
  invited_by uuid REFERENCES users(id) ON DELETE SET NULL,
  expires_at timestamptz NOT NULL,
  accepted_by uuid REFERENCES users(id) ON DELETE SET NULL,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX company_invitations_company_idx ON company_invitations(company_id,status,created_at DESC);
ALTER TABLE company_invitations ADD CONSTRAINT company_invitation_pending_token CHECK(status <> 'pending' OR token_hash IS NOT NULL);

-- Product collaboration and network entities (0.23 target schema completion).
CREATE TABLE projects (
  id uuid PRIMARY KEY,
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  skills jsonb NOT NULL DEFAULT '[]'::jsonb,
  commitment text NOT NULL,
  status text NOT NULL CHECK (status IN ('open','closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz
);
CREATE INDEX projects_owner_idx ON projects(owner_id,status);
CREATE TABLE project_applications (
  id uuid PRIMARY KEY,
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message text NOT NULL DEFAULT '',
  status text NOT NULL CHECK (status IN ('pending','accepted','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  UNIQUE(project_id,user_id)
);
CREATE TABLE connections (
  id uuid PRIMARY KEY,
  from_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason text NOT NULL,
  status text NOT NULL CHECK (status IN ('pending','accepted','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  CHECK(from_user_id <> to_user_id),
  UNIQUE(from_user_id,to_user_id)
);
CREATE INDEX connections_inbox_idx ON connections(to_user_id,status,created_at DESC);

-- Private beta invitations and tester feedback.
CREATE TABLE beta_invitations (
  id uuid PRIMARY KEY,
  email text NOT NULL,
  account_type text NOT NULL CHECK (account_type IN ('candidate','company')),
  token_hash text UNIQUE,
  status text NOT NULL CHECK (status IN ('pending','accepted','revoked')),
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  accepted_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  CHECK(status <> 'pending' OR token_hash IS NOT NULL)
);
CREATE INDEX beta_invitations_email_idx ON beta_invitations(email,status,expires_at);
CREATE TABLE beta_feedback (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  category text NOT NULL CHECK (category IN ('bug','confusing','idea','other')),
  area text NOT NULL DEFAULT '',
  message text NOT NULL,
  status text NOT NULL CHECK (status IN ('open','reviewed','accepted','declined')),
  reviewed_by uuid REFERENCES users(id) ON DELETE SET NULL,
  review_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz
);
CREATE INDEX beta_feedback_queue_idx ON beta_feedback(status,created_at DESC);
CREATE TABLE migration_import_log (
  id bigserial PRIMARY KEY,
  source_sha256 text NOT NULL,
  entity_name text NOT NULL,
  imported_rows integer NOT NULL CHECK(imported_rows >= 0),
  imported_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(source_sha256,entity_name)
);

-- Password reset tokens are one-time credentials; outstanding tokens are invalidated during migration.
CREATE TABLE password_reset_tokens (
  id uuid PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL
);
CREATE INDEX password_reset_user_idx ON password_reset_tokens(user_id,expires_at);
