# Passerelle vers un exécuteur isolé — alpha.13

## Ce qui est livré
- Une passerelle serveur distincte de la logique métier pour les deux exercices de code versionnés.
- Activation uniquement si `ZERIHLINK_RUNNER_URL` (HTTPS obligatoire) et `ZERIHLINK_RUNNER_TOKEN` (32 caractères minimum) sont configurés.
- Aucun mode local de secours : en l'absence de configuration, l'API répond `503 RUNNER_NOT_CONFIGURED` et aucun code n'est exécuté.
- Délai d'appel de 5 secondes, limite de cinq appels par candidat et par minute, source limitée à 12 000 caractères, sorties bornées.
- Le service externe reçoit un identifiant de tâche opaque, le code, le sujet/version et des paramètres de ressources ; aucun nom, email ou identifiant candidat n'est transmis.
- SQL : première défense en profondeur contre les instructions d'écriture et d'administration. Ce filtre lexical ne remplace jamais les droits SQL read-only du moteur isolé.
- Journal d'audit minimal : exercice, langage, statut et durée, jamais le code source ni les sorties.

## Contrat du service externe
`POST /v1/execute`, authentification Bearer, JSON : `jobId`, `exercise`, `source`, `fixtureVariant`, `limits`.
Réponse JSON attendue : `jobId` identique, `status` parmi `completed|timeout|rejected`, `stdout`, `stderr`, `tests[]`, `durationMs`.

## Conditions impératives avant activation
Le service d'exécution n'est **pas fourni ni activé** dans cette alpha. Il ne faut pas configurer ces variables avant d'avoir déployé et audité un exécuteur dédié. Celui-ci doit utiliser des conteneurs ou micro-VM éphémères non privilégiés, sans réseau sortant, sans secrets ni montage de données de production, FS en lecture seule sauf espace temporaire, limites CPU/mémoire/PID/temps/sortie, destruction garantie et tests d'évasion. Pour SQL, utiliser un jeu synthétique jetable, un utilisateur SQL strictement read-only, une transaction annulée systématiquement et un moteur configuré sans extensions/fonctions dangereuses.

La passerelle HTTPS ne constitue pas à elle seule une sandbox. L'activation reste bloquée jusqu'à audit indépendant du service distant et validation des scénarios d'attaque.


## Durcissement alpha.16
- La passerelle n’accepte que les réponses `application/json`.
- Le corps est lu en flux et plafonné à 64 Ko, même si l’en-tête `Content-Length` est absent ou mensonger.
- Les réponses mal formées, non JSON et surdimensionnées sont rejetées.
- Les redirections sont désactivées (`redirect: error`) pour empêcher le transfert du jeton Bearer vers une autre destination.
- Ces contrôles protègent la passerelle, mais ne remplacent pas l’audit de l’exécuteur isolé.
