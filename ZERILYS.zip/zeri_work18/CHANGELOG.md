## 1.9.0-alpha.20 — espace de travail Project Labs
- Ajout d'un formulaire structuré et bilingue de création de projet, avec champs validés et compensation conditionnelle pour les défis d’entreprise.
- Ajout d'une fiche projet interactive avec composition de l'équipe, candidatures reçues et accès au tableau de tâches.
- Ajout d'une route de consultation des candidatures réservée au propriétaire du projet.
- Le propriétaire peut accepter ou refuser les candidatures depuis l'espace projet ; les limites de capacité restent vérifiées côté serveur.
- Les membres acceptés et le propriétaire accèdent au tableau privé, peuvent créer des tâches, renseigner une échéance et suivre leur état.
- L'interface de travail est responsive et disponible dans les deux langues de l'application ; les contenus fournis par les membres sont échappés.
- Les tâches restent privées, ne figurent pas dans les listes publiques et les mutations sont journalisées.
- Limites : pas encore de messagerie, documents collaboratifs, notifications temps réel ou portfolio collectif.

## 1.9.0-alpha.15 — cohérence linguistique français / anglais
- Reprise de la couche i18n : traduction des contenus statiques et dynamiques dans les deux sens, avec restauration fiable du texte source lors du changement de langue.
- Ajout d'un bouton compact avec drapeau britannique pour passer à un anglais natif ; le drapeau français permet de revenir au français.
- Ajout de formulations anglaises naturelles pour les parcours candidats et entreprises, sans simple traduction littérale de l'interface française.
- Le français reste la langue par défaut ; la préférence de langue du compte reste persistante.

## 1.9.0-alpha.14 — compaction de la page publique

- Réduction des espacements verticaux entre les sections de découverte, collaborations, opportunités et intelligence.
- Titres de sections ramenés à une échelle plus modérée, avec une hiérarchie typographique plus équilibrée.
- Cartes, filtres, panneaux et zones de texte resserrés pour réduire le défilement sans retirer de contenu ni de fonctionnalité.
- Ajustements spécifiques mobile pour conserver une lecture confortable.

## 1.9.0-alpha.13 — passerelle contrôlée vers un exécuteur isolé et retrait de la console publique

- Suppression complète du bloc inférieur « Gestion de la confiance / Accès restreint » de la page d'accueil : diagnostics, modération, demandes de vérification, justificatifs, retours et invitations bêta individuelles ou groupées.
- Les fonctions et routes administratives côté serveur sont conservées et restent soumises à leurs contrôles d'accès ; seule leur interface intégrée à la page publique est retirée.
## 1.9.0-alpha.12 — premiers exercices techniques Python et SQL

- Ajout de deux exercices individualisés de code : nettoyage de données Python et analyse de commandes SQL.
- Interface de dépôt adaptée au code avec amorce, livrables et critères visibles.
- Soumission reliée à la revue humaine à l'aveugle ; aucune notation automatique.
- Aucun code candidat n'est exécuté. La frontière de sécurité et les prérequis d'un futur exécuteur isolé sont documentés dans `CODE_EXERCISES_ALPHA12.md`.

## 1.9.0-alpha.11 — guide de calibration des évaluateurs

- Ajout d’un guide opérationnel accessible depuis la console de revue.
- Repères détaillés pour les 16 critères des quatre cas pratiques : finance, commerce, recherche et ingénierie.
- Description des éléments observables, des signaux de maîtrise élevée et des lacunes importantes.
- Rappel des principes de neutralité, de prudence et de demande de seconde lecture.
- Le guide précise qu’il s’agit d’une base éditoriale pilote, pas d’une calibration psychométrique validée.

## 1.9.0-alpha.10 — revue à l’aveugle et calibration initiale

- La file de revue des cas pratiques ne transmet plus l’identifiant, le nom, l’intitulé professionnel ni la déclaration d’usage de l’IA du candidat.
- Chaque copie reçoit une référence de dossier opaque ; la route d’enregistrement continue de cibler l’épreuve sans exposer l’identité dans la file.
- Ajout de repères communs pour les niveaux 1 à 4 afin de réduire les écarts d’interprétation entre évaluateurs.
- Ajout d’une consigne rappelant de noter les éléments observables et de ne pas rechercher l’identité du candidat.
- Limite explicitée : une réponse rédigée peut contenir des indices auto-identifiants ; l’anonymisation est une réduction des biais, pas une garantie d’anonymat absolu.

## 1.9.0-alpha.8 — partage sélectif des évaluations

- Le partage des résultats est désactivé par défaut et indépendant de l’envoi d’intérêt.
- Le candidat sélectionne les évaluations précises autorisées pour chaque candidature.
- Consentement versionné, horodaté et journalisé; retrait possible à tout moment.
- L’espace entreprise ne reçoit que les évaluations expressément autorisées pour la candidature concernée.
- Les réponses aux questionnaires ne sont pas exposées; les cas pratiques ne sont transmis que sur sélection explicite.
- Les anciens accords globaux ne sont pas considérés comme une autorisation granulaire.

## 1.9.0-alpha.7 — espace de revue humaine des cas pratiques

- Ajout d’une file de revue réservée aux comptes explicitement autorisés par `ZERIHLINK_REVIEWER_EMAILS`.
- Consultation sécurisée des réponses, paramètres individualisés, version du cas et déclaration d’usage de l’IA.
- Évaluation critère par critère : note de 1 à 4, commentaire obligatoire, décision motivée et synthèse obligatoire.
- Traçabilité de l’identité du réviseur et de la date de revue ; impossibilité de modifier une décision déjà enregistrée.
- Le candidat retrouve le retour détaillé dans son historique privé ; aucun résultat de cas pratique n’est exposé sur son profil public.
- Smoke authentifié étendu : accès candidat refusé à la file, accès réviseur autorisé, revue enregistrée, attribution et protection contre la double revue vérifiées.
- Validation locale : 214/214 tests, contrôle syntaxique, smoke général, évaluations, cohorte ouverte de 50 membres, préférences linguistiques et cohorte sur invitation.

## 1.9.0-alpha.4 — Politique IA par offre

- L’entreprise choisit une politique IA par opportunité : autorisée, non autorisée pendant les évaluations, ou usage attendu et évalué.
- La règle et les précisions de l’employeur sont visibles avant la candidature, dans les offres publiques et l’espace entreprise.
- Cette préférence est une déclaration de cadre d’évaluation, pas un dispositif technique de surveillance ni une garantie anti-triche. Elle ne modifie pas rétroactivement les évaluations personnelles déjà réalisées.

## 1.9.0-alpha.2 — transparence des stages et alternances

- Les pages publiques des entreprises transmettent désormais les informations structurantes des stages et alternances : date de début, durée, rythme, gratification/rémunération, encadrement et niveau d’études indicatif.
- Les cartes d’opportunités côté candidat et les vues de gestion côté recruteur affichent ces informations de manière compacte et lisible.
- Les familles graduate programme, VIE et projet de recherche sont désormais acceptées par le contrôle d’intégrité des données.
- Ajout de tests dédiés à la sérialisation publique, à l’affichage des informations et à la validation des types d’opportunités.
- Validation locale : 201/201 tests, contrôle syntaxique, smoke applicatif, évaluations, cohorte ouverte de 50 membres, préférences linguistiques et cohorte sur invitation.

## 1.9.0-alpha.1 — élargissement des publics et des domaines

- Élargissement du positionnement aux talents qualifiés de Bac+4 à la recherche avancée : ingénierie, numérique, finance, commerce/management, sciences et recherche.
- Bibliothèque de connaissances étendue de 3 à 9 évaluations (comptabilité/finance, statistiques, ingénierie systèmes, stratégie, méthodologie de recherche, gestion de projet en complément de SQL, Python et risque).
- Métadonnées de tests indiquant qu'il s'agit de questionnaires de connaissances, avec publics cibles.
- Ajout d'un niveau de formation indicatif aux offres ; il ne constitue pas un filtre automatique.
- Mise à jour de la promesse de la page d'accueil et du formulaire d'opportunité en français.
- Documentation du nouveau périmètre, des parcours stage/alternance et de la stratégie d'évaluations pratiques.

## Mise à jour éditoriale — Vitrine française simplifiée (1.6.0-alpha.1)

- Refonte de la page d’accueil : proposition de valeur raccourcie, centrée sur les actions réelles (rechercher des profils, consulter des opportunités, rejoindre ou créer un projet).
- Suppression des paragraphes marketing redondants et des promesses répétées autour du potentiel, de l’intelligence et du réseau.
- Réduction du discours sur l’intelligence marché au bénéfice des usages concrets : recherche par compétences, découverte de profils et consultation des réalisations.
- Renforcement de la rédaction française native via le dictionnaire de langue ; l’anglais reste disponible par sélection explicite.
- Conservation des espaces connectés, du parcours candidat, des outils recruteur, des contrôles de confidentialité et des mentions de confiance.
- Tests : 181/181 unitaires passés ; contrôles syntaxiques, smoke applicatif, smoke bêta et préférence linguistique passés.

## Version 1.6.0-alpha.1 — Contrôle de concurrence PostgreSQL

- Ajout d’un contrôle optimiste de révision (compare-and-swap) sur chaque écriture PostgreSQL.
- Une instance dont l’état est devenu obsolète ne peut plus écraser un snapshot plus récent : l’écriture échoue explicitement et impose un redémarrage pour recharger l’état autoritaire.
- File d’écriture ordonnée conservée au sein d’une instance ; tests dédiés aux révisions attendues et aux conflits inter-instances.
- Cette protection prévient la perte silencieuse de mises à jour, mais ne constitue pas une architecture multi-instance prête pour la production.

## Version 1.5.0-alpha.1 — Persistance PostgreSQL activable

- Ajout d’un adaptateur de persistance PostgreSQL JSONB activable explicitement par `ZERIHLINK_STORAGE=postgres`.
- Chargement de l’état depuis PostgreSQL au démarrage ; échec fermé si la base n’est pas joignable.
- Écriture atomique et attendue avant la réponse API, avec file d’attente ordonnée et numéro de révision.
- Conservation du stockage JSON comme mode local par défaut.
- Ajout de tests de persistance, d’échec fermé et d’ordre des écritures.
- Limites documentées : snapshot JSONB plutôt que dépôt relationnel normalisé, médias avatars encore locaux, pas de multi-instance.

## Version 1.4.0-alpha.1 — Préparation contrôlée de PostgreSQL

- Ajout d’un importeur PostgreSQL explicite, protégé par un précontrôle et un indicateur `--apply`.
- Application transactionnelle du schéma et des données, vérification de la base cible et contrôle du nombre de comptes importés.
- Ajout d’un runbook de migration et de tests de garde-fous.
- Le runtime reste sur JSON : aucune bascule de production n’est revendiquée dans cette version.

## Version 1.1.0-alpha.1 — Talent Intelligence
- Repositionnement spécialisé finance, IA et data.
- Navigation publique rétablie et simplifiée : Talents, Opportunités, Collaborations, Intelligence marché.
- Raccourcis de recherche spécialisés reliés à la recherche de profils existante.
- Retrait de l’univers trading et des modules de marché financier du produit unifié.
- Documentation de la vision produit, du modèle économique hypothétique et des prérequis de lancement commercial.

## Version 1.0.0-rc.4 — Déploiement Render sécurisé

- Retient Render comme cible de déploiement de la première bêta privée, en s'appuyant sur le Blueprint déjà présent.
- Ferme les inscriptions par défaut dans `render.yaml` (`ZERIHLINK_ALLOW_SIGNUP=false`) ; le verrou juridique reste indépendant et fermé.
- Clarifie le parcours de déploiement, les coûts à vérifier avant création du service et du disque, et les contrôles à réaliser après mise en ligne.
- Ajoute des tests de non-régression sur les valeurs sûres du Blueprint, le disque persistant et le contrôle de santé.
- Aucun service Render n'a été créé et aucun frais n'a été engagé : le déploiement nécessite le compte et le dépôt privé du propriétaire.

# Journal des modifications

## Version 1.0.0-rc.3

- Le rapport de lancement distingue désormais la configuration d’inscription sans invitation de l’autorisation juridique effective : l’état affiché indique explicitement que toute inscription reste bloquée tant que le verrou juridique n’est pas levé.
- Tests de non-régression du rapport de préouverture renforcés.

# Changelog

## 1.9.0-alpha.18 — 2026-11-13

- Project Labs : typologie structurée des projets (collectif, pédagogique, recherche, défi d'entreprise), durée, taille d'équipe, livrables, compétences et compensation affichés.
- Protection des candidats : publication d'un défi d'entreprise commercial bloquée sans rémunération ou prise en charge des frais explicitement déclarée.
- Constitution d'équipe : le créateur occupe une place et le serveur empêche les acceptations dépassant la capacité maximale.
- Interface : cartes projets enrichies, création guidée des projets (type, durée, capacité, livrables, compensation) et libellés français natifs.
- Tests : validation des champs, limites, compensation des défis commerciaux et capacité d'équipe.


## 1.0.0-rc.3 — 2026-11-13

- Harmonisation française des parcours de candidature côté candidat et côté entreprise : statuts, historique, retrait, notes internes et états vides.
- Ajout de tests de non-régression dédiés aux deux espaces de suivi des candidatures.
- Conservation des validations serveur, de la synchronisation du profil et du verrou juridique de lancement de rc.1.

## 1.0.0-rc.1 — fiabilisation du profil et cohérence des compétences

- Validation serveur des URL de profil : HTTPS obligatoire, hôte requis et identifiants intégrés refusés ; une URL vide reste autorisée pour retirer le site.
- Validation stricte des valeurs de disponibilité et de visibilité avant toute mutation du profil.
- Alignement des niveaux de compétence affichés sur les valeurs réellement enregistrées par l’API (`learning`, `practitioner`, `advanced`, `expert`) avec des libellés français natifs.
- Localisation des libellés de preuves dans la constellation des compétences.
- Ajout de tests de non-régression ciblant ces contrats API et UI.

## 1.0.0-rc.1 — synchronisation transversale du profil
- Ajout d'un rafraîchissement centralisé des vues dépendantes du profil à partir des données canoniques renvoyées par le serveur.
- Après modification de l'identité, actualisation de Human Orbit, des réalisations, de la progression, de la découverte, des collaborations et des opportunités.
- Même synchronisation après ajout d'une compétence, ajout d'une réalisation et changement ou suppression de photo.
- Ajout de tests de non-régression dédiés à la cohérence des surfaces et à l'alignement des métadonnées.
- Aucun changement au verrou juridique de lancement.

## 0.98.0 — découverte et collaborations en français natif

- Correction du rendu des cartes de découverte : libellés d’état, localisation, réalisations, complémentarité et mise en relation passent par la couche de langue.
- Localisation des compteurs et actions de pagination du réseau, y compris les états de chargement et d’erreur.
- Localisation des cartes de collaborations : disponibilité, nombre de personnes intéressées, auteur, modalités et action d’exploration.
- Conservation du texte saisi par les membres sans traduction automatique et échappement HTML des contenus affichés.
- Ajout de quatre tests de non-régression dédiés ; mise à jour des tests historiques qui vérifiaient l’ancien libellé de pagination.
- Validation complète : 144 tests automatisés et tous les scénarios `test:release` réussis.
- Le contrôle de lancement reste non conforme : 12 blocages et 4 avertissements, notamment hébergement, sauvegardes hors site, validation juridique et recette humaine.

## 0.90.0 — Consolidation expérience profil et internationalisation

- Harmonisation des libellés français des huit dimensions Human Orbit et du profil public.
- Traduction des actions de partage, signalement, blocage, photo, compétences et réalisations.
- Vérification de la persistance du profil : confirmation serveur, rechargement des données et actualisation des vues dépendantes.
- Ajout de tests de non-régression sur la langue française, le choix explicite de l’anglais et le cycle d’enregistrement du profil.

## 0.87.0 — homogénéisation des parcours dynamiques en français

- Extension du dictionnaire français aux états du réseau, aux collaborations et aux principaux retours d’action du compte.
- Conservation de l’anglais lorsque cette langue est explicitement sélectionnée.
- Ajout de tests ciblés sur les libellés dynamiques et alignement des métadonnées de version.

## 0.83.0 — lisibilité Human Orbit sur mobile
- Agrandissement du centre d'identité sur téléphone et amélioration des tailles de texte professionnelles.
- Lisibilité renforcée des satellites, des compétences et des indications d'exploration.
- Meilleur retour à la ligne pour les libellés longs et ajustement de la zone de complétion.
- Ajout de tests de non-régression dédiés à cette recette responsive.

# Journal des modifications

## 0.82.0 — parcours membres en français

- Complément de la couche française pour les états dynamiques du profil, des compétences, des réalisations, des mises en relation, des notifications et des opportunités.
- Ajout de tests de non-régression ciblés sur ces parcours et maintien de la confirmation serveur lors de l’enregistrement du profil.
- Les contrôles de lancement externes et juridiques restent indépendants et ne sont pas levés par cette version.

## 0.77.0 — cohérence française des interactions réseau

- Étendu le dictionnaire français aux contenus générés dynamiquement dans la découverte des membres, les cartes de profils, les collaborations et la constellation des compétences.
- Harmonisé les libellés du menu de profil, les états vides, les actions de connexion et les messages de chargement.
- Conservé l’anglais comme langue alternative explicite ; le français reste la langue initiale.
- Aucun changement des règles d’accès, de confidentialité ou du verrou juridique de lancement.

## 0.76.0 — finition de l’interface d’identité en français

- Extension du dictionnaire français aux libellés statiques de Human Orbit, à l’éditeur de profil et aux fenêtres de connexion.
- Harmonisation des termes de navigation, des actions et des états visibles dans l’espace identité.
- Le choix anglais reste disponible et conserve les libellés d’origine.

# ZERILYS — Journal des versions

# ZERILYS — journal des versions

## 0.75.0 — accessibilité et confort d’utilisation

- Généralise un indicateur de focus clavier visible sur les commandes et liens interactifs.
- Renforce les zones tactiles sur les appareils à pointeur tactile.
- Respecte globalement la préférence système de réduction des animations et transitions.
- Ajoute des tests de non-régression dédiés à ces comportements et aligne les références de version.

## 0.65.0 — Profil central et expérience française
- Agrandissement du cœur Human Orbit et amélioration de la lisibilité du nom, de la présentation professionnelle et du lieu.
- Affichage des compétences, centres d’intérêt et contributions déclarées dans le cœur du profil, y compris sur mobile.
- Extension du dictionnaire français aux champs du formulaire, aux états des satellites et aux interactions du réseau.
- Conservation des informations saisies par l’utilisateur sans traduction automatique des contenus personnels.
- Le verrou juridique de production reste inchangé.


## 0.64.0 — Refonte de lisibilité Human Orbit
- Enregistrement du profil renforcé : fusion de la réponse serveur, relecture du profil et rafraîchissement de toutes les vues après sauvegarde.
- Centre de l’Orbit agrandi sur ordinateur, avec nom, fonction, localisation et repères de compétences plus lisibles.
- Refonte visuelle des satellites et du panneau de progression : cartes plus sobres, hiérarchie typographique renforcée et intitulés français.
- Traductions françaises étendues aux panneaux dynamiques du profil, aux états et aux commandes fréquemment affichés.
- Ajustements spécifiques aux petits écrans pour préserver la lisibilité du portrait central.
- Le verrou juridique de production reste inchangé.

## 0.31.0 — Beta hardening and documentation alignment
- Hardened static resource handling: missing assets return HTTP 404 instead of the application shell.
- Rejects malformed percent-encoded request paths with HTTP 400 without terminating the server.
- Added an isolated HTTP hardening smoke suite to the full release test command.
- Reconciled the 50-tester guide and release documentation with the actual 0.30 product capabilities and current operational boundaries.

## 0.30.0 — Privacy by default
- New personal and company accounts start with private personal-profile visibility.
- Candidate discovery and public profile URLs remain unavailable until the member explicitly chooses public visibility.
- Candidates can still browse verified opportunities and share their profile for a specific application.
- Registration and the Professional Universe now explain the active privacy state.
- Existing members' visibility choices are not silently changed.

## 0.29.0 — Company verification and trusted opportunities
- Added company verification submissions with business email, HTTPS website and public evidence note.
- Added reviewer queue and approve/reject workflow with mandatory review notes.
- Unverified companies' published offers are hidden from candidate discovery and company pages; interest is blocked until approval.
- Changes to company name, industry or website invalidate verification and hide offers until re-review.
- Private verification details are excluded from public responses and included in account export and a dedicated PostgreSQL target field.

## 0.28.0 — Transactional email and password recovery
- Added a configurable authenticated email webhook for private beta invitations.
- Invitations are sent by email when configured; manual delivery remains available, including fallback if the webhook fails.
- Added non-enumerating password reset requests, hashed single-use tokens, 30-minute expiry and session revocation after reset.
- Added password recovery UI and a release smoke test using a local mock webhook.
- Outstanding password reset tokens are intentionally invalidated rather than migrated to PostgreSQL.

## 0.27.0 — Beta terms, privacy notice & consent
- Added explicit acceptance of the beta terms and acknowledgement of the privacy notice during registration.
- Added versioned consent records with timestamps and account-owner export.
- Existing accounts without current consent are prompted and blocked from other authenticated operations until they accept, export or delete/sign out.
- Added draft terms and privacy notice pages, clearly marked as not legally approved.
- Added a server-side legal approval switch; registration is disabled by default until the operator enables it after legal review.
- Added smoke coverage for legacy-account gating and missing-consent rejection.

## 0.26.0 — Beta release gate & 50-tester plan
- Added a production preflight covering secrets, reviewer access, invitation gate, trusted proxy, persistent storage, version consistency, live health, data integrity and backup verification.
- Added explicit manual gates for browser QA, legal review, reviewer coverage and off-site backup/restore.
- Added a complete staged operating plan for the first 50 testers.
- Added `npm run test:release` to run the complete automated suite.
- The preflight deliberately does not mark the public launch ready; deployment and manual gates remain outstanding.

## 0.25.0 — Guided activation path
- Added transparent readiness criteria for candidate and company identities.
- Added an in-product activation checklist in the Professional Universe with direct actions to complete missing signals.
- Candidate guidance covers identity, capabilities, evidence, intentions and discoverability choice.
- Company guidance covers company identity, first opportunity and required capabilities.
- Readiness is a setup checklist, not a popularity or hiring score.

## 0.24.0 — Data integrity preflight
- Added a reusable data integrity inspector for core references, permissions, application states and audit-chain integrity.
- Added `npm run validate:data` for offline preflight checks and `npm run smoke:data` for synthetic valid/corrupt store tests.
- Exposed integrity status and error counts in the reviewer-only operations dashboard.
- Improved account deletion cleanup for private-note authors and reviewer references.

## 0.23.0 — PostgreSQL migration package
- Completed the target relational schema for collaboration, connections, company teams, beta invitations and tester feedback.
- Added a JSON-to-PostgreSQL SQL export tool with source checksum, SQL escaping, deterministic status-event IDs and per-entity import counts.
- Added synthetic export smoke coverage.
- Corrected no runtime storage switch: JSON remains the active store; no PostgreSQL connection/import has been executed.

## 0.22.0 — Reverse-proxy-aware rate limiting
- Added an explicit trusted-proxy mode for deriving the client IP from the rightmost X-Forwarded-For address.
- Kept proxy headers ignored by default unless `ZERIHLINK_TRUST_PROXY=true` is set.
- Configured the Render blueprint to enable trusted-proxy mode behind its reverse proxy.
- Added smoke coverage proving that spoofed leftmost addresses cannot split a client's rate-limit bucket.

## 0.21.0 — Private beta feedback loop
- Added authenticated tester feedback submission with category and product area.
- Added personal feedback history and reviewer-only triage queue.
- Reviewers can mark feedback reviewed, accept for follow-up or decline, with an optional internal note.
- Included feedback in account export and removed it during account deletion.
- Added smoke coverage for submission, access control, review and deletion cleanup.

## 0.20.0 — Operational readiness & storage guard
- Added a data-directory process lock to prevent concurrent app instances from sharing the JSON store.
- Added reviewer-only operational diagnostics for storage, membership counts, moderation queues and local backup integrity.
- Added operational health panel to the Trust Operations console.
- Added duplicate-instance and backup-health smoke coverage.

## 0.19.0 — Controlled beta invitations
- Added reviewer-created, single-use invitations bound to one exact email address, with expiry and revocation.
- Added invitation management to the restricted Trust Operations console.
- Registration now accepts either the configured shared beta code or a valid personal invitation token.
- Fixed the health endpoint version so it reports the actual application release.
- Exposed the shared-code and personal-token fields correctly in the registration interface.

## 0.18.0 — Account security & backup integrity
- Added active-session listing, revocation of other sessions and a 10-session account limit.
- Added authenticated password changes with current-password verification and revocation of other sessions.
- Added checksummed local backups, backup verification and guarded atomic restore with pre-restore safety copies.
- Added automated backup/restore smoke coverage.
- Off-site backup and PostgreSQL remain outstanding.

## 0.17.0 — Trust & Safety operations console
- Added a restricted reviewer interface for member reports and submitted evidence.
- Added human review actions for report resolution and evidence verification/rejection, with optional notes.
- Reviewer visibility is still enforced by server-side reviewer allowlist checks; the UI hides itself on authorization failure.
- Added a reviewer workflow guide and QA notes.

## 0.16.0 — Data portability & account control
- Expanded the JSON account export to cover candidate/company opportunities, applications, evidence, connections, notifications, blocks, reports, memberships and related audit events.
- Added complete operational cleanup for account deletion, including offer applications, company data, memberships, invitations, notifications, reports and blocks.
- Added a Data & Privacy interface with account export and explicit account deletion confirmation.
- Retained opaque audit records for accountability; legal retention and erasure policy still requires formal review.

## 0.15.0 — Company workspace interface
- Added an in-product company team panel for owners and invited members.
- Added invitation creation with secure one-time token display, team member listing and owner revocation controls.
- Added workspace selection for members belonging to multiple companies.
- Applied role-aware UI: viewers see read-only opportunities and applications; recruiters can manage recruitment workflows; only owners edit company identity and invite/remove members.
- Added smoke coverage for the in-product controls and automatic single-workspace resolution.

## 0.14.0 — Company workspace & team roles
- Added owner-controlled, single-use, seven-day company invitations.
- Added recruiter and read-only viewer roles with server-side permission checks.
- Enabled team members to share the company offer and application workspace.
- Updated PostgreSQL target schema and documented invitation/permission semantics.
- Email delivery and PostgreSQL runtime integration remain out of scope and are explicitly not claimed.

# Changelog

## 0.11.0 — Opportunity lifecycle & consent-based applications
- Added candidate application history and status visibility.
- Candidates can withdraw interest; withdrawn applications disappear from the company inbox and revoke company access to application profile details.
- Private candidates can apply to an individual offer. Expressing interest explicitly shares their professional profile with that company for that offer only.
- Companies can review applications, move them through review/interview/declined, and close or republish offers.
- Added editable company identity workspace.
- Added integration coverage for private-profile consent, company status updates, withdrawal, access revocation and offer lifecycle.

## 0.10.0 — Company identities & opportunity constellation
- Added candidate/company account types at registration.
- Added company identity fields and company-only structured opportunity publishing.
- Added opportunity discovery with transparent skill/intent overlap reasons; no hiring suitability score.
- Added candidate interest flow and company-side interest overview.
- Added Global Pulse as a separate editorial area. Live prices are intentionally absent until a licensed market-data provider is selected.
- No social feed, personal posts, likes, or political-content publishing.
- JSON persistence schema automatically initializes new company, offer and application collections.


## 0.12.0 — Company Universe & Notifications
- Public company pages with structured identity and published opportunities only.
- In-app notifications for new candidate interest and application status changes, with per-user read state.
- Company links from opportunity listings; no social feed or freeform posts.

## 0.14.0 — Recruitment Workflow & Data Foundation
- Candidate-visible application status timeline.
- Company-only internal notes attached to an application; never included in candidate responses.
- Status transitions recorded with actor type and timestamp; internal notes are erased when a candidate withdraws consent.
- PostgreSQL relational schema draft and migration planning documentation; the running application still uses the JSON store.

## 0.32.0 — Candidate-centred orbital landing experience
- Replaced the generic global-network hero with a futuristic candidate identity at the centre of an interactive orbital field.
- Added six concise satellites: capabilities, proof, trajectory, intent, network, opportunities and impact, each linking to the corresponding platform area.
- Reduced the landing copy and prioritised the candidate identity and registration action.
- Added responsive desktop/mobile styling and reduced-motion support while preserving existing application workflows.

## 0.33.0 — Release version consistency
- Aligned server health/version metadata and release smoke expectations with the package and VERSION file.
- Added regression coverage so preflight can detect version drift before a beta release.

## 0.34.0 — Candidate-first entry and profile access
- Replaced the long public landing-page scroll with a focused, single-screen candidate identity entry.
- Kept the candidate orbit as the central visual, shortened the supporting copy and removed the scroll-oriented secondary CTA.
- Hid the secondary discovery, project, opportunity and market sections from the public landing page without deleting their application markup or internal workflows.
- Replaced the logged-in initials-only avatar with an explicit “My profile” control that opens the candidate identity modal.
- Tightened mobile layout and made the identity modal easier to navigate on smaller screens.
- Version metadata aligned across package, VERSION and server health response.


## 0.35.0 — Real portraits and member-wide profile access
- Added member photo upload, replacement and removal with client-side 512px JPEG compression, strict server-side MIME/signature checks and a 500 KB stored-image limit.
- Displayed real profile photos in the member control, personal identity core, network cards and public/member profile views.
- Refined the Human Orbit portrait treatment with restrained graphite/silver styling and subtle motion rather than strong neon effects.
- Authenticated members can now discover and open every candidate profile, including profiles not exposed to anonymous visitors; profile blocks remain respected.
- Anonymous visitors continue to see only profiles explicitly set to public. Private visibility therefore limits anonymous/public discovery, not member-to-member access.


## 0.36.0 — Human Orbit premium visual refinement
- Reworked the personal and public identity surfaces around a restrained graphite, silver and cool-neutral palette.
- Reduced cyan/violet glow effects across orbit rings, capability satellites, navigation nodes and profile inspectors.
- Preserved the real portrait as the dominant central anchor with a subtle, non-distorting motion treatment.
- Added a reduced-motion accessibility override for identity animations and transitions.


## 0.37.0 — Dedicated profile media storage
- Moved member portraits out of the main JSON profile store into separate, access-controlled media files on the persistent data volume.
- Added authenticated media delivery, private-profile and block-aware image access, atomic photo replacement/removal, and safe filename validation.
- Added automatic migration of 0.35 embedded profile photos into media files without losing existing portraits.
- Updated account export to include the original photo data and backups to embed/restore profile media with checksummed manifests.
- Added an integration smoke that restarts the server and verifies both the profile photo and session remain available.


## 0.38.0 — Member discovery inside Human Orbit
- Connected the NETWORK orbit node to a live member explorer inside the candidate's own profile universe.
- Added in-profile search by member name, professional skill and location, with real profile photos and direct profile opening.
- Search results include private profiles for signed-in members, while existing block and consent rules remain enforced by the API.
- Removed the placeholder edit-identity action from the NETWORK inspector so it now performs the advertised discovery action.


## 0.39.0 — One-click profile portrait setup
- Moved the hidden photo input into the visible profile modal so the central Human Orbit portrait can open the photo picker directly.
- Added a subtle “ADD PHOTO” cue when no portrait exists and a “CHANGE” cue on hover when a portrait is already set.
- Kept the full profile editor's add/change/remove controls; photo upload now requires one less step from the central profile view.


## 0.40.0 — Progressive member discovery
- Added a “Load more profiles” action to the in-profile NETWORK explorer.
- Member search results now reveal in batches of seven instead of stopping after the first seven profiles.
- The explorer preserves its scroll position as additional profiles are revealed and continues to respect the server's visibility and block filters.


## 0.41.0 — Mobile Human Orbit refinement
- Reworked the personal profile universe for narrow screens so the portrait and all seven navigation signals fit inside the viewport.
- Reduced orbit diameters, node sizes and typography while preserving readable touch targets and the graphite/silver visual system.
- Hid secondary skill satellites on small screens; capabilities remain available through the dedicated orbit node.
- Tightened the profile inspector, network explorer and bottom action area for mobile navigation.


## 0.42.0 — Mobile public member identity
- Refined the public/member profile modal for narrow phones: compact portrait header, smaller orbital stage, scaled satellites and a more usable inspector.
- Reflowed profile actions into a wrapped footer so connect, report, block and share controls remain reachable.
- Added extra-small phone adjustments for 420px and below.


## 0.43.0 — Shareable public identity pages
- Added crawler-readable `/p/:id` pages for public candidate profiles with Open Graph and Twitter metadata, canonical URL, profile headline/description and real profile photo when available.
- Public profiles share a public preview link; private profiles share a member-only link and remain unavailable to anonymous visitors.
- Member-only profile links now prompt for sign-in and resume the requested profile after authentication or required consent.
- Added `ZERIHLINK_PUBLIC_URL` as the canonical production origin for social preview metadata.


## 0.44.0 — Shared-profile conversion and fast opening
- Added a clear `Join to connect` action to public member profiles for signed-out visitors.
- After registration or sign-in, the app returns the new member to the profile they were viewing.
- Public share links now open the requested identity before unrelated discovery and opportunity requests finish loading.
- The join action is hidden for signed-in members, who retain the direct connect/report/block actions.


## 0.45.0 — Server-side member discovery pagination
- Replaced the fixed 50-profile discovery ceiling with validated cursor/offset pagination, total counts and `hasMore` metadata.
- The NETWORK explorer requests additional server pages as the member cohort grows, while continuing to reveal results seven at a time.
- Added request sequencing so a slower previous search cannot overwrite a newer query.
- Preserved name/skill/location filtering, match ranking, private member access, consent gating and block exclusions across every page.


## 0.46.0 — First-cohort 50-member validation
- Added an automated 50-account cohort smoke test with unique proxy client IPs to exercise the beta registration flow under realistic per-client rate limiting.
- Validated that one member can discover and open all 49 other private candidate profiles across three cursor pages.
- Validated private profile photo delivery to a signed-in member and denial to anonymous visitors.
- Uploaded ten real-format media payloads and verified they remain separate from the main JSON user store.
- Added cohort registration, discovery and store-size timing to the release test report.


## 0.47.0 — First-cohort launch kit and stronger preflight
- Added a production environment template, closed-beta deployment runbook and first-50-tester guide.
- Updated the Render blueprint with canonical public/deployment URLs and explicit human release acknowledgements.
- Preflight now verifies the writable avatar media directory, live avatar references and avatar inclusion in the latest checksummed backup.
- Added a warning when the canonical public HTTPS origin is not configured.
- Added an explicit persistent-volume acknowledgement for non-Render hosting paths; the acknowledgement does not substitute for a real persistent disk.


## 0.48.0 — Safe backup rotation
- Added configurable backup retention (default 14, allowed 2–100) and prune older backup/manifest pairs only after a new backup is fully written.
- Incomplete orphan backup files and orphan manifests are cleaned during the next successful rotation.
- Backup verification and preflight now verify both embedded photo counts and total photo bytes.
- Added a retention smoke covering pruning, manifest pairing and rejection of unsafe retention values.


## 0.49.0 — Invitation-controlled first cohort
- Upgraded the 50-member cohort smoke to use a reviewer account and 50 individual one-time invitations instead of open registration.
- Each invited tester registers using their email-bound personal invitation; the cohort test confirms all invitations are consumed.
- The synthetic deployment now enforces the shared beta gate and disables email webhook delivery so personal invitation tokens are exercised directly.


## 0.50.0 — Bulk beta invitations
- Added a reviewer-only bulk invitation endpoint for up to 50 unique email addresses, with all-or-nothing validation before creating invitations.
- Each address receives an email-bound, single-use token; duplicate addresses, existing accounts and pending invitations are rejected before any batch is created.
- Optional email delivery runs in small batches; failed or unavailable delivery returns the one-time tokens for private manual distribution.
- Added a reviewer console form to paste a cohort list, create invitations in one action and copy manual tokens as an email/token list.
- Upgraded the 50-member cohort smoke to exercise the bulk endpoint end-to-end.


## 0.51.0 — Invitation batch tracking
- Bulk invitations now share a batch ID, allowing reviewers to track a cohort after tokens are redeemed.
- Reviewer invitation overview now reports total, pending, accepted, revoked and expired counts, plus per-batch registration progress.
- Pending invitations remain individually revocable; raw tokens are never included in batch history.
- The 50-member cohort smoke confirms the batch moves from 50 pending to 50 accepted registrations.


## 0.52.0 — Accessible profile and modal navigation
- Added accessible dialog semantics, initial focus, focus restoration and keyboard focus trapping across application modals.
- Escape closes ordinary dialogs but cannot bypass the mandatory legal-consent gate.
- Orbit nodes expose their selected state through `aria-pressed`; avatar upload status is announced to assistive technology.
- Added high-contrast keyboard focus indicators and a global reduced-motion preference that suppresses non-essential animation and transitions.


## 0.53.0 — Remote deployment acceptance check
- Added a read-only remote acceptance script for deployed version, security headers, invitation gate, anonymous profile privacy, static assets and unknown profile/avatar denial.
- Optional public/private profile IDs let the operator verify actual share metadata and anonymous private-profile denial without supplying credentials.
- Added a local production-mode integration smoke to exercise the remote check before deployment.
- Added `npm run check:remote` for the real host and included the local integration in `npm run test:release`.


## 0.54.0 — Private beta release candidate
- Consolidated the first-50-tester invitation email, updated tester guide, final launch checklist and release-candidate evidence report.
- Added a single reference point for the 13 remaining deployment/legal/operations blockers and the known single-instance JSON and data-licensing limitations.
- Updated the release package and remote acceptance version to 0.54.0.


## 0.56.0 — French-first internationalization

- French is the default product language for the first French-speaking launch cohort.
- First-visit language follows the browser's preferred language when supported; otherwise the experience defaults to French. This avoids unnecessary IP-based geolocation.
- A persistent FR / EN language selector is available in the top navigation.
- The language preference is stored locally and can be changed at any time; switching language restores the original source strings before applying the selected language.
- Added a curated French product vocabulary and native French copy for the landing experience, account creation, candidate profile, opportunities, network, company workspace, notifications, security and account controls. Dynamically rendered interface content is translated as it appears.
- Server error messages displayed in the interface use the same translation catalogue where a reviewed French equivalent exists.
- Beta Terms and Privacy Notice are now written in French for the first cohort, while remaining explicitly marked as legal drafts awaiting qualified review.
- Standard registration remains invitation-free. The separate legal approval gate remains active and must not be bypassed.


## 0.57.0 — French-first language refinement

- Extended reviewed French wording across remaining candidate, network, opportunity, company and reviewer flows.
- Added FR / EN locale-aware date and time formatting.
- Visible data panels refresh after a language change so date presentation follows the selected language.
- Member-authored content remains unchanged and is not automatically translated.


## 0.58.0 — Open registration cohort validation

- Added a dedicated 50-member end-to-end smoke using open registration without invitation tokens.
- Verified cross-member access to all 49 other private profiles, pagination and avatar access boundaries.
- Kept optional invitation cohort validation separate from the standard open signup path.


## 0.59.0 — Account language preference

- Saved the selected FR / EN language to the member account for cross-device continuity.
- Kept language preference private from other members and included it in account export.
- Added validation and persistence smoke tests.


## 0.60.0 — Email confirmation

- Added optional single-use email confirmation links for open registration when transactional email is configured.
- Added resend and delivery-failure recovery paths without blocking account creation.
- Kept verification state private and included token cleanup in account deletion.


## 0.61.0 — Open signup abuse controls

- Added a dedicated smoke test for per-client registration rate limiting (20 registration attempts per minute, while login and password-reset endpoints keep the stricter authentication limit).
- Documented safe reverse-proxy trust configuration.


## 0.62.0 — French deployment readiness

- Added a French operator-facing launch preflight report.
- Added a French Render / generic hosting deployment guide and explicit operational gates.

## 0.63.0 — Local beta test mode
- Adds an explicit local-only switch to test account registration without the legal approval gate.
- The switch is ignored automatically whenever `NODE_ENV=production`; the production legal gate remains unchanged.
- Adds French setup and safety instructions in `docs/TEST_BETA_LOCALE_0_63.md`.


## 0.66.0 — Human Orbit clarity and French-first profile interface
- Renforced the central identity hierarchy and readable profile facts on desktop and mobile.
- Expanded French UI coverage for profile editing, availability, visibility, capability and evidence actions.
- Refined the lower profile-completion layer and reduced decorative weight.
- Preserved the existing server-side registration/legal safeguards.
- Automated checks required before distribution: `npm test` and `npm run check`.

## 0.67.0 — French-first profile experience

- Expanded the French translation dictionary for dynamically rendered candidate, member-network, opportunity, company and notification panels.
- Improved the Human Orbit identity anchor dimensions and retained legibility on mobile breakpoints.
- Added regression coverage for profile-save refresh flow, French dynamic surfaces, Human Orbit sizing and the production legal registration lock.
- Validation: 73 automated tests pass; JavaScript syntax checks pass.
- Launch preflight remains intentionally NOT READY: 12 blockers and 4 warnings remain, including legal review, production secrets, persistent storage, backups, moderation and real-device QA.


## 0.68.0 — Release validation consistency

- Corrected stale version expectations in local smoke tests that still expected 0.66.0 despite the 0.67.0 application build.
- Aligned package, server, VERSION, release tests and remote acceptance smoke with 0.68.0.
- Kept historical feature test names and previous release notes intact.
- Added explicit QA documentation for the release-validation repair.

## 0.69.0 — Human Orbit et expérience de profil

- French-first : les nouveaux visiteurs démarrent en français, tout en conservant le choix explicite d'une autre langue.
- Le centre Human Orbit met davantage en évidence le nom, l'intitulé professionnel, la localisation, les compétences, les intérêts, les contributions et les aspirations.
- Le panneau d'accueil de l'identité présente maintenant la biographie, les apports, les attentes, les centres d'intérêt et le site internet enregistrés.
- Le parcours de complétion devient une grille de cartes d'action plus lisible, responsive et cohérente avec l'identité visuelle.
- Ajout de traductions françaises pour les surfaces de profil, les actions, les états et les éléments dynamiques de l'éditeur.
- Le flux d'enregistrement reste confirmé par le serveur et actualise le profil, les réalisations, le parcours de complétion et le panneau d'exploration.


## 0.70.0 — finition française et lisibilité mobile

- Étend la couverture française aux panneaux Human Orbit rendus dynamiquement, au parcours d’activation et à l’éditeur complet du profil.
- Traduit les libellés, états, aides, placeholders et actions qui restaient en anglais dans les parcours d’identité.
- Corrige la réduction excessive du cercle sur les petits écrans : le cœur reste lisible et les informations professionnelles restent visibles.
- Ajoute des états de focus cohérents pour les cartes d’action et les commandes de l’identité.
- Conserve les contrôles de sauvegarde côté serveur et les garde-fous juridiques de la bêta.


## 0.71.0 — profils publics et mise en relation

- Harmonise en français les profils publics et les panneaux de compétences.
- Traduit les états de vérification, les réalisations, les libellés de visibilité et les actions de connexion.
- Ajoute des tests de non-régression sur le parcours public et ses actions.

## 0.72.0 — finition française des panneaux dynamiques

- Complète la traduction française des panneaux Human Orbit générés après connexion : synthèse, compétences, réalisations, trajectoire, aspirations, réseau, opportunités et impact.
- Harmonise les états vides, les aides contextuelles, les actions et les retours de mise en relation pour éviter les bascules FR/EN lors de la navigation.
- Ajoute une couverture de non-régression ciblée sur les libellés dynamiques réellement produits par l'interface.
- Aucun changement aux règles de confidentialité, d'accès, de consentement ou de persistance.

## 0.73.0 — retours et notifications en français

- Étend la rédaction française aux retours d'action et notifications produits après les parcours de mise en relation, de signalement, de gestion d'entreprise, de candidature, de sécurité du compte, de photo et de justificatifs.
- Traduit également les messages de confirmation, les erreurs de parcours et les retours d'administration pour limiter les bascules ponctuelles en anglais.
- Ajoute des tests ciblés sur les nouveaux libellés et la cohérence de version.


## 0.74.0 — cohérence française des espaces de gestion

- Étend le dictionnaire français aux états dynamiques de la console de modération, aux invitations individuelles et groupées, aux réglages de compte et aux dialogues de création de projet.
- Traduit les libellés de statut et les états vides les plus fréquents dans les vues d’administration.
- Met à jour les métadonnées de version et les scénarios de validation de release.
- Ne modifie pas les règles de consentement, le verrou juridique de production ni les contrôles d’accès.


## 0.80.0 — Recette de l’identité et du réseau en français

- Étend la traduction française des panneaux Human Orbit, des états de compétences et réalisations, des relations, des notifications et des profils d’entreprise.
- Traduit les actions et confirmations dynamiques les plus fréquentes du parcours membre.
- Supprime un double passage inutile du traducteur lors de l’initialisation.
- Ne modifie pas les règles de visibilité, d’accès, de consentement ou le verrou juridique de lancement.

## 0.80.0 — consolidation de la livraison bêta

- Aligne les métadonnées d'exécution et les contrôles de release sur la version 0.80.0.
- Réconcilie le README avec les fonctionnalités et limites réellement présentes dans la version actuelle.
- Remplace le guide testeur obsolète par un parcours concret couvrant création du profil, Human Orbit, réseau, confidentialité et remontée d'anomalies.
- Ajoute une recette de livraison qui sépare explicitement les contrôles automatisés des validations réelles d'hébergement, de sécurité opérationnelle et de conformité.
- Maintient le verrou juridique de production et documente les limites du stockage JSON mono-instance.


## 0.80.0 — contrôle renforcé du secret de session

- Le précontrôle vérifie désormais la diversité du secret de session, et pas seulement sa longueur.
- Le secret n’est jamais affiché dans le rapport ; les secrets longs mais prévisibles sont refusés.
- Ajoute un test de régression dédié à cette règle de sécurité.
- Conserve explicitement les blocages juridiques et opérationnels : aucun feu vert de lancement n’est simulé.

## 0.81.0 — recette opérateur et préparation de l'ouverture

- Aligne les métadonnées de version, le serveur et les tests sur 0.81.0.
- Ajoute une séquence opérateur unique et vérifiable pour hébergement, sauvegardes, restauration, tests humains, validation juridique et ouverture progressive.
- Précise les preuves attendues avant de cocher les validations humaines ; les contrôles locaux ne sont pas assimilés à une validation de production.
- Maintient le verrou juridique de production fermé par défaut.

## 0.84.0 — finition française du parcours d’identité

- Étend le dictionnaire français aux panneaux dynamiques du profil : identité centrale, compétences, réalisations, parcours, aspirations, réseau, opportunités et impact.
- Traduit les états de chargement, les états vides et les actions de mise en relation générés après interaction.
- Harmonise les messages liés à l’ajout de compétences, aux preuves, à l’enregistrement du profil et aux photos.
- Ajoute des tests de régression dédiés à la couverture française du parcours dynamique et à la langue initiale française.
- Ne modifie pas le verrou juridique ni les prérequis de production ; les validations humaines restent requises.

## 0.85.0 — finition française des détails de compétences

- Corrige un mélange français/anglais dans le panneau qui s'ouvre lorsqu'un membre sélectionne une compétence dans la constellation Human Orbit.
- Traduit le statut de la compétence, le niveau, le nombre de preuves associées, l'état sans preuve, les statuts de vérification et l'action d'ajout de preuve.
- Conserve l'anglais uniquement lorsque la personne a explicitement choisi cette langue.
- Ajoute des tests de régression ciblés sur le panneau dynamique et l'alignement des métadonnées de version.
- Ne modifie pas les règles d'accès, de visibilité, de consentement ou de conservation des données.


## 0.87.0 — consolidation multi-parcours

- Extension de la rédaction française native aux parcours de découverte, opportunités, espace entreprise, édition d’identité, réalisations et confidentialité.
- Harmonisation des libellés des champs, boutons, états et aides, tout en conservant le choix explicite de l’anglais.
- Ajout de tests de non-régression couvrant plusieurs parcours produit et les régions accessibles.
- Version de consolidation : pas de ZIP intermédiaire par micro-correction ; les prochains lots regrouperont plusieurs axes de qualité.

## 0.88.0 — Human Orbit et cohérence des panneaux dynamiques
- Complète le dictionnaire français des panneaux Human Orbit : identité, compétences, réalisations, trajectoire, aspirations, réseau et opportunités.
- Traduit les états et micro-interactions affichés après consultation d’un signal et transmission d’un intérêt.
- Ajoute des tests de non-régression sur les libellés dynamiques et la conservation de l’échappement des contenus saisis par les membres.


## 0.89.0 — identité publique et réseau entièrement francisés
- Corrige les derniers libellés anglais injectés dans la consultation d’un profil public : identité centrale, compétences, réalisations, partage et actions de confiance.
- Harmonise les états et actions du réseau : demandes reçues/envoyées, acceptation, refus, blocage et retours utilisateur.
- Les contenus saisis par les membres restent traités comme des données et échappés avant insertion ; seule l’interface statique est traduite.
- Ajoute une couverture de non-régression dédiée aux vues publiques et aux interactions du réseau.
- Conserve le français par défaut et le choix explicite de l’anglais.

## 0.90.0 — Consolidation transversale du profil

- Extension de la couche française aux huit dimensions Human Orbit et aux interactions du profil public : partage, signalement, blocage, photo, compétences et réalisations.
- Ajout de tests de non-régression sur le français par défaut, le choix explicite de l’anglais et le cycle d’enregistrement du profil (confirmation serveur, rafraîchissement et actualisation des vues).
- Alignement des métadonnées de version dans les tests et scénarios smoke.
- Ajout d'une recette transversale ordinateur/mobile couvrant identité, réseau, opportunités, confidentialité, accessibilité et exploitation.
- Validation : 126 tests automatisés et l'ensemble des scénarios `test:release` passent ; contrôle de lancement toujours NON PRÊT (12 blocages, 4 avertissements).

## 0.93.0 — French-first dynamic interface coverage
- Expanded the French dictionary across Human Orbit, discovery, connection states, company profiles and opportunity messaging.
- Added regression coverage for key dynamic copy, French-first selection, explicit English and text-node-only translation.
- Preserved the legal launch lock and all existing release/security checks.


## 0.93.0 — Correct language switching and source restoration

- Fixed the language layer so switching from French to English restores the original source text instead of leaving previously translated nodes in French.
- Applied the same restoration rule to translatable attributes (`placeholder`, `aria-label`, `title`, `alt`).
- Kept dynamic DOM observation active in both languages so newly rendered content remains consistent after language changes.
- Added regression tests for text restoration, attribute restoration, dynamic mutation handling and release metadata.

## 0.93.0 — Dynamic profile and opportunity language consistency
- Added a shared exact-phrase helper for interpolated Human Orbit content so dynamic enum values use the selected interface language.
- Localized skill levels, evidence types/statuses and opportunity types/modes in French.
- Preserved user-provided content as data; only known interface labels are translated.
- Added regression coverage for interpolated UI labels and release/legal-lock metadata.


## 0.95.0 — Mobile identity workspace hardening

- Stabilized the final mobile CSS cascade for the Human Orbit workspace across 760px, 390px and 340px viewports.
- Prevented flex/grid children and identity panels from forcing horizontal overflow.
- Kept the identity core readable without scaling the whole orbit, and improved wrapping for long names, headlines and node labels.
- Added structural regression tests for compact mobile layouts and touch-friendly workspace sizing.
- This is CSS/source-level validation; physical-device visual QA remains a launch prerequisite.


## 0.95.0 — French coverage for dynamic member journeys

- Expanded the French-first dictionary for authentication, discovery, network pagination, collaborations, connections, notifications, moderation and profile editing.
- Kept user-authored profile content untouched; only known interface copy is translated.
- Aligned release metadata and smoke-test expectations at 0.95.0.
- Added regression coverage for the newly covered dynamic surfaces.

## 0.98.0 — Human Orbit panel localization
- Route every static Human Orbit panel heading, description, empty state, search prompt and action label through the active language layer at render time.
- Localize profile editor section headings while preserving member-authored profile text verbatim and escaped.
- Add regression coverage for render-time translation and release metadata.

## 0.98.0 — Public identity and member actions localization
- Localized public identity labels, evidence counts, skill verification states, empty states and sharing/reporting/blocking actions through the active French-first language dictionary.
- Localized connection cards, connection responses, notification headings and read actions.
- Localized company-page opportunity headings and empty states.
- Kept member-authored names, headlines, skill names and evidence descriptions escaped and unchanged.
- Added regression tests for public identity copy, dynamic actions, member-content escaping and release metadata.
- Automated checks do not replace real browser/device visual QA or production deployment checks.

## 1.0.0-rc.1 — synchronisation transversale du profil
- Ajout d'un rafraîchissement centralisé des vues dépendantes du profil à partir des données canoniques renvoyées par le serveur.
- Après modification de l'identité, actualisation de Human Orbit, des réalisations, de la progression, de la découverte, des collaborations et des opportunités.
- Même synchronisation après ajout d'une compétence, ajout d'une réalisation et changement ou suppression de photo.
- Ajout de tests de non-régression dédiés à la cohérence des surfaces et à l'alignement des métadonnées.
- Aucun changement au verrou juridique de lancement.

## 1.2.0-alpha.1 — Specialist discovery foundation
- Added a curated, explainable finance / AI / data skill vocabulary with synonym expansion for candidate discovery.
- Search now recognizes equivalent specialist terminology (for example quant / quantitative research, LLM / generative AI, credit risk / risk modelling) instead of requiring exact wording.
- Added focused tests for synonym expansion, profile discovery and semantic skill overlap.
- This is deterministic vocabulary matching, not an AI model, external labour-market feed or hiring score.


## 1.4.0-alpha.1 — Employer offer packaging
- Added a dedicated employer-facing commercial section with candidate, recruiter, team and enterprise offer hypotheses.
- Clearly marked indicative prices as non-contractual and subject to validation through customer interviews and paid pilots.
- Added a company-account CTA wired to the existing registration journey.
- Localized the new section in French and English.
- No billing, checkout or subscription activation is represented as implemented.

## 1.7.0-alpha.1 — Product re-foundation

- Reframed the product around evidence-led specialist talent discovery, practical assessment and missions.
- Added a standalone explainable dual-axis matching engine: Match Parcours and Match Technique remain separate; no blended score is emitted.
- Missing technical evidence is `non_evalue`/unknown, never zero; technical coverage is reported separately.
- Added unit tests for the scoring boundaries and human-review requirement.
- Added the product re-foundation and brand-renaming brief. ZERILYS is now explicitly a technical working name; MATCHCANDIDATE is discarded.
- This release does not yet connect assessments or missions to persisted candidate records or the employer UI.


## 1.9.0-alpha.1 — Skills assessment engine

- Added a server-graded, versioned assessment library for SQL, Python/data and financial risk fundamentals.
- Added authenticated candidate assessment history and attempt submission, with a five-attempt cap per test version.
- Kept answer keys server-side and assessment records out of public profile serialization.
- Connected assessment evidence to Match Technique and surfaced separate Match Parcours / Match Technique indicators on candidate opportunity cards.
- Added skill-driven assessment recommendations on new employer offers and an endpoint to customize the assessment plan.
- Added an assessment console to the candidate Human Orbit.

## 1.9.0-alpha.3 — Cadre d'intégrité des évaluations
- Ajout d'un cadre anti-triche multicouche adapté aux évaluations assistées ou non par IA.
- Distinction explicite entre IA interdite, IA autorisée et ressources ouvertes.
- Vérification de maîtrise, variantes individualisées, revue humaine et procédure de contestation spécifiées.
- Garde-fous renforcés sur vie privée, accessibilité, consentement et absence de décision automatique défavorable.
- Ajout de tests de présence et de cohérence du cadre.
- Cette version formalise le modèle cible ; elle n'implémente pas encore la surveillance ni la détection comportementale.

## 1.9.0-alpha.5 — preuve de raisonnement et transparence IA
- Ajout d'une explication structurée du raisonnement à la fin de chaque évaluation.
- Déclaration explicite de l'usage de l'IA (non utilisée, utilisée comme assistance, ou préférence de non-réponse).
- Conservation de l'explication comme élément de preuve distinct du score QCM ; aucune notation automatique du texte libre.
- Mention explicite qu'une revue humaine est nécessaire pour interpréter le raisonnement.
- Validation serveur de la longueur du raisonnement et de la déclaration IA.


## 1.9.0-alpha.7 — Cas pratiques individualisés
- Ajout de quatre cas pratiques : diagnostic de trésorerie, lancement commercial, critique de protocole de recherche et analyse de défaillance industrielle.
- Chaque candidat reçoit des paramètres individualisés et déterministes, sans dépendre d'une génération IA opaque.
- Les consignes, livrables et critères de revue sont communiqués avant la soumission.
- Les réponses sont conservées dans l'historique privé du candidat et soumises à une revue humaine ; aucun score automatique n'est attribué.
- Déclaration d'usage de l'IA conservée avec chaque dépôt ; limitation à trois tentatives par cas et par candidat.
- Ajout des routes API authentifiées, de l'interface candidat et des tests unitaires / parcours.
- Aucun code candidat n'est exécuté sur le serveur ; les environnements d'exécution isolés restent un chantier préalable aux exercices de programmation exécutables.


## 1.9.0-alpha.9 — Qualification verification
- Candidate-submitted diploma/equivalence evidence with private document storage and format/signature checks.
- Reviewer-only queue and document access; decisions require a reason and are audit logged.
- Public profile exposes only a minimal verified-qualification indicator, never documents or review notes.
- AI is not used to make verification decisions; automated document extraction remains a future assistive feature requiring human confirmation.


## 1.9.0-alpha.16 — Durcissement de la passerelle d’exécution
- Refus des redirections HTTP afin d’éviter qu’un jeton d’accès du runner soit transmis après une redirection.
- Lecture en flux des réponses du runner avec plafond strict de 64 Ko avant analyse JSON.
- Refus des réponses sans type MIME JSON, mal formées ou trop volumineuses.
- Ajout de tests dédiés aux réponses malveillantes et aux redirections.
- L’exécuteur distant reste désactivé par défaut ; cette évolution ne constitue pas une sandbox et ne permet pas encore d’activer l’exécution en production.

## 1.9.0-alpha.17 — 2026-11-13
- Nettoyage au démarrage des sessions et jetons d'authentification expirés ; retrait des secrets d'invitations inutilisables et purge des anciennes métadonnées d'invitation après 90 jours.
- Export de compte enrichi avec l'historique privé des évaluations, les métadonnées de vérification de diplôme et les justificatifs encore stockés.
- Documentation du périmètre de conservation provisoire et guide opérationnel des pilotes commerciaux.

## 1.9.0-alpha.19 — 2026-11-13

- Project Labs : ajout d'un tableau de tâches privé par équipe, avec attribution aux membres acceptés, échéances et statuts (à faire, en cours, terminé).
- Contrôle d'accès : seuls le créateur et les membres acceptés peuvent consulter le tableau ; seuls les membres de l'équipe peuvent créer ou mettre à jour les tâches.
- Gouvernance : réattribution réservée au responsable du projet, limite de 200 tâches par projet, journalisation des créations et modifications.
- Confidentialité : les tâches ne sont jamais incluses dans la liste publique des projets.
