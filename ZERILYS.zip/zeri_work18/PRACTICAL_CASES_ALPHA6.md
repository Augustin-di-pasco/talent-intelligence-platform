# Cas pratiques individualisés — alpha.6

## Objectif
Compléter les questionnaires de connaissances par des mises en situation écrites, adaptées à plusieurs familles de métiers. Le candidat doit produire une démarche, expliciter ses hypothèses et remettre des recommandations ou un plan d'analyse.

## Cas disponibles
- Finance : diagnostic de trésorerie et besoin en fonds de roulement.
- Commerce / conseil : validation d'un marché et plan go/no-go.
- Recherche : critique d'un protocole observationnel et reproductibilité.
- Ingénierie : diagnostic d'une défaillance industrielle et validation sécurisée.

## Individualisation
Les paramètres numériques sont sélectionnés côté serveur à partir d'un hachage stable du candidat, du cas et de la version. Le même candidat retrouve le même sujet dans une version donnée ; deux candidats peuvent recevoir des données différentes. Il ne s'agit pas d'une randomisation cryptographique ni d'une preuve d'identité.

## Évaluation
Les consignes, livrables et critères de revue sont visibles avant la remise. Les réponses sont enregistrées dans `practicalAssessments`, privées au candidat, et marquées `submitted_for_human_review`. Le score reste `null`, les critères ne sont pas notés automatiquement. Le texte libre n'est pas envoyé à un modèle d'IA pour notation.

## Usage de l'IA
Chaque dépôt conserve une déclaration `not_used`, `used` ou `prefer_not_to_say`. Cette déclaration reste déclarative et ne prouve pas l'utilisation réelle d'un outil.

## Limites alpha.6
- Les réponses sont textuelles ; pas encore de fichiers joints, d'exécution de code, de requêtes SQL en bac à sable ou de simulation interactive.
- Pas encore d'interface évaluateur permettant de noter les critères, commenter et valider le dossier.
- Pas encore de partage des cas pratiques avec un employeur : les dépôts restent privés au candidat.
- Pas encore de variante adaptative en cours d'épreuve.
- Les cas doivent faire l'objet d'une validation métier, d'un pilote de calibration et d'une analyse d'accessibilité avant usage sélectif réel.
