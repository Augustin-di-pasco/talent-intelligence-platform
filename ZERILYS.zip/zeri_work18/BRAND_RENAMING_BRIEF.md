# Décision de marque — ZERILYS

Le nom ZERILYS est confirmé comme marque officielle du produit. Voir `BRAND_SYSTEM.md` pour le positionnement, la signature et l’architecture de marque.
