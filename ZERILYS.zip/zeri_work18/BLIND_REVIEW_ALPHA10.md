# Revue à l’aveugle des cas pratiques — alpha.10

## Objectif
Réduire les biais d'évaluation liés à l'identité, au parcours déclaré et à la déclaration d'usage de l'IA, sans prétendre garantir un anonymat absolu.

## Données présentées à l'évaluateur
- Référence opaque de dossier (préfixe `DOSSIER-` et huit caractères hexadécimaux).
- Domaine, intitulé et version du cas pratique.
- Réponse et paramètres individualisés nécessaires à son interprétation.
- Grille de critères et date de soumission.

## Données masquées dans la file
- Identifiant du candidat, nom et intitulé professionnel.
- Déclaration d'usage de l'IA.

La route de revue conserve l'identifiant technique de la tentative dans l'action réservée à l'évaluateur, mais la file ne fournit aucune correspondance vers le compte candidat. Les résultats restent accessibles au candidat dans son espace privé.

## Repères communs de notation
- **1 — Insuffisant :** éléments insuffisants ou erreurs majeures.
- **2 — À renforcer :** maîtrise partielle, lacunes importantes.
- **3 — Maîtrisé :** attendu atteint avec quelques limites.
- **4 — Très bien maîtrisé :** maîtrise solide, raisonnement explicite et adapté.

Chaque note conserve un commentaire factuel obligatoire et une synthèse motivée. Aucun score global automatique n'est calculé.

## Limites et précautions
L'anonymisation de la file ne supprime pas les indices éventuellement contenus dans le texte libre (nom d'employeur, projet identifiable, style rédactionnel, etc.). L'interface demande aux évaluateurs de ne pas chercher à confirmer l'identité et de noter uniquement les éléments observables. Une procédure de double revue, d'arbitrage et de mesure de l'accord inter-évaluateurs reste à construire avant tout usage à fort enjeu.

Les repères 1–4 constituent une première harmonisation éditoriale, pas une calibration psychométrique validée. Il faudra tester les écarts entre évaluateurs sur un corpus pilote, documenter les désaccords et ajuster les grilles par domaine.
