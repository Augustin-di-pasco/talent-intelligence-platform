# Exercices techniques Python et SQL — alpha.12

## Livré
- Deux sujets individualisés et versionnés : nettoyage de données en Python et agrégation de commandes en SQL.
- Zone de rédaction adaptée au code, amorce fournie, consignes et critères de revue visibles avant soumission.
- Les soumissions empruntent le workflow existant de revue humaine à l'aveugle ; aucun score global n'est calculé automatiquement.

## Frontière de sécurité explicite
Cette version **n'exécute aucun code candidat**. Le contenu est traité comme du texte, limité par la validation de soumission existante (100 à 12 000 caractères), stocké dans le dossier privé du candidat et présenté à l'évaluateur comme une preuve à relire. Le serveur applicatif n'appelle ni `eval`, ni `exec`, ni interpréteur Python, ni moteur SQL sur ce contenu.

## Avant toute exécution interactive
Un service d'exécution séparé devra être conçu et audité : conteneur/VM éphémère non privilégié, système de fichiers en lecture seule, réseau désactivé, aucun secret ni montage de données de production, quotas CPU/mémoire/PID/espace, timeout strict, limites de sortie, filtrage SQL en lecture seule sur jeu de données synthétique, destruction systématique après tentative, journaux minimaux et tests d'évasion. Le service devra être isolé du serveur web et de la base de comptes. Tant que cette infrastructure n'existe pas, l'interface annonce clairement que le code n'est pas exécuté.
