# ZERILYS — Plan de mise en service pour les 50 premiers testeurs

**Version de référence : 1.0.0-rc.4**
**Hébergeur retenu : Render (Blueprint déjà présent dans le dépôt).**  
**État : préversion techniquement validée, déploiement réel non effectué, ouverture interdite tant que les validations externes ne sont pas terminées.**

Ce document distingue les actions réalisables dans le code de celles qui exigent un compte d'hébergement, un domaine, une personne responsable ou un avis juridique. Un contrôle automatisé ne vaut jamais preuve qu'une action externe a été réalisée.

## 1. Ce qui est déjà validé dans cette livraison

- 165 tests automatisés réussis et contrôles syntaxiques réussis.
- Parcours principaux candidat/entreprise, candidatures, projets, confidentialité, signalements et modération couverts par les tests de fumée.
- Tests de charge fonctionnelle limitée : 50 inscriptions ouvertes et 50 inscriptions par invitation, avec découverte des profils et contrôles d'accès aux photos.
- Persistance des profils/photos après redémarrage, sauvegarde vérifiée, restauration, intégrité des données et durcissement HTTP testés localement.
- Le serveur refuse effectivement les inscriptions tant que `ZERIHLINK_BETA_LEGAL_APPROVED=false`. Le Blueprint Render configure désormais aussi `ZERIHLINK_ALLOW_SIGNUP=false` par défaut.

## 2. Actions obligatoires avant d'inviter qui que ce soit

| Ordre | Action | Responsable / preuve attendue |
|---|---|---|
| 1 | Créer un compte Render et connecter un dépôt Git privé contenant le projet. Vérifier le coût du service et du disque avant de confirmer. | Propriétaire du projet ; dépôt privé et budget validé. |
| 2 | Créer le Blueprint Render depuis `render.yaml` et vérifier `NODE_ENV=production`. Garder les inscriptions fermées. | Propriétaire ; URL du service et journal de démarrage sans erreur. |
| 3 | Générer un secret de session aléatoire unique (au moins 32 caractères) dans le gestionnaire de secrets de l'hébergeur. Ne jamais le transmettre dans le chat ni le committer. | Propriétaire ; contrôle `launch:check` réussi. |
| 4 | Monter un disque persistant sur `/opt/render/project/src/data` (Render) ou définir `ZERIHLINK_DATA_DIR` sur le volume persistant de l'hébergeur choisi. | Propriétaire ; redémarrage sans perte des données. |
| 5 | Déclarer une adresse e-mail valide de modération dans `ZERIHLINK_REVIEWER_EMAILS` et nommer les modérateurs. | Responsable de modération ; test d'accès à la file de signalements. |
| 6 | Configurer le domaine canonique HTTPS dans `ZERIHLINK_PUBLIC_URL` et `ZERIHLINK_DEPLOYMENT_URL`. | Propriétaire ; `/api/health` retourne la bonne version. |
| 7 | Configurer le fournisseur e-mail et ses secrets si les confirmations, invitations et réinitialisations doivent être envoyées automatiquement. | Propriétaire ; e-mail réel reçu et lien à usage unique testé. |
| 8 | Créer une sauvegarde locale vérifiée après les premiers essais, puis copier cette sauvegarde hors de l'hébergement et effectuer un test de restauration. | Propriétaire ; archive + manifeste + preuve de restauration. |
| 9 | Faire examiner les conditions de bêta, la notice de confidentialité, les durées de conservation, les mentions légales et la marque par un professionnel compétent. | Conseil juridique ; validation écrite et textes corrigés. |
| 10 | Définir les personnes chargées de la modération, les délais de réponse, l'escalade et la permanence quotidienne. | Responsable de modération ; planning nommé. |
| 11 | Faire la recette manuelle sur un ordinateur et un vrai téléphone : inscription, connexion, édition du profil, photo, Human Orbit, recherche, confidentialité, candidatures côté candidat et entreprise, signalement, export et suppression de compte. | Testeurs internes ; procès-verbal daté et anomalies bloquantes résolues. |
| 12 | Seulement après les étapes 1 à 11, renseigner les accusés de contrôle réels et basculer `ZERIHLINK_BETA_LEGAL_APPROVED=true`. | Propriétaire + validation juridique ; contrôle final sans bloqueur. |

## 3. Limites connues à respecter pendant le pilote

- Une seule instance applicative utilisant un seul volume de données ; ne pas activer de mise à l'échelle horizontale.
- Le stockage courant est un fichier JSON ; PostgreSQL est une voie d'export/migration, pas le stockage transactionnel utilisé par l'application.
- Le rate limiting est local au processus ; ce pilote n'est pas dimensionné pour une ouverture publique à grande échelle.
- Les cours de marché en direct restent désactivés tant que les droits de redistribution ne sont pas confirmés.
- Sans fournisseur e-mail, les invitations peuvent être gérées manuellement et la récupération de mot de passe ne peut pas être livrée par e-mail.
- Ne pas recueillir de données sensibles ni d'informations confidentielles d'employeurs pendant ce pilote.

## 4. Commandes de contrôle

```bash
npm ci
npm run test:release
npm run launch:check
```

`npm run launch:check` doit finir avec zéro bloqueur. Il faut ensuite refaire le contrôle après déploiement avec les variables d'environnement réelles. Ne jamais définir les variables d'accusé (`ZERIHLINK_BROWSER_QA_ACK`, `ZERIHLINK_LEGAL_REVIEW_ACK`, `ZERIHLINK_REVIEWER_COVERAGE_ACK`, `ZERIHLINK_OFFSITE_BACKUP_ACK`) à `true` avant que les contrôles correspondants aient été réellement exécutés.

## 5. Décision de lancement

À la livraison de `1.0.0-rc.4`, le contrôle local affiche 12 bloqueurs et 4 avertissements. La version est une candidate de recette, pas une bêta ouverte. Les actions restantes dépendent d'accès et de décisions qui ne sont pas disponibles dans le dépôt (hébergement, domaine, secrets, e-mail, modération, validation juridique et appareils physiques). La bonne décision est de terminer ces opérations sur l'environnement cible, puis de faire une seule validation finale avant l'arrivée des 50 testeurs.
