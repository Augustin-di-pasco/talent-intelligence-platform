# Refonte produit — 1.9.0-alpha.7

## North star
Move specialist recruitment from claims on a CV toward capabilities supported by evidence. The platform should help people reveal what they can do, meet others around meaningful work, and help employers discover relevant talent beyond job titles and years of experience.

## Audiences and initial market
- Candidats : talents qualifiés de Bac+4 à la recherche avancée, dans l’ingénierie, le numérique, la finance, le commerce/management, les sciences et la recherche.
- Jeunes talents : stages, alternances, projets de fin d’études, graduate programmes et premiers emplois.
- Professionnels et experts : mobilité, recrutement, missions, R&D et collaborations.
- Paying customer hypothesis: employers and specialist recruiters who need better evidence and faster shortlists.
- Pilote initial : France, interface française native, profils Bac+4 et plus ; l’internationalisation reste une exigence d’architecture.

## Product system
1. **Human Orbit** — candidate-owned professional identity: skills, experience, education, interests, intent and evidence.
2. **ZERIH ASSESS** — provisional internal label for reusable skill assessments. The expanded pilot library covers SQL, Python/data, financial risk, accounting/financial analysis, statistics, engineering systems, business strategy, research methodology and project management. These initial quizzes are knowledge diagnostics, not proof of professional mastery.
3. **Mission Labs** — planned practical missions, individual or collaborative, that create reviewable evidence. Commercially useful work must be paid or fairly compensated; selection exercises must be bounded and simulated.
4. **Intelligence** — transversal graph connecting skills, evidence, people, employer needs and opportunities.
5. **Opportunities** — stages, alternances, CDI/CDD, graduate programmes, VIE, missions, projets de recherche et collaborations.

## Two-axis matching
Every candidate/opportunity view should show two separate, explainable indicators:
- **Match Parcours**: relevant declared skills, education, experience and achievements.
- **Match Technique**: completed platform assessments and validated mission evidence.

Never combine them into a hidden global score. Display score, coverage, evidence source, test version and date. Missing evidence is “non évalué”, not zero. Years of experience are context, never a hard exclusion gate. Human review remains necessary.

## Employer workflow
1. Publish a structured opportunity and required capabilities.
2. Review the platform's suggested assessment plan.
3. Edit the plan to include only relevant assessments.
4. Receive candidate interest with Match Parcours and Match Technique displayed separately.
5. View technical results only when the candidate explicitly opted to share them for that opportunity.
6. Review underlying evidence and make the decision as a human.

## Candidate workflow
1. Build a Human Orbit profile, including structured education and experience.
2. Add skills and supporting evidence.
3. Complete reusable assessments once; results stay in the candidate's private assessment history.
4. Choose separately whether to share assessment results when expressing interest in an opportunity.
5. Discover opportunities and see both matching dimensions with coverage.
6. Later, join Mission Labs to demonstrate skills in practical, collaborative work.

## Current implementation in 1.9.0-alpha.7
- Structured experience and education records can be added to the candidate profile.
- Nine server-graded, versioned knowledge questionnaires are available: SQL, Python/data, risk, accounting/finance, statistics, engineering systems, business strategy, research methodology and project management.
- Candidate results are private in the authenticated assessment-history endpoint and excluded from public profile serialization.
- Role skills automatically suggest assessments; recruiters can edit the assessment plan on each offer.
- Candidate opportunity cards display separate Match Parcours and Match Technique scores.
- Employers can specify indicative study levels. These are contextual signals, not automatic exclusion gates.
- Internship and apprenticeship offers require a start date, duration and explicit compensation/gratification information; rhythm and supervision fields are also available.
- Candidate opt-in is required before assessment results are exposed in the employer application view.
- The first dual-match implementation uses structured skills, education/experience keywords and assessment results. It is not yet a calibrated psychometric or predictive model.

## Not yet implemented
- Full CV parsing/import and structured achievement history.
- Practical code execution, SQL sandboxing, case studies and proctored/anti-cheating controls.
- Complete internship/apprenticeship contract details, regulatory compliance checks and employer-side legal guidance.
- Assessment item bank management, psychometric calibration, benchmark cohorts and fairness monitoring.
- Mission Labs workflows, collaborative contribution tracking, validation and compensation.
- Employer-side evidence drill-down, full candidate comparison workspace and audit-ready decision explanations.
- Production AI features, external integrations and international market rollout.

## Naming status
ZERILYS is the confirmed parent brand. MATCHCANDIDATE is discarded. SKILLSLINK is excluded. ZERIH ASSESS remains a provisional internal module label only. Trademark registration and domain ownership are separate legal and administrative steps.
