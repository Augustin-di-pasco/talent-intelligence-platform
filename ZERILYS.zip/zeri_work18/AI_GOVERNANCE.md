# AI and assessment governance — product requirements

## Product boundary
The platform may help candidates understand their evidence and help employers explore relevant capabilities. It must not make hiring decisions, reject candidates automatically, or disguise a ranking as a neutral score.

## Two independent indicators
- Match Parcours: contextual comparison of declared experience, education, achievements and relevant background.
- Match Technique: observed outcomes from platform assessments and validated mission evidence.
- Do not produce a hidden blended score. Do not interpret missing evidence as zero. Display coverage, source, date and assessment version.
- Experience duration must not be a hard exclusion gate. Explain which requirements were matched and which remain unknown.
- Human review and candidate contestability remain mandatory product principles.

## Assessment quality
- Each assessment has a version, scope, level, duration and competency mapping.
- Keep answer keys server-side and audit submissions.
- Candidate results are private by default and shared only through explicit consent/workflow.
- Show that a quiz result is evidence about that test, not a professional certification or a prediction of job performance.
- Add accessibility accommodations, equivalent alternative evidence and transparent retake rules before broad rollout.
- Do not use unpaid productive employer work as a selection exercise. Commercially useful missions must be paid or otherwise fairly compensated; selection exercises must use bounded fictional/simulated cases.

## EU AI Act — legal review required
AI systems intended for recruitment or selection, including systems that analyse/filter applications or evaluate candidates, are listed in Annex III, point 4(a), as high-risk use cases. The AI Act's amended timetable sets application of the relevant Annex III high-risk obligations from 2 December 2027. This later application date is not a blanket exemption from other applicable law or from preparing governance, documentation, human oversight, data quality, transparency and risk controls. Any claim that a specific feature is outside high-risk classification requires a documented legal assessment; profiling in an Annex III use case remains particularly sensitive.

Sources reviewed 13 November 2026:
- European Commission AI Act overview and implementation timeline: https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- AI Act Service Desk, Employment examples: https://ai-act-service-desk.ec.europa.eu/fr/node/464
- Consolidated Regulation (EU) 2024/1689 as amended: https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng

This note is product planning, not legal advice. Obtain specialist counsel before deployment of AI-assisted recruitment features.
