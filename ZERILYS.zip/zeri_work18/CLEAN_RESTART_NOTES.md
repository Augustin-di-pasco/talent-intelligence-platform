# Clean restart notes

This release archive excludes the historical `legacy/` tree, local runtime data, secrets, node_modules, and generated logs. It is built from the validated 1.9.0-alpha.20 source. No user avatar or qualification-document files are included; those are runtime user data and must be migrated only through the authenticated backup/restore workflow.

The GitHub `main` branch was found to contain an older 1.0.0-rc.4 release and must not be deployed as-is. See `PUBLIC_LAUNCH_STATUS_2026-11-13.md` for the actual infrastructure and launch gates.
