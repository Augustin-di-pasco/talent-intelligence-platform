# Cadre anti-triche et intégrité des évaluations — v1.9.1

## Décision produit

La plateforme ne promettra jamais de détecter infailliblement l'usage d'une IA. Elle cherchera à établir une preuve crédible de maîtrise, à rendre l'assistance non autorisée moins utile et à distinguer explicitement l'usage interdit de l'usage professionnel légitime de l'IA.

## 1. Trois politiques d'assistance par évaluation

Chaque évaluation doit publier avant son démarrage une politique explicite :

- `closed_book`: IA, web et ressources externes interdits ; uniquement pour des connaissances ou automatismes que l'exercice mesure réellement.
- `ai_allowed`: IA autorisée ; le candidat décrit les outils et prompts essentiels, vérifie les résultats et justifie ses décisions. La capacité évaluée inclut le jugement et la vérification.
- `open_resources`: documentation et ressources autorisées, mais aide humaine/IA précisée séparément.

Les aménagements raisonnables et technologies d'assistance sont déclarés séparément et ne doivent pas être assimilés à une fraude.

## 2. Défense en profondeur

### Conception des sujets
- Banque d'items versionnée et suffisamment large ; tirage aléatoire contrôlé.
- Paramètres, jeux de données et contraintes individualisés.
- Questions de transfert : modifier une hypothèse, corriger un résultat erroné, expliquer un arbitrage.
- Épreuves pratiques avec livrables, tests et critères de notation publiés.
- Rotation des sujets et suivi des expositions pour limiter les fuites.

### Preuve de maîtrise
- Demander les étapes, hypothèses, sources et décisions pertinentes, pas seulement la réponse finale.
- Conserver les versions utiles du travail et les événements techniques strictement nécessaires.
- Prévoir une courte vérification orale ou un exercice de transfert, proportionné à l'enjeu.
- Comparer la cohérence entre résultat, raisonnement et vérification, sans exiger un style rédactionnel particulier.

### Signaux d'intégrité
Des signaux peuvent déclencher une revue : similarité anormale de réponses, séquences temporelles atypiques, changements de fenêtre lorsque mesurables, collage massif ou incohérence avec une vérification complémentaire. Aucun signal isolé, détecteur d'IA ou score comportemental ne constitue une preuve suffisante ni ne doit entraîner automatiquement une exclusion.

## 3. Tableau de bord d'intégrité

Pour chaque tentative, afficher séparément :
- résultat de l'évaluation et compétences réellement couvertes ;
- politique d'assistance applicable et déclaration du candidat ;
- éléments de preuve disponibles (livrables, versions, réponses de transfert) ;
- anomalies observées, contexte et niveau de confiance ;
- statut : `clear`, `review_required`, `candidate_clarification`, `verified`, `inconclusive`.

Ne pas calculer de « probabilité de triche » présentée comme une vérité. Ne pas fusionner l'intégrité avec le score de compétence. Une anomalie non résolue conduit à « résultat à confirmer », pas à une note nulle.

## 4. Parcours de revue équitable

1. Informer le candidat des règles, outils autorisés, données collectées et conséquences possibles avant le test.
2. Détecter et documenter un signal précis, sans accusation automatique.
3. Permettre au candidat de donner une explication et de signaler un problème technique ou un aménagement.
4. Proposer, si nécessaire, une vérification équivalente supervisée ou orale.
5. Faire prendre toute décision défavorable par une personne compétente, avec motif traçable et possibilité de contestation.

## 5. Vie privée, accessibilité et conformité

- Collecte minimale et proportionnée ; privilégier les traces de l'épreuve plutôt que la surveillance permanente.
- Pas d'enregistrement webcam/micro, reconnaissance faciale, biométrie, scan de pièce ou analyse émotionnelle par défaut.
- Toute surveillance renforcée éventuelle exige une analyse juridique et une analyse d'impact RGPD préalables, une information claire, une durée de conservation définie, des accès restreints et une alternative adaptée lorsque nécessaire.
- Ne pas utiliser les mouvements oculaires, la vitesse de frappe, le ton de voix ou les mouvements corporels comme preuve de fraude.
- Prévoir clavier, lecteur d'écran, temps aménageable et alternatives accessibles ; les aménagements ne doivent pas pénaliser le résultat.
- Les résultats d'évaluation ne sont partagés avec un employeur qu'avec le consentement explicite du candidat pour la candidature concernée.
- Le produit ne doit pas prendre seul une décision de recrutement ou d'exclusion.

Les systèmes d'IA utilisés pour évaluer, filtrer ou classer des candidats peuvent relever des systèmes à haut risque au titre de l'AI Act. La qualification exacte dépend de la finalité et de l'usage ; validation juridique et gouvernance dédiées sont indispensables avant activation.

## 6. Expérience candidat recommandée

Avant chaque test, une fiche très courte explique : objectif, durée, compétences évaluées, politique IA, ressources autorisées, données observées, aménagements possibles et procédure de contestation.

Après le test, le candidat reçoit un retour utile sur les compétences démontrées et celles qui restent non évaluées. Les recruteurs voient les preuves et leurs limites, jamais une étiquette opaque de « candidat suspect ».

## 7. Ordre de réalisation technique

1. Ajouter la politique d'assistance et les règles d'épreuve au catalogue d'évaluations.
2. Versionner les sujets et créer des variantes individualisées.
3. Enregistrer les livrables, versions et événements minimaux avec horodatage.
4. Créer le workflow de revue humaine et de vérification complémentaire.
5. Ajouter le tableau de bord d'intégrité et les exports consentis.
6. Réaliser tests de biais, accessibilité, sécurité, conservation et conformité avant pilote.

## Limites

Ce document définit une architecture produit et une politique cible. Il ne signifie pas que les fonctions de proctoring, de détection, de vérification orale ou de journalisation décrites sont déjà implémentées. Aucun détecteur actuel ne permet d'identifier de façon fiable et universelle un texte généré par IA.


## Évolution alpha.5 — justification et déclaration d’usage IA
Chaque évaluation demande désormais une explication du raisonnement (40 à 1 500 caractères) et une déclaration volontaire sur l’usage de l’IA. Le score reste calculé uniquement à partir des réponses objectives. Le texte libre est conservé comme preuve complémentaire, avec `human_review_required` et `scored:false`. La déclaration n'est pas une preuve technique de l'usage réel d'un outil. Aucun détecteur d'IA ni verdict automatique de fraude n'est utilisé.
