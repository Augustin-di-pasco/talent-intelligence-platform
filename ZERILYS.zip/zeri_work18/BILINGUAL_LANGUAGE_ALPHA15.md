# Couche linguistique bilingue — alpha.15

- Le français reste la langue initiale et le choix par défaut des nouveaux visiteurs.
- Un bouton compact affiche le drapeau britannique pour basculer vers l’anglais ; en mode anglais, il affiche le drapeau français pour revenir au français.
- La sélection est conservée localement pour les visiteurs et dans les préférences du compte pour les membres connectés.
- Les contenus d’interface statiques et les contenus dynamiques connus sont traduits dans les deux sens. Les attributs d’accessibilité et les libellés de formulaire sont également couverts.
- Les formulations anglaises sont rédigées pour un usage professionnel anglophone (candidats et employeurs), et non obtenues par une substitution littérale mot à mot.
- Les contenus libres rédigés par les membres (noms, descriptions, projets, messages, intitulés personnels) ne sont pas traduits automatiquement.
- La couche de traduction conserve le texte source afin de permettre plusieurs changements de langue sans accumuler de traductions ni altérer les contenus.
- Les préférences de langue restent privées et ne sont pas exposées dans les profils publics.

La couverture est une base éditoriale bilingue en cours d’enrichissement ; les textes nouveaux doivent être ajoutés aux deux dictionnaires et vérifiés dans leur contexte avant publication.
