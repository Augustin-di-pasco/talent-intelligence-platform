# ZERILYS — Talent Intelligence 1.5.0-alpha.1

## Version 1.5.0-alpha.1 — Persistance PostgreSQL activable

Ajout d’une première présentation structurée des offres candidat, recruteur, équipe et entreprise. Les prix affichés sont des hypothèses commerciales à tester, non contractuelles ; aucun paiement n’est activé. La version reste une alpha et ne doit pas être ouverte au public avant levée des points bloquants.

## Version 1.2.0-alpha.1 — Découverte spécialisée

La plateforme ajoute une première couche de vocabulaire métier pour la recherche de profils en finance, IA, data et ingénierie. La recherche reconnaît désormais des synonymes spécialisés (par exemple quant / recherche quantitative, LLM / IA générative, risque de crédit / modélisation des risques). Cette correspondance déterministe améliore la découverte sans attribuer de score d’employabilité. Voir `docs/SPECIALIST_DISCOVERY_1_2.md`. Le lancement public reste bloqué par les prérequis juridiques, sécurité, données et opérations listés dans `docs/COMMERCIAL_READINESS.md`.

## Historique des versions précédentes

Renforcement de la cohérence française des contenus injectés dynamiquement dans le réseau, les collaborations, l’authentification et les retours de compte. L’anglais reste disponible via le sélecteur de langue.
# ZERILYS 1.1.0-alpha.1 — Talent Intelligence

ZERILYS is the official product brand: a Talent Intelligence platform connecting professional identity, demonstrable capabilities, trust, discovery and collaboration. The selected brand name does not replace separate trademark, domain and legal checks.

## Version 1.1.0-alpha.1 — repositionnement Talent Intelligence

Cette version clarifie aussi le contrôle de préouverture : le rapport sépare la configuration des inscriptions sans invitation du verrou juridique qui bloque réellement toute inscription. Elle consolide également la localisation française des parcours de candidature, de la réception d’un intérêt côté entreprise au suivi et au retrait côté candidat. Voir le guide bêta pour la recette de bout en bout.

Cette préversion consolide la synchronisation du profil après modification, la validation serveur des URL HTTPS, de la visibilité et de la disponibilité, ainsi que l’alignement des niveaux de compétence affichés avec les valeurs enregistrées. Les libellés des preuves dans la constellation suivent également la langue de l’interface.

Validation locale : 159 tests unitaires et tests de contrat réussis, plus la suite `npm run test:release` (smokes fonctionnels, cohorte de 50 membres, persistance, sauvegardes, export, intégrité, préflight, acceptation distante locale, e-mail et HTTP). `npm run launch:check` reste volontairement bloquant : la bêta n’est pas prête à être ouverte tant que les 12 points bloquants ne sont pas traités.

## Run locally

Requirements: Node.js 20+. On Windows, double-click `START_ZERILYS.bat` for a local test session (the launcher enables the local-only beta test switch); on macOS/Linux run `npm start`, then open `http://localhost:8787`. No third-party runtime packages are required. Data is stored locally in the legacy-compatible file `data/zerihlink.json`; the internal storage path is retained to avoid breaking existing installations.

## 0.9 trust and safety foundation

- Members can report a public identity with a reason and category. Duplicate open reports from the same reporter against the same member are prevented.
- Configured reviewers (`ZERIHLINK_REVIEWER_EMAILS`) can inspect the open report queue and mark reports reviewed or dismissed with a note.
- Members can block and unblock another member. Blocking hides both identities from each other's discovery and public profile views, prevents new connection requests and removes any existing connection between them.
- Report and block actions are available directly from a public identity view when signed in.

**Operational limitation:** this is a moderation foundation, not a staffed trust-and-safety operation. Reviewers must be designated, response times and escalation rules must be defined, and reports do not automatically suspend accounts. The current reviewer role is email-configured, not a separate admin identity system. The JSON store and single-process limitations from 0.8 remain.

## 0.7 product experience — candidate-first Professional Universe

- The Professional Universe remains the primary candidate workspace.
- Closing a Proof, Trajectory or identity editor now closes only the editor layer; it does not dismiss the underlying candidate universe.
- The selected signal is preserved when the editor opens, saves or closes.
- Escape follows the same one-layer-at-a-time behavior.
- Editors use section-specific titles and focus the relevant field.

## 0.6 product experience — intentional connection protocol

- **Context before contact:** members cannot send an empty connection invitation; every request requires a reason of at least 20 characters.
- **Incoming and outgoing signals:** a connection field shows requests, their context and their state. Recipients can accept or decline; only the recipient can decide.
- **No popularity mechanic:** requests are not likes or follows. They are explicit, contextual invitations to connect.
- **Duplicate and self-request prevention:** pending or accepted relationships cannot be duplicated, and members cannot connect to themselves.

## 0.5 product experience — identity and intent graph

- **The person is the anchor:** the candidate identity remains at the center of the visual system. Skills orbit the person rather than replacing the person with a score or dashboard.
- **Live capability satellites:** each skill becomes an interactive node in the identity field. Selecting one opens its level, evidence relationships and review context in the identity console.
- **Evidence-to-capability relationships:** a project, credential, work sample or publication can be explicitly linked to a skill. The API validates that the linked skill belongs to the authenticated member.
- **Focus mode:** a deliberate visual mode quiets the surrounding navigation nodes and brings the identity and capability constellation forward.
- **Public identity explorer:** public profiles use the same human-centred constellation idea. Visitors can select a capability and inspect the evidence explicitly linked to it. Shareable URLs use `/?profile=<id>`.
- **Evidence language stays precise:** evidence records are not automatically proof of competence. Self-attested, pending review, verified and rejected statuses remain distinct. Reviewing an evidence item does not silently award a verified skill badge.
- Responsive adaptation for smaller screens; orbital controls and skill nodes remain interactive.
- **Intent signals:** members can state what they can contribute, what they are looking for and which themes interest them.
- **Explainable complementarity:** discovery checks whether one member’s stated needs match another member’s skills or offers, and vice versa; shared interests add context. Results show reasons instead of an opaque ranking. This is a discovery aid, not a hiring recommendation.

## Product foundation retained from 0.2 / 0.3

- Registration/login, scrypt password hashes, opaque hashed sessions, HttpOnly/SameSite cookies and production Secure cookie flag.
- Double-submit CSRF protection for state-changing API requests.
- Baseline in-memory rate limiting.
- Self-attested → pending review → verified/rejected evidence lifecycle; reviewer access controlled by `ZERIHLINK_REVIEWER_EMAILS`.
- Collaboration project creation, applications, owner decisions, project closure and applicant withdrawal.
- Authenticated account export and deletion.
- Local append-only-style audit hash chain (not externally anchored or certified).

## Environment

Set a unique `ZERIHLINK_SESSION_SECRET` of at least 32 characters for shared use. Set `NODE_ENV=production` behind HTTPS to enable Secure cookies. Configure reviewer emails with `ZERIHLINK_REVIEWER_EMAILS`. The current local launcher does not automatically load `.env`.

## État de la version actuelle (0.80)

ZERILYS est un réseau professionnel centré sur le profil de chaque personne et son univers Human Orbit. Les inscriptions standard sont ouvertes sans invitation obligatoire dès que le verrou juridique indépendant est levé. La première cohorte est française : le français est la langue par défaut pour les nouveaux visiteurs, avec choix manuel FR / EN mémorisé. La photo réelle du membre se place au centre de son profil ; les compétences, réalisations, aspirations, relations et opportunités s’organisent autour de cette identité. Tous les membres connectés peuvent consulter les profils des autres membres, sous réserve des blocages.

La version 0.80 consolide la base de la bêta privée : français par défaut, choix FR / EN mémorisé, profils Human Orbit, découverte des membres, connexions contextualisées, espaces entreprises et outils de modération. Cette version renforce également le contrôle de diversité du secret de session et documente les limites opérationnelles réelles. Les tests automatisés ne remplacent pas les essais sur le véritable hébergement et les appareils physiques.

### Runtime architecture and limits
- Node.js 20+; no third-party runtime dependencies.
- The active persistence layer is an atomic local JSON file. PostgreSQL is a target schema/export path only; the application does not connect to PostgreSQL at runtime.
- Run exactly one application instance against a given data directory. Horizontal scaling is not supported.
- Rate limiting is process-local. A persistent host disk and verified off-site backups are operational requirements.
- Email delivery and password recovery require a configured authenticated email webhook. Without it, beta invitations may require manual delivery and password recovery cannot deliver a reset token.
- GLOBAL PULSE does not display live market data. No market-data redistribution licence is integrated.

### Privacy and trust boundaries
- New personal profiles are private by default for anonymous discovery; all signed-in members can still discover and consult every candidate profile. Members can opt into anonymous discovery and public profile links.
- A private candidate may share their professional profile with a company for one specific verified opportunity by expressing interest; withdrawal revokes that application access.
- Company opportunities are discoverable only after human company verification.
- Evidence review is a human review of submitted material, not an official credential or guarantee of competence.
- Les conditions de bêta et la politique de confidentialité sont des projets jusqu’à leur validation par un professionnel compétent. Le verrou juridique côté serveur doit rester désactivé tant que cette validation n’est pas terminée.
- Do not collect sensitive personal data or confidential employer information during the pilot.

### Validation
Run the complete automated suite with:

```bash
npm run test:release
```

This includes unit tests, syntax checks, product-flow smoke tests, beta/security configuration checks, backup/restore, PostgreSQL export, data integrity, preflight behavior, email webhook/password-reset flows and HTTP hardening checks.

### Launch gates
Automated tests do not certify a deployment. Avant d’activer les inscriptions en production, compléter les validations manuelles : contrôle de l’hébergement réel, tests navigateur sur ordinateur et mobile, validation juridique, équipe de modération identifiée, sauvegarde externe vérifiée et restauration testée, et configuration de l’envoi d’e-mails (ou procédure manuelle documentée). `npm run preflight:beta` reports outstanding blockers. Public launch is not approved by this release.

## Release notes

### 0.73.0

- Complète la traduction française native des panneaux dynamiques et des états vides Human Orbit.
- Ajoute des tests de non-régression sur les contenus effectivement injectés après connexion.

### 0.62.0
- French launch preflight report and deployment guide for the first beta.

### 0.61.0
- Open registration is protected by a per-client rate limit (20 registration attempts per minute) with a production-mode smoke test.

### 0.60.0
- Optional email-address confirmation for open signup when transactional email is configured, with single-use links and resend recovery.

### 0.59.0
- FR / EN language choice is saved to each member account and restored across devices.
- Language preference remains private from public profile data.

### 0.58.0
- Dedicated 50-member end-to-end test for standard open registration without invitation tokens.
- Validates access to all 49 other private profiles and profile-photo access boundaries.

### 0.57.0
- French-first language layer refined across candidate, network, opportunity, company and reviewer flows.
- Locale-aware dates and times follow the selected FR / EN language.

### 0.56.0
- French-first language layer with automatic browser-preference detection, persistent FR / EN selection and dynamic interface translation.
- French beta terms, privacy notice and first-tester guide, still marked as legal drafts.
- Standard self-service registration no longer requires an invitation; the separate legal approval gate remains active.

### 0.32.0
- Hardened static-resource handling: missing assets now return 404 rather than the application shell.
- Malformed percent-encoded paths are rejected safely without terminating the server.
- Reconciled the beta guide and release documentation with the actual 0.30 feature set and current operational limits.

### 0.6.0
- Added intentional person-to-person connection requests, contextual invitations and recipient-controlled decisions.

### 0.5.0
- Added contribution, needs and interest fields to living identity.
- Added transparent, mutual complementarity matching and reason labels to discovery.
- Added smoke coverage for a real intent-to-skill match.

### 0.4.0
- Added a dynamic capability constellation orbiting the candidate identity.
- Added selectable skill satellites and a focus mode.
- Added explicit evidence-to-skill links and ownership validation.
- Reworked public identity exploration around the person's central identity and selectable capabilities.
- Added evidence counts per capability without treating evidence as automatic verification.


## Déploiement de la bêta privée sur Render

Le projet est préconfiguré pour **Render** via `render.yaml`. C'est le choix retenu pour la première bêta : le service Node.js, le contrôle de santé et le disque persistant sont décrits dans un seul Blueprint. Le déploiement n'est toutefois pas effectué depuis ce dépôt : il nécessite un compte Render, un dépôt Git privé connecté et la validation du coût affiché par Render.

### Configuration de sécurité par défaut

- `ZERIHLINK_ALLOW_SIGNUP=false` : les inscriptions sont fermées par défaut.
- `ZERIHLINK_BETA_LEGAL_APPROVED=false` : le verrou juridique reste fermé indépendamment du réglage précédent.
- Un secret de session est généré par Render ; il doit rester confidentiel.
- Une seule instance et un disque persistant sont prévus. Ne pas activer la mise à l'échelle horizontale.
- Le proxy de confiance est activé pour l'architecture Render ; ne pas recopier ce réglage aveuglément sur un autre hébergeur.

### Étapes de mise en service

1. Créer un dépôt Git **privé** et y importer le contenu du ZIP de livraison (sans données locales ni secrets).
2. Dans Render, créer un Blueprint à partir de ce dépôt et examiner le tarif du service et du disque avant de confirmer la création.
3. Vérifier que le disque est monté sur `/opt/render/project/src/data` et que `ZERIHLINK_SESSION_SECRET` a été généré.
4. Renseigner les variables d'environnement demandées par le Blueprint, notamment l'adresse de modération et les URL HTTPS une fois le domaine connu.
5. Déployer en gardant les inscriptions fermées, puis vérifier `/api/health`, la persistance après redémarrage et les sauvegardes.
6. Effectuer les validations juridiques, opérationnelles et humaines décrites dans `GO_LIVE_50_TESTERS.md`. Ne jamais activer le verrou juridique avant validation écrite.

Le stockage JSON est adapté à un pilote strictement limité à une instance ; il ne convient pas à une ouverture publique ni à une montée en charge commerciale. Les tarifs, régions et conditions de Render peuvent évoluer : les vérifier dans le compte avant toute dépense.

### Environment
See `.env.example`. Production refuses to start with the built-in development secret. Use HTTPS and a unique random secret.

### Backup
Run `npm run backup` on the host or in an environment with access to the mounted data directory. Backups must be copied off the service disk to a separate secure location on a schedule; the included command only creates a local snapshot.

### Beta operating checklist
- Keep registration closed until the legal and operational launch checks are complete; if a controlled pilot is approved, use personal invitations for the first cohort.
- Tell participants what profile fields are public before they publish.
- Ask testers not to add sensitive personal data or confidential employer information.
- Test account export and deletion before inviting the group.
- Assign a human moderator for reports and evidence-review requests.
- Confirm hosting region, retention, backup, privacy notice, terms and legal basis before collecting real participant data.

### Not yet commercial-production ready
Email verification, password reset, a transactional database, automated off-site backups, monitoring/alerting, advanced moderation workflows, and formal legal review of privacy/terms are still required before opening registration to the public.

### 0.12.0
- Added report and block flows to establish baseline member safety controls.
- Added reviewer-only report queue and resolution states.
- Enforced blocks across discovery, public profile access and new connection requests; existing direct connections are removed when blocking.


## Company and opportunity model (0.10)
Candidate and company accounts are distinct. Companies publish structured jobs, internships, apprenticeships and collaborations only; there is no social-post or feed feature. Candidate opportunity matching is explainable and limited to skill/intent overlap, not a hiring suitability score. Global Pulse is a separate economic-awareness area; live market prices require a commercially licensed data provider and are not simulated.

## 0.10 beta boundaries
- Candidate and company accounts share the existing beta authentication and JSON persistence. This is a functional prototype, not yet a multi-tenant enterprise system.
- Company users can publish structured offers and review candidate interest. Company-member roles, legal entity verification, ATS integrations, interview workflows and formal application status management remain future work.
- Matching currently explains literal skill overlap and limited intent/description overlap. It must not be interpreted as candidate suitability, a ranking of people, or an automated hiring decision.
- Existing 0.9 accounts are migrated in memory as candidate identities when the store loads.
- Global Pulse is an editorial shell only. No current prices, news feed, or market data are presented until reliable sources, licensing and refresh rules are established.

## Application lifecycle (0.12)
Candidates can review the status of each expressed interest and withdraw it. A private candidate can still express interest in a specific offer: that deliberate action shares their professional profile with that company for that opportunity only. Withdrawing removes the candidate from the company's active inbox and revokes access through that inbox. Companies can move an interest through review, interview or declined, and close or republish offers.


## Version 0.14 — Recruitment workflow and PostgreSQL foundation

Candidate application status changes now appear in a dated timeline. Companies can add private internal notes to applications; those notes are never returned to candidate accounts and are erased when a candidate withdraws consent. A PostgreSQL target schema and migration plan are included as preparation only: the running service still uses the JSON file store. See `docs/POSTGRESQL_MIGRATION.md`.


## Company workspace (0.14)
Company owners can invite existing ZERILYS members as recruiters or read-only viewers. Invitations are single-use, expire after seven days, and currently require manual token delivery; no invitation email is sent. See `docs/COMPANY_WORKSPACE_0_14.md` for role permissions and API details.


## Company workspace interface (0.15)
Owners and invited team members can access the company workspace from the opportunities area. Owners manage invitations and team access; recruiters manage opportunities and applications; viewers have read-only access. Invitation tokens must still be delivered manually because transactional email is not connected.


## Data & privacy controls (0.16)
Members can export their account records as JSON and request account deletion from the Professional Universe's Data & Privacy panel. Account deletion removes associated operational records, while opaque audit events are retained for accountability. This is not a substitute for a formal legal/privacy review or a documented statutory retention policy.


## Trust & Safety operations (0.17)
Authorized reviewers configured through `ZERIHLINK_REVIEWER_EMAILS` can inspect open reports and evidence awaiting review from the restricted Trust Operations panel. All review API routes remain server-authorized; hiding the panel is not the security boundary.


## Account security and backup operations (0.18)
The Data & Privacy panel now lists active sessions, can revoke other sessions, and supports authenticated password changes. Run `npm run backup` for a local checksummed snapshot and `npm run backup:verify` to verify it. Restoring requires `ZERIHLINK_RESTORE_FILE` plus `ZERIHLINK_RESTORE_CONFIRM=RESTORE` and creates a pre-restore safety copy. Backups are still on the same disk; off-site backup and PostgreSQL are not configured.


## Controlled beta invitations (0.19)
Authorized reviewers can create single-use invitations tied to one exact email address, revoke pending invitations, and share the token privately. The token is stored as a hash, expires, and cannot be replayed. The configured shared beta code remains supported. No invitation email is sent automatically.


## Operational readiness (0.20)
The runtime now refuses a second process using the same data directory and exposes storage/backup diagnostics only to authorized reviewers. It remains a single-process JSON-file application; the lock is a safeguard, not a replacement for PostgreSQL or off-site backups.


## Private beta feedback (0.21)
Members can submit structured feedback from their Professional Universe. Authorized reviewers can triage bug reports, confusing experiences, ideas and other feedback. Reviewers can mark an item reviewed, accept it for follow-up or decline it. Feedback is included in account export and removed with account deletion.


## Reverse-proxy rate limiting (0.22)
When deployed behind a trusted reverse proxy, set `ZERIHLINK_TRUST_PROXY=true`. The application then keys rate limits on the rightmost `X-Forwarded-For` address; otherwise it uses the socket peer address. Do not enable this setting when the application is directly exposed to untrusted clients.


## PostgreSQL migration package (0.23)
The target schema now covers the current product entities. `npm run export:postgres` generates a transactional SQL export from the JSON store; `npm run smoke:postgres-export` tests the generated file using synthetic data. This does not activate PostgreSQL: the runtime still uses the JSON store, and the SQL has not yet been executed against a real PostgreSQL server.


## Data integrity preflight (0.24)
Run `npm run validate:data` against the configured JSON data directory before a release or migration. The reviewer operations dashboard also reports the current integrity status. The validator checks references and the append-only audit hash chain; it does not replace a database migration test or a security audit.


## Guided activation (0.25)
The Professional Universe now includes a transparent activation checklist for candidates; company accounts receive a separate setup path. It helps members complete the information needed for useful discovery without creating a popularity or suitability score.


## Bêta privée — release gate (0.26)
`npm run test:release` runs the automated suite. `npm run preflight:beta` checks the production configuration and manual launch acknowledgements. The preflight will block until a deployed URL, browser QA, legal review, reviewer coverage and off-site backup/restore are confirmed. The 50-tester rollout plan is in `docs/BETA_LAUNCH_PLAN_0_26.md`.


## Beta consent (0.27)
New registrations must accept the beta terms and acknowledge the privacy notice. Existing accounts are prompted when their recorded versions are outdated. The current documents are drafts only and are not legally approved; registration is server-disabled by default (`ZERIHLINK_BETA_LEGAL_APPROVED=false`) until the controller details and legal review are complete.


## Email delivery and password recovery (0.28)
A generic authenticated email webhook can deliver private beta invitations and password-reset tokens. Without it, invitations fall back to manual delivery and password reset is unavailable. See `docs/EMAIL_DELIVERY_0_28.md` for the webhook contract and required configuration.


## Company verification (0.29)
Company opportunities are discoverable only after an authorized reviewer approves the company's public identity evidence. Identity changes invalidate approval. See `docs/COMPANY_VERIFICATION_0_29.md`.


## Privacy by default (0.30)
New personal profiles start private to anonymous visitors, while all signed-in members can consult every candidate profile. Members can opt into public discovery and public profile links. Existing members' visibility settings are preserved. See `docs/PRIVACY_DEFAULTS_0_30.md`.


## Member portraits and profile access (0.35)
Members can add, replace or remove a profile portrait. The portrait is resized in the browser and displayed in the personal identity core, member cards and profile views. All signed-in members can discover and consult every candidate profile, including profiles marked private; private mode only excludes anonymous discovery and public profile links. Blocked member pairs remain isolated. See `docs/QA_0_35.md` for limits and manual checks.


## Profile media storage (0.37)
Profile photographs are stored as separate compressed files under the persistent data directory, not embedded in the main JSON account store. Backups include the media bytes in the checksummed backup snapshot; account exports include the member's own image. The hosting volume must persist both `zerihlink.json` and the `avatars/` directory. A restart integration smoke checks that both photo and session survive on the same volume. See `docs/QA_0_37.md`.


## Member discovery in Human Orbit (0.38)
The NETWORK node in a member's personal orbit opens a compact, searchable member explorer. Signed-in users can search candidate profiles by name, skill or location and open another member's professional universe without leaving the profile experience. Private visibility and block restrictions continue to be enforced by the server. See `docs/QA_0_38.md`.


## One-click portrait setup (0.39)
The central avatar in the personal Human Orbit opens the photo picker directly. Members without a photo see a restrained `ADD PHOTO` hint; existing portraits show `CHANGE` on hover. The full editor continues to provide add, replace and remove controls.


## Progressive member discovery (0.40)
The in-profile NETWORK explorer now reveals search results in batches of seven with a compact `Load more profiles` action, making the first cohort easier to browse without a long page or an overwhelming list.


## Mobile Human Orbit (0.41)
The personal profile has a dedicated narrow-screen layout: the central portrait and all seven main orbit signals stay within the viewport, while secondary skill satellites are replaced by the dedicated CAPABILITIES panel to avoid crowding.


## Mobile member profile viewing (0.42)
Profiles opened from the NETWORK explorer now have a dedicated mobile layout, with a compact portrait header, smaller orbit, scrollable inspector and wrapped profile actions.


## Shareable identity links (0.43)
Public profiles use crawler-readable `/p/:id` pages with Open Graph and Twitter preview metadata. Private profiles share a member-only `/?profile=...` link; a signed-out recipient is prompted to sign in and then returned to the requested profile. Set `ZERIHLINK_PUBLIC_URL` to the canonical HTTPS origin in production so link previews use the correct domain.


## Shared-profile conversion (0.44)
Signed-out visitors can join directly from a public profile to connect with that member. The requested identity is retained through registration, login and legal-consent completion, and shared profiles open before background discovery requests complete.


## Scalable member discovery (0.45)
The NETWORK explorer now uses validated server-side pagination instead of stopping at 50 profiles. It reveals seven at a time and fetches the next server page when needed, so every member remains discoverable as the cohort grows.


## First 50-member cohort validation (0.46)
The release suite now creates 50 test candidate accounts, verifies discovery and access to all 49 other private profiles over three server pages, checks private photo delivery and confirms profile media remains separate from the JSON account store. Run `npm run smoke:cohort50` independently.


## Closed-beta launch kit (0.47)
Use `.env.production.example`, `docs/BETA_LAUNCH_RUNBOOK_0_50.md` and `docs/BETA_TESTER_GUIDE_0_47.md` to prepare the first 50 testers. The preflight now checks that avatar media storage is writable and intact, that the newest backup includes profile photos, and warns when the canonical public HTTPS origin is missing. It deliberately keeps legal and human QA acknowledgements as manual blockers.


## Backup retention (0.48)
Local backups retain the newest 14 verified backup/manifest pairs by default. Configure `ZERIHLINK_BACKUP_RETENTION` from 2 to 100. Older pairs and orphan files are pruned only after a new snapshot and manifest are written; keep a separate off-site copy as required by the launch runbook.


## Invitation-controlled cohort test (0.49)
The 50-member cohort smoke still validates optional email-bound invitations for a research cohort; standard account creation is open and does not require an invitation.


## Bulk beta invitations (0.50)
Reviewers can paste up to 50 email addresses into the restricted Trust & Safety console and create a complete invitation batch in one action. Validation is all-or-nothing; each invitation remains unique, email-bound and single-use. Manual tokens are shown once and can be copied as an email/token list when transactional email is not configured.


## Invitation cohort tracking (0.51)
The reviewer console now tracks each bulk invitation batch after delivery, showing how many testers have registered, remain pending, were revoked or expired. Invitation tokens are not retained in the batch history; pending invitations remain individually revocable.


## Accessibility and reduced motion (0.52)
Application dialogs now manage focus and keyboard navigation, orbit selections expose their active state to assistive technology, photo status is announced, and users who request reduced motion receive a static, low-motion experience.


## Remote deployment acceptance (0.53)
After deployment, run `ZERIHLINK_DEPLOYMENT_URL=https://your-domain.example npm run check:remote`. The read-only check validates the deployed version, security headers, invitation gate, anonymous profile privacy and static assets. Optional public/private profile IDs verify real share pages without credentials.


## Version 0.62 — French deployment readiness
The 0.62 package includes the FR / EN selector, French-first product copy, expanded translations across candidate and operational journeys, locale-aware date/time formatting, French beta legal drafts, and the updated first-tester guide. It remains a staging candidate until the legal placeholders are completed and approved, the production host is validated, and the manual browser and operations checks are complete.


### Local beta test mode — important

The Windows launcher enables `ZERIHLINK_LOCAL_BETA_TEST_MODE=true` for local testing only. The server explicitly ignores this switch when `NODE_ENV=production`. This allows local account/profile testing while the public production legal registration gate remains independent and closed until the beta terms and privacy notice have been appropriately reviewed and approved. Do not deploy the local launcher or its environment switch as a production configuration.


## Version 0.68 — fiabilité des contrôles de release

La version 0.68 aligne les contrôles smoke locaux et distants sur la version réellement exécutée. Les tests de déploiement, de persistance des portraits, de préférences linguistiques et de cohorte 50 vérifient désormais la version courante au lieu de conserver une référence obsolète à 0.66. Cette correction évite les faux échecs de validation et rétablit une chaîne de contrôle exploitable avant la bêta.


## Version 0.71 — profils publics et mise en relation

La version 0.71 améliore la lecture de l’identité professionnelle après enregistrement : le centre Human Orbit est agrandi, les informations clés sont mieux hiérarchisées et le panneau de synthèse reprend la présentation, les apports, les aspirations, les intérêts et le site internet. Le parcours de complétion est présenté sous forme de cartes d’action. Les nouveaux visiteurs commencent en français, et les surfaces du profil bénéficient d’une couverture de traduction étendue. Voir `docs/QA_0_69.md` pour le périmètre et les limites de validation.


La version 0.70 étend la traduction française aux écrans dynamiques et à l’éditeur complet du profil, améliore les libellés du parcours d’activation et évite la réduction excessive du cœur Human Orbit sur les petits écrans. Les validations de release sont consignées dans `docs/QA_0_70.md`.


La version 0.71 étend l’harmonisation française aux profils publics et aux actions de mise en relation. Voir `docs/QA_0_71.md` et `docs/RELEASE_CANDIDATE_0_71.md`.

### Contrôle ciblé 0.84

La version 0.84 étend la couche de traduction française aux panneaux de profil générés dynamiquement et aux retours d'interaction. Les tests automatisés vérifient la présence des libellés principaux et le maintien du français comme langue initiale. Cette vérification de code ne remplace pas une recette visuelle sur navigateur réel.


### Contrôle ciblé 0.85

La version 0.85 corrige le panneau de détail d’une compétence dans Human Orbit : intitulé, niveau, statut de vérification, preuves associées, état sans preuve et action d’ajout sont désormais rédigés en français lorsque l’interface est en français. Un test de non-régression couvre les états dynamiques de ce panneau. La recette visuelle sur navigateur réel reste nécessaire.


### Version 0.87.0
Consolidation de plusieurs parcours en un seul lot : français natif, découverte, opportunités, espace entreprise, identité, réalisations et confidentialité. Voir `CHANGELOG.md`.

### Version 0.93.0
The French-first interface dictionary now covers additional dynamically rendered Human Orbit, discovery, connection and company-space messages. Automated regression tests protect these key language paths. Production launch still requires the deployment, legal, backup and human-device checks described below.


### Version 0.93.0

Corrects a language-switching defect: choosing English now restores the original English copy across existing text nodes and translatable attributes, while dynamic content continues to be observed. Includes dedicated regression coverage.

### Version 0.93.0
The French-first language layer now covers interpolated skill, evidence and opportunity labels in dynamic Human Orbit panels. User-entered profile content remains unchanged.


### Version 0.95.0

Renforcement du responsive Human Orbit sur téléphones compacts : largeur maîtrisée, panneaux flexibles, libellés qui reviennent à la ligne et règles dédiées aux écrans de 390 px et 340 px. La validation automatisée ne remplace pas les essais visuels sur appareils physiques.


### Version 0.95.0

Renforce la couverture française des parcours dynamiques (authentification, découverte, réseau, collaborations, notifications, modération et édition du profil). Le contenu personnel saisi par les membres reste inchangé.

### 0.98.0
Human Orbit panel copy and editor section headings are resolved through the active language layer at render time. Member-authored profile content remains in its original language.

### 0.98.0
Public identity, network actions and notification interface copy now use the active language layer. Member-authored profile and evidence content remains unchanged and escaped.

### Version 1.1.0-alpha.1 — repositionnement Talent Intelligence — synchronisation du profil
Après une modification de profil, les vues dépendantes sont rechargées depuis la version canonique du serveur : Human Orbit, compétences, réalisations, découverte, collaborations, opportunités et suivi des candidatures. Les mutations de photo, de compétence et de réalisation utilisent le même mécanisme.

## Talent Intelligence direction (1.1.0-alpha.1)

ZERILYS is now positioned as a specialist talent platform for finance, AI and data. See `docs/PRODUCT_VISION_TALENT_INTELLIGENCE.md` for product strategy and commercial hypotheses, and `docs/COMMERCIAL_READINESS.md` for the explicit public-launch blockers. The previous WORLD INTELLIGENCE and ZERILYS packages are preserved under `legacy/`; WORLD INTELLIGENCE is not part of the runtime.

## Nouvelle direction produit (1.7.0-alpha.1)

La direction produit évolue vers une plateforme spécialisée de découverte et de validation des compétences : identité professionnelle, évaluations réutilisables, missions pratiques, opportunités et matching à deux dimensions (Parcours / Technique). Le nom ZERILYS est un nom technique provisoire en attente d'un renommage ; MATCHCANDIDATE est abandonné.

Lire `docs/PRODUCT_REFOUNDATION_1_7.md` et `docs/BRAND_RENAMING_BRIEF.md`. Le moteur `src/dual-match.js` est une première brique testée, non encore intégrée aux parcours API et interface.


## ZERIH ASSESS — évaluations de compétences (1.9.0-alpha.7)

Le profil candidat dispose d’un espace d’évaluation avec une première bibliothèque pilote (SQL, Python/data, risque financier). Les résultats sont corrigés côté serveur, datés, associés à une version de test et réutilisables dans le Match Technique. Les offres d’entreprise reçoivent des suggestions d’évaluations à partir des compétences demandées ; le plan peut être ajusté par le recruteur via l’API de gestion d’offre. Les évaluations ne sont pas exposées dans les profils publics.

Les résultats de cette bibliothèque sont des preuves limitées aux tests proposés : ils ne constituent pas une certification professionnelle ni une prédiction de performance future.


## Périmètre métier élargi
La cible couvre les talents qualifiés de Bac+4 à la recherche avancée : ingénierie, numérique, finance, commerce/management, sciences et recherche. Les opportunités comprennent stages, alternances, emplois, graduate programmes, missions et collaborations. Voir `PRODUCT_SCOPE_EXPANSION_1.9.md`.


## Partage sélectif des évaluations — alpha.8

Les résultats d’évaluation ne sont jamais partagés lors de l’envoi d’un intérêt. Depuis le suivi de chaque candidature, le candidat peut sélectionner les évaluations précises à communiquer à l’entreprise concernée. Le choix est versionné et journalisé ; une sélection vide retire l’autorisation et coupe immédiatement l’accès futur depuis l’espace entreprise. Les réponses aux questionnaires ne sont pas transmises ; un cas pratique n’est communiqué que s’il est explicitement sélectionné. La révocation ne peut toutefois pas effacer une information déjà consultée ou copiée par son destinataire.
