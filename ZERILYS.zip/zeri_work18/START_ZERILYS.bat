@echo off
setlocal
cd /d "%~dp0"
title ZERILYS — Test local
set ZERIHLINK_LOCAL_BETA_TEST_MODE=true
where node >nul 2>nul
if errorlevel 1 (echo Install Node.js 20+ from https://nodejs.org/ & pause & exit /b 1)
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node.split('.')[0]"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 20 (echo Node.js 20+ required & pause & exit /b 1)
start "ZERILYS server" cmd /k "cd /d ""%~dp0"" && npm.cmd start"
set /a N=0
:wait
set /a N+=1
powershell -NoProfile -ExecutionPolicy Bypass -Command "try {$r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:8787/api/health -TimeoutSec 2; if($r.StatusCode -eq 200){exit 0}else{exit 1}}catch{exit 1}"
if not errorlevel 1 goto ready
if %N% GEQ 30 (echo Server did not start. Check ZERILYS server window. & pause & exit /b 1)
timeout /t 1 /nobreak >nul
goto wait
:ready
start "" http://localhost:8787
exit /b 0
