# État du lancement public — 13 novembre 2026

## Infrastructure
- Une base Render PostgreSQL 18 a été créée dans la région Frankfurt : `talent-intelligence-prod-db`.
- Plan provisionné : `basic_256mb`, disque 1 GB. Statut initial retourné par Render : `creating`.
- Tableau de bord : https://dashboard.render.com/d/dpg-dbrmgn0m7kps73cn3790-a
- Aucun service web Render n'a été créé. Le dépôt GitHub connecté (`Augustin-di-pasco/ZERILYS`, branche `main`) contient une version historique `1.0.0-rc.4`, pas cette version `1.9.0-alpha.20`. La déployer aurait publié le mauvais produit.
- Le code alpha.20 n'a pas encore été synchronisé vers GitHub. L'environnement d'exécution disponible ici ne peut pas joindre GitHub par Git/SSH et le connecteur GitHub disponible ne fournit pas de transfert de répertoire local complet.

## Stockage
Le code propose un adaptateur PostgreSQL activable via `ZERIHLINK_STORAGE=postgres` et `DATABASE_URL`. Il persiste l'état applicatif dans une ligne JSONB, et non dans un schéma relationnel normalisé. Les médias (avatars et justificatifs) restent sur volume persistant. Le mode mono-instance reste requis.

## Vérifications locales sur la source alpha.20
- `npm test` : 250/250 réussis.
- `npm run check` : réussi.
- `npm run smoke:postgres-runtime` : 6/6 réussis.
- Les smoke tests de release et contrôles de pré-lancement sont décrits dans `RELEASE_MANIFEST.md` et `GO_LIVE_50_TESTERS.md`.

## Ce qui interdit encore d'ouvrir les inscriptions
- Synchroniser la source exacte alpha.20 vers le dépôt distant et relire le diff.
- Déployer le service web et lier sa variable `DATABASE_URL` à la base créée.
- Configurer la clé de session, les modérateurs, l'URL canonique, les sauvegardes hors site et l'email transactionnel.
- Vérifier `/api/health` sur le vrai domaine et effectuer les tests humains ordinateur/mobile.
- Revue juridique des conditions, confidentialité, conservation, consentement et mentions légales.
- Ne pas passer `ZERIHLINK_BETA_LEGAL_APPROVED=true` ni `ZERIHLINK_ALLOW_SIGNUP=true` avant cette validation.

## Attention aux coûts
La base PostgreSQL est une ressource payante (plan Basic). Le montant exact courant doit être vérifié dans le tableau de bord Render avant toute montée en gamme. Aucun service web n'a encore été créé ni facturé par ce déploiement.
