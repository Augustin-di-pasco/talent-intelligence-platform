# ZERILYS — identité de marque officielle

**Marque :** ZERILYS  
**Signature :** BEYOND THE CV.  
**Descripteur :** Talent Intelligence Platform  
**Promesse :** révéler les compétences réelles, les rendre démontrables et connecter les talents aux opportunités pertinentes.

## Positionnement
ZERILYS est une plateforme de Talent Intelligence centrée sur la personne. Elle aide les candidats, étudiants, jeunes diplômés, professionnels et chercheurs à rendre leurs compétences lisibles au-delà du CV, grâce à des preuves, des évaluations réutilisables et des missions concrètes. Elle aide les organisations à découvrir des profils et à apprécier les compétences avec transparence et intervention humaine.

## Architecture produit
- **Human Orbit** — identité professionnelle et trajectoire.
- **Assessments** — évaluations structurées et preuves de compétences.
- **Mission Labs** — mises en situation et projets collaboratifs encadrés.
- **Intelligence** — graphe de compétences, preuves, talents et besoins.
- **Opportunities** — emplois, stages, alternances, VIE, missions et projets de recherche.

## Principes de marque et de produit
- Une marque internationale, une expérience française native par défaut et une version anglaise cohérente.
- Aucune note globale opaque : distinguer parcours déclaré et compétences évaluées.
- Une preuve absente signifie « non évalué », jamais zéro.
- Le jugement humain, la transparence, la confidentialité et l'accessibilité priment.
- Aucune mission productive non rémunérée déguisée en exercice de sélection.

## Gouvernance de marque
Le choix du nom ZERILYS est confirmé par le porteur du projet. Les vérifications et dépôts de marque, les droits sur les domaines et les identifiants sociaux restent des démarches juridiques et administratives distinctes ; le présent document ne constitue pas un certificat de disponibilité ni un dépôt.
