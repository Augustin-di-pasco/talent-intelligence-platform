# ZERILYS — Guide de recette bêta · 1.0.0-rc.4

## Statut de diffusion
Cette archive est une préversion technique destinée à la recette interne. Elle ne doit pas être distribuée comme bêta ouverte tant que `npm run launch:check` n’indique pas une préparation complète et que les contrôles humains, juridiques et d’hébergement ne sont pas effectivement réalisés. Le verrou `ZERIHLINK_BETA_LEGAL_APPROVED` doit rester à `false` jusque-là.

# Guide des 50 premiers testeurs ZERILYS

Bienvenue dans la bêta privée française de ZERILYS. Cette phase sert à vérifier l'utilité du produit, la compréhension des parcours et la qualité de l'expérience avant toute ouverture plus large.

## Avant de commencer

- Utilisez une adresse e-mail à laquelle vous avez accès.
- Choisissez un mot de passe unique que vous n'utilisez pas ailleurs.
- Complétez votre identité professionnelle avec des informations que vous acceptez de partager avec les autres membres de la bêta.
- N'ajoutez pas de données sensibles, de documents confidentiels d'entreprise ou d'informations personnelles concernant des tiers.

## Parcours à tester

1. Créer un compte et se connecter.
2. Ajouter une photo et compléter le profil professionnel.
3. Vérifier que les informations enregistrées réapparaissent correctement dans Human Orbit après fermeture et reconnexion.
4. Ajouter des compétences, des réalisations et des intentions.
5. Explorer les profils des autres membres et vérifier la lisibilité sur téléphone.
6. Envoyer une demande de connexion en expliquant son contexte.
7. Consulter les notifications et répondre aux demandes reçues.
8. Tester les réglages de confidentialité, le partage de profil et la déconnexion.
9. Signaler immédiatement tout contenu inapproprié ou problème de sécurité via le canal communiqué par l'équipe.

## Comment transmettre un retour utile

Pour chaque problème, indiquez :
- l'appareil et le navigateur utilisés ;
- la page ou l'action concernée ;
- les étapes pour reproduire le problème ;
- le résultat attendu et le résultat observé ;
- une capture d'écran si elle ne contient pas d'informations confidentielles.

## Confidentialité et limites de la bêta

La bêta est un environnement de test. Ne considérez pas les profils, les éléments de preuve ou les rapprochements comme des certifications ou des recommandations d'embauche. Vérifiez les réglages de visibilité avant de partager un lien. Les demandes de connexion sont volontaires et doivent rester contextualisées.

L'équipe doit communiquer aux testeurs les documents juridiques validés, les coordonnées de contact, les règles de conservation et le canal de support avant toute collecte de données réelles. Ce guide produit ne remplace pas ces documents.

## Grille de recette — à remplir par l'équipe avant ouverture

| Domaine | Vérification attendue | Résultat |
|---|---|---|
| Inscription | Création, confirmation e-mail ou procédure manuelle, reconnexion | À tester sur l'hébergement |
| Profil | Les champs enregistrés restent présents après fermeture et reconnexion | À tester sur l'hébergement |
| Human Orbit | Les 8 panneaux sont compréhensibles, lisibles et correctement numérotés | À tester sur ordinateur et mobile |
| Langue | Français par défaut sur un navigateur français et après changement de langue | À tester sur navigateur réel |
| Réseau | Recherche, pagination, consultation d'un profil et demande contextualisée | À tester avec plusieurs comptes |
| Confidentialité | Profil privé non visible aux visiteurs anonymes ; visibilité membre conforme au choix | À tester avec session et navigation privée |
| Opportunités | Offre d'entreprise non vérifiée masquée ; intérêt explicite et retrait correctement gérés | À tester avec compte entreprise et candidat |
| Accessibilité | Navigation clavier, focus visible, zoom 200 %, libellés des champs | À tester sur navigateur réel |
| Sécurité | Signalement, blocage, déconnexion et accès aux médias selon les droits | À tester avec plusieurs comptes |

Ne renseigner « Réussi » qu'après exécution réelle. Conserver la date, le navigateur, l'appareil et le compte de test (sans mot de passe) pour chaque anomalie.

## Règle d'ouverture

Ne pas inviter les 50 testeurs tant que le verrou juridique, l'URL HTTPS, la persistance, les sauvegardes/restaurations, les comptes de modération et le canal de support ne sont pas validés. Les tests automatisés du dépôt ne valent pas recette humaine.

## Recette transversale — version 0.90

Effectuer les scénarios ci-dessous sur ordinateur et téléphone, en français puis en anglais :

1. **Identité et persistance** — modifier nom, titre, lieu, présentation, disponibilité, visibilité, liens et aspirations ; enregistrer ; fermer puis rouvrir le profil ; vérifier que chaque valeur est conservée dans Human Orbit et dans l’aperçu public selon les règles de visibilité.
2. **Compétences et réalisations** — ajouter, supprimer et associer une compétence à une réalisation ; vérifier les compteurs, les états déclaratif/vérifié et l’absence de contenu utilisateur interprété comme HTML.
3. **Réseau** — rechercher un membre, ouvrir son profil, envoyer une demande, accepter/refuser, bloquer/débloquer et vérifier les états affichés des deux côtés.
4. **Opportunités** — consulter une offre, vérifier les critères de correspondance, manifester son intérêt et contrôler l’état côté candidat et entreprise.
5. **Profil public et confidentialité** — tester un profil public puis membre uniquement en session connectée et déconnectée ; vérifier les liens partagés, photos, signalements et blocages.
6. **Langues et accessibilité** — vérifier le français natif par défaut, le choix explicite de l’anglais, les libellés des panneaux ouverts dynamiquement, le clavier, le focus, les lecteurs d’écran et la réduction des animations.
7. **Sécurité et exploitation** — tester consentement juridique, sessions, limitation des tentatives, sauvegarde incluant les médias et restauration sur environnement isolé.

Consigner pour chaque scénario : appareil/navigateur, compte et rôle, résultat attendu, résultat observé, capture ou vidéo si anomalie, sévérité et étapes de reproduction. Ne pas marquer la recette comme validée sur la seule base des tests automatisés.

## Vérification linguistique — lot 0.91
Sur chaque parcours, vérifier que les textes chargés après une interaction restent en français : panneaux Human Orbit, recherche de membres, états des mises en relation, pages entreprise et offres. Basculer volontairement en anglais puis revenir en français pour vérifier que le choix de langue reste cohérent. Signaler toute phrase anglaise visible dans l'interface française.


## Recette linguistique — lot 0.92

- Ouvrir l’application en français et vérifier les libellés des écrans principaux.
- Basculer vers l’anglais : les textes déjà affichés, placeholders, descriptions accessibles et textes alternatifs doivent revenir en anglais.
- Ouvrir ensuite un panneau dynamique (profil, réseau, entreprise), puis rebasculez en français et en anglais : aucun écran ne doit conserver un mélange des deux langues.

### Langue et contenus dynamiques (0.93)
- Dans Human Orbit, ouvrir Compétences, Réalisations et Opportunités avec des données renseignées.
- Vérifier que les niveaux, types et états sont en français sans traduire les noms ou descriptions saisis par le membre.
- Basculer FR → EN → FR avec un panneau déjà ouvert et vérifier que les libellés restent cohérents.


### Recette mobile complémentaire (0.94)

Tester Human Orbit sur des largeurs de 340 px, 360 px, 390 px et 430 px : vérifier l'absence de défilement horizontal, la lisibilité du nom/titre/localisation, l'absence de chevauchement entre satellites, l'accès aux panneaux et la taille des zones tactiles. Refaire les mêmes contrôles en orientation paysage et avec un nom professionnel long.


### Contrôle linguistique transversal (0.95)

- Vérifier les écrans de connexion et de création de compte en français puis en anglais.
- Parcourir la découverte, les résultats paginés, les demandes de mise en relation et les notifications.
- Vérifier que les libellés d’interface changent de langue mais que le nom, le parcours, les compétences et les descriptions rédigés par un membre ne sont jamais traduits automatiquement.
- Contrôler les messages vides, les erreurs réseau et les états de chargement.


## Contrôles complémentaires — version 0.96

- En français, vérifier les cartes de découverte : localisation, nombre de réalisations, état du profil, complémentarité et bouton de mise en relation.
- Dans le réseau Human Orbit, vérifier le compteur « X sur Y profils », le chargement progressif, les états vides et les erreurs.
- Dans les collaborations, vérifier les modalités, le nombre de personnes intéressées, le nom du porteur et le bouton d’exploration.
- Basculer en anglais puis revenir en français : vérifier que les libellés suivent la langue sélectionnée.
- Vérifier que les intitulés, descriptions et compétences rédigés par les membres restent strictement inchangés.
- Réaliser ces contrôles sur un téléphone et un ordinateur ; les tests automatisés ne remplacent pas cette recette humaine.

### Recette 0.97 — Human Orbit et changement de langue
- Ouvrir successivement les huit panneaux Human Orbit en français puis en anglais.
- Vérifier les titres, descriptions, états vides, champs de recherche et actions dans la langue choisie.
- Vérifier que les textes personnels saisis par un membre restent inchangés lors du changement de langue.
- Modifier l'identité, revenir aux panneaux, puis vérifier que les données personnelles restent présentes.

### Recette 0.99 — cohérence du profil
1. Modifier le nom, l'intitulé, la localisation, la présentation, les intentions et la visibilité ; enregistrer.
2. Vérifier que Human Orbit et l'en-tête du profil reflètent immédiatement les nouvelles valeurs.
3. Revenir à la découverte, aux collaborations et aux opportunités : les données liées au profil doivent être actualisées sans rechargement manuel de la page.
4. Ajouter une compétence puis une réalisation ; vérifier les compteurs, les panneaux et les signaux associés.
5. Remplacer puis supprimer la photo ; vérifier le menu, l'éditeur, Human Orbit et les cartes de découverte.
6. Recharger la page et confirmer que les valeurs persistées restent identiques.


### Recette 1.0.0-rc.4 — profil et compétences
- Enregistrer une adresse de site en HTTPS, puis vérifier son affichage sur l’identité ; supprimer ensuite cette adresse et vérifier qu’elle disparaît.
- Confirmer que les URL HTTP, les URL avec identifiants intégrés et les protocoles non web sont refusés par le serveur.
- Envoyer des valeurs de disponibilité ou de visibilité non proposées : le serveur doit répondre 400 sans modifier le profil.
- Ajouter une compétence à chacun des niveaux disponibles et vérifier les libellés français « En apprentissage », « Opérationnel », « Avancé » et « Expert ».
- Vérifier que les satellites et leurs libellés de preuves restent lisibles en français et en anglais.
- Ces tests automatisés ne remplacent pas la recette visuelle sur téléphone et ordinateur.

## Mise à jour 1.0.0-rc.4 — parcours de candidature

- Les statuts et l’historique de candidature sont affichés dans la langue choisie, côté candidat comme côté entreprise.
- Le retrait d’intérêt reste une action explicite avec confirmation ; il retire l’accès de l’entreprise aux informations de candidature selon le parcours prévu.
- Les notes internes de recrutement sont clairement identifiées comme privées à l’équipe de l’entreprise.
- Lors de la recette, vérifier un cycle complet : intérêt transmis, examen, entretien ou refus, notification reçue et retrait éventuel.
