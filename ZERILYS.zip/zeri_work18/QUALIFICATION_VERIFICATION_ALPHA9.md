# Vérification des diplômes et équivalences — alpha.9

## Parcours candidat
- Le candidat renseigne l'intitulé, l'établissement/organisme, le niveau et le type de justificatif (diplôme ou équivalence).
- Dépôt PDF/JPG/PNG limité à 650 Ko, contrôle de signature du fichier et stockage privé avec permissions restrictives.
- Un seul dossier en attente à la fois. Le candidat consulte le statut et le retour depuis son profil.

## Décision et badge
- File accessible uniquement aux adresses configurées dans `ZERIHLINK_REVIEWER_EMAILS`.
- Consultation du document limitée à l'évaluateur habilité et au statut en attente.
- Décision motivée obligatoire : vérifié, complément demandé ou refusé. Chaque décision est auditée.
- Le badge public est un indicateur binaire : il apparaît uniquement si au moins un diplôme ou une équivalence a été validé. Aucun document, intitulé détaillé, commentaire ou niveau n'est exposé publiquement.
- Après décision, le fichier justificatif est supprimé du stockage actif. Le statut, la justification interne et l'empreinte SHA-256 sont conservés dans le dossier. La suppression du compte supprime aussi les justificatifs encore en attente.
- Les sauvegardes incluent les justificatifs encore en attente et les restaurent dans le répertoire privé. Elles restent donc elles-mêmes des données sensibles à protéger.

## Rôle éventuel de l'IA
L'alpha.9 n'utilise pas d'IA pour valider les diplômes. C'est volontaire : une IA peut aider plus tard à lire un document, extraire l'établissement, le titre, la date et signaler des incohérences, mais ne doit jamais attribuer seule le badge. La décision finale doit rester humaine, avec possibilité de demander un complément ou une revue. Toute future analyse IA devra être annoncée, minimisée, traçable, évaluée sur les faux positifs/faux négatifs et validée juridiquement.

## Limites
- Pas de connexion automatique aux registres d'établissements ou bases officielles.
- Pas de validation cryptographique des diplômes, ni détection avancée de falsification.
- Le contrôle humain n'est pas une certification officielle du diplôme.
- Les justificatifs de diplômes sont des données personnelles : politique de conservation, information candidat, base légale, droits d'accès et sous-traitants doivent être revus avant ouverture réelle.
