/* ZERILYS language layer — French-first default, persistent explicit choice, dynamic content. */
(() => {
  const STORAGE_KEY = "zerihlink.language.v1";
  const supported = new Set(["fr", "en"]);
  const fr = {
    'FINANCE · AI · DATA TALENT NETWORK': 'RÉSEAU DE TALENTS · FINANCE · IA · DATA',
    'The right expertise.': 'Les bonnes expertises.',
    'Within reach.': 'À portée de main.',
    'Find specialist talent, relevant opportunities and people to build with.': 'Trouvez des talents spécialisés, des opportunités et des partenaires de projet.',
    'Create my profile': 'Créer mon profil',
    'YOUR PROFILE': 'VOTRE PROFIL',
    'PROFESSIONAL PROFILE': 'PROFIL PROFESSIONNEL',
    'OPEN TO WHAT’S NEXT': 'PRÊT POUR LA SUITE',
    'Skills': 'Compétences', 'Opportunities': 'Opportunités', 'Evidence': 'Réalisations', 'Experience': 'Parcours', 'Your goals': 'Vos objectifs', 'Network': 'Réseau', 'Projects': 'Projets',
    'SKILLS · EVIDENCE · OPPORTUNITIES': 'COMPÉTENCES · PREUVES · OPPORTUNITÉS',
    'PROFILE': 'PROFIL', 'OPPORTUNITIES': 'OPPORTUNITÉS', 'PROJECTS': 'PROJETS',
    'Explore specialist<br><em>profiles.</em>': 'Explorez des profils<br><em>spécialisés.</em>',
    'Find people by expertise, experience and demonstrated work.': 'Trouvez des profils par expertise, expérience et réalisations.',
    'Search a skill, a profile or a location': 'Rechercher une compétence, un profil ou un lieu',
    'Search profiles ↗': 'Rechercher des profils ↗', 'POPULAR SPECIALTIES': 'SPÉCIALITÉS RECHERCHÉES',
    'What are you building?': 'Que souhaitez-vous construire ?',
    'Describe the challenge and the contribution you need (at least 30 characters).': 'Décrivez le défi et les contributions recherchées (30 caractères minimum).',
    'Project type': 'Type de projet', 'Unknown project type.': 'Type de projet inconnu.',
    'Compensation for this company challenge: paid or expenses': 'Compensation du défi : paid ou expenses',
    'A company challenge must be compensated.': 'Un défi d’entreprise doit prévoir une rémunération ou une prise en charge des frais.',
    'Skills needed, separated by commas (optional)': 'Compétences recherchées, séparées par des virgules (facultatif)',
    'Expected duration in weeks (optional)': 'Durée prévisionnelle en semaines (facultatif)',
    'Maximum team size, including you': 'Taille maximale de l’équipe, vous compris',
    'Expected deliverables, separated by commas (optional)': 'Livrables attendus, séparés par des virgules (facultatif)',
    'Community project': 'Projet collectif', 'Learning project': 'Projet pédagogique', 'Research project': 'Projet de recherche', 'Company challenge': 'Défi d’entreprise',
    'Paid': 'Rémunéré', 'Expenses covered': 'Frais pris en charge', 'Equity-based': 'Avec participation au capital', 'Learning project · unpaid': 'Projet pédagogique non rémunéré', 'No compensation specified': 'Aucune compensation précisée',
    'weeks': 'semaines', 'Team up to': 'Équipe jusqu’à',
    'PROJECT LABS': 'ATELIERS DE PROJETS', 'Create a project': 'Créer un projet',
    'Describe the goal, the people you need and the outcome your team will produce.': 'Décrivez l’objectif, les profils recherchés et le résultat attendu de l’équipe.',
    'Project title': 'Titre du projet', 'Project description': 'Description du projet',
    'e.g. Build a financial forecasting tool': 'Ex. : concevoir un outil de prévision financière',
    'Explain the challenge, context and contribution expected.': 'Présentez le défi, son contexte et les contributions attendues.',
    'Time commitment': 'Disponibilité requise', 'A few hours a week': 'Quelques heures par semaine',
    'Part time': 'À temps partiel', 'Full time': 'À temps plein',
    'Compensation for company challenge': 'Compensation du défi d’entreprise',
    'Commercial company challenges must be paid or cover participant expenses.': 'Les défis commerciaux doivent être rémunérés ou couvrir les frais des participants.',
    'Duration (weeks)': 'Durée (semaines)', 'Skills needed (comma separated)': 'Compétences recherchées (séparées par des virgules)',
    'Finance, Python, product design…': 'Finance, Python, conception produit…',
    'Expected deliverables (comma separated)': 'Livrables attendus (séparés par des virgules)',
    'Prototype, report, presentation…': 'Prototype, rapport, présentation…', 'Publish project': 'Publier le projet',
    'Loading project workspace…': 'Chargement de l’espace projet…', 'Project': 'Projet',
    'Project team': 'Équipe projet', 'Project lead': 'Responsable du projet', 'Applications': 'Candidatures',
    'No introduction provided.': 'Aucun message de présentation.', 'No applications yet.': 'Aucune candidature pour le moment.',
    'Accept': 'Accepter', 'Decline': 'Refuser', 'Member': 'Membre', 'Team task board': 'Tableau des tâches',
    'todo': 'à faire', 'in_progress': 'en cours', 'done': 'terminé', 'pending': 'en attente', 'accepted': 'acceptée', 'rejected': 'refusée',
    'Task status': 'État de la tâche', 'To do': 'À faire', 'In progress': 'En cours', 'Done': 'Terminé',
    'Team member': 'Membre de l’équipe', 'No tasks yet. Add the first action for your team.': 'Aucune tâche. Ajoutez la première action de votre équipe.',
    'New task': 'Nouvelle tâche', 'e.g. Prepare the first prototype': 'Ex. : préparer le premier prototype',
    'Description': 'Description', 'What needs to be done?': 'Que faut-il réaliser ?', 'Assign to': 'Attribuer à',
    'Due date': 'Échéance', 'Add task': 'Ajouter la tâche', 'Join this project to access the private team workspace, tasks and deliverables.': 'Rejoignez ce projet pour accéder à l’espace privé de l’équipe, aux tâches et aux livrables.',
    'Apply to join': 'Candidater pour rejoindre', 'Member accepted into the team.': 'Membre accepté dans l’équipe.',
    'Application declined.': 'Candidature refusée.', 'Task updated.': 'Tâche mise à jour.', 'Task added to the team board.': 'Tâche ajoutée au tableau de l’équipe.',
    'Duration not specified': 'Durée non précisée', 'The team will appear here after members are accepted.': 'L’équipe apparaîtra ici après l’acceptation des membres.' ,
    'PROJECTS & COLLABORATIONS': 'PROJETS & COLLABORATIONS',
    'Find the right people<br><em>to build with.</em>': 'Trouvez les bonnes personnes<br><em>pour construire.</em>',
    'Discover projects or bring your own challenge to the network.': 'Découvrez des projets ou proposez votre propre initiative au réseau.',
    'From idea<br>to team.': 'De l’idée<br>à l’équipe.',
    'Meet people with complementary skills and move a project forward.': 'Réunissez des compétences complémentaires pour faire avancer un projet.',
    'Create a project ↗': 'Créer un projet ↗', 'JOBS & MISSIONS': 'OFFRES & MISSIONS',
    'Opportunities that<br><em>match your expertise.</em>': 'Des opportunités<br><em>adaptées à votre expertise.</em>',
    'Browse roles and missions published by companies.': 'Consultez les postes et missions publiés par les entreprises.',
    'NO SOCIAL FEED · ONLY PROFESSIONAL OPPORTUNITIES': 'PAS DE FIL SOCIAL · DES OPPORTUNITÉS PROFESSIONNELLES',
    'Refresh ↻': 'Actualiser ↻', 'MY APPLICATIONS': 'MES CANDIDATURES', 'Track your applications': 'Suivez vos candidatures',
    'TALENT SEARCH': 'RECHERCHE DE TALENTS',
    'Search by skills.<br><em>Not just job titles.</em>': 'Recherchez par compétences.<br><em>Pas seulement par métier.</em>',
    'Explore skills, experience and evidence across the profiles on ZERILYS.': 'Explorez les compétences, parcours et réalisations des profils ZERILYS.',
    '01 / SEARCH': '01 / RECHERCHE', 'Search by expertise': 'Rechercher par expertise',
    'Find profiles by specialist skills and experience.': 'Trouvez des profils par compétences spécialisées et expérience.',
    '02 / DISCOVERY': '02 / DÉCOUVERTE', 'Spot complementary skills': 'Repérer les compétences complémentaires',
    'Identify people whose expertise fits your needs.': 'Identifiez les profils dont l’expertise répond à votre besoin.',
    '03 / EVIDENCE': '03 / RÉALISATIONS', 'See what is demonstrated': 'Voir les compétences démontrées',
    'Review skills, experience and supporting evidence in member profiles.': 'Consultez les compétences, parcours et réalisations associés aux profils.',
    'PROFILES FIRST · No opaque candidate scores or fabricated market statistics.': 'LES PROFILS AVANT TOUT · Aucun score opaque ni statistique de marché inventée.',
    'TRUST & TRANSPARENCY': 'CONFIANCE & TRANSPARENCE',
    'Skills backed<br><em>by evidence.</em>': 'Des compétences<br><em>étayées par des preuves.</em>',
    'Each profile distinguishes declared skills from demonstrated experience. You can see what supports each claim.': 'Chaque profil distingue les compétences déclarées de l’expérience démontrée. Les éléments justificatifs restent visibles.',
    '✓ Supporting evidence': '✓ Réalisations associées', '✓ Clear skill levels': '✓ Niveaux explicites', '✓ Privacy controls': '✓ Contrôle de la confidentialité', '✓ Human decisions': '✓ Décisions humaines',
    'Your next opportunity<br><em>starts here.</em>': 'Votre prochaine opportunité<br><em>commence ici.</em>',
    'Join ZERILYS ↗': 'Rejoindre ZERILYS ↗', 'Connexion': 'Connexion', 'Créer un compte': 'Créer un compte',
    'RECRUTEMENT SPÉCIALISÉ · OFFRE ENTREPRISE': 'SPECIALIST RECRUITMENT · EMPLOYER OFFER',
    'Recruter autrement.': 'Recruit differently.',
    'Avec plus de signal.': 'With stronger signals.',
    'Un espace conçu pour identifier des expertises rares, comprendre les compétences démontrées et suivre les échanges avec les talents.': 'A workspace to identify rare expertise, understand demonstrated capabilities and manage conversations with talent.',
    'CANDIDAT': 'CANDIDATE',
    'Identité professionnelle': 'Professional identity',
    'Gratuit': 'Free',
    'Profil professionnel évolutif': 'Evolving professional profile',
    'Compétences et réalisations': 'Skills and evidence',
    'Découverte et opportunités': 'Discovery and opportunities',
    'Accès candidat envisagé': 'Proposed candidate access',
    'RECRUTEUR': 'RECRUITER',
    'Recherche spécialisée de talents': 'Specialist talent search',
    'Profils, compétences et preuves': 'Profiles, skills and evidence',
    'Publication et suivi des opportunités': 'Opportunity publishing and tracking',
    'Gestion du pipeline de candidatures': 'Application pipeline management',
    'Hypothèse tarifaire à valider en pilote': 'Indicative pricing to validate in pilot',
    'ÉQUIPE': 'TEAM',
    'Espace de recrutement partagé': 'Shared recruitment workspace',
    'Rôles recruteur et consultation': 'Recruiter and viewer roles',
    'Coordination des opportunités': 'Opportunity coordination',
    'Gestion d’équipe': 'Team management',
    'ENTREPRISE': 'ENTERPRISE',
    'Sur mesure': 'Custom',
    'Déploiement et accompagnement dédiés': 'Dedicated rollout and support',
    'Paramétrage selon les besoins': 'Configuration to fit your needs',
    'Conditions et support spécifiques': 'Tailored terms and support',
    'Étude au cas par cas': 'Reviewed case by case',
    'Ces montants sont des hypothèses de travail, pas des tarifs contractuels. Aucun paiement ni abonnement n’est activé dans cette version. Les offres seront ajustées après entretiens et pilotes payants.': 'These amounts are working assumptions, not contractual prices. No payment or subscription is enabled in this release. Offers will be refined after customer interviews and paid pilots.',
    'Créer un compte entreprise ↗': 'Create a company account ↗',
    'Premiers partenaires recherchés pour co-construire l’offre.': 'Seeking first partners to co-design the offer.',
    'THE SPECIALIST TALENT INTELLIGENCE PLATFORM': 'LA PLATEFORME SPÉCIALISÉE D’INTELLIGENCE DES TALENTS',
    'Talent intelligence.': 'L’intelligence des talents.',
    'Human potential.': 'Le potentiel humain.',
    'The specialist network for finance, AI and data. Make expertise visible, credible and discoverable.': 'Le réseau spécialisé en finance, IA et data. Rendez votre expertise visible, crédible et accessible.',
    'Build your professional identity ↗': 'Construire mon identité professionnelle ↗',
    'FINANCE · AI · DATA TALENT GRAPH': 'CARTOGRAPHIE DES TALENTS · FINANCE · IA · DATA',
    'Find the expertise behind': 'Identifiez les expertises derrière',
    'what comes next.': 'vos prochains défis.',
    'Search specialist profiles by skills, experience, evidence and professional intent — not just job titles.': 'Recherchez des profils spécialisés par compétences, expérience, réalisations et aspirations — au-delà des seuls intitulés de poste.',
    'Explore talents ↗': 'Explorer les talents ↗',
    'EXPLORE SPECIALISATIONS': 'EXPLORER LES SPÉCIALITÉS',
    'Quantitative finance': 'Finance quantitative',
    'AI & machine learning': 'IA et machine learning',
    'Data science': 'Data science',
    'Risk modelling': 'Modélisation des risques',
    'Fintech engineering': 'Ingénierie fintech',
    'TALENT MARKET INTELLIGENCE': 'INTELLIGENCE DU MARCHÉ DES TALENTS',
    'See the skills.': 'Comprendre les compétences.',
    'Understand the market.': 'Lire le marché.',
    'Turn a hiring need into a clear map of capabilities, adjacent disciplines and evidence. Intelligence is grounded in profiles and opportunities actually present on the platform.': 'Transformez un besoin de recrutement en cartographie claire des compétences, disciplines connexes et réalisations. L’analyse repose sur les profils et opportunités réellement présents sur la plateforme.',
    '01 / SPECIALIST SEARCH': '01 / RECHERCHE SPÉCIALISÉE',
    'Search beyond job titles': 'Rechercher au-delà des intitulés de poste',
    'Use specialist queries for quantitative finance, machine learning, data engineering, risk and fintech skills already represented in member profiles.': 'Recherchez des compétences en finance quantitative, machine learning, ingénierie data, gestion des risques et fintech déjà présentes dans les profils membres.',
    '02 / TALENT DISCOVERY': '02 / DÉCOUVERTE DES TALENTS',
    'Find rare combinations': 'Identifiez les combinaisons rares',
    'Surface people whose skills, experience and demonstrated work intersect with a specific hiring challenge.': 'Faites émerger les profils dont les compétences, l’expérience et les réalisations répondent à un besoin précis.',
    '03 / MARKET SIGNALS': '03 / SIGNAUX DU MARCHÉ',
    'Understand what is represented': 'Comprendre les profils représentés',
    'Read the skills and roles represented by platform profiles and company opportunities. External market benchmarks will be added only with traceable sources.': 'Analysez les compétences et métiers présents dans les profils et les offres publiées. Les comparaisons externes ne seront ajoutées qu’avec des sources traçables.',
    'EVIDENCE FIRST · No fabricated market statistics, automated employability scores or opaque candidate rankings.': 'PRIORITÉ AUX PREUVES · Aucune statistique de marché inventée, note automatique d’employabilité ou classement opaque des candidats.',
    'YOUR CORE SIGNAL': 'VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'Your identity at a glance.': 'Votre identité professionnelle en un coup d’œil.',
    'Add a short introduction to explain your professional background, strengths and the direction you want to take.': 'Ajoutez une courte présentation de votre parcours, de vos points forts et de la direction que vous souhaitez prendre.',
    'WHAT I CAN BRING': 'CE QUE JE PEUX APPORTER',
    'WHAT I AM LOOKING FOR': 'CE QUE JE RECHERCHE',
    'INTERESTS': 'CENTRES D’INTÉRÊT',
    'WEBSITE': 'SITE WEB',
    'Not defined yet': 'À renseigner',
    'Not added yet': 'Non renseigné',
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.': 'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.',
    'CAPABILITY FIELD': 'UNIVERS DES COMPÉTENCES',
    'What can you actually do?': 'Que savez-vous concrètement faire ?',
    'verified': 'vérifiée',
    'self-declared': 'déclarée',
    'evidence record(s)': 'réalisation(s) associée(s)',
    'Practitioner': 'Opérationnel',
    'Learning': 'En apprentissage',
    'Advanced': 'Avancé',
    'Expert': 'Expert',
    'project': 'projet',
    'credential': 'certification',
    'publication': 'publication',
    'work_sample': 'exemple de travail',
    'PRIVATE COMPANY NOTES · only visible to your team': 'NOTES INTERNES · visibles uniquement par votre équipe',
    'Add an internal note…': 'Ajouter une note interne…',
    'Save internal note': 'Enregistrer la note interne',
    'No candidate interest yet.': 'Aucun candidat ne s’est encore manifesté.',
    'Internal note saved.': 'Note interne enregistrée.',
    'Candidate status updated.': 'Statut du candidat mis à jour.',
    'interest_sent': 'intérêt envoyé',
    'reviewing': 'en cours d’examen',
    'interview': 'entretien',
    'declined': 'non retenu',
    'job': 'emploi',
    'internship': 'stage',
    'apprenticeship': 'alternance',
    'collaboration': 'collaboration',
    'hybrid': 'hybride',
    'remote': 'à distance',
    'onsite': 'sur site',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.': 'Votre univers de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez des réalisations pour les étayer.',
    'PROOF LAYER': 'RÉALISATIONS',
    'Show the work behind the claim.': 'Donnez à voir le concret derrière vos compétences.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.': 'Aucune réalisation n’a encore été ajoutée. Des projets, diplômes, publications ou exemples de travaux peuvent rendre vos compétences plus tangibles.',
    'TRAJECTORY': 'PARCOURS',
    'Where have you been — where next?': 'D’où venez-vous et où souhaitez-vous aller ?',
    'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.': 'Votre parcours continue de s’écrire. Présentez vos expériences, les défis que vous avez relevés et les directions que vous souhaitez explorer.',
    'The profile should reveal a direction, not just a chronology.': 'Votre profil doit révéler une trajectoire, pas seulement une chronologie.',
    'INTENT FIELD': 'ASPIRATIONS',
    'What do you want to make possible?': 'Qu’aimeriez-vous rendre possible ?',
    'You are open to new opportunities.': 'Vous êtes ouvert aux nouvelles opportunités.',
    'You are open to selective connections.': 'Vous privilégiez les mises en relation ciblées.',
    'You are not looking for opportunities right now.': 'Vous ne recherchez pas d’opportunité pour le moment.',
    'MEMBER NETWORK': 'RÉSEAU DES MEMBRES',
    'Discover the people around your orbit.': 'Découvrez les personnes qui gravitent dans votre univers.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.': 'Chaque membre connecté peut consulter les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.',
    'Search members, skills or places': 'Rechercher des membres, des compétences ou des lieux',
    'Search member profiles': 'Rechercher des profils de membres',
    'Loading member profiles…': 'Chargement des profils des membres…',
    'OPPORTUNITY CONSTELLATION': 'CONSTELLATION DES OPPORTUNITÉS',
    'What is orbiting your next move?': 'Quelles opportunités accompagnent votre prochaine étape ?',
    'Company': 'Entreprise',
    'Explore this opportunity and inspect its requirements.': 'Consultez cette opportunité et prenez connaissance de ses critères.',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.': 'Aucune opportunité ne gravite encore autour de votre profil. Lorsque des entreprises publieront des offres détaillées, les opportunités correspondant à vos compétences et à vos aspirations apparaîtront ici, avec les raisons de leur pertinence.',
    'No hiring score. No popularity ranking. You remain in control of your visibility.': 'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.',
    'IMPACT SIGNAL': 'SIGNAL D’IMPACT',
    'Make contribution visible.': 'Rendez votre contribution visible.',
    'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.': 'Montrez les résultats, pas seulement les intitulés. Le signal d’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.',
    'Edit identity': 'Modifier mon identité',
    'Add a capability': 'Ajouter une compétence',
    'Add evidence': 'Ajouter une réalisation',
    'Shape your signal.': 'Donnez forme à votre identité.',
    'Activate your capabilities.': 'Mettez vos compétences en valeur.',
    'Show the work behind your claims.': 'Illustrez vos compétences par des réalisations.',
    'Tell the story of your trajectory.': 'Racontez votre parcours.',
    'Define what comes next.': 'Définissez la suite de votre parcours.',
    'Make your contribution visible.': 'Rendez votre contribution visible.',
    'No evidence has been linked publicly to this capability yet.': 'Aucune réalisation n’est encore associée publiquement à cette compétence.',
    'This identity is still taking shape. Its next signals will appear here.': 'Cette identité se construit progressivement. De nouveaux éléments apparaîtront ici.',
    'HUMAN SIGNAL': 'IDENTITÉ PROFESSIONNELLE',
    'CAPABILITY SIGNAL': 'SIGNAL DE COMPÉTENCE',
    'Independently verified': 'Vérifiée indépendamment',
    'Self-described': 'Déclarée',
    'Location not shared': 'Lieu non communiqué',
    'Human potential in motion': 'Le potentiel humain en mouvement',
    'capabilities': 'compétences',
    'evidence': 'réalisations',
    'Join to connect ↗': 'Rejoindre le réseau ↗',
    'Connect with intent': 'Entrer en contact',
    'Share this identity': 'Partager ce profil',
    'Share public profile': 'Partager le profil public',
    'Member-only link shared. Only signed-in members can open it.': 'Lien réservé aux membres partagé. Seuls les membres connectés peuvent l’ouvrir.',
    'Public profile link shared.': 'Lien du profil public partagé.',
    'Report': 'Signaler',
    'Block': 'Bloquer',
    'Unblock': 'Débloquer',
    'Describe the issue (at least 20 characters). This report will be sent to the moderation team.': 'Décrivez le problème (20 caractères minimum). Ce signalement sera transmis à l’équipe de modération.',
    'Report sent to the moderation team.': 'Signalement transmis à l’équipe de modération.',
    'Block this member? You will no longer see each other in discovery or be able to connect.': 'Bloquer ce membre ? Vous ne vous verrez plus dans la découverte et ne pourrez plus entrer en contact.',
    'Member blocked.': 'Membre bloqué.',
    'Member unblocked.': 'Membre débloqué.',
    'This identity is not available.': 'Ce profil n’est pas disponible.',
    'Your professional profile has been shared with this company for this opportunity.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.',
    'Interest sent ✓': 'Intérêt envoyé ✓',
    'Profile photo updated.': 'Photo de profil mise à jour.',
    'Profile photo removed.': 'Photo de profil supprimée.',
    'Choose an image smaller than 15 MB.': 'Choisissez une image de moins de 15 Mo.',
    'Choose a JPG, PNG or WebP image.': 'Choisissez une image au format JPG, PNG ou WebP.',
    'Preparing photo…': 'Préparation de la photo…',
    'Image dimensions are too large. Choose a smaller photo.': 'Les dimensions de l’image sont trop importantes. Choisissez une photo plus petite.',
    'Photo too large after compression. Choose a smaller image.': 'La photo reste trop volumineuse après compression. Choisissez une image plus petite.',
    'Photo updated.': 'Photo mise à jour.',
    'Photo removed.': 'Photo supprimée.',
    'Capability added. Add evidence to strengthen its signal.': 'Compétence ajoutée. Associez une réalisation pour étayer ce signal.',
    'Evidence added as self-attested. It is not independently verified.': 'Réalisation ajoutée sur déclaration. Elle n’a pas été vérifiée indépendamment.',
    'Evidence submitted for independent review.': 'Réalisation transmise pour examen indépendant.',
    'YOUR CAPABILITIES': 'VOS COMPÉTENCES',
    'Add skills to activate your field': 'Ajoutez des compétences pour activer votre univers',
    'CAPABILITY / SIGNAL': 'COMPÉTENCE / SIGNAL',
    'INDEPENDENTLY VERIFIED': 'VÉRIFIÉE INDÉPENDAMMENT',
    'SELF-DESCRIBED CAPABILITY': 'COMPÉTENCE DÉCLARÉE',
    'Level:': 'Niveau :',
    'This capability is part of your living identity.': 'Cette compétence fait partie de votre identité professionnelle évolutive.',
    'linked evidence record': 'réalisation associée',
    'linked evidence records': 'réalisations associées',
    'No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.': 'Aucune réalisation associée pour le moment. Reliez un projet, un diplôme ou un exemple de travail pour illustrer cette compétence.',
    'Link evidence ↗': 'Associer une réalisation ↗',
    'YOUR CORE SIGNAL': 'VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'Your identity at a glance.': 'Votre identité professionnelle en un coup d’œil.',
    'Add a short introduction to explain your professional background, strengths and the direction you want to take.': 'Ajoutez une courte présentation de votre parcours, de vos points forts et de la direction que vous souhaitez prendre.',
    'WHAT I CAN BRING': 'CE QUE JE PEUX APPORTER',
    'WHAT I AM LOOKING FOR': 'CE QUE JE RECHERCHE',
    'INTERESTS': 'CENTRES D’INTÉRÊT',
    'WEBSITE': 'SITE WEB',
    'Not defined yet': 'À renseigner',
    'Not added yet': 'Non renseigné',
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.': 'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.',
    'CAPABILITY FIELD': 'UNIVERS DES COMPÉTENCES',
    'What can you actually do?': 'Que savez-vous concrètement faire ?',
    'verified': 'vérifiée',
    'self-declared': 'déclarée',
    'evidence record(s)': 'réalisation(s) associée(s)',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.': 'Votre univers de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez des réalisations pour les étayer.',
    'Add a capability': 'Ajouter une compétence',
    'PROOF LAYER': 'RÉALISATIONS',
    'Show the work behind the claim.': 'Donnez à voir le concret derrière vos compétences.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.': 'Aucune réalisation n’a encore été ajoutée. Des projets, diplômes, publications ou exemples de travaux peuvent rendre vos compétences plus tangibles.',
    'Add evidence': 'Ajouter une réalisation',
    'TRAJECTORY': 'PARCOURS',
    'Where have you been — where next?': 'D’où venez-vous et où souhaitez-vous aller ?',
    'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.': 'Votre parcours continue de s’écrire. Présentez vos expériences, les défis que vous avez relevés et les directions que vous souhaitez explorer.',
    'The profile should reveal a direction, not just a chronology.': 'Votre profil doit révéler une trajectoire, pas seulement une chronologie.',
    'INTENT FIELD': 'ASPIRATIONS',
    'What do you want to make possible?': 'Qu’aimeriez-vous rendre possible ?',
    'You are open to new opportunities.': 'Vous êtes ouvert aux nouvelles opportunités.',
    'You are open to selective connections.': 'Vous privilégiez les mises en relation ciblées.',
    'You are not looking for opportunities right now.': 'Vous ne recherchez pas d’opportunité pour le moment.',
    'These signals help the network surface complementary people — not rank people by popularity.': 'Ces informations aident le réseau à faire émerger des profils complémentaires, sans classement par popularité.',
    'MEMBER NETWORK': 'RÉSEAU DES MEMBRES',
    'Discover the people around your orbit.': 'Découvrez les personnes qui gravitent dans votre univers.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.': 'Chaque membre connecté peut consulter les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.',
    'Search members, skills or places': 'Rechercher des membres, des compétences ou des lieux',
    'Search ↗': 'Rechercher ↗',
    'Loading member profiles…': 'Chargement des profils…',
    'No matching profiles. Try another name, skill or location.': 'Aucun profil correspondant. Essayez un autre nom, une autre compétence ou un autre lieu.',
    'OPPORTUNITY CONSTELLATION': 'CONSTELLATION DES OPPORTUNITÉS',
    'What is orbiting your next move?': 'Quelles opportunités accompagnent votre prochaine étape ?',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.': 'Aucune opportunité ne gravite encore autour de votre profil. Lorsque des entreprises publieront des offres détaillées, les opportunités correspondant à vos compétences et à vos aspirations apparaîtront ici, avec les raisons de leur pertinence.',
    'No hiring score. No popularity ranking. You remain in control of your visibility.': 'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.',
    'IMPACT SIGNAL': 'SIGNAL D’IMPACT',
    'Your identity at a glance.': 'Votre identité professionnelle en un coup d’œil.',
    'Add a short introduction to explain your professional background, strengths and the direction you want to take.': 'Ajoutez une courte présentation de votre parcours, de vos points forts et de la direction que vous souhaitez prendre.',
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.': 'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.',
    'What can you actually do?': 'Que savez-vous concrètement faire ?',
    'verified': 'vérifiée',
    'self-declared': 'déclarée',
    'evidence record(s)': 'réalisation(s) associée(s)',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.': 'Votre univers de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez des réalisations pour les étayer.',
    'Show the work behind the claim.': 'Donnez à voir le concret derrière vos compétences.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.': 'Aucune réalisation n’a encore été ajoutée. Des projets, diplômes, publications ou exemples de travaux peuvent rendre vos compétences plus tangibles.',
    'Where have you been — where next?': 'D’où venez-vous et où souhaitez-vous aller ?',
    'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.': 'Votre parcours continue de s’écrire. Présentez vos expériences, les défis que vous avez relevés et les directions que vous souhaitez explorer.',
    'The profile should reveal a direction, not just a chronology.': 'Votre profil doit révéler une trajectoire, pas seulement une chronologie.',
    'What do you want to make possible?': 'Qu’aimeriez-vous rendre possible ?',
    'You are open to new opportunities.': 'Vous êtes ouvert aux nouvelles opportunités.',
    'You are open to selective connections.': 'Vous privilégiez les mises en relation ciblées.',
    'You are not looking for opportunities right now.': 'Vous ne recherchez pas d’opportunité pour le moment.',
    'These signals help the network surface complementary people — not rank people by popularity.': 'Ces informations aident le réseau à faire émerger des profils complémentaires, sans classement par popularité.',
    'Discover the people around your orbit.': 'Découvrez les personnes qui gravitent dans votre univers.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.': 'Chaque membre connecté peut consulter les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.',
    'Search members, skills or places': 'Rechercher des membres, des compétences ou des lieux',
    'Search member profiles': 'Rechercher des profils de membres',
    'Loading member profiles…': 'Chargement des profils des membres…',
    'What is orbiting your next move?': 'Quelles opportunités accompagnent votre prochaine étape ?',
    'Company': 'Entreprise',
    'Explore this opportunity and inspect its requirements.': 'Consultez cette opportunité et prenez connaissance de ses critères.',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.': 'Aucune opportunité ne gravite encore autour de votre profil. Lorsque des entreprises publieront des offres détaillées, les opportunités correspondant à vos compétences et à vos aspirations apparaîtront ici, avec les raisons de leur pertinence.',
    'No hiring score. No popularity ranking. You remain in control of your visibility.': 'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.',
    'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.': 'Montrez les résultats obtenus, pas seulement les intitulés. L’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.',
    'Shape your signal.': 'Donnez forme à votre identité.',
    'Activate your capabilities.': 'Activez vos compétences.',
    'Show the work behind your claims.': 'Illustrez vos compétences par vos réalisations.',
    'Tell the story of your trajectory.': 'Racontez votre parcours.',
    'Define what comes next.': 'Définissez la suite de votre parcours.',
    'Make your contribution visible.': 'Rendez votre contribution visible.',
    'Add a capability': 'Ajouter une compétence',
    'Edit identity': 'Modifier mon identité',
    'Interest sent ✓': 'Intérêt envoyé ✓',
    'Your professional profile has been shared with this company for this opportunity.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.',
    'Make contribution visible.': 'Rendez votre contribution visible.',
    'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.': 'Montrez les résultats obtenus, pas seulement les intitulés. L’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.',
    'Shape your signal.': 'Donnez forme à votre identité.',
    'Activate your capabilities.': 'Activez vos compétences.',
    'Show the work behind your claims.': 'Illustrez vos compétences par vos réalisations.',
    'Tell the story of your trajectory.': 'Racontez votre parcours.',
    'Define what comes next.': 'Définissez la suite de votre parcours.',
    'Make your contribution visible.': 'Rendez votre contribution visible.',
    'Edit identity': 'Modifier mon identité',
    'Your professional profile has been saved and refreshed.': 'Votre profil professionnel a été enregistré et actualisé.',
    'evidence': 'réalisation(s)',
    'CAPABILITY SIGNAL': 'SIGNAL DE COMPÉTENCE',
    'Independently verified': 'Vérifiée indépendamment',
    'Self-described': 'Déclarée par le membre',
    'No evidence has been linked publicly to this capability yet.': 'Aucune réalisation n’est encore associée publiquement à cette compétence.',
    'This identity is still taking shape. Its next signals will appear here.': 'Cette identité professionnelle se construit. Ses prochains éléments apparaîtront ici.',
    'ZERILYS / LIVING IDENTITY': 'ZERILYS / IDENTITÉ ÉVOLUTIVE',
    'Human potential in motion': 'Le potentiel professionnel en mouvement',
    'Location not shared': 'Lieu non communiqué',
    'A professional identity is not a list. It is a field of capabilities, proof and possibilities.': 'Une identité professionnelle ne se résume pas à une liste. Elle révèle des compétences, des réalisations et des possibilités.',
    'HUMAN SIGNAL': 'SIGNAL HUMAIN',
    'CAPABILITY FIELD': 'UNIVERS DES COMPÉTENCES',
    'Signals will appear here': 'Les signaux apparaîtront ici',
    'linked evidence record(s)': 'réalisation(s) associée(s)',
    'Join to connect ↗': 'Rejoindre pour échanger ↗',
    '⟡ Connect with intent': '⟡ Proposer une mise en relation',
    'Report': 'Signaler',
    'Block': 'Bloquer',
    'Unblock': 'Débloquer',
    '↗ Share this identity': '↗ Partager ce profil',
    '↗ Share public profile': '↗ Partager le profil public',
    '↗ Share member link': '↗ Partager le lien membre',
    'Public profile link shared.': 'Lien du profil public partagé.',
    'Member-only link shared. Only signed-in members can open it.': 'Lien réservé aux membres partagé. Seuls les membres connectés peuvent l’ouvrir.',
    'Member-only link copied. Only signed-in members can open it.': 'Lien réservé aux membres copié. Seuls les membres connectés peuvent l’ouvrir.',
    'Describe the issue (at least 20 characters). This report will be sent to the moderation team.': 'Décrivez le problème (20 caractères minimum). Ce signalement sera transmis à l’équipe de modération.',
    'Report sent to the moderation team.': 'Signalement transmis à l’équipe de modération.',
    'Block this member? You will no longer see each other in discovery or be able to connect.': 'Bloquer ce membre ? Vous ne vous verrez plus dans la découverte du réseau et ne pourrez plus entrer en relation.',
    'Member blocked.': 'Membre bloqué.',
    'Member unblocked.': 'Membre débloqué.',
    'COMPANY UNIVERSE': 'UNIVERS DE L’ENTREPRISE',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES',
    'Location not specified': 'Lieu non précisé',
    'This company has not added an overview yet.': 'Cette entreprise n’a pas encore renseigné sa présentation.',
    'Company website ↗': 'Site web de l’entreprise ↗',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'YOUR NETWORK': 'VOTRE RÉSEAU',
    'Notifications': 'Notifications',
    'Read': 'Lu',
    'Mark read': 'Marquer comme lu',
    'You are all caught up.': 'Vous êtes à jour.',
    'No published opportunities yet. Company opportunities will appear here when they are available.': 'Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur mise en ligne.',
    'Location flexible': 'Lieu flexible',
    'Explore this opportunity. Matching signals will appear as your skills and intentions become more specific.': 'Consultez cette opportunité. Les points de correspondance se préciseront à mesure que vous renseignerez vos compétences et vos aspirations.',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'Your professional profile has been shared with this company for this opportunity only.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.',
    'Company page is not available.': 'La page de cette entreprise est indisponible.',
    'This company page is not available.': 'La page de cette entreprise est indisponible.',
    'This identity is not available.': 'Ce profil est indisponible.',
    'Identity link copied.': 'Lien du profil copié.',
    'Explore this professional identity on ZERILYS': 'Découvrez ce profil professionnel sur ZERILYS',
    'Share is unavailable in this browser.': 'Le partage n’est pas disponible dans ce navigateur.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'ZERILYS member': 'Membre ZERILYS',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'En relation',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Connections are temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'Your intentional connection request has been sent.': 'Votre demande de mise en relation a été envoyée.',
    'Your intentional connection request has been sent.': 'Votre demande de mise en relation a été envoyée.',
    'Share is unavailable in this browser.': 'Le partage n’est pas disponible dans ce navigateur.',
    'Capability added. Add evidence to strengthen its signal.': 'Compétence ajoutée. Associez une réalisation pour l’étayer.',
    'Evidence submitted for independent review.': 'Réalisation transmise pour examen indépendant.',
    'Evidence added as self-attested. It is not independently verified.': 'Réalisation ajoutée sur déclaration. Elle n’a pas été vérifiée indépendamment.',
    'Preparing photo…': 'Préparation de la photo…',
    'Photo updated.': 'Photo mise à jour.',
    'Profile photo updated.': 'Photo de profil mise à jour.',
    'Profile photo removed.': 'Photo de profil supprimée.',
    'Choose an image smaller than 15 MB.': 'Choisissez une image de moins de 15 Mo.',
    'Choose a JPG, PNG or WebP image.': 'Choisissez une image au format JPG, PNG ou WebP.',
    'Image dimensions are too large. Choose a smaller photo.': 'Les dimensions de l’image sont trop importantes. Choisissez une photo plus petite.',
    'Photo too large after compression. Choose a smaller image.': 'La photo reste trop volumineuse après compression. Choisissez une image plus petite.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'En relation',
    'Declined': 'Refusée',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre réseau est encore vide. Découvrez un profil et envoyez une demande de mise en relation pour commencer.',
    'Connections are temporarily unavailable.': 'Les mises en relation sont momentanément indisponibles.',
    'Searching the member network…': 'Recherche dans le réseau des membres…',
    'Load next profiles ↓': 'Afficher les profils suivants ↓',
    'Loading…': 'Chargement…',
    'Unable to load more profiles.': 'Impossible de charger davantage de profils.',
    'of': 'sur',

    "THE GLOBAL NETWORK":"AU-DELÀ DU CV.",
    "Primary navigation":"Navigation principale",
    "Log in":"Se connecter",
    "Join ZERILYS":"Rejoindre ZERILYS",
    "Notifications":"Notifications",
    "THE FUTURE OF PROFESSIONAL IDENTITY":"L’AVENIR DE L’IDENTITÉ PROFESSIONNELLE",
    "Your identity.":"Votre identité.",
    "Your universe.":"Votre univers.",
    "One living candidate profile. Your capabilities, proof and next opportunities — revealed around you.":"Un profil professionnel vivant. Vos compétences, vos réalisations et vos prochaines opportunités réunies autour de vous.",
    "Create your identity":"Créer mon profil",
    "YOUR FUTURE SELF":"VOTRE AVENIR PROFESSIONNEL",
    "PROFESSIONAL IDENTITY":"IDENTITÉ PROFESSIONNELLE",
    "READY TO EVOLVE":"PRÊT À ÉVOLUER",
    "CAPABILITIES":"COMPÉTENCES",
    "What you can do":"Ce que vous savez faire",
    "OPPORTUNITIES":"OPPORTUNITÉS",
    "What is opening up":"Ce qui s’ouvre à vous",
    "PROOF":"RÉALISATIONS",
    "What you can show":"Ce que vous pouvez démontrer",
    "TRAJECTORY":"PARCOURS",
    "Where you are going":"Où vous souhaitez aller",
    "INTENT":"ASPIRATIONS",
    "What you want next":"Ce que vous recherchez",
    "NETWORK":"RÉSEAU",
    "Who you can meet":"Les personnes à rencontrer",
    "IMPACT":"IMPACT",
    "What you can change":"Ce que vous pouvez faire évoluer",
    "ONE IDENTITY · INFINITE POSSIBILITIES":"UNE IDENTITÉ · DES POSSIBILITÉS INFINIES",
    "IDENTITY":"IDENTITÉ",
    "OPPORTUNITY":"OPPORTUNITÉ",
    "COLLABORATION":"COLLABORATION",
    "THE OPPORTUNITY GRAPH":"LE GRAPHE DES OPPORTUNITÉS",
    "Find the people behind":"Rencontrez les personnes qui font",
    "what's possible.":"avancer les projets.",
    "Discover people by what they know, what they have built, and what they want to make possible next.":"Découvrez des personnes selon leurs compétences, leurs réalisations et leurs projets à venir.",
    "Every signed-in member can explore every other member profile. Private mode only limits anonymous discovery and public profile links.":"Chaque membre connecté peut consulter les profils des autres membres. Le mode privé limite uniquement l’accès des visiteurs non connectés et les liens publics.",
    "Search skills, people, disciplines or places":"Rechercher une compétence, une personne, un domaine ou un lieu",
    "ENTER":"ENTRÉE",
    "Explore network ↗":"Explorer le réseau ↗",
    "Loading the network…":"Chargement du réseau…",
    "BUILD SOMETHING THAT MATTERS":"CONSTRUIRE CE QUI COMPTE",
    "Great work is rarely":"Les grandes réussites se construisent rarement",
    "built alone.":"en solitaire.",
    "Join an emerging project or bring a challenge to the network. Find collaborators through complementary skills and shared intent.":"Rejoignez un projet ou partagez un défi avec le réseau. Trouvez des partenaires grâce à leurs compétences et à des ambitions communes.",
    "From connection":"De la rencontre",
    "to contribution.":"à la contribution.",
    "Turn a shared ambition into a team, a prototype, a venture or a meaningful outcome.":"Transformez une ambition commune en équipe, en prototype, en entreprise ou en résultat concret.",
    "Start a project ↗":"Lancer un projet ↗",
    "Finding open collaborations…":"Recherche de projets ouverts…",
    "OPPORTUNITY CONSTELLATION":"CONSTELLATION DES OPPORTUNITÉS",
    "Let the right opportunities":"Faites venir à vous",
    "find their orbit.":"les bonnes opportunités.",
    "Structured opportunities from companies. Relevant signals, explained through skills and intent — never an opaque hiring score.":"Des opportunités proposées par les entreprises, mises en perspective selon les compétences et les aspirations — sans classement opaque des candidats.",
    "NO SOCIAL FEED · NO PERSONAL POSTS · ONLY PROFESSIONAL OPPORTUNITIES":"PAS DE FIL D’ACTUALITÉ · PAS DE PUBLICATIONS PERSONNELLES · DES OPPORTUNITÉS PROFESSIONNELLES",
    "Refresh opportunities ↻":"Actualiser les opportunités ↻",
    "Expressing interest shares your professional profile with that company for this opportunity only. You can withdraw at any time.":"En manifestant votre intérêt, vous transmettez votre profil professionnel à cette entreprise pour cette opportunité uniquement. Vous pouvez vous retirer à tout moment.",
    "YOUR OPPORTUNITY PATH":"VOTRE PARCOURS D’OPPORTUNITÉS",
    "Your interests and application progress":"Vos intérêts et le suivi de vos candidatures",
    "Company identity":"Identité de l’entreprise",
    "Company name":"Nom de l’entreprise",
    "Industry":"Secteur d’activité",
    "Website (HTTPS)":"Site web (HTTPS)",
    "Headquarters / operating locations":"Siège social / lieux d’activité",
    "What the company does, its mission and areas of activity":"Activité, mission et domaines d’intervention de l’entreprise",
    "Save company identity":"Enregistrer les informations de l’entreprise",
    "Company verification":"Vérification de l’entreprise",
    "Opportunities become visible to candidates only after a reviewer confirms the organization. This is a human review, not an automated badge.":"Les opportunités ne sont visibles des candidats qu’après vérification de l’entreprise par notre équipe. Cette validation est humaine, et non automatique.",
    "Business email address":"Adresse e-mail professionnelle",
    "Point reviewers to public evidence they can independently check (company registry, official site, public profile…).":"Indiquez des sources publiques permettant de vérifier l’entreprise (registre officiel, site internet, profil public…).",
    "Submit for verification ↗":"Demander la vérification ↗",
    "Company team":"Équipe de l’entreprise",
    "Shared workspace with explicit roles. Recruiters can manage opportunities and applications; viewers can only consult.":"Espace partagé avec des rôles distincts. Les recruteurs gèrent les opportunités et les candidatures ; les membres en lecture seule peuvent les consulter.",
    "Colleague email":"E-mail du collègue",
    "Recruiter · manage opportunities":"Recruteur · gestion des opportunités",
    "Viewer · read only":"Consultation · lecture seule",
    "Invite member ↗":"Inviter un membre ↗",
    "Publish a structured opportunity":"Publier une opportunité détaillée",
    "Role or opportunity title":"Intitulé du poste ou de l’opportunité",
    "Describe the mission, expected contribution and context (30+ characters)":"Décrivez la mission, la contribution attendue et le contexte (30 caractères minimum)",
    "Required skills, separated by commas":"Compétences requises, séparées par des virgules",
    "Job":"Emploi",
    "Internship":"Stage",
    "Apprenticeship":"Alternance",
    "Hybrid":"Hybride",
    "Remote":"À distance",
    "On-site":"Sur site",
    "Location":"Lieu",
    "Publish opportunity ↗":"Publier l’opportunité ↗",
    "Your published opportunities":"Vos opportunités publiées",
    "Candidate interests":"Intérêt des candidats",
    "GLOBAL PULSE / WORLD ECONOMY":"REPÈRES MONDIAUX / ÉCONOMIE",
    "Understand the world.":"Comprendre le monde.",
    "Not trade it.":"Pas spéculer.",
    "A concise view of economic signals, major companies and business context. No portfolio, trading signals or investment recommendations.":"Un aperçu des indicateurs économiques, des grandes entreprises et du contexte des affaires. Aucun portefeuille, signal de trading ou conseil en investissement.",
    "MARKET INDICES":"INDICES BOURSIERS",
    "Live values will appear only when a properly licensed data source is connected.":"Les données en temps réel ne seront affichées qu’après connexion d’une source dûment autorisée.",
    "GLOBAL COMPANIES":"ENTREPRISES INTERNATIONALES",
    "Company snapshots and share prices, with source and timestamp clearly displayed.":"Fiches entreprises et cours de Bourse, avec indication claire de la source et de l’heure de mise à jour.",
    "ECONOMIC CONTEXT":"CONTEXTE ÉCONOMIQUE",
    "What moves business?":"Qu’est-ce qui fait évoluer l’économie ?",
    "Short, sourced briefings on rates, inflation, energy, trade and major economic events.":"Des synthèses sourcées sur les taux, l’inflation, l’énergie, le commerce et les grands événements économiques.",
    "DATA INTEGRITY FIRST · No simulated prices or invented market movements. Commercial redistribution requires explicit data licensing.":"PRIORITÉ À LA FIABILITÉ · Aucun cours simulé ni mouvement de marché inventé. Toute redistribution commerciale nécessite une licence de données.",
    "THE ZERILYS TRUST LAYER":"LE SOCLE DE CONFIANCE ZERILYS",
    "Trust should be":"La confiance se",
    "earned, not claimed.":"construit, elle ne se décrète pas.",
    "Profiles distinguish self-described skills from demonstrated experience. Evidence is visible, provenance matters, and verification is explicit — never implied.":"Les profils distinguent les compétences déclarées de l’expérience démontrée. Les justificatifs sont visibles, leur origine compte et toute vérification est clairement indiquée.",
    "Evidence-first profiles":"Des profils étayés par des réalisations",
    "Transparent skill levels":"Des niveaux de compétence transparents",
    "Privacy by design":"La confidentialité dès la conception",
    "Human-controlled collaboration":"Une collaboration maîtrisée par les personnes",
    "Trust & Safety review.":"Modération et confiance.",
    "This workspace is visible only to accounts explicitly authorized by the server configuration. Review reports and submitted evidence with human judgment.":"Cet espace est réservé aux comptes autorisés par la configuration du serveur. Les signalements et les justificatifs sont examinés par une personne.",
    "Service operations":"État du service",
    "Restricted operational diagnostics. No passwords, tokens or private message content are exposed.":"Diagnostic réservé aux équipes habilitées. Aucun mot de passe, jeton ou contenu de message privé n’est affiché.",
    "Refresh status ↻":"Actualiser l’état ↻",
    "Loading service health…":"Vérification du service…",
    "Company verification requests":"Demandes de vérification des entreprises",
    "Open member reports":"Signalements en attente",
    "Evidence awaiting review":"Justificatifs à examiner",
    "Tester feedback":"Retours des testeurs",
    "Invite beta testers":"Inviter des testeurs bêta",
    "Create a single-use invitation for one email address. The token is shown once for private manual delivery.":"Créez une invitation à usage unique pour une adresse e-mail. Le code ne sera affiché qu’une fois pour une transmission privée.",
    "Tester email":"E-mail du testeur",
    "Candidate":"Candidat",
    "Company":"Entreprise",
    "Create invitation ↗":"Créer l’invitation ↗",
    "Invite a cohort":"Inviter un groupe de testeurs",
    "Paste up to 50 email addresses, one per line. The entire batch is validated before any invitation is created.":"Collez jusqu’à 50 adresses e-mail, une par ligne. Toutes les adresses sont vérifiées avant la création des invitations.",
    "Tester email addresses, one per line":"Adresses e-mail des testeurs, une par ligne",
    "Create cohort invitations ↗":"Créer les invitations du groupe ↗",
    "THE NEXT CHAPTER IS COLLECTIVE":"LA SUITE S’ÉCRIT ENSEMBLE",
    "Make your potential":"Donnez à votre potentiel",
    "matter somewhere.":"un terrain pour s’exprimer.",
    "Join the network ↗":"Rejoindre le réseau ↗",
    "Trust · Capability · Collaboration":"Confiance · Compétences · Collaboration",
    "A CONNECTION WITH INTENT":"UNE RENCONTRE QUI A DU SENS",
    "Why should your paths cross?":"Pourquoi vos chemins devraient-ils se croiser ?",
    "Write a short, personal reason. The recipient sees your context before deciding.":"Expliquez brièvement et personnellement votre démarche. Votre interlocuteur en connaîtra le contexte avant de répondre.",
    "I noticed your work in… I think we could…":"J’ai découvert votre travail sur… Je pense que nous pourrions…",
    "Send intentional connection ↗":"Envoyer ma demande de mise en relation ↗",
    "HUMAN CONNECTION PROTOCOL":"MISE EN RELATION HUMAINE",
    "Your connection field.":"Vos relations.",
    "Every request carries context. No empty invitations, no popularity mechanics.":"Chaque demande est contextualisée. Pas d’invitation impersonnelle ni de course à la popularité.",
    "Loading connections…":"Chargement des relations…",
    "YOUR DATA / YOUR CONTROL":"VOS DONNÉES / VOTRE CONTRÔLE",
    "Data & privacy.":"Données et confidentialité.",
    "Your account information and the visibility of your professional identity.":"Les informations de votre compte et la visibilité de votre profil professionnel.",
    "ACCOUNT EMAIL":"E-MAIL DU COMPTE",
    "PROFILE VISIBILITY":"VISIBILITÉ DU PROFIL",
    "Beta terms & privacy":"Conditions bêta et confidentialité",
    "Consent status unavailable.":"État du consentement indisponible.",
    "Private Beta Terms":"Conditions de la bêta privée",
    "Privacy Notice":"Politique de confidentialité",
    "Account security":"Sécurité du compte",
    "Manage active sign-in sessions. A maximum of ten active sessions is allowed per account.":"Gérez les sessions ouvertes sur votre compte. Dix sessions actives au maximum sont autorisées.",
    "Loading sessions…":"Chargement des sessions…",
    "Sign out other sessions":"Fermer les autres sessions",
    "Change password":"Modifier le mot de passe",
    "Current password":"Mot de passe actuel",
    "New password (12–128 characters)":"Nouveau mot de passe (12 à 128 caractères)",
    "Confirm new password":"Confirmer le nouveau mot de passe",
    "Update password":"Mettre à jour le mot de passe",
    "Download your data":"Télécharger vos données",
    "Export your profile, evidence, applications, company workspace records, connections, notifications and related account records in JSON format.":"Exportez votre profil, vos justificatifs, vos candidatures, les données de votre espace entreprise, vos relations, vos notifications et les données associées au compte au format JSON.",
    "Download my data ↧":"Télécharger mes données ↧",
    "Delete your account":"Supprimer votre compte",
    "Log in ↗":"Se connecter ↗",
    "Create account ↗":"Créer mon compte ↗",
    "Welcome back":"Ravi de vous revoir",
    "Join a network built around what you can do.":"Rejoignez un réseau qui valorise ce que vous savez faire.",
    "Continue building what comes next.":"Continuez à construire la suite de votre parcours.",
    "Already a member? Log in":"Déjà membre ? Connectez-vous",
    "New to ZERILYS? Create an identity":"Nouveau sur ZERILYS ? Créez votre profil",
    "Forgot password?":"Mot de passe oublié ?",
    "Your name":"Votre nom",
    "Identity type":"Type de profil",
    "Candidate / professional":"Candidat / professionnel",
    "Company / organization":"Entreprise / organisation",
    "Email address":"Adresse e-mail",
    "Password":"Mot de passe",
    "At least 12 characters":"12 caractères minimum",
    "I accept the":"J’accepte les",
    "I acknowledge the":"Je reconnais avoir pris connaissance de la",
    "Both confirmations are required to create an account.":"Ces deux confirmations sont nécessaires pour créer un compte.",
    "Your personal profile starts private. You can choose public discoverability later; company pages follow a separate verification process.":"Votre profil personnel est privé par défaut. Vous pourrez choisir de le rendre visible aux autres membres ; les pages des entreprises suivent une procédure de vérification distincte.",
    "Shape your signal.":"Donnez forme à votre profil.",
    "Profile photo":"Photo de profil",
    "Use a clear portrait. JPG, PNG or WebP · up to 500 KB.":"Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum.",
    "Add / change photo":"Ajouter / modifier la photo",
    "Remove photo":"Supprimer la photo",
    "Professional headline":"Présentation professionnelle",
    "Availability":"Disponibilité",
    "Open to opportunities":"À l’écoute d’opportunités",
    "Selective":"Ouvert à certaines propositions",
    "Not looking right now":"Pas en recherche actuellement",
    "Profile visibility":"Visibilité du profil",
    "Public — discoverable by other members":"Visible — consultable par les autres membres",
    "Private — members only; hidden from public links":"Réservé aux membres ; masqué des liens publics",
    "About your work":"À propos de votre parcours",
    "What do you know how to do? What are you curious to build?":"Que savez-vous faire ? Quels projets souhaitez-vous développer ?",
    "What can you bring?":"Ce que vous pouvez apporter",
    "Separate items with commas":"Séparez les éléments par des virgules",
    "What are you looking for?":"Ce que vous recherchez",
    "Interests and themes":"Centres d’intérêt et domaines",
    "Climate, education, open source, health":"Climat, éducation, logiciel libre, santé",
    "Website (HTTPS only)":"Site web (HTTPS uniquement)",
    "Save identity ↗":"Enregistrer mon profil ↗",
    "Capabilities":"Compétences",
    "Add a skill, e.g. Product strategy":"Ajouter une compétence, par ex. stratégie produit",
    "Practitioner":"Pratique professionnelle",
    "Learning":"En apprentissage",
    "Advanced":"Avancé",
    "Expert":"Expert",
    "Add":"Ajouter",
    "Evidence of your work":"Réalisations et justificatifs",
    "Project, credential or achievement":"Projet, certification ou réalisation",
    "Connect to a capability (optional)":"Associer à une compétence (facultatif)",
    "What did you contribute or demonstrate?":"Quelle a été votre contribution ou qu’avez-vous démontré ?",
    "Add evidence":"Ajouter un justificatif",
    "Edit identity ↗":"Modifier mon profil ↗",
    "My profile":"Mon profil",
    "Open my candidate profile":"Ouvrir mon profil professionnel",
    "Open your candidate profile":"Ouvrir votre profil professionnel",
    "Your identity has been updated.":"Votre profil a bien été mis à jour.",
    "Profile photo updated.":"Votre photo de profil a été mise à jour.",
    "Profile photo removed.":"Votre photo de profil a été supprimée.",
    "Preparing photo…":"Préparation de la photo…",
    "Choose a JPG, PNG or WebP image.":"Choisissez une image JPG, PNG ou WebP.",
    "Choose an image smaller than 15 MB.":"Choisissez une image de moins de 15 Mo.",
    "Image dimensions are too large. Choose a smaller photo.":"Les dimensions de l’image sont trop importantes. Choisissez une photo plus petite.",
    "Photo too large after compression. Choose a smaller image.":"La photo reste trop volumineuse après compression. Choisissez une image plus petite.",
    "Photo updated.":"Photo mise à jour.",
    "Photo removed.":"Photo supprimée.",
    "Create an account without an invitation":"Créer un compte sans invitation",
    "Your account deletion request has been processed.":"La demande de suppression de votre compte a été traitée.",
    "Your beta consent has been saved.":"Votre consentement aux conditions de la bêta a été enregistré.",
    "Welcome to ZERILYS. Your identity is ready to shape.":"Bienvenue sur ZERILYS. Votre profil est prêt à être complété.",
    "Your collaboration is live.":"Votre projet est maintenant visible.",
    "Opportunity published. Its match signals are now available to candidates.":"L’opportunité est publiée. Les candidats peuvent désormais découvrir les éléments qui correspondent à leur profil.",
    "Company identity updated.":"Les informations de l’entreprise ont été mises à jour.",
    "Company verification request submitted.":"La demande de vérification de l’entreprise a été envoyée.",
    "Thank you. Your feedback has been sent to the beta review team.":"Merci. Votre retour a été transmis à l’équipe chargée de la bêta.",
    "The new passwords do not match.":"Les deux nouveaux mots de passe ne correspondent pas.",
    "Password changed successfully.":"Le mot de passe a été modifié.",
    "Password updated. Sign in with your new password.":"Mot de passe modifié. Connectez-vous avec votre nouveau mot de passe.",
    "Consent is unavailable until the legal review is complete.":"Le consentement sera disponible une fois la validation juridique terminée.",
    "Registration is paused until the beta legal review is complete.":"Les inscriptions sont temporairement suspendues dans l’attente de la validation juridique des documents de la bêta.",
    "Access is paused while the beta terms and privacy notice await legal approval. You may export your data or sign out.":"L’accès est suspendu dans l’attente de la validation juridique des conditions de la bêta et de la politique de confidentialité. Vous pouvez exporter vos données ou vous déconnecter.",
    "No published opportunities yet. Company opportunities will appear here when they are available.":"Aucune opportunité n’est publiée pour le moment. Les propositions des entreprises apparaîtront ici dès qu’elles seront disponibles.",
    "No interest expressed yet. Your opportunity journey will appear here.":"Vous n’avez manifesté d’intérêt pour aucune opportunité. Votre suivi apparaîtra ici.",
    "No candidate interest yet.":"Aucun candidat n’a manifesté d’intérêt pour le moment.",
    "No team members yet.":"Aucun membre dans l’équipe pour le moment.",
    "No active sessions found.":"Aucune session active.",
    "You are all caught up.":"Vous êtes à jour.",
    "Mark read":"Marquer comme lu",
    "Read":"Lu",
    "Interest sent":"Intérêt transmis",
    "Under review":"À l’étude",
    "Interview stage":"Étape d’entretien",
    "Not selected":"Non retenu",
    "Withdrawn":"Retiré",
    "Withdraw":"Me retirer",
    "Declined":"Refusé",
    "Reviewing":"En cours d’examen",
    "New interest":"Nouvel intérêt",
    "Interview":"Entretien",
    "Save internal note":"Enregistrer la note interne",
    "Remove access":"Retirer l’accès",
    "Search ↗":"Rechercher ↗",
    "Join to connect ↗":"Rejoindre pour contacter ↗",
    "Express interest ↗":"Manifester mon intérêt ↗",
    "Link evidence ↗":"Ajouter un justificatif ↗",
    "Report":"Signaler",
    "Block":"Bloquer",
    "Accept":"Accepter",
    "Explore collaboration ↗":"Découvrir le projet ↗",
    "Published opportunities":"Opportunités publiées",
    "No hiring score. No popularity ranking. You remain in control of your visibility.":"Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.",
    "Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.":"Votre réseau est encore vide. Découvrez un profil et envoyez une demande de mise en relation personnalisée pour commencer.",
    "Connections are temporarily unavailable.":"Les relations sont temporairement indisponibles.",
    "Opportunity signals are temporarily unavailable.":"Les opportunités sont temporairement indisponibles.",
    "Loading member profiles…":"Chargement des profils…",
    "Load next profiles ↓":"Afficher les profils suivants ↓",
    "Unable to load more profiles.":"Impossible de charger davantage de profils.",
    "This company page is not available.":"Cette page entreprise n’est pas disponible.",
    "Company workspace unavailable:":"Espace entreprise indisponible :",
    "You have not sent any feedback yet.":"Vous n’avez pas encore envoyé de retour.",
    "Awaiting review":"En attente d’examen",
    "Reviewed":"Examiné",
    "Accepted for follow-up":"Retenu pour suivi",
    "Not selected":"Non retenu",
    "Add projects, credentials or work that demonstrates your capabilities.":"Ajoutez des projets, certifications ou réalisations qui illustrent vos compétences.",
    "Add the capabilities you want to be known for.":"Ajoutez les compétences pour lesquelles vous souhaitez être reconnu.",
    "The profile should reveal a direction, not just a chronology.":"Votre profil doit faire ressortir une direction, pas seulement une chronologie.",
    "These signals help the network surface complementary people — not rank people by popularity.":"Ces repères aident à faire émerger des profils complémentaires, sans classement par popularité.",
    "This identity is still taking shape. Its next signals will appear here.":"Ce profil est en cours de construction. Ses prochains éléments apparaîtront ici.",
    "No evidence has been linked publicly to this capability yet.":"Aucun justificatif public n’est encore associé à cette compétence.",
    "No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.":"Aucun justificatif associé pour le moment. Ajoutez un projet, une certification ou un exemple de réalisation pour illustrer cette compétence.",
    "Company identity reviewed by the ZERILYS trust team.":"L’identité de l’entreprise a été examinée par l’équipe confiance de ZERILYS.",
    "Your opportunities are not yet visible to candidates.":"Vos opportunités ne sont pas encore visibles des candidats.",
    "Submit public evidence so a reviewer can confirm the organization.":"Fournissez des éléments publics permettant de confirmer l’existence de l’organisation.",
    "Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.",
    "Your professional profile has been shared with this company for this opportunity only.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.",
    "Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué.",
    "Interest already sent ✓":"Intérêt déjà transmis ✓",
    "Current session":"Session actuelle",
    "Active session":"Session active",
    "THIS DEVICE":"CET APPAREIL",
    "ACTIVE":"ACTIVE",
    "Started":"Ouverte le",
    "Expires":"Expire le",
    "Read-only access: you can consult opportunities and candidate applications.":"Accès en lecture seule : vous pouvez consulter les opportunités et les candidatures.",
    "You manage this company workspace.":"Vous gérez cet espace entreprise.",
    "You can manage opportunities and applications.":"Vous pouvez gérer les opportunités et les candidatures.",
    "Save internal note":"Enregistrer la note interne",
    "Open to opportunities":"À l’écoute d’opportunités",
    "PUBLIC · anonymous discovery enabled":"PUBLIC · visible des visiteurs",
    "PRIVATE · members only":"PRIVÉ · réservé aux membres",
    "Public profile link shared.":"Le lien public du profil a été copié.",
    "Member-only link copied. Only signed-in members can open it.":"Le lien réservé aux membres a été copié. Seuls les membres connectés peuvent l’ouvrir.",
    "Your identity has been updated.":"Votre profil a bien été mis à jour.",
    "Your profile photo has been updated.":"Votre photo de profil a été mise à jour.",
    "Your profile photo has been removed.":"Votre photo de profil a été supprimée.",
    "Your interest was withdrawn.":"Votre intérêt a été retiré.",
    "Your account deletion request has been processed.":"La demande de suppression de votre compte a été traitée.",
    "Your account has been updated.":"Votre compte a été mis à jour.",
    "Password changed successfully.":"Le mot de passe a été modifié.",
    "Password updated.":"Mot de passe mis à jour.",
    "Something went wrong":"Une erreur est survenue",
    "Unavailable":"Indisponible",
    "Loading…":"Chargement…",
    "Loading the network…":"Chargement du réseau…",
    "Loading opportunity signals…":"Chargement des opportunités…",
    "Loading open collaborations…":"Chargement des collaborations…",
    "Loading reports…":"Chargement des signalements…",
    "Loading company requests…":"Chargement des demandes des entreprises…",
    "Loading evidence…":"Chargement des justificatifs…",
    "Loading sessions…":"Chargement des sessions…",
    "Loading connections…":"Chargement des relations…",
    "Loading service health…":"Vérification de l’état du service…",
    "Loading member profiles…":"Chargement des profils…",
    "Add a skill":"Ajouter une compétence",
    "Profile in progress":"Profil en cours de création",
    "PUBLIC · anonymous discovery enabled":"PUBLIC · visible des visiteurs",
    "PRIVATE · members only":"PRIVÉ · réservé aux membres",
    "Open profile":"Ouvrir le profil",
    "Edit profile":"Modifier le profil",
    "Profile photo":"Photo de profil",
    "My profile":"Mon profil",
    "My network":"Mon réseau",
    "Your network":"Votre réseau",
    "Company website ↗":"Site de l’entreprise ↗",
    "Location not specified":"Lieu non précisé",
    "Location flexible":"Lieu flexible",
    "VERIFIED":"VÉRIFIÉE",
    "VERIFIED COMPANY":"ENTREPRISE VÉRIFIÉE",
    "REVIEW PENDING":"VÉRIFICATION EN COURS",
    "NOT VERIFIED":"NON VÉRIFIÉE",
    "NOT VERIFIED · RESUBMISSION AVAILABLE":"NON VÉRIFIÉE · NOUVELLE DEMANDE POSSIBLE",
    "NOT VERIFIED · OPPORTUNITIES HIDDEN":"NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES",
    "PUBLIC":"PUBLIC",
    "PRIVATE":"PRIVÉ",
    "Read only":"Lecture seule",
    "Company team":"Équipe de l’entreprise",
    "Workspace":"Espace de travail",
    "Recruiter":"Recruteur",
    "Viewer":"Consultation",
    "Candidate":"Candidat",
    "Company":"Entreprise",
    "Project":"Projet",
    "Capabilities":"Compétences",
    "Evidence":"Réalisations",
    "Network":"Réseau",
    "Impact":"Impact",
    "Intent":"Aspirations",
    "Overview":"Vue d’ensemble",
    "Identity":"Identité",
    "Trajectory":"Parcours",
    "Notifications":"Notifications",
    "Your account is ready":"Votre compte est prêt",
    "You are all caught up.":"Vous êtes à jour.",
    "No published opportunities at the moment.":"Aucune opportunité publiée pour le moment.",
    "The new passwords do not match.":"Les nouveaux mots de passe ne correspondent pas.",
    "Permanently delete your ZERILYS account and associated operational data?":"Supprimer définitivement votre compte ZERILYS et les données opérationnelles associées ?",
    "Sign out every other active session?":"Fermer toutes les autres sessions actives ?",
    "Remove this member's access to the company workspace?":"Retirer à ce membre l’accès à l’espace entreprise ?",
    "Withdraw your interest? The company will no longer be able to view your application details.":"Retirer votre candidature ? L’entreprise ne pourra alors plus consulter les informations associées.",
    "What are you building?":"Que souhaitez-vous construire ?",
    "Describe the challenge and the contribution you need (at least 30 characters).":"Décrivez le défi et la contribution recherchée (30 caractères minimum).",
    "Skills needed, separated by commas (optional)":"Compétences recherchées, séparées par des virgules (facultatif)",
    "Your identity is ready to shape.":"Votre profil est prêt à être complété.",
    "Your collaboration is live.":"Votre collaboration est publiée.",
    "Your beta consent has been saved.":"Votre consentement aux conditions de la bêta a été enregistré.",
    "Evidence added as self-attested. It is not independently verified.":"Votre réalisation a été ajoutée comme déclaration personnelle. Elle n’a pas fait l’objet d’une vérification indépendante.",
    "Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Ajoutez des réalisations pour l’étayer.",
    "Profile photo updated.":"Photo de profil mise à jour.",
    "Profile photo removed.":"Photo de profil supprimée.",
    "Preparing photo…":"Préparation de la photo…",
    "Choose a JPG, PNG or WebP image.":"Choisissez une image JPG, PNG ou WebP.",
    "Choose an image smaller than 15 MB.":"Choisissez une image de moins de 15 Mo.",
    "Photo too large after compression. Choose a smaller image.":"La photo reste trop volumineuse après compression. Choisissez une image plus petite.",
    "Image dimensions are too large. Choose a smaller photo.":"Les dimensions de l’image sont trop importantes. Choisissez une photo plus petite.",
    "Registration is paused until the beta legal review is complete.":"Les inscriptions sont suspendues dans l’attente de la validation juridique des documents de la bêta.",
    "Welcome to ZERILYS. Your identity is ready to shape.":"Bienvenue sur ZERILYS. Votre profil est prêt à être complété.",
    "Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert.",
    "A few signals will make your universe clearer.":"Quelques éléments supplémentaires rendront votre profil plus complet.",
    "Your activation checklist is temporarily unavailable.":"La liste des étapes de création de votre profil est temporairement indisponible.",
    "Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace compétences est vide. Ajoutez les compétences que vous souhaitez mettre en avant, puis associez-y des réalisations.",
    "No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité ne gravite encore autour de votre profil. Lorsque les entreprises publieront leurs propositions, vous les retrouverez ici avec les raisons de leur adéquation à vos compétences et à vos aspirations.",
    "No social feed":"Pas de fil d’actualité",
    "No personal posts":"Pas de publications personnelles",
    "Only professional opportunities":"Des opportunités professionnelles uniquement",
    "Add photo":"Ajouter une photo",
    "CHANGE":"MODIFIER",
    "ADD PHOTO":"AJOUTER UNE PHOTO",
    "A CONNECTION WITH INTENT":"UNE MISE EN RELATION QUI A DU SENS",
    "ACCOUNT RECOVERY":"RÉCUPÉRATION DU COMPTE",
    "ACTIVATION PATH":"VOTRE PARCOURS DE CRÉATION",
    "Accept and continue":"Accepter et continuer",
    "Add your first signal ↗":"Ajouter votre premier élément ↗",
    "Back to sign in":"Retour à la connexion",
    "Before you continue.":"Avant de continuer.",
    "COMPANY STUDIO":"ESPACE ENTREPRISE",
    "Create a single-use invitation for one email address. The token is shown once for private manual delivery.":"Créez une invitation à usage unique pour une adresse e-mail. Le code ne sera affiché qu’une fois pour une transmission privée.",
    "Enter your account email. If an account exists and email delivery is available, a one-time reset token will be sent.":"Saisissez l’adresse e-mail de votre compte. Si celui-ci existe et que l’envoi d’e-mails est opérationnel, un lien de réinitialisation à usage unique vous sera envoyé.",
    "Everything you add strengthens this identity.":"Chaque élément ajouté enrichit votre profil.",
    "Experience & direction":"Expérience et projet professionnel",
    "Explore capabilities ↗":"Découvrir les compétences ↗",
    "Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez l’univers qui entoure votre profil. Chaque élément relie une compétence à un contexte, une réalisation ou une aspiration.",
    "Export a copy of your account data":"Exporter une copie de vos données",
    "I found a bug":"J’ai repéré un problème",
    "I have an idea":"J’ai une idée à proposer",
    "IDENTITY CONFIGURATION":"CONFIGURATION DU PROFIL",
    "IDENTITY CONSOLE":"ESPACE IDENTITÉ",
    "IDENTITY STRENGTH":"COMPLÉTUDE DU PROFIL",
    "Make your capabilities visible.":"Donnez de la visibilité à vos compétences.",
    "Manage active sign-in sessions. A maximum of ten active sessions is allowed per account.":"Gérez les sessions ouvertes sur votre compte. Dix sessions actives au maximum sont autorisées.",
    "Not a CV. A living map of what you are, what you can prove, and what you could create next.":"Plus qu’un CV : une représentation vivante de votre parcours, de vos réalisations et de ce que vous souhaitez construire.",
    "One space. Your whole potential.":"Un espace pour révéler tout votre potentiel.",
    "One-time reset token":"Code de réinitialisation à usage unique",
    "OPEN TO OPPORTUNITIES":"À L’ÉCOUTE D’OPPORTUNITÉS",
    "Optional personal invitation":"Invitation personnelle (facultative)",
    "Other feedback":"Autres retours",
    "People & proximity":"Personnes et proximité",
    "Permanently delete account":"Supprimer définitivement le compte",
    "PRIVATE TO YOU":"VISIBLE PAR VOUS SEUL",
    "PRIVATE BETA / HELP US IMPROVE":"BÊTA PRIVÉE / AIDEZ-NOUS À PROGRESSER",
    "PRIVATE BETA / REQUIRED ACKNOWLEDGEMENT":"BÊTA PRIVÉE / ACCORD REQUIS",
    "Preparing your next steps…":"Préparation des prochaines étapes…",
    "Reset your password.":"Réinitialisez votre mot de passe.",
    "SELECT A SIGNAL OR CAPABILITY TO EXPLORE":"SÉLECTIONNEZ UN ÉLÉMENT OU UNE COMPÉTENCE À EXPLORER",
    "Send feedback ↗":"Envoyer mon retour ↗",
    "Send reset token":"Envoyer le lien de réinitialisation",
    "Share beta feedback":"Partager un retour sur la bêta",
    "Share your feedback.":"Votre avis nous intéresse.",
    "Sign out instead":"Se déconnecter à la place",
    "Something is confusing":"Un point manque de clarté",
    "Tell us what worked, what confused you, or what should change. Your feedback is visible to the authorized ZERILYS review team.":"Dites-nous ce qui fonctionne, ce qui vous semble confus ou ce qui devrait évoluer. Votre retour sera visible par l’équipe ZERILYS habilitée.",
    "The beta terms and privacy notice have been updated. Please review the current documents and confirm both items to continue using ZERILYS.":"Les conditions de la bêta et la politique de confidentialité ont été mises à jour. Veuillez consulter les documents en vigueur et confirmer les deux points pour continuer à utiliser ZERILYS.",
    "This permanently removes your account, profile, evidence, offers, applications, company memberships, notifications and related operational records. Audit events are retained as accountability records with opaque identifiers. This action cannot be undone.":"Cette opération supprime définitivement votre compte, votre profil, vos justificatifs, vos offres, vos candidatures, vos accès aux espaces entreprise, vos notifications et les données opérationnelles associées. Les traces d’audit sont conservées sous des identifiants non directement attribuables. Cette action est irréversible.",
    "Type your account email to confirm":"Saisissez l’adresse e-mail de votre compte pour confirmer",
    "Update password":"Mettre à jour le mot de passe",
    "What comes next":"La suite de votre parcours",
    "Work that matters":"Des projets qui comptent",
    "YOUR CORE SIGNAL":"VOTRE ESSENTIEL",
    "YOUR IDENTITY FIELD":"VOTRE UNIVERS PROFESSIONNEL",
    "YOUR NEXT CHAPTER STARTS HERE":"VOTRE PROCHAINE ÉTAPE COMMENCE ICI",
    "YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE",
    "YOUR UNIVERSE":"VOTRE UNIVERS",
    "↗ Share identity":"↗ Partager mon profil",
    "◉ Focus mode":"◉ Mode concentration",
    "⟡ Connections":"⟡ Relations",
    "Your previous feedback":"Vos précédents retours",
    "Your professional signal":"Votre identité professionnelle",
    "Your location":"Votre lieu de résidence",
    "Your name":"Votre nom",
    "Company website (optional)":"Site internet de l’entreprise (facultatif)",
    "Current password":"Mot de passe actuel",
    "New password":"Nouveau mot de passe",
    "I accept the current":"J’accepte les conditions en vigueur",
    "I acknowledge the current":"Je reconnais avoir pris connaissance de la politique en vigueur",
    "Your connection field.":"Votre réseau.",
    "Loading your feedback…":"Chargement de vos retours…",
    "No published opportunities at the moment.":"Aucune opportunité publiée pour le moment.",
    "No candidate interest yet.":"Aucun candidat n’a manifesté d’intérêt pour le moment.",
    "Company workspace unavailable: ":"Espace entreprise indisponible : ",
    "No active sessions found.":"Aucune session active.",
    "No team members yet.":"Aucun membre dans l’équipe pour le moment.",
    "No interest expressed yet. Your opportunity journey will appear here.":"Vous n’avez manifesté d’intérêt pour aucune opportunité. Votre suivi apparaîtra ici.",
    "The profile should reveal a direction, not just a chronology.":"Votre profil doit faire ressortir une direction, pas seulement une chronologie.",
    "Evidence submitted for independent review.":"Votre justificatif a été transmis pour examen indépendant.",
    "Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Connection response saved.":"Votre réponse a été enregistrée.",
    "Company page is not available.":"La page de cette entreprise n’est pas disponible.",
    "This identity is not available.":"Ce profil n’est pas disponible.",
    "Share is unavailable in this browser.":"Le partage n’est pas disponible dans ce navigateur.",
    "Public profile link shared.":"Le lien public du profil a été copié.",
    "Member-only link shared. Only signed-in members can open it.":"Le lien réservé aux membres a été copié. Seuls les membres connectés peuvent l’ouvrir.",
    "Open to opportunities":"À l’écoute d’opportunités",
    "Not looking right now":"Pas en recherche actuellement",
    "Select a capability (optional)":"Choisir une compétence (facultatif)",
    "No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucun justificatif n’a encore été ajouté. Des projets, certifications, publications ou exemples de travaux peuvent illustrer vos compétences.",
    "No evidence has been linked publicly to this capability yet.":"Aucun justificatif public n’est encore associé à cette compétence.",
    "No opportunity signals are orbiting your identity yet.":"Aucune opportunité ne gravite encore autour de votre profil.",
    "Your connection field is empty.":"Votre réseau est encore vide.",
    "No hiring score. No popularity ranking. You remain in control of your visibility.":"Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.",
    "Before you continue.":"Avant de continuer.",
    "Accept and continue":"Accepter et continuer",
    "Add your first signal ↗":"Ajouter votre premier élément ↗",
    "Everything you add strengthens this identity.":"Chaque élément ajouté enrichit votre profil.",
    "Experience & direction":"Expérience et projet professionnel",
    "Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez l’univers qui entoure votre profil. Chaque élément relie une compétence à un contexte, une réalisation ou une aspiration.",
    "Export a copy of your account data":"Exporter une copie de vos données",
    "Enter your account email. If an account exists and email delivery is available, a one-time reset token will be sent.":"Saisissez l’adresse e-mail de votre compte. Si celui-ci existe et que l’envoi d’e-mails est opérationnel, un lien de réinitialisation à usage unique vous sera envoyé.",
    "I found a bug":"J’ai repéré un problème",
    "I have an idea":"J’ai une idée à proposer",
    "IDENTITY CONSOLE":"ESPACE IDENTITÉ",
    "IDENTITY STRENGTH":"COMPLÉTUDE DU PROFIL",
    "Make your capabilities visible.":"Donnez de la visibilité à vos compétences.",
    "Not a CV. A living map of what you are, what you can prove, and what you could create next.":"Plus qu’un CV : une représentation vivante de votre parcours, de vos réalisations et de ce que vous souhaitez construire.",
    "One space. Your whole potential.":"Un espace pour révéler tout votre potentiel.",
    "One-time reset token":"Code de réinitialisation à usage unique",
    "OPEN TO OPPORTUNITIES":"À L’ÉCOUTE D’OPPORTUNITÉS",
    "Optional personal invitation":"Invitation personnelle (facultative)",
    "Other feedback":"Autres retours",
    "People & proximity":"Personnes et proximité",
    "Permanently delete account":"Supprimer définitivement le compte",
    "PRIVATE TO YOU":"VISIBLE PAR VOUS SEUL",
    "PRIVATE BETA / HELP US IMPROVE":"BÊTA PRIVÉE / AIDEZ-NOUS À PROGRESSER",
    "PRIVATE BETA / REQUIRED ACKNOWLEDGEMENT":"BÊTA PRIVÉE / ACCORD REQUIS",
    "Preparing your next steps…":"Préparation des prochaines étapes…",
    "Reset your password.":"Réinitialisez votre mot de passe.",
    "SELECT A SIGNAL OR CAPABILITY TO EXPLORE":"SÉLECTIONNEZ UN ÉLÉMENT OU UNE COMPÉTENCE À EXPLORER",
    "Send feedback ↗":"Envoyer mon retour ↗",
    "Send reset token":"Envoyer le lien de réinitialisation",
    "Share beta feedback":"Partager un retour sur la bêta",
    "Share your feedback.":"Votre avis nous intéresse.",
    "Sign out instead":"Se déconnecter à la place",
    "Something is confusing":"Un point manque de clarté",
    "Tell us what worked, what confused you, or what should change. Your feedback is visible to the authorized ZERILYS review team.":"Dites-nous ce qui fonctionne, ce qui vous semble confus ou ce qui devrait évoluer. Votre retour sera visible par l’équipe ZERILYS habilitée.",
    "The beta terms and privacy notice have been updated. Please review the current documents and confirm both items to continue using ZERILYS.":"Les conditions de la bêta et la politique de confidentialité ont été mises à jour. Veuillez consulter les documents en vigueur et confirmer les deux points pour continuer à utiliser ZERILYS.",
    "This permanently removes your account, profile, evidence, offers, applications, company memberships, notifications and related operational records. Audit events are retained as accountability records with opaque identifiers. This action cannot be undone.":"Cette opération supprime définitivement votre compte, votre profil, vos justificatifs, vos offres, vos candidatures, vos accès aux espaces entreprise, vos notifications et les données opérationnelles associées. Les traces d’audit sont conservées sous des identifiants non directement attribuables. Cette action est irréversible.",
    "Type your account email to confirm":"Saisissez l’adresse e-mail de votre compte pour confirmer",
    "What comes next":"La suite de votre parcours",
    "Work that matters":"Des projets qui comptent",
    "YOUR CORE SIGNAL":"VOTRE ESSENTIEL",
    "YOUR IDENTITY FIELD":"VOTRE UNIVERS PROFESSIONNEL",
    "YOUR NEXT CHAPTER STARTS HERE":"VOTRE PROCHAINE ÉTAPE COMMENCE ICI",
    "YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE",
    "YOUR UNIVERSE":"VOTRE UNIVERS",
    "↗ Share identity":"↗ Partager mon profil",
    "◉ Focus mode":"◉ Mode concentration",
    "⟡ Connections":"⟡ Relations",
    "Your previous feedback":"Vos précédents retours",
    "Your professional signal":"Votre identité professionnelle",
    "Your location":"Votre lieu de résidence",
    "Your name":"Votre nom",
    "Company website (optional)":"Site internet de l’entreprise (facultatif)",
    "I accept the current":"J’accepte les conditions en vigueur",
    "I acknowledge the current":"Je reconnais avoir pris connaissance de la politique en vigueur",
    "Loading your feedback…":"Chargement de vos retours…",
    "No interest expressed yet. Your opportunity journey will appear here.":"Vous n’avez manifesté d’intérêt pour aucune opportunité. Votre suivi apparaîtra ici.",
    "No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucun justificatif n’a encore été ajouté. Des projets, certifications, publications ou exemples de travaux peuvent illustrer vos compétences.",
    "Evidence submitted for independent review.":"Votre justificatif a été transmis pour examen indépendant.",
    "Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Connection response saved.":"Votre réponse a été enregistrée.",
    "This identity is not available.":"Ce profil n’est pas disponible.",
    "Share is unavailable in this browser.":"Le partage n’est pas disponible dans ce navigateur.",
    "Your interest was withdrawn.":"Votre intérêt a été retiré.",
    "Company page is not available.":"La page de cette entreprise n’est pas disponible.",
    "Your activation checklist is temporarily unavailable.":"La liste des étapes de création de votre profil est temporairement indisponible.",
    "A few signals will make your universe clearer.":"Quelques éléments supplémentaires rendront votre profil plus complet.",
    "Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert.",
    "Loading feedback…":"Chargement des retours…",
    "No matching profiles. Try another name, skill or location.":"Aucun profil correspondant. Essayez un autre nom, une autre compétence ou un autre lieu.",
    "The network is taking shape. Be among the first to create a profile.":"Le réseau se construit. Soyez parmi les premiers à créer votre profil.",
    "The network is temporarily unavailable.":"Le réseau est temporairement indisponible.",
    "Collaborations are temporarily unavailable.":"Les collaborations sont temporairement indisponibles.",
    "No open collaborations yet. Be the first to start one.":"Aucun projet ouvert pour le moment. Soyez le premier à en lancer un.",
    "No published opportunities at the moment.":"Aucune opportunité publiée pour le moment.",
    "No published opportunities yet. Company opportunities will appear here when they are available.":"Aucune opportunité n’est publiée pour le moment. Les propositions des entreprises apparaîtront ici dès qu’elles seront disponibles.",
    "Your account has been updated.":"Votre compte a été mis à jour.",
    "No active sessions found.":"Aucune session active.",
    "Company website ↗":"Site de l’entreprise ↗",
    "Location not specified":"Lieu non précisé",
    "Location flexible":"Lieu flexible",
    "Your previous feedback":"Vos précédents retours",
    "This company has not added an overview yet.":"Cette entreprise n’a pas encore renseigné sa présentation.",
    "Professional member":"Membre du réseau professionnel",
    "Building their next chapter":"Prépare la suite de son parcours",
    "Explore this identity":"Découvrir ce profil",
    "Discover this identity":"Découvrir ce profil",
    "Explore ↗":"Découvrir ↗",
    "Connect with intent":"Entrer en relation",
    "INCOMING SIGNAL":"DEMANDE REÇUE",
    "OUTGOING SIGNAL":"DEMANDE ENVOYÉE",
    "Connected":"En relation",
    "Awaiting response":"En attente de réponse",
    "Connection request sent":"Demande de mise en relation envoyée",
    "Company identity reviewed by the ZERILYS trust team.":"L’identité de l’entreprise a été examinée par l’équipe confiance de ZERILYS.",
    "Your opportunities are not yet visible to candidates.":"Vos opportunités ne sont pas encore visibles des candidats.",
    "Submit public evidence so a reviewer can confirm the organization.":"Fournissez des éléments publics permettant de confirmer l’existence de l’organisation.",
    "The profile should reveal a direction, not just a chronology.":"Votre profil doit faire ressortir une direction, pas seulement une chronologie.",
    "These signals help the network surface complementary people — not rank people by popularity.":"Ces repères aident à faire émerger des profils complémentaires, sans classement par popularité.",
    "Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace compétences est vide. Ajoutez les compétences que vous souhaitez mettre en avant, puis associez-y des réalisations.",
    "No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité ne gravite encore autour de votre profil. Lorsque les entreprises publieront leurs propositions, vous les retrouverez ici avec les raisons de leur adéquation à vos compétences et à vos aspirations.",
    "The member network is temporarily unavailable.":"Le réseau des membres est temporairement indisponible.",
    "Your profile is ready to be discovered.":"Votre profil est prêt à être découvert.",
    "Profile link copied.":"Le lien du profil a été copié.",
    "Identity link copied.":"Le lien du profil a été copié.",
    "Current session":"Session actuelle",
    "Active session":"Session active",
    "THIS DEVICE":"CET APPAREIL",
    "ACTIVE":"ACTIVE",
    "Started":"Ouverte le",
    "Expires":"Expire le",
    "Share this identity":"Partager ce profil",
    "Profile in progress":"Profil en cours de création",
    "Your profile is private":"Votre profil est privé",
    "Your profile is public":"Votre profil est public",
    "Open my candidate profile":"Ouvrir mon profil professionnel",
    "Open your candidate profile":"Ouvrir votre profil professionnel",
    "Remove skill":"Supprimer cette compétence",
    "Submit for review ↗":"Soumettre pour vérification ↗",
    "Evidence submitted for independent review.":"Votre justificatif a été transmis pour examen indépendant.",
    "Your professional profile has been shared with this company for this opportunity only.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.",
    "Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué.",
    "You are all caught up.":"Vous êtes à jour.",
    "Mark read":"Marquer comme lu",
    "Read":"Lu",
    "No candidate interest yet.":"Aucun candidat n’a manifesté d’intérêt pour le moment.",
    "No team members yet.":"Aucun membre dans l’équipe pour le moment.",
    "No active sessions found.":"Aucune session active.",
    "Company workspace unavailable: ":"Espace entreprise indisponible : ",
    "Accept the current beta terms and privacy notice to continue.":"Acceptez les conditions de la bêta et prenez connaissance de la politique de confidentialité en vigueur pour continuer.",
    "Registration is paused until the beta terms and privacy notice have been legally approved.":"Les inscriptions sont suspendues dans l’attente de la validation juridique des conditions de la bêta et de la politique de confidentialité.",
    "You must accept the beta terms and acknowledge the privacy notice.":"Vous devez accepter les conditions de la bêta et confirmer avoir pris connaissance de la politique de confidentialité.",
    "Consent is paused until the beta terms and privacy notice have been legally approved.":"Le recueil du consentement est suspendu dans l’attente de la validation juridique des documents de la bêta.",
    "14 days":"14 jours",
    "30 days":"30 jours",
    "7 days":"7 jours",
    "Collaboration":"Collaboration",
    "Data & privacy":"Données et confidentialité",
    "Edit identity":"Modifier mon profil",
    "HUMAN SIGNAL / 001":"SIGNAL HUMAIN / 001",
    "Langue":"Langue",
    "Name":"Nom",
    "Shared beta code (or use a personal invitation)":"Code bêta (ou invitation personnelle)",
    "TRUST OPERATIONS / RESTRICTED ACCESS":"GESTION DE LA CONFIANCE / ACCÈS RESTREINT",
    "You can create an account without an invitation. If you received a personal invitation, it is reserved for your email address and can be used once.":"Vous pouvez créer un compte sans invitation. Si vous avez reçu une invitation personnelle, elle est réservée à votre adresse e-mail et ne peut être utilisée qu’une seule fois.",
    "Your professional universe.":"Votre univers professionnel.",
    "ZERIH / IDENTITY OS":"ZERIH / SYSTÈME D’IDENTITÉ",
    "ZERILYS — The Global Network":"ZERILYS — Au-delà du CV",
    "© 2026 ZERILYS. Beyond the CV.":"© 2026 ZERILYS. Au-delà du CV.",
    "· LIVE":"· EN DIRECT",
    "✓ Evidence-first profiles":"✓ Des profils étayés par des réalisations",
    "✓ Human-controlled collaboration":"✓ Une collaboration maîtrisée par les personnes",
    "✓ Privacy by design":"✓ La confidentialité dès la conception",
    "✓ Transparent skill levels":"✓ Des niveaux de compétence transparents",
    "A professional identity is not a list. It is a field of capabilities, proof and possibilities.":"Une identité professionnelle ne se résume pas à une liste. C’est un univers de compétences, de réalisations et de possibilités.",
    "Add skills to activate your field":"Ajoutez des compétences pour activer votre univers",
    "Accept for follow-up":"Retenir pour suivi",
    "Dismiss":"Ignorer",
    "Mark reviewed":"Marquer comme examiné",
    "Reject evidence":"Refuser le justificatif",
    "Reject request":"Refuser la demande",
    "Revoke":"Révoquer",
    "Verify company":"Vérifier l’entreprise",
    "Verify evidence":"Vérifier le justificatif",
    "Company website ↗":"Site de l’entreprise ↗",
    "Open company website ↗":"Ouvrir le site de l’entreprise ↗",
    "Open submitted source ↗":"Ouvrir la source transmise ↗",
    "Copy manual tokens ↗":"Copier les codes à transmettre ↗",
    "PRIVATE COMPANY NOTES · only visible to your team":"NOTES INTERNES · visibles uniquement par votre équipe",
    "Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.":"Chaque membre connecté peut consulter les profils des autres candidats. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.",
    "Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.":"Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.",
    "Signals will appear here":"Vos éléments apparaîtront ici",
    "YOUR CAPABILITIES":"VOS COMPÉTENCES",
    "YOUR NETWORK":"VOTRE RÉSEAU",
    "CAPABILITY FIELD":"ESPACE COMPÉTENCES",
    "CAPABILITY SIGNAL":"REPÈRE DE COMPÉTENCE",
    "COMPANY UNIVERSE":"UNIVERS DE L’ENTREPRISE",
    "COMPANY VERIFICATION":"VÉRIFICATION DE L’ENTREPRISE",
    "YOUR CORE SIGNAL":"VOTRE ESSENTIEL",
    "HUMAN SIGNAL":"SIGNAL HUMAIN",
    "RELEASE":"VERSION",
    "STORAGE":"STOCKAGE",
    "DATA FILE":"FICHIER DE DONNÉES",
    "DATA INTEGRITY":"INTÉGRITÉ DES DONNÉES",
    "LOCAL BACKUP":"SAUVEGARDE LOCALE",
    "Off-site: not configured":"Sauvegarde externe : non configurée",
    "MEMBERS":"MEMBRES",
    "MODERATION QUEUE":"FILE DE MODÉRATION",
    "PERSONAL INVITATIONS":"INVITATIONS PERSONNELLES",
    "Searching the member network…":"Recherche dans le réseau des membres…",
    "The network is taking shape. Be among the first to create a profile.":"Le réseau se construit. Soyez parmi les premiers à créer votre profil.",
    "The network is temporarily unavailable.":"Le réseau est temporairement indisponible.",
    "Collaborations are temporarily unavailable.":"Les collaborations sont temporairement indisponibles.",
    "No open collaborations yet. Be the first to start one.":"Aucun projet ouvert pour le moment. Soyez le premier à en lancer un.",
    "No open reports. The queue is clear.":"Aucun signalement en attente.",
    "No open tester feedback.":"Aucun retour de test en attente.",
    "No company verification requests.":"Aucune demande de vérification d’entreprise.",
    "No evidence awaiting review.":"Aucun justificatif en attente d’examen.",
    "No bulk invitation batches yet.":"Aucun lot d’invitations pour le moment.",
    "No pending personal invitations.":"Aucune invitation personnelle en attente.",
    "Invitation created for":"Invitation créée pour",
    "Invitation email sent to":"Invitation envoyée à",
    "Invitation created. Share this single-use token privately with":"Invitation créée. Transmettez ce code à usage unique en privé à",
    "It expires in seven days. ZERILYS does not send invitation emails yet.":"Cette invitation expire dans sept jours. ZERILYS n’envoie pas encore les e-mails d’invitation.",
    "tokens for private manual delivery.":"codes à transmettre manuellement et en privé.",
    "registered":"inscrits",
    "pending":"en attente",
    "revoked":"révoquées",
    "expired":"expirées",
    "invitations created":"invitations créées",
    "emails sent":"e-mails envoyés",
    "No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucun justificatif n’a encore été ajouté. Des projets, certifications, publications ou exemples de travaux peuvent illustrer vos compétences.",
    "Level:":"Niveau :",
    "Level: ":"Niveau : ",
    "linked evidence records":"justificatifs associés",
    "evidence record":"justificatif",
    "evidence records":"justificatifs",
    "capabilities":"compétences",
    "interest":"intérêt",
    "interested":"intéressés",
    "Connected":"En relation",
    "Awaiting response":"En attente de réponse",
    "OUTGOING SIGNAL":"DEMANDE ENVOYÉE",
    "INCOMING SIGNAL":"DEMANDE REÇUE",
    "YOUR NETWORK":"VOTRE RÉSEAU",
    "Profile link copied.":"Le lien du profil a été copié.",
    "Identity link copied.":"Le lien du profil a été copié.",
    "Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés de ZERILYS. Le mode privé le masque des liens publics et de la découverte anonyme.",
    "Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres de ZERILYS et accessible par son lien public. Vous pouvez à tout moment limiter sa découverte par les visiteurs non connectés.",
    "Your company identity is separate from your personal profile. Company opportunities appear only after company verification.":"L’identité de votre entreprise est distincte de votre profil personnel. Ses opportunités ne sont visibles qu’après vérification de l’entreprise.",
    "Define your professional signal":"Présentez votre identité professionnelle",
    "Location not shared":"Lieu non communiqué",
    "Building their next chapter":"Prépare la suite de son parcours",
    "Professional member":"Membre du réseau professionnel",
    "Explore this identity":"Découvrir ce profil",
    "Discover this identity":"Découvrir ce profil",
    "Your profile is ready to be discovered.":"Votre profil est prêt à être découvert.",
    "Your connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Member blocked.":"Membre bloqué.",
    "Member unblocked.":"Blocage levé.",
    "Report sent to the moderation team.":"Votre signalement a été transmis à l’équipe de modération.",
    "Your profile is not available.":"Ce profil n’est pas disponible.",
    "The profile is not available.":"Ce profil n’est pas disponible.",
    "No company verification requests.":"Aucune demande de vérification d’entreprise.",
    "Company verification request submitted.":"La demande de vérification de l’entreprise a été envoyée.",
    "Offer status updated.":"Le statut de l’opportunité a été mis à jour.",
    "Candidate status updated.":"Le statut de la candidature a été mis à jour.",
    "Team access removed.":"L’accès à l’espace entreprise a été retiré.",
    "Internal note saved.":"Note interne enregistrée.",
    "Company identity updated.":"Les informations de l’entreprise ont été mises à jour.",
    "Your identity has been updated.":"Votre profil a bien été mis à jour.",
    "Your connection response has been saved.":"Votre réponse à la demande de mise en relation a été enregistrée.",
    "Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Your collaboration is live.":"Votre projet est maintenant visible.",
    "The new passwords do not match.":"Les deux nouveaux mots de passe ne correspondent pas.",
    "Your account deletion request has been processed.":"La demande de suppression de votre compte a été traitée.",
    "Your beta consent has been saved.":"Votre consentement aux conditions de la bêta a été enregistré.",
    "YOUR CORE SIGNAL":"VOTRE ESSENTIEL",
    "Make your capabilities visible.":"Donnez de la visibilité à vos compétences.",
    "Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez l’univers qui entoure votre profil. Chaque élément relie une compétence à un contexte, une réalisation ou une aspiration.",
    "What can you actually do?":"Que savez-vous réellement faire ?",
    "PROOF LAYER":"ESPACE RÉALISATIONS",
    "Show the work behind the claim.":"Montrez ce qui étaye vos compétences.",
    "Where have you been — where next?":"D’où venez-vous et où souhaitez-vous aller ?",
    "Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.":"Votre parcours continue de s’écrire. Présentez votre activité, les défis que vous avez relevés et la direction que vous souhaitez explorer.",
    "INTENT FIELD":"ESPACE ASPIRATIONS",
    "What do you want to make possible?":"Qu’aimeriez-vous rendre possible ?",
    "You are open to new opportunities.":"Vous êtes à l’écoute de nouvelles opportunités.",
    "You are open to selective connections.":"Vous privilégiez les propositions ciblées.",
    "You are not looking for opportunities right now.":"Vous ne recherchez pas d’opportunité pour le moment.",
    "Not defined yet":"À préciser",
    "MEMBER NETWORK":"RÉSEAU DES MEMBRES",
    "Discover the people around your orbit.":"Découvrez les personnes qui gravitent autour de votre univers.",
    "Search members, skills or places":"Rechercher des membres, des compétences ou des lieux",
    "Search member profiles":"Rechercher des profils de membres",
    "What is orbiting your next move?":"Quelles opportunités peuvent accompagner votre prochaine étape ?",
    "Explore this opportunity and inspect its requirements.":"Découvrez cette opportunité et consultez les attentes associées.",
    "IMPACT SIGNAL":"REPÈRE D’IMPACT",
    "Make contribution visible.":"Rendez vos contributions visibles.",
    "Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.":"Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.",
    "Add a capability":"Ajouter une compétence",
    "Add evidence":"Ajouter une réalisation",
    "Edit identity":"Modifier mon profil",
    "INDEPENDENTLY VERIFIED":"VÉRIFIÉ INDÉPENDAMMENT",
    "SELF-DESCRIBED CAPABILITY":"COMPÉTENCE DÉCLARÉE",
    "Level: ":"Niveau : ",
    "linked evidence record":"réalisation associée",
    "linked evidence records":"réalisations associées",
    "Link evidence ↗":"Associer une réalisation ↗",
    "verified":"vérifiée",
    "self-declared":"déclarée",
    "WHAT I CAN BRING":"CE QUE JE PEUX APPORTER",
    "WHAT I AM LOOKING FOR":"CE QUE JE RECHERCHE",
    "INCOMING SIGNAL":"DEMANDE REÇUE",
    "OUTGOING SIGNAL":"DEMANDE ENVOYÉE",
    "Human potential in motion":"Un potentiel humain en mouvement",
    "Connected":"En relation",
    "Awaiting response":"En attente de réponse",
    "Connection response saved.":"Votre réponse à la demande de mise en relation a été enregistrée.",
    "This company has not added an overview yet.":"Cette entreprise n’a pas encore renseigné sa présentation.",
    "Company website ↗":"Site de l’entreprise ↗",
    "Location not provided":"Lieu non renseigné",
    "Location flexible":"Lieu flexible",
    "Hybrid":"Hybride",
    "Remote":"À distance",
    "On-site":"Sur site",
    "Job":"Emploi",
    "Internship":"Stage",
    "Apprenticeship":"Alternance",
    "Collaboration":"Collaboration",
    "Interest sent ✓":"Intérêt transmis ✓",
    "Interest already sent ✓":"Intérêt déjà transmis ✓",
    "Interest sent":"Intérêt transmis",
    "Under review":"À l’étude",
    "Interview stage":"Étape d’entretien",
    "Not selected":"Non retenu",
    "Withdrawn":"Retiré",
    "Updated":"Mis à jour",
    "PRIVATE COMPANY NOTES · only visible to your team":"NOTES INTERNES · visibles uniquement par votre équipe",
    "Add an internal note…":"Ajouter une note interne…",
    "New interest":"Nouvel intérêt",
    "Reviewing":"En cours d’examen",
    "Interview":"Entretien",
    "Declined":"Refusé",
    "This member is not available.":"Ce membre n’est pas disponible.",
    "Describe the issue (at least 20 characters). This report will be sent to the moderation team.":"Décrivez le problème (20 caractères minimum). Votre signalement sera transmis à l’équipe de modération.",
    "Block this member? You will no longer see each other in discovery or be able to connect.":"Bloquer ce membre ? Vous ne pourrez plus vous voir dans le réseau ni entrer en relation.",
    "Unblock":"Débloquer",
    "Member blocked.":"Membre bloqué.",
    "Member unblocked.":"Blocage levé.",
    "Report sent to the moderation team.":"Votre signalement a été transmis à l’équipe de modération.",
    "This identity is not available.":"Ce profil n’est pas disponible.",
    "ZERILYS professional identity":"Profil professionnel ZERILYS",
    "Explore this professional identity on ZERILYS":"Découvrez ce profil professionnel sur ZERILYS",
    "Share is unavailable in this browser.":"Le partage n’est pas disponible dans ce navigateur.",
    "Identity link copied.":"Le lien du profil a été copié.",
    "Remove skill":"Supprimer cette compétence",
    "Submit for review ↗":"Soumettre pour vérification ↗",
    "Evidence submitted for independent review.":"Votre réalisation a été transmise pour examen indépendant.",
    "What would you bring to this collaboration? (optional)":"Que pourriez-vous apporter à cette collaboration ? (facultatif)",
    "Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.":"Votre réseau est encore vide. Découvrez un profil et envoyez une demande de mise en relation personnalisée pour commencer.",
    "Every request carries context. No empty invitations, no popularity mechanics.":"Chaque demande est contextualisée. Pas d’invitation impersonnelle ni de course à la popularité.",
    "Connections are temporarily unavailable.":"Les relations sont temporairement indisponibles.",
    "Describe the issue":"Décrivez le problème",
    "Add an optional moderation note (not visible to the reported member).":"Ajouter une note de modération facultative (non visible par la personne signalée).",
    "Add an optional evidence review note.":"Ajouter une note facultative sur l’examen de la réalisation.",
    "Explain what public evidence you checked (minimum 20 characters).":"Précisez les éléments publics que vous avez vérifiés (20 caractères minimum).",
    "What are you building?":"Que souhaitez-vous construire ?",
    "Describe the challenge and the contribution you need (at least 30 characters).":"Décrivez le défi et la contribution recherchée (30 caractères minimum).",
    "Skills needed, separated by commas (optional)":"Compétences recherchées, séparées par des virgules (facultatif)",
    "Interest sent. The project owner can review your application.":"Votre intérêt a été transmis. Le responsable du projet peut maintenant examiner votre proposition.",
    "Report review saved.":"L’examen du signalement a été enregistré.",
    "Evidence review saved.":"L’examen de la réalisation a été enregistré.",
    "Company verification request submitted.":"La demande de vérification de l’entreprise a été envoyée.",
    "Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.",
    "Your professional profile has been shared with this company for this opportunity only.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.",
    "Interest already sent ✓":"Intérêt déjà transmis ✓",
    "Withdraw your interest? The company will no longer be able to view your application details.":"Retirer votre candidature ? L’entreprise ne pourra alors plus consulter les informations associées.",
    "Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué.",
    "Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert.",
    "A few signals will make your universe clearer.":"Quelques éléments supplémentaires rendront votre profil plus complet.",
    "Your activation checklist is temporarily unavailable.":"La liste des étapes de création de votre profil est temporairement indisponible.",
    "Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace compétences est vide. Ajoutez les compétences que vous souhaitez mettre en avant, puis associez-y des réalisations.",
    "No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité ne gravite encore autour de votre profil. Lorsque les entreprises publieront leurs propositions, vous les retrouverez ici avec les raisons de leur adéquation à vos compétences et à vos aspirations.",
    "Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés de ZERILYS. Le mode privé le masque des liens publics et de la découverte anonyme.",
    "Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres de ZERILYS et accessible par son lien public. Vous pouvez à tout moment limiter sa découverte par les visiteurs non connectés.",
    "Your company identity is separate from your personal profile. Company opportunities appear only after company verification.":"L’identité de votre entreprise est distincte de votre profil personnel. Ses opportunités ne sont visibles qu’après vérification de l’entreprise.",
    "Define your professional signal":"Présentez votre identité professionnelle",
    "Your name":"Votre nom",
    "Location not shared":"Lieu non communiqué",
    "Your identity has been updated.":"Votre profil a bien été mis à jour.",
    "Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Ajoutez des réalisations pour l’étayer.",
    "Evidence added as self-attested. It is not independently verified.":"Votre réalisation a été ajoutée comme déclaration personnelle. Elle n’a pas fait l’objet d’une vérification indépendante.",
    "Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Your account deletion request has been processed.":"La demande de suppression de votre compte a été traitée.",
    "Sign out every other active session?":"Fermer toutes les autres sessions actives ?",
    "Permanently delete your ZERILYS account and associated operational data?":"Supprimer définitivement votre compte ZERILYS et les données opérationnelles associées ?",
    "The new passwords do not match.":"Les deux nouveaux mots de passe ne correspondent pas.",
    "Password changed successfully.":"Le mot de passe a été modifié.",
    "Password updated. Sign in with your new password.":"Mot de passe modifié. Connectez-vous avec votre nouveau mot de passe.",
    "Welcome to ZERILYS. Your identity is ready to shape.":"Bienvenue sur ZERILYS. Votre profil est prêt à être complété.",
    "Your collaboration is live.":"Votre projet est maintenant visible.",
    "Your identity has been updated.":"Votre profil a bien été mis à jour.",
    "Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert.",
    "The new passwords do not match.":"Les deux nouveaux mots de passe ne correspondent pas.",
    "The profile should reveal a direction, not just a chronology.":"Votre profil doit faire ressortir une direction, pas seulement une chronologie.",
    "These signals help the network surface complementary people — not rank people by popularity.":"Ces repères aident à faire émerger des profils complémentaires, sans classement par popularité.",
    "The network is taking shape. Be among the first to create a profile.":"Le réseau se construit. Soyez parmi les premiers à créer votre profil.",
    "The network is temporarily unavailable.":"Le réseau est temporairement indisponible.",
    "Collaborations are temporarily unavailable.":"Les collaborations sont temporairement indisponibles.",
    "No open collaborations yet. Be the first to start one.":"Aucun projet ouvert pour le moment. Soyez le premier à en lancer un.",
    "No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucun justificatif n’a encore été ajouté. Des projets, certifications, publications ou exemples de travaux peuvent illustrer vos compétences.",
    "Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.":"Votre réseau est encore vide. Découvrez un profil et envoyez une demande de mise en relation personnalisée pour commencer.",
    "No company verification requests.":"Aucune demande de vérification d’entreprise.",
    "No evidence awaiting review.":"Aucun justificatif en attente d’examen.",
    "No open reports. The queue is clear.":"Aucun signalement en attente.",
    "No open tester feedback.":"Aucun retour de test en attente.",
    "No bulk invitation batches yet.":"Aucun lot d’invitations pour le moment.",
    "No pending personal invitations.":"Aucune invitation personnelle en attente.",
    "Company workspace unavailable: ":"Espace entreprise indisponible : ",
    "The account is unavailable":"Le compte est indisponible",
    "No company opportunities published yet.":"Aucune opportunité d’entreprise publiée pour le moment.",
    "Location not provided":"Lieu non renseigné",
    "Location not specified":"Lieu non précisé",
    "No description supplied.":"Aucune description fournie.",
    "Reported by":"Signalé par",
    "Submitted by":"Transmis par",
    "expires":"expire le",
    "registered":"inscrits",
    "pending":"en attente",
    "revoked":"révoquées",
    "expired":"expirées",
    "emails sent":"e-mails envoyés",
    "invitations created":"invitations créées",
    "Only visible to your team":"Visible uniquement par votre équipe",
    "Company":"Entreprise",
    "Candidate":"Candidat",
    "Member":"Membre",
    "Member profile":"Profil membre",
    "Company identity":"Identité de l’entreprise",
    "Company workspace":"Espace entreprise",
    "Recruiter":"Recruteur",
    "Viewer":"Consultation",
    "Read-only access":"Accès en lecture seule",
    "Workspace":"Espace de travail",
    "Started":"Ouverte le",
    "Expires":"Expire le",
    "date unavailable":"date indisponible",
    "CURRENT SESSION":"SESSION ACTUELLE",
    "Current session":"Session actuelle",
    "Active session":"Session active",
    "THIS DEVICE":"CET APPAREIL",
    "ACTIVE":"ACTIVE",
    "OTHER SESSION":"AUTRE SESSION",
    "Current beta terms and privacy notice have not been accepted.":"Les conditions de la bêta et la politique de confidentialité en vigueur n’ont pas encore été acceptées.",
    "Accepted terms v":"Conditions v",
    "and privacy notice v":"et politique de confidentialité v",
    "on":"le",
    "DATA INTEGRITY":"INTÉGRITÉ DES DONNÉES",
    "LOCAL BACKUP":"SAUVEGARDE LOCALE",
    "Off-site: not configured":"Sauvegarde externe : non configurée",
    "MEMBERS":"MEMBRES",
    "MODERATION QUEUE":"FILE DE MODÉRATION",
    "PERSONAL INVITATIONS":"INVITATIONS PERSONNELLES",
    "COMPANY VERIFICATION":"VÉRIFICATION DES ENTREPRISES",
    "RELEASE":"VERSION",
    "STORAGE":"STOCKAGE",
    "DATA FILE":"FICHIER DE DONNÉES",
    "PRIVATE COMPANY NOTES · only visible to your team":"NOTES INTERNES · visibles uniquement par votre équipe",
    "Add an internal note…":"Ajouter une note interne…",
    "Describe the issue (at least 20 characters). This report will be sent to the moderation team.":"Décrivez le problème (20 caractères minimum). Votre signalement sera transmis à l’équipe de modération.",
    "Block this member? You will no longer see each other in discovery or be able to connect.":"Bloquer ce membre ? Vous ne pourrez plus vous voir dans le réseau ni entrer en relation.",
    "Explain what public evidence you checked (minimum 20 characters).":"Précisez les éléments publics que vous avez vérifiés (20 caractères minimum).",
    "Add an optional moderation note (not visible to the reported member).":"Ajouter une note de modération facultative (non visible par la personne signalée).",
    "Add an optional evidence review note.":"Ajouter une note facultative sur l’examen de la réalisation.",
    "What are you building?":"Que souhaitez-vous construire ?",
    "Describe the challenge and the contribution you need (at least 30 characters).":"Décrivez le défi et la contribution recherchée (30 caractères minimum).",
    "Skills needed, separated by commas (optional)":"Compétences recherchées, séparées par des virgules (facultatif)",
    "What would you bring to this collaboration? (optional)":"Que pourriez-vous apporter à cette collaboration ? (facultatif)",
    "Interest sent. The project owner can review your application.":"Votre intérêt a été transmis. Le responsable du projet peut maintenant examiner votre proposition.",
    "Report review saved.":"L’examen du signalement a été enregistré.",
    "Evidence review saved.":"L’examen de la réalisation a été enregistré.",
    "Open company website ↗":"Ouvrir le site de l’entreprise ↗",
    "Open submitted source ↗":"Ouvrir la source transmise ↗",
    "Copy manual tokens ↗":"Copier les codes à transmettre ↗",
    "Invitation revoked.":"Invitation révoquée.",
    "Company identity updated.":"Les informations de l’entreprise ont été mises à jour.",
    "Candidate status updated.":"Le statut de la candidature a été mis à jour.",
    "Offer status updated.":"Le statut de l’opportunité a été mis à jour.",
    "Team access removed.":"L’accès à l’espace entreprise a été retiré.",
    "Internal note saved.":"Note interne enregistrée.",
    "Opportunity published. Its match signals are now available to candidates.":"L’opportunité est publiée. Les candidats peuvent désormais découvrir les éléments qui correspondent à leur profil.",
    "Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.",
    "Your professional profile has been shared with this company for this opportunity only.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.",
    "Interest already sent ✓":"Intérêt déjà transmis ✓",
    "Interest sent ✓":"Intérêt transmis ✓",
    "Search members, skills or places":"Rechercher des membres, des compétences ou des lieux",
    "Search member profiles":"Rechercher des profils de membres",
    "Search ↗":"Rechercher ↗",
    "Loading member profiles…":"Chargement des profils…",
    "Loading…":"Chargement…",
    "Load next profiles ↓":"Afficher les profils suivants ↓",
    "Unable to load more profiles.":"Impossible de charger davantage de profils.",
    "No matching profiles. Try another name, skill or location.":"Aucun profil correspondant. Essayez un autre nom, une autre compétence ou un autre lieu.",
    "The member network is temporarily unavailable.":"Le réseau des membres est temporairement indisponible.",
    "A professional identity is not a list. It is a field of capabilities, proof and possibilities.":"Une identité professionnelle ne se résume pas à une liste. C’est un univers de compétences, de réalisations et de possibilités.",
    "Make contribution visible.":"Rendez vos contributions visibles.",
    "Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.":"Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.",
    "No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité ne gravite encore autour de votre profil. Lorsque les entreprises publieront leurs propositions, vous les retrouverez ici avec les raisons de leur adéquation à vos compétences et à vos aspirations.",
    "No hiring score. No popularity ranking. You remain in control of your visibility.":"Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.",
    "Email address":"Adresse e-mail",
    "Email verification status unavailable.":"État de confirmation de l’adresse e-mail indisponible.",
    "Resend confirmation email":"Renvoyer l’e-mail de confirmation",
    "Email address confirmed.":"Adresse e-mail confirmée.",
    "Your email address is confirmed.":"Votre adresse e-mail est confirmée.",
    "Your email address is not confirmed yet. Check your inbox for the confirmation link.":"Votre adresse e-mail n’est pas encore confirmée. Consultez votre boîte de réception pour retrouver le lien de confirmation.",
    "Email confirmation is not configured on this service yet.":"La confirmation par e-mail n’est pas encore configurée sur ce service.",
    "A new confirmation link has been sent to your email address.":"Un nouveau lien de confirmation vient de vous être envoyé.",
    "Your account is ready. Check your email to confirm your address.":"Votre compte est prêt. Consultez votre e-mail pour confirmer votre adresse.",
    "Your account is ready, but the confirmation email could not be sent. You can try again from your settings.":"Votre compte est prêt, mais l’e-mail de confirmation n’a pas pu être envoyé. Vous pourrez réessayer depuis vos paramètres.",
    "The confirmation email is not configured on this service yet.":"La confirmation par e-mail n’est pas encore configurée sur ce service.",
    "This confirmation link is invalid or expired.":"Ce lien de confirmation est invalide ou expiré.",
    "The confirmation email could not be sent. Please try again shortly.":"L’e-mail de confirmation n’a pas pu être envoyé. Réessayez dans quelques instants.",
    "Confirm my email address":"Confirmer mon adresse e-mail",
    "Confirmez votre adresse e-mail — ZERILYS":"Confirmez votre adresse e-mail — ZERILYS",
    "YOUR IDENTITY FIELD":"VOTRE ESPACE PROFIL","YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE","Your professional universe.":"Votre univers professionnel.",
    "Not a CV. A living map of what you are, what you can prove, and what you could create next.":"Bien plus qu’un CV : une représentation vivante de vos compétences, de vos réalisations et de vos prochaines ambitions.",
    "One space. Your whole potential.":"Un espace. Tout votre potentiel.","YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE","Focus mode":"Mode concentration","Explore field":"Explorer l’univers",
    "Connections":"Relations","Share identity":"Partager mon profil","Data & privacy":"Données et confidentialité","Share beta feedback":"Donner mon avis sur la bêta",
    "IDENTITY CONSOLE":"ESPACE PROFIL","YOUR CORE SIGNAL":"VOTRE PROFIL","Make your capabilities visible.":"Mettez vos compétences en valeur.","Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez les dimensions de votre profil : compétences, réalisations, parcours et aspirations.",
    "CAPABILITY FIELD":"MES COMPÉTENCES","What can you actually do?":"Ce que vous savez faire","PROOF LAYER":"MES RÉALISATIONS","Show the work behind the claim.":"Illustrez vos compétences par des réalisations concrètes.","TRAJECTORY":"MON PARCOURS","Where have you been — where next?":"Votre expérience et vos prochaines étapes","INTENT FIELD":"MES ASPIRATIONS","What do you want to make possible?":"Ce que vous souhaitez construire","MEMBER NETWORK":"LE RÉSEAU","Discover the people around your orbit.":"Découvrez les professionnels qui peuvent enrichir votre réseau.","OPPORTUNITY CONSTELLATION":"MES OPPORTUNITÉS","What is orbiting your next move?":"Les opportunités qui correspondent à vos ambitions","IMPACT SIGNAL":"MON IMPACT","Make contribution visible.":"Rendez votre contribution visible.",
    "YOUR CAPABILITIES":"VOS COMPÉTENCES","Add skills to activate your field":"Ajoutez des compétences pour enrichir votre profil","YOUR PROFESSIONAL UNIVERSE":"VOTRE UNIVERS PROFESSIONNEL","PRIVATE TO YOU":"VISIBLE PAR VOUS SEUL","SELECT A SIGNAL OR CAPABILITY TO EXPLORE":"SÉLECTIONNEZ UN ÉLÉMENT POUR EXPLORER VOTRE PROFIL",
    "OPEN TO OPPORTUNITIES":"À L’ÉCOUTE D’OPPORTUNITÉS","SELECTIVE CONNECTIONS":"OUVERT AUX ÉCHANGES CIBLÉS","NOT SEEKING RIGHT NOW":"PAS EN RECHERCHE ACTUELLEMENT","Location not shared":"Lieu non renseigné","Define your professional signal":"Présentez votre activité professionnelle",
    "YOUR CAPABILITIES":"VOS COMPÉTENCES","CAPABILITIES":"COMPÉTENCES","PROOF":"RÉALISATIONS","NETWORK":"RÉSEAU","INTENT":"ASPIRATIONS","OPPORTUNITIES":"OPPORTUNITÉS","IMPACT":"IMPACT",
    "ACTIVATION PATH":"VOTRE PROFIL EN CONSTRUCTION","Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert.","A few signals will make your universe clearer.":"Quelques informations supplémentaires rendront votre profil plus précis.","Preparing your next steps…":"Préparation de votre profil…","complete":"terminé","complete":"terminé",
    "Define your professional identity":"Présentez votre identité professionnelle","A clear headline, location and short professional introduction.":"Un intitulé clair, un lieu et une courte présentation.","Map your capabilities":"Ajoutez vos compétences","Add at least three skills with realistic proficiency levels.":"Ajoutez au moins trois compétences et indiquez votre niveau.","Attach evidence to your skills":"Illustrez vos compétences","Add one concrete project, result or reference.":"Ajoutez un projet, un résultat ou une référence concrète.","Make your intentions visible":"Précisez vos aspirations","Explain what you can contribute or what you are looking for.":"Indiquez ce que vous pouvez apporter ou ce que vous recherchez.","Choose your discoverability":"Choisissez votre visibilité","You remain in control: public discovery is optional.":"Vous gardez le contrôle de la visibilité publique de votre profil.",
    "Identity updated.":"Profil mis à jour.","Your identity has been updated.":"Votre profil a bien été mis à jour.","Your identity has been updated and refreshed.":"Votre profil a bien été enregistré et actualisé.","Your profile has been saved and refreshed.":"Votre profil a bien été enregistré et actualisé.","Add a capability":"Ajouter une compétence","Add evidence":"Ajouter une réalisation","Edit identity":"Modifier mon profil","Save identity ↗":"Enregistrer mon profil ↗","Shape your signal.":"Donnez forme à votre profil.","Professional headline":"Présentation professionnelle","Location":"Localisation","Availability":"Disponibilité","Profile visibility":"Visibilité du profil","About your work":"À propos de votre parcours","What can you bring?":"Ce que vous pouvez apporter","What are you looking for?":"Ce que vous recherchez","Interests and themes":"Centres d’intérêt et domaines","Website (HTTPS only)":"Site web (HTTPS uniquement)",
    "Evidence added as self-attested. It is not independently verified.":"Réalisation ajoutée. Elle est déclarative et n’a pas fait l’objet d’une vérification indépendante.","Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Associez-lui une réalisation pour l’illustrer.","Profile photo updated.":"Photo de profil mise à jour.","Profile photo removed.":"Photo de profil supprimée.","Preparing photo…":"Préparation de la photo…",
    "Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés. Le mode privé le masque aux visiteurs non connectés et aux liens publics.","Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres et via son lien public. Vous pouvez limiter sa visibilité à tout moment."
    ,"Experience & direction":"Expérience et perspectives","What comes next":"La suite de votre parcours","People & proximity":"Rencontres et réseau","Work that matters":"Vos contributions",
    "Add / change photo":"Ajouter ou modifier la photo","Remove photo":"Supprimer la photo","Profile photo":"Photo de profil","Use a clear portrait. JPG, PNG or WebP · up to 500 KB.":"Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum.",
    "Name":"Nom","Open to opportunities":"À l’écoute d’opportunités","Selective":"Ouvert aux échanges ciblés","Not looking right now":"Pas en recherche actuellement",
    "Public — discoverable by other members":"Public — visible par les autres membres","Private — members only; hidden from public links":"Privé — réservé aux membres, masqué des liens publics",
    "What do you know how to do? What are you curious to build?":"Quelles sont vos compétences et qu’aimeriez-vous développer ?",
    "Separate items with commas":"Séparez les éléments par des virgules","Product strategy, fundraising, engineering":"Stratégie produit, financement, ingénierie","A technical co-founder, climate projects, mentorship":"Un associé technique, des projets à impact, du mentorat",
    "Climate, education, open source, health":"Climat, éducation, logiciels libres, santé","Add a skill, e.g. Product strategy":"Ajouter une compétence, ex. stratégie produit",
    "Practitioner":"Pratique courante","Learning":"En apprentissage","Advanced":"Avancé","Expert":"Expert","Add":"Ajouter","Evidence of your work":"Vos réalisations",
    "Project, credential or achievement":"Projet, certification ou réussite","https:// link (optional)":"Lien https:// (facultatif)","Connect to a capability (optional)":"Associer à une compétence (facultatif)",
    "What did you contribute or demonstrate?":"Quelle a été votre contribution ou qu’avez-vous démontré ?",
    "Experience & direction":"Expérience et perspectives","What comes next":"La suite de votre parcours","People & proximity":"Rencontres et réseau","Work that matters":"Vos contributions",
    "The network is taking shape. Be among the first to create a profile.":"Le réseau se construit. Faites partie des premiers à créer votre profil.",
    "Building their next chapter":"Prépare la suite de son parcours","Location not shared":"Lieu non renseigné","Profile in progress":"Profil en cours de création","Discover this identity":"Découvrir ce profil","Explore ↗":"Découvrir ↗","Connect with intent":"Proposer une mise en relation",
    "Searching the member network…":"Recherche dans le réseau…","No matching profiles. Try another name, skill or location.":"Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu.",
    "Load next profiles ↓":"Afficher les profils suivants ↓","Loading…":"Chargement…","Loading member profiles…":"Chargement des profils…",
    "Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.":"Votre parcours se construit. Présentez votre expérience, les défis relevés et les directions que vous souhaitez explorer.",
    "Not defined yet":"À préciser","WHAT I CAN BRING":"CE QUE JE PEUX APPORTER","WHAT I AM LOOKING FOR":"CE QUE JE RECHERCHE",
    "Level:":"Niveau :","self-declared":"déclarée","verified":"vérifiée","evidence record(s)":"réalisation(s) associée(s)","linked evidence record":"réalisation associée","Link evidence ↗":"Associer une réalisation ↗",
    "Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés. Le mode privé le masque aux visiteurs non connectés et aux liens publics.",
    "Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres et via son lien public. Vous pouvez limiter sa visibilité à tout moment."

    ,"THE GLOBAL NETWORK":"AU-DELÀ DU CV."
    ,"YOUR IDENTITY FIELD":"VOTRE ESPACE IDENTITÉ"
    ,"YOUR IDENTITY FIELD · LIVE":"VOTRE ESPACE IDENTITÉ · EN DIRECT"
    ,"YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE"
    ,"One space. Your whole potential.":"Un espace. Tout votre potentiel."
    ,"Your professional universe.":"Votre univers professionnel."
    ,"Not a CV. A living map of what you are, what you can prove, and what you could create next.":"Bien plus qu’un CV : une représentation vivante de votre identité, de vos réalisations et de vos prochaines ambitions."
    ,"Focus mode":"Mode focus"
    ,"Connections":"Relations"
    ,"Share identity":"Partager mon profil"
    ,"Data & privacy":"Données et confidentialité"
    ,"Share beta feedback":"Donner mon avis"
    ,"CAPABILITIES":"COMPÉTENCES"
    ,"PROOF":"RÉALISATIONS"
    ,"TRAJECTORY":"PARCOURS"
    ,"INTENT":"ASPIRATIONS"
    ,"NETWORK":"RÉSEAU"
    ,"IMPACT":"CONTRIBUTIONS"
    ,"OPPORTUNITIES":"OPPORTUNITÉS"
    ,"Experience & direction":"Expérience et perspectives"
    ,"What comes next":"Vos prochaines étapes"
    ,"People & proximity":"Rencontres et réseau"
    ,"Work that matters":"Vos contributions"
    ,"SELECT A SIGNAL OR CAPABILITY TO EXPLORE":"SÉLECTIONNEZ UN ÉLÉMENT POUR L’EXPLORER"
    ,"IDENTITY CONSOLE":"ESPACE IDENTITÉ"
    ,"YOUR CORE SIGNAL":"VOTRE PROFIL"
    ,"Make your capabilities visible.":"Mettez vos compétences en valeur."
    ,"Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez les dimensions de votre profil. Chaque élément révèle vos compétences, vos réalisations ou vos aspirations."
    ,"PRIVATE TO YOU":"VISIBLE PAR VOUS SEUL"
    ,"PROFILE COMPLETION":"PROFIL COMPLÉTÉ"
    ,"YOUR UNIVERSE":"VOTRE UNIVERS"
    ,"Every element enriches your professional identity.":"Chaque information enrichit votre identité professionnelle."
    ,"Edit my profile":"Modifier mon profil"
    ,"Complete my profile":"Compléter mon profil"
    ,"IDENTITY CONFIGURATION":"PERSONNALISATION DU PROFIL"
    ,"Shape your signal.":"Construisez votre identité."
    ,"Profile photo":"Photo de profil"
    ,"Use a clear portrait. JPG, PNG or WebP · up to 500 KB.":"Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum."
    ,"Add / change photo":"Ajouter / remplacer la photo"
    ,"Remove photo":"Supprimer la photo"
    ,"Name":"Nom"
    ,"Professional headline":"Présentation professionnelle"
    ,"Location":"Lieu"
    ,"Availability":"Disponibilité"
    ,"Open to opportunities":"À l’écoute d’opportunités"
    ,"Selective":"Ouvert à certaines opportunités"
    ,"Not looking right now":"Pas de recherche actuellement"
    ,"Profile visibility":"Visibilité du profil"
    ,"Public — discoverable by other members":"Public — visible par les autres membres"
    ,"Private — members only; hidden from public links":"Réservé aux membres, absent des liens publics"
    ,"About your work":"À propos de votre parcours"
    ,"What do you know how to do? What are you curious to build?":"Que savez-vous faire ? Quels projets souhaitez-vous développer ?"
    ,"What can you bring?":"Ce que vous pouvez apporter"
    ,"What are you looking for?":"Ce que vous recherchez"
    ,"Separate items with commas":"Séparez les éléments par des virgules"
    ,"Interests and themes":"Centres d’intérêt et domaines"
    ,"Website (HTTPS only)":"Site web (HTTPS uniquement)"
    ,"Save identity":"Enregistrer mon profil"
    ,"Capabilities":"Compétences"
    ,"Add a skill, e.g. Product strategy":"Ajouter une compétence, ex. stratégie produit"
    ,"Practitioner":"Pratique confirmée"
    ,"Learning":"En apprentissage"
    ,"Advanced":"Avancé"
    ,"Expert":"Expert"
    ,"Add":"Ajouter"
    ,"Evidence of your work":"Réalisations et expériences"
    ,"Project, credential or achievement":"Projet, certification ou réalisation"
    ,"https:// link (optional)":"Lien https:// (facultatif)"
    ,"Connect to a capability (optional)":"Associer à une compétence (facultatif)"
    ,"What did you contribute or demonstrate?":"Quelle a été votre contribution ou qu’avez-vous démontré ?"
    ,"Link evidence":"Associer une réalisation"
    ,"evidence":"réalisation(s)"
    ,"signal":"élément"
    ,"signals":"éléments"
    ,"records":"réalisations"
    ,"OPEN TO OPPORTUNITIES":"À L’ÉCOUTE D’OPPORTUNITÉS"
    ,"SELECTIVE CONNECTIONS":"OUVERT AUX RENCONTRES CIBLÉES"
    ,"NOT SEEKING RIGHT NOW":"PAS DE RECHERCHE ACTUELLEMENT"
    ,"Add the capabilities you want to be known for.":"Ajoutez les compétences que vous souhaitez mettre en avant."
    ,"Add projects, credentials or work that demonstrates your capabilities.":"Ajoutez des projets, certifications ou réalisations qui illustrent vos compétences."
    ,"Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Associez-lui une réalisation pour la valoriser."
    ,"Profile photo updated.":"Photo de profil mise à jour."
    ,"Profile photo removed.":"Photo de profil supprimée."
    ,"Preparing photo…":"Préparation de la photo…"
    ,"Photo updated.":"Photo mise à jour."
    ,"Your profile has been saved and refreshed.":"Votre profil a bien été enregistré et actualisé."
    ,"Capability / signal":"Compétence / élément"
    ,"INDEPENDENTLY VERIFIED":"VÉRIFIÉ INDÉPENDAMMENT"
    ,"SELF-DESCRIBED CAPABILITY":"COMPÉTENCE DÉCLARÉE"
    ,"Level:":"Niveau :"
    ,"This capability is part of your living identity.":"Cette compétence fait partie de votre identité professionnelle."
    ,"No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.":"Aucune réalisation associée. Ajoutez un projet, une certification ou un exemple de travail pour illustrer cette compétence."
    ,"Link evidence ↗":"Associer une réalisation ↗"
    ,"Evidence submitted for independent review.":"Réalisation transmise pour vérification indépendante."
    ,"Evidence added as self-attested. It is not independently verified.":"Réalisation ajoutée sur déclaration. Elle n’a pas fait l’objet d’une vérification indépendante."
    ,"Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés. Le mode privé le masque aux visiteurs non connectés et aux liens publics."
    ,"Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres et via son lien public. Vous pouvez limiter sa visibilité à tout moment."
    ,"Le parcours de création":"Votre profil en quelques étapes"
    ,"Create your identity":"Créer mon profil"
    ,"Welcome back":"Ravi de vous retrouver"
    ,"Join a network built around what you can do.":"Rejoignez un réseau qui valorise vos compétences et vos réalisations."
    ,"Continue building what comes next.":"Poursuivez la construction de votre parcours professionnel."
    ,"Create account ↗":"Créer mon compte ↗"
    ,"Log in ↗":"Se connecter ↗"
    ,"Already a member? Log in":"Déjà membre ? Se connecter"
    ,"New to ZERILYS? Create an identity":"Nouveau sur ZERILYS ? Créer un profil"
    ,"My profile":"Mon profil"
    ,"Open your candidate profile":"Ouvrir mon profil professionnel"
    ,"Open my candidate profile":"Ouvrir mon profil professionnel"
    ,"The network is taking shape. Be among the first to create a profile.":"Le réseau se construit. Soyez parmi les premiers à créer votre profil."
    ,"Building their next chapter":"Prépare la suite de son parcours"
    ,"Location not shared":"Lieu non communiqué"
    ,"evidence item":"réalisation"
    ,"evidence items":"réalisations"
    ,"Profile in progress":"Profil en cours de création"
    ,"COMPLEMENTARITY SIGNAL":"POINTS DE COMPLÉMENTARITÉ"
    ,"connection potential":"potentiel de collaboration"
    ,"Discover this identity":"Découvrir ce profil"
    ,"Explore ↗":"Explorer ↗"
    ,"Connect with intent":"Proposer une mise en relation"
    ,"The network is temporarily unavailable.":"Le réseau est momentanément indisponible."
    ,"Searching the member network…":"Recherche dans le réseau…"
    ,"No matching profiles. Try another name, skill or location.":"Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu."
    ,"Professional member":"Membre du réseau professionnel"
    ,"profiles":"profils"
    ,"Loading…":"Chargement…"
    ,"Load":"Afficher"
    ,"more profiles ↓":"profils supplémentaires ↓"
    ,"Load next profiles ↓":"Afficher les profils suivants ↓"
    ,"Unable to load more profiles.":"Impossible de charger davantage de profils."
    ,"The member network is temporarily unavailable.":"Le réseau des membres est momentanément indisponible."
    ,"Your name":"Votre nom"
    ,"Add a professional headline":"Ajoutez un intitulé professionnel"
    ,"Location not specified":"Localisation non renseignée"
    ,"Save identity ↗":"Enregistrer mon profil ↗"
    ,"Add evidence":"Ajouter une réalisation"
    ,"Submit for review ↗":"Transmettre pour vérification ↗"
    ,"Add":"Ajouter"
    ,"Capabilities":"Compétences"
    ,"Evidence of your work":"Réalisations et preuves"
    ,"Profile visibility":"Visibilité du profil"
    ,"Availability":"Disponibilité"
    ,"About your work":"À propos de votre activité"
    ,"Website (HTTPS only)":"Site internet (HTTPS uniquement)"
    ,"Professional headline":"Intitulé professionnel"
    ,"Interests and themes":"Centres d’intérêt et domaines"
    ,"What can you bring?":"Que pouvez-vous apporter ?"
    ,"What are you looking for?":"Que recherchez-vous ?"
    ,"Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace de compétences est encore vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez-leur des réalisations."
    ,"Define your professional signal":"Définissez votre positionnement professionnel"
    ,"OPEN TO OPPORTUNITIES":"À L’ÉCOUTE D’OPPORTUNITÉS"
    ,"SELECTIVE CONNECTIONS":"OUVERT AUX RENCONTRES CIBLÉES"
    ,"NOT SEEKING RIGHT NOW":"PAS DE RECHERCHE ACTUELLEMENT"
    ,"signals":"repères"
    ,"records":"réalisations"
    ,"YOUR CAPABILITIES":"VOS COMPÉTENCES"
    ,"Add skills to activate your field":"Ajoutez des compétences pour activer votre univers"
    ,"CAPABILITY / SIGNAL":"COMPÉTENCE / REPÈRE"
    ,"Level:":"Niveau :"
    ,"linked evidence record":"réalisation associée"
    ,"linked evidence records":"réalisations associées"
    ,"Make your capabilities visible.":"Mettez vos compétences en lumière."
    ,"Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez votre univers professionnel : chaque repère relie vos compétences à votre expérience, vos réalisations et vos aspirations."
    ,"CAPABILITY FIELD":"CHAMP DES COMPÉTENCES"
    ,"What can you actually do?":"Quelles sont vos compétences concrètes ?"
    ,"verified":"vérifiée"
    ,"self-declared":"déclarée"
    ,"evidence record(s)":"réalisation(s)"
    ,"Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace de compétences est vide. Ajoutez les compétences que vous souhaitez valoriser, puis associez-leur des réalisations."
    ,"Add a capability":"Ajouter une compétence"
    ,"Add evidence":"Ajouter une réalisation"
    ,"Edit identity":"Modifier mon profil"
    ,"PROOF LAYER":"RÉALISATIONS"
    ,"Show the work behind the claim.":"Illustrez vos compétences par des réalisations."
    ,"No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucune réalisation pour le moment. Ajoutez des projets, certifications, publications ou exemples de travaux."
    ,"TRAJECTORY":"PARCOURS PROFESSIONNEL"
    ,"Where have you been — where next?":"D’où venez-vous et quelle suite souhaitez-vous donner à votre parcours ?"
    ,"Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.":"Votre parcours continue de s’écrire. Présentez votre expérience, les défis relevés et les directions que vous souhaitez explorer."
    ,"The profile should reveal a direction, not just a chronology.":"Votre profil doit révéler une direction, pas seulement une chronologie."
    ,"INTENT FIELD":"ASPIRATIONS"
    ,"What do you want to make possible?":"Qu’aimeriez-vous rendre possible ?"
    ,"You are open to new opportunities.":"Vous êtes à l’écoute de nouvelles opportunités."
    ,"You are open to selective connections.":"Vous privilégiez les rencontres ciblées."
    ,"You are not looking for opportunities right now.":"Vous ne recherchez pas d’opportunité actuellement."
    ,"WHAT I CAN BRING":"CE QUE JE PEUX APPORTER"
    ,"WHAT I AM LOOKING FOR":"CE QUE JE RECHERCHE"
    ,"Not defined yet":"À préciser"
    ,"These signals help the network surface complementary people — not rank people by popularity.":"Ces repères permettent de faire émerger des complémentarités, sans classer les personnes selon leur popularité."
    ,"MEMBER NETWORK":"RÉSEAU DES MEMBRES"
    ,"Discover the people around your orbit.":"Découvrez les personnes qui gravitent autour de votre univers."
    ,"Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.":"Chaque membre connecté peut consulter les profils des autres membres. Recherchez par nom, compétence ou lieu pour découvrir leur univers professionnel."
    ,"Search member profiles":"Rechercher des profils de membres"
    ,"Search member profiles":"Rechercher des profils de membres"
    ,"Loading member profiles…":"Chargement des profils…"
    ,"OPPORTUNITY CONSTELLATION":"CONSTELLATION DES OPPORTUNITÉS"
    ,"What is orbiting your next move?":"Quelles opportunités accompagnent votre prochaine étape ?"
    ,"No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité ne correspond encore à votre profil. Les offres publiées par les entreprises apparaîtront ici avec les raisons de leur pertinence."
    ,"No hiring score. No popularity ranking. You remain in control of your visibility.":"Aucune note de recrutement ni classement de popularité. Vous gardez le contrôle de votre visibilité."
    ,"IMPACT SIGNAL":"IMPACT"
    ,"Make contribution visible.":"Donnez de la visibilité à vos contributions."
    ,"Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.":"Mettez en avant vos résultats, pas seulement vos intitulés de poste. Reliez vos projets, vos contributions et des réalisations vérifiables."
    ,"Company identity":"Identité de l’entreprise"
    ,"Company universe":"Univers de l’entreprise"
    ,"Notifications":"Notifications"
    ,"Mark read":"Marquer comme lu"
    ,"You are all caught up.":"Vous êtes à jour."
    ,"No published opportunities at the moment.":"Aucune opportunité publiée pour le moment."
    ,"Express interest ↗":"Manifester mon intérêt ↗"
    ,"Interest sent ✓":"Intérêt envoyé ✓"
    ,"Interest already sent ✓":"Intérêt déjà envoyé ✓"
    ,"Withdraw":"Retirer ma candidature"
    ,"Withdraw your interest? The company will no longer be able to view your application details.":"Retirer votre candidature ? L’entreprise ne pourra plus consulter les informations associées."
    ,"Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué."
    ,"Your opportunity journey will appear here.":"Le suivi de vos démarches apparaîtra ici."
    ,"Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert."
    ,"A few signals will make your universe clearer.":"Quelques repères supplémentaires rendront votre profil plus complet."
    ,"Registration is paused until the beta legal review is complete.":"Les inscriptions sont suspendues dans l’attente de la validation juridique des documents de la bêta."
    ,"Something went wrong":"Une erreur est survenue"
    ,"Unable to load more profiles.":"Impossible de charger davantage de profils."
    ,"Your profile has been saved and refreshed.":"Votre profil a bien été enregistré et actualisé."
    ,"Permanently delete your ZERILYS account and associated operational data?":"Supprimer définitivement votre compte ZERILYS et les données associées ?"
    ,"Your account deletion request has been processed.":"Votre demande de suppression de compte a été prise en compte."
    ,"This company page is not available.":"Cette page entreprise est indisponible."
    ,"Connections are temporarily unavailable.":"Les mises en relation sont momentanément indisponibles."
    ,"Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée."
    ,"Connection response saved.":"Votre réponse à la demande de mise en relation a été enregistrée."
    ,"Accept":"Accepter"
    ,"Decline":"Refuser"
    ,"Connected":"En relation"
    ,"Awaiting response":"En attente de réponse"
    ,"INCOMING SIGNAL":"DEMANDE REÇUE"
    ,"OUTGOING SIGNAL":"DEMANDE ENVOYÉE"
    ,"Company website":"Site internet de l’entreprise"
    ,"Published opportunities":"Opportunités publiées"
    ,"VERIFIED COMPANY":"ENTREPRISE VÉRIFIÉE"
    ,"NOT VERIFIED · OPPORTUNITIES HIDDEN":"NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES"
    ,"Location not specified":"Lieu non précisé"
    ,"This company has not added an overview yet.":"Cette entreprise n’a pas encore renseigné sa présentation."
    ,"No published opportunities yet. Company opportunities will appear here when they are available.":"Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur publication."
    ,"Opportunity signals are temporarily unavailable.":"Les opportunités sont momentanément indisponibles."
    ,"Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité."
    ,"Le parcours de création":"Votre profil en quelques étapes"
    ,"YOUR IDENTITY FIELD":"VOTRE ESPACE IDENTITÉ"
    ,"HUMAN SIGNAL / 001":"SIGNAL HUMAIN / 001"
    ,"Your professional universe.":"Votre univers professionnel."
    ,"Not a CV. A living map of what you are, what you can prove, and what you could create next.":"Bien plus qu’un CV : une cartographie vivante de votre identité, de vos réalisations et de vos prochaines possibilités."
    ,"YOUR PROFESSIONAL IDENTITY":"VOTRE IDENTITÉ PROFESSIONNELLE"
    ,"One space. Your whole potential.":"Un espace. Tout votre potentiel."
    ,"Focus mode":"Mode concentration"
    ,"Connections":"Relations"
    ,"Share identity":"Partager mon profil"
    ,"Data & privacy":"Données et confidentialité"
    ,"Share beta feedback":"Donner mon avis"
    ,"CAPABILITIES":"COMPÉTENCES"
    ,"PROOF":"RÉALISATIONS"
    ,"TRAJECTORY":"PARCOURS"
    ,"INTENT":"ASPIRATIONS"
    ,"NETWORK":"RÉSEAU"
    ,"IMPACT":"IMPACT"
    ,"SELECT A SIGNAL OR CAPABILITY TO EXPLORE":"SÉLECTIONNEZ UN SIGNAL POUR EXPLORER VOTRE UNIVERS"
    ,"IDENTITY CONSOLE":"ESPACE D’EXPLORATION"
    ,"PRIVATE TO YOU":"VISIBLE PAR VOUS SEUL"
    ,"ZERIH / IDENTITY OS":"ZERIH / IDENTITÉ NUMÉRIQUE"
    ,"YOUR CORE SIGNAL":"VOTRE IDENTITÉ EN UN COUP D’ŒIL"
    ,"Make your capabilities visible.":"Donnez de la visibilité à vos compétences."
    ,"Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.":"Explorez les différentes dimensions de votre profil : compétences, réalisations, parcours et aspirations."
    ,"Your name":"Votre nom"
    ,"Your professional signal":"Votre identité professionnelle"
    ,"Lieu non renseigné":"Lieu non renseigné"
    ,"OPEN TO OPPORTUNITIES":"OUVERT AUX OPPORTUNITÉS"
    ,"SELECTIVE CONNECTIONS":"OUVERT AUX ÉCHANGES CIBLÉS"
    ,"NOT SEEKING RIGHT NOW":"PAS EN RECHERCHE ACTUELLEMENT"
    ,"signals":"signaux"
    ,"records":"réalisations"
    ,"Experience & direction":"Expérience et direction"
    ,"What comes next":"Et maintenant ?"
    ,"People & proximity":"Rencontres et proximité"
    ,"Work that matters":"Contributions et impact"
    ,"PROFILE COMPLETED":"PROFIL COMPLÉTÉ"
    ,"YOUR UNIVERSE":"VOTRE UNIVERS"
    ,"Each element enriches your professional identity.":"Chaque élément enrichit votre identité professionnelle."
    ,"Edit my profile":"Modifier mon profil"
    ,"Complete my profile":"Compléter mon profil"
    ,"Shape your signal.":"Façonnez votre identité."
    ,"Activate your capabilities.":"Mettez vos compétences en valeur."
    ,"Show the work behind your claims.":"Illustrez vos compétences par vos réalisations."
    ,"Tell the story of your trajectory.":"Racontez votre parcours."
    ,"Define what comes next.":"Définissez vos prochaines aspirations."
    ,"Make your contribution visible.":"Donnez de la visibilité à vos contributions."
    ,"Profile photo":"Photo de profil"
    ,"Use a clear portrait. JPG, PNG or WebP · up to 500 KB.":"Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum."
    ,"Add / change photo":"Ajouter / modifier la photo"
    ,"Remove photo":"Supprimer la photo"
    ,"Name":"Nom"
    ,"Professional headline":"Intitulé professionnel"
    ,"Location":"Localisation"
    ,"Availability":"Disponibilité"
    ,"Open to opportunities":"Ouvert aux opportunités"
    ,"Selective":"Ouvert aux échanges ciblés"
    ,"Not looking right now":"Pas en recherche actuellement"
    ,"Profile visibility":"Visibilité du profil"
    ,"Public — discoverable by other members":"Public — visible par les autres membres"
    ,"Private — members only; hidden from public links":"Privé — réservé aux membres, absent des liens publics"
    ,"About your work":"À propos de votre activité"
    ,"What can you bring?":"Que pouvez-vous apporter ?"
    ,"Separate items with commas":"Séparez les éléments par des virgules"
    ,"What are you looking for?":"Que recherchez-vous ?"
    ,"Interests and themes":"Centres d’intérêt et domaines"
    ,"Website (HTTPS only)":"Site internet (HTTPS uniquement)"
    ,"Save identity":"Enregistrer mon profil"
    ,"Capabilities":"Compétences"
    ,"Add a skill, e.g. Product strategy":"Ajouter une compétence, ex. stratégie produit"
    ,"Practitioner":"Opérationnel"
    ,"Learning":"En apprentissage"
    ,"Advanced":"Avancé"
    ,"Expert":"Expert"
    ,"Add":"Ajouter"
    ,"Evidence of your work":"Réalisations et preuves"
    ,"Project, credential or achievement":"Projet, certification ou réussite"
    ,"https:// link (optional)":"Lien https:// (facultatif)"
    ,"Connect to a capability (optional)":"Associer à une compétence (facultatif)"
    ,"What did you contribute or demonstrate?":"Quelle a été votre contribution ou votre réalisation ?"
    ,"Your profile is visible to signed-in ZERILYS members. Private mode keeps it out of public links and anonymous discovery.":"Votre profil est visible par les membres connectés de ZERILYS. Le mode privé le masque des liens publics et de la découverte anonyme."
    ,"Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.":"Votre profil est visible par les membres de ZERILYS et via son lien public. Vous pouvez limiter sa découverte anonyme à tout moment."
    ,"A few signals will make your universe clearer.":"Quelques informations supplémentaires rendront votre profil plus complet."
    ,"Your professional universe is ready to be explored.":"Votre univers professionnel est prêt à être découvert."
    ,"Define your professional identity":"Présentez votre identité professionnelle"
    ,"A clear headline, location and short professional introduction.":"Un intitulé clair, votre localisation et une courte présentation."
    ,"Map your capabilities":"Cartographiez vos compétences"
    ,"Add at least three skills with realistic proficiency levels.":"Ajoutez au moins trois compétences et indiquez votre niveau."
    ,"Attach evidence to your skills":"Associez des réalisations à vos compétences"
    ,"Add one concrete project, result or reference.":"Ajoutez un projet concret, un résultat ou une référence."
    ,"Make your intentions visible":"Précisez vos aspirations"
    ,"Explain what you can contribute or what you are looking for.":"Expliquez ce que vous pouvez apporter ou ce que vous recherchez."
    ,"Choose your discoverability":"Choisissez votre visibilité"
    ,"You remain in control: public discovery is optional.":"Vous gardez le contrôle : la visibilité publique reste facultative."
    ,"complete":"terminés"
    ,"Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace de compétences est encore vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez-leur des réalisations."
    ,"What can you actually do?":"Que savez-vous concrètement faire ?"
    ,"Show the work behind the claim.":"Montrez ce qui étaye vos compétences."
    ,"Where have you been — where next?":"D’où venez-vous et où souhaitez-vous aller ?"
    ,"What do you want to make possible?":"Que souhaitez-vous rendre possible ?"
    ,"Discover the people around your orbit.":"Découvrez les personnes qui gravitent autour de vos projets."
    ,"What is orbiting your next move?":"Quelles opportunités peuvent accompagner votre prochaine étape ?"
    ,"Make contribution visible.":"Rendez vos contributions visibles."
    ,"Add a capability":"Ajouter une compétence"
    ,"Add evidence":"Ajouter une réalisation"
    ,"Edit identity":"Modifier mon profil"
    ,"No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucune réalisation n’a encore été ajoutée. Projets, certifications, publications et exemples de travaux rendent vos compétences concrètes."
    ,"No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.":"Aucune réalisation associée pour le moment. Ajoutez un projet, une certification ou un exemple de travail."
    ,"Link evidence":"Associer une réalisation"
    ,"No matching profiles. Try another name, skill or location.":"Aucun profil correspondant. Essayez un autre nom, une compétence ou une ville."
    ,"Searching the member network…":"Recherche dans le réseau…"
    ,"Search members, skills or places":"Rechercher un membre, une compétence ou un lieu"
    ,"Search":"Rechercher"
    ,"Loading member profiles…":"Chargement des profils…"
    ,"Loading…":"Chargement…"
    ,"Load next profiles ↓":"Afficher les profils suivants ↓"
    ,"Your profile has been saved and updated.":"Votre profil a bien été enregistré et actualisé."
    ,"Profile photo updated.":"Photo de profil mise à jour."
    ,"Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Associez-lui une réalisation pour renforcer votre profil."
    ,"Evidence added as self-attested. It is not independently verified.":"Réalisation ajoutée comme déclarée par vos soins. Elle n’a pas fait l’objet d’une vérification indépendante."
    ,"Your identity at a glance.":"Votre identité en un coup d’œil."
    ,"WHAT I CAN BRING":"CE QUE JE PEUX APPORTER"
    ,"WHAT I AM LOOKING FOR":"CE QUE JE RECHERCHE"
    ,"INTERESTS":"CENTRES D’INTÉRÊT"
    ,"WEBSITE":"SITE INTERNET"
    ,"Not defined yet":"À préciser"
    ,"Not added yet":"Non renseigné"
    ,"Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.":"Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension."
    ,"Add a short introduction to explain your professional background, strengths and the direction you want to take.":"Ajoutez une courte présentation de votre parcours, de vos points forts et de la direction que vous souhaitez prendre."
    ,"CAPABILITY FIELD":"CHAMP DES COMPÉTENCES"
    ,"PROOF LAYER":"ESPACE DES RÉALISATIONS"
    ,"INTENT FIELD":"ESPACE DES ASPIRATIONS"
    ,"MEMBER NETWORK":"RÉSEAU DES MEMBRES"
    ,"IMPACT SIGNAL":"SIGNAL D’IMPACT"
    ,"OPPORTUNITY CONSTELLATION":"CONSTELLATION DES OPPORTUNITÉS"
    ,"Level:":"Niveau :"
    ,"This capability is part of your living identity.":"Cette compétence fait partie intégrante de votre identité professionnelle."
    ,"linked evidence record":"réalisation associée"
    ,"linked evidence records":"réalisations associées"
    ,"No evidence has been linked publicly to this capability yet.":"Aucune réalisation publique n’est encore associée à cette compétence."
    ,"The profile should reveal a direction, not just a chronology.":"Votre profil doit révéler une direction, et pas seulement une chronologie."
    ,"Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.":"Votre histoire professionnelle s’écrit encore. Présentez votre activité, les défis relevés et les directions que vous souhaitez explorer."
    ,"You are open to new opportunities.":"Vous êtes ouvert aux nouvelles opportunités."
    ,"You are open to selective connections.":"Vous privilégiez les échanges ciblés."
    ,"You are not looking for opportunities right now.":"Vous ne recherchez pas d’opportunités pour le moment."
    ,"These signals help the network surface complementary people — not rank people by popularity.":"Ces informations permettent au réseau de faire émerger des complémentarités, sans classement fondé sur la popularité."
    ,"Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.":"Chaque membre connecté peut explorer les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel."
    ,"Explore this opportunity and inspect its requirements.":"Découvrez cette opportunité et consultez les compétences recherchées."
    ,"No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.":"Aucune opportunité n’est encore associée à votre profil. Lorsque les entreprises publieront leurs offres, les opportunités pertinentes apparaîtront ici avec les raisons de leur correspondance avec vos compétences et vos aspirations."
    ,"No hiring score. No popularity ranking. You remain in control of your visibility.":"Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité."
    ,"Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.":"Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera vos projets, vos contributions et des réalisations pouvant être examinées indépendamment."
    ,"Search member profiles":"Rechercher des profils"
    ,"Search ↗":"Rechercher ↗"
    ,"Link evidence ↗":"Associer une réalisation ↗"
    ,"Add a capability ↗":"Ajouter une compétence ↗"
    ,"Add evidence ↗":"Ajouter une réalisation ↗"
    ,"Edit identity ↗":"Modifier mon profil ↗"
    ,"Express interest ↗":"Manifester mon intérêt ↗"
    ,"Interest sent ✓":"Intérêt envoyé ✓"
    ,"Capability added. Add evidence to strengthen its signal.":"Compétence ajoutée. Associez-lui une réalisation pour renforcer votre profil."
    ,"Evidence submitted for independent review.":"Réalisation transmise pour vérification indépendante."
    ,"Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité."
    ,"Select a signal or capability to explore":"Sélectionnez un signal ou une compétence pour explorer votre profil"
    ,"YOUR CAPABILITIES":"VOS COMPÉTENCES"
    ,"Add skills to activate your field":"Ajoutez des compétences pour activer votre espace"
    ,"evidence":"réalisations"
    ,"verified":"vérifiée"
    ,"self-declared":"déclarée"
    ,"CAPABILITY / SIGNAL":"COMPÉTENCE / SIGNAL"
    ,"INDEPENDENTLY VERIFIED":"VÉRIFIÉE INDÉPENDAMMENT"
    ,"SELF-DESCRIBED CAPABILITY":"COMPÉTENCE DÉCLARÉE"
    ,"Level":"Niveau"
    ,"advanced":"avancé"
    ,"practitioner":"opérationnel"
    ,"learning":"en apprentissage"
    ,"expert":"expert"
    ,"self attested":"déclarée par le membre"
    ,"pending review":"en attente de vérification"
    ,"verified":"vérifiée"
    ,"rejected":"refusée"
    ,"project":"projet"
    ,"credential":"certification"
    ,"work":"travail"
    ,"publication":"publication"
    ,"profiles":"profils"
    ,"of":"sur"
    ,"Load":"Afficher"
    ,"more profiles":"profils supplémentaires"
    ,"Load next profiles ↓":"Afficher les profils suivants ↓"
    ,"No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.":"Aucune réalisation associée pour le moment. Ajoutez un projet, une certification ou un exemple de travail."
    ,"This capability is part of your living identity.":"Cette compétence fait partie intégrante de votre identité professionnelle."
    ,"Show the work behind the claim.":"Montrez ce qui étaye vos compétences."
    ,"What can you actually do?":"Que savez-vous concrètement faire ?"
    ,"What do you want to make possible?":"Que souhaitez-vous rendre possible ?"
    ,"Discover the people around your orbit.":"Découvrez les personnes qui gravitent autour de vos projets."
    ,"Make contribution visible.":"Rendez vos contributions visibles."
    ,"Make your contribution visible.":"Donnez de la visibilité à vos contributions."
    ,"Add evidence":"Ajouter une réalisation"
    ,"Edit identity":"Modifier mon profil"
    ,"Link evidence ↗":"Associer une réalisation ↗"
    ,"Submit for review ↗":"Transmettre pour vérification ↗"
    ,"Evidence submitted for independent review.":"Réalisation transmise pour vérification indépendante."
    ,"Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité."
    ,"Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué."
    ,'YOUR CORE SIGNAL':'VOTRE IDENTITÉ EN UN COUP D’ŒIL'
    ,'Your identity at a glance.':'Votre identité en un coup d’œil.'
    ,'CAPABILITY FIELD':'CHAMP DES COMPÉTENCES'
    ,'PROOF LAYER':'ESPACE DES RÉALISATIONS'
    ,'TRAJECTORY':'PARCOURS PROFESSIONNEL'
    ,'INTENT FIELD':'ESPACE DES ASPIRATIONS'
    ,'MEMBER NETWORK':'RÉSEAU DES MEMBRES'
    ,'OPPORTUNITY CONSTELLATION':'CONSTELLATION DES OPPORTUNITÉS'
    ,'IMPACT SIGNAL':'SIGNAL D’IMPACT'
    ,'What can you actually do?':'Que savez-vous concrètement faire ?'
    ,'Show the work behind the claim.':'Montrez ce qui étaye vos compétences.'
    ,'Where have you been — where next?':'D’où venez-vous et où souhaitez-vous aller ?'
    ,'What do you want to make possible?':'Que souhaitez-vous rendre possible ?'
    ,'Discover the people around your orbit.':'Découvrez les personnes qui gravitent autour de vos projets.'
    ,'What is orbiting your next move?':'Quelles opportunités peuvent accompagner votre prochaine étape ?'
    ,'Make contribution visible.':'Rendez vos contributions visibles.'
    ,'Add a short introduction to explain your professional background, strengths and the direction you want to take.':'Présentez votre parcours, vos points forts et la direction que vous souhaitez prendre.'
    ,'WHAT I CAN BRING':'CE QUE JE PEUX APPORTER'
    ,'WHAT I AM LOOKING FOR':'CE QUE JE RECHERCHE'
    ,'INTERESTS':'CENTRES D’INTÉRÊT'
    ,'WEBSITE':'SITE INTERNET'
    ,'Not defined yet':'À préciser'
    ,'Not added yet':'Non renseigné'
    ,'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.':'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.'
    ,'verified':'vérifiée'
    ,'self-declared':'déclarée'
    ,'evidence record(s)':'réalisation(s) associée(s)'
    ,'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.':'Votre espace de compétences est encore vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez-leur des réalisations.'
    ,'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.':'Aucune réalisation n’a encore été ajoutée. Projets, certifications, publications et exemples de travaux rendent vos compétences concrètes.'
    ,'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.':'Votre histoire professionnelle s’écrit encore. Présentez votre activité, les défis relevés et les directions que vous souhaitez explorer.'
    ,'The profile should reveal a direction, not just a chronology.':'Votre profil doit révéler une direction, et pas seulement une chronologie.'
    ,'You are open to new opportunities.':'Vous êtes ouvert aux nouvelles opportunités.'
    ,'You are open to selective connections.':'Vous privilégiez les échanges ciblés.'
    ,'You are not looking for opportunities right now.':'Vous ne recherchez pas d’opportunités pour le moment.'
    ,'These signals help the network surface complementary people — not rank people by popularity.':'Ces informations permettent au réseau de faire émerger des complémentarités, sans classement fondé sur la popularité.'
    ,'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.':'Chaque membre connecté peut explorer les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.'
    ,'Search members, skills or places':'Rechercher un membre, une compétence ou un lieu'
    ,'Search member profiles':'Rechercher des profils'
    ,'Search ↗':'Rechercher ↗'
    ,'Loading member profiles…':'Chargement des profils…'
    ,'No matching profiles. Try another name, skill or location.':'Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu.'
    ,'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.':'Aucune opportunité n’est encore associée à votre profil. Les offres pertinentes apparaîtront ici avec les raisons de leur correspondance avec vos compétences et vos aspirations.'
    ,'No hiring score. No popularity ranking. You remain in control of your visibility.':'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.'
    ,'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.':'Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera vos projets, vos contributions et des réalisations vérifiables.'
    ,'Shape your signal.':'Façonnez votre identité professionnelle.'
    ,'Activate your capabilities.':'Mettez vos compétences en valeur.'
    ,'Show the work behind your claims.':'Donnez à voir vos réalisations.'
    ,'Tell the story of your trajectory.':'Racontez votre parcours.'
    ,'Define what comes next.':'Précisez vos prochaines aspirations.'
    ,'Make your contribution visible.':'Mettez vos contributions en lumière.'
    ,'Profile photo':'Photo de profil'
    ,'Use a clear portrait. JPG, PNG or WebP · up to 500 KB.':'Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum.'
    ,'Add / change photo':'Ajouter ou modifier la photo'
    ,'Remove photo':'Supprimer la photo'
    ,'Name':'Nom'
    ,'Professional headline':'Intitulé professionnel'
    ,'Location':'Lieu'
    ,'Availability':'Disponibilité'
    ,'Open to opportunities':'Ouvert aux opportunités'
    ,'Selective':'Échanges ciblés'
    ,'Not looking right now':'Pas en recherche actuellement'
    ,'Profile visibility':'Visibilité du profil'
    ,'Public — discoverable by other members':'Public — visible par les autres membres'
    ,'Private — members only; hidden from public links':'Privé — réservé aux membres, absent des liens publics'
    ,'About your work':'À propos de votre activité'
    ,'What do you know how to do? What are you curious to build?':'Que savez-vous faire ? Quels projets souhaitez-vous construire ?'
    ,'What can you bring?':'Ce que vous pouvez apporter'
    ,'Separate items with commas':'Séparez les éléments par des virgules'
    ,'What are you looking for?':'Ce que vous recherchez'
    ,'Interests and themes':'Centres d’intérêt et thématiques'
    ,'Website (HTTPS only)':'Site internet (HTTPS uniquement)'
    ,'Save identity ↗':'Enregistrer mon profil ↗'
    ,'Capabilities':'Compétences'
    ,'Add a skill, e.g. Product strategy':'Ajouter une compétence, ex. stratégie produit'
    ,'Practitioner':'Opérationnel'
    ,'Learning':'En apprentissage'
    ,'Advanced':'Avancé'
    ,'Expert':'Expert'
    ,'Add':'Ajouter'
    ,'Evidence of your work':'Réalisations et preuves de votre travail'
    ,'Project, credential or achievement':'Projet, certification ou réalisation'
    ,'https:// link (optional)':'Lien https:// (facultatif)'
    ,'Connect to a capability (optional)':'Associer à une compétence (facultatif)'
    ,'What did you contribute or demonstrate?':'Quelle a été votre contribution ou qu’avez-vous démontré ?'
    ,'Add evidence':'Ajouter une réalisation'
    ,'Identity configuration':'Configuration du profil'
    ,'Your professional universe.':'Votre univers professionnel.'
    ,'Not a CV. A living map of what you are, what you can prove, and what you could create next.':'Bien plus qu’un CV : une cartographie vivante de vos compétences, de vos réalisations et de vos prochaines possibilités.'
    ,'Focus mode':'Mode concentration'
    ,'Connections':'Relations'
    ,'Share identity':'Partager mon profil'
    ,'Data & privacy':'Données et confidentialité'
    ,'Share beta feedback':'Donner mon avis sur la bêta'
    ,'YOUR IDENTITY FIELD':'VOTRE ESPACE IDENTITÉ'
    ,'YOUR PROFESSIONAL IDENTITY':'VOTRE IDENTITÉ PROFESSIONNELLE'
    ,'One space. Your whole potential.':'Un espace. Tout votre potentiel.'
    ,'SELECT A SIGNAL OR CAPABILITY TO EXPLORE':'SÉLECTIONNEZ UN SIGNAL OU UNE COMPÉTENCE POUR EXPLORER'
    ,'IDENTITY CONSOLE':'ESPACE IDENTITÉ'
    ,'PRIVATE TO YOU':'VISIBLE UNIQUEMENT PAR VOUS'
    ,'IDENTITY CONFIGURATION':'CONFIGURATION DU PROFIL'
    ,'Add or change your profile photo':'Ajouter ou modifier votre photo de profil'
    ,'Open your candidate profile':'Ouvrir mon profil'
    ,'Open my candidate profile':'Ouvrir mon profil'
    ,'Profile in progress':'Profil en cours de création'
    ,'Your activation checklist is temporarily unavailable.':'Votre parcours de complétion est momentanément indisponible.'
    ,'Your professional universe is ready to be explored.':'Votre univers professionnel est prêt à être découvert.'
    ,'A few signals will make your universe clearer.':'Quelques informations supplémentaires donneront plus de relief à votre univers.'
    ,'complete':'terminées'
    ,'of':'sur'
    ,'records':'réalisations'
    ,'signals':'compétences'
    ,'Selective connections':'Échanges ciblés'
    ,'NOT SEEKING RIGHT NOW':'PAS EN RECHERCHE ACTUELLEMENT'
    ,'OPEN TO OPPORTUNITIES':'OUVERT AUX OPPORTUNITÉS'
    ,'SELECTIVE CONNECTIONS':'OUVERT AUX ÉCHANGES CIBLÉS'
    ,'Profile photo updated.':'Photo de profil mise à jour.'
    ,'Profile photo removed.':'Photo de profil supprimée.'
    ,'Your profile has been saved and updated.':'Votre profil a bien été enregistré et actualisé.'
    ,'Capability added. Add evidence to strengthen its signal.':'Compétence ajoutée. Associez-lui une réalisation pour renforcer votre profil.'
    ,'Interest already sent ✓':'Intérêt déjà envoyé ✓'
    ,'Withdraw your interest? The company will no longer be able to view your application details.':'Retirer votre intérêt ? L’entreprise ne pourra plus consulter les détails de votre candidature.'
    ,'Withdraw':'Retirer'
    ,'Opportunity':'Opportunité'
    ,'Company':'Entreprise'
    ,'Updated':'Mis à jour le'
    ,'No interest expressed yet. Your opportunity journey will appear here.':'Vous n’avez pas encore manifesté d’intérêt. Vos démarches apparaîtront ici.'
    ,'ZERILYS / LIVING IDENTITY':'ZERILYS / IDENTITÉ VIVANTE'
    ,'CAPABILITY SIGNAL':'SIGNAL DE COMPÉTENCE'
    ,'Independently verified':'Vérifiée indépendamment'
    ,'Self-described':'Déclarée par le membre'
    ,'No evidence has been linked publicly to this capability yet.':'Aucune réalisation publique n’est encore associée à cette compétence.'
    ,'This identity is still taking shape. Its next signals will appear here.':'Cette identité se construit progressivement. Les prochains signaux apparaîtront ici.'
    ,'HUMAN SIGNAL':'SIGNAL HUMAIN'
    ,'CAPABILITY FIELD':'CHAMP DES COMPÉTENCES'
    ,'Signals will appear here':'Les signaux apparaîtront ici'
    ,'A professional identity is not a list. It is a field of capabilities, proof and possibilities.':'Une identité professionnelle ne se résume pas à une liste. Elle révèle des compétences, des réalisations et des possibilités.'
    ,'capabilities':'compétences'
    ,'evidence':'réalisations'
    ,'evidence records':'réalisations'
    ,'Join to connect ↗':'Rejoindre pour échanger ↗'
    ,'Connect with intent':'Entrer en relation'
    ,'Copy profile link':'Copier le lien du profil'
    ,'Profile link copied.':'Lien du profil copié.'
    ,'Location not shared':'Lieu non communiqué'
    ,'Human potential in motion':'Un potentiel en mouvement'
    ,'Professional member':'Membre du réseau'
    ,'Explore':'Explorer'
    ,'No evidence':'Aucune réalisation'
    ,'Connection request sent.':'Demande de mise en relation envoyée.'
    ,'You are already connected.':'Vous êtes déjà en relation.'
    ,'Connection request':'Demande de mise en relation'
    ,'Why would you like to connect?':'Pourquoi souhaitez-vous entrer en relation ?'
    ,'Send request':'Envoyer la demande'
    ,'Cancel':'Annuler'
    ,'Your message':'Votre message'
    ,'Write a short note about the reason for connecting.':'Expliquez brièvement la raison de votre prise de contact.'
    ,'Profile not found':'Profil introuvable'
    ,'Profile unavailable':'Profil indisponible'
    ,'Only signed-in members can open this profile.':'Seuls les membres connectés peuvent consulter ce profil.'
    ,'Open profile':'Ouvrir le profil'
    ,'Back to network':'Retour au réseau'
    ,'View profile':'Voir le profil'
    ,'Connection pending':'Demande en attente'
    ,'Connected':'En relation'
    ,'Private profile':'Profil privé'
    ,'Public profile':'Profil public'
    ,'You are viewing a member profile.':'Vous consultez le profil d’un membre.'
    ,'Profile shared successfully.':'Profil partagé avec succès.'
    ,'Open to opportunities':'Ouvert aux opportunités'
    ,'Selective connections':'Échanges ciblés'
    ,'Not looking right now':'Pas en recherche actuellement'
    ,'View capabilities':'Voir les compétences'
    ,'View evidence':'Voir les réalisations'
    ,'Your profile is visible to signed-in members.':'Votre profil est visible par les membres connectés.'
    ,'Join ZERILYS to explore the network.':'Rejoignez ZERILYS pour explorer le réseau.'
    ,'No matching profiles. Try another name, skill or location.':'Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu.'
    ,'Building their next chapter':'Prépare la suite de son parcours'
    ,'Profile in progress':'Profil en cours de création'
    ,'COMPLEMENTARITY SIGNAL':'SIGNAL DE COMPLÉMENTARITÉ'
    ,'connection potential':'potentiel de connexion'
    ,'Discover this identity':'Découvrir ce profil'
    ,'Explore ↗':'Explorer ↗'
    ,'People & proximity':'Membres et proximité'
    ,'Work that matters':'Des réalisations qui comptent'
    ,'Experience & direction':'Expérience et trajectoire'
    ,'What comes next':'Et maintenant ?'
    ,'No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.':'Aucune réalisation associée pour le moment. Ajoutez un projet, une certification ou un exemple de travail.'
    ,'YOUR CORE SIGNAL':'VOTRE IDENTITÉ'
    ,'Your identity at a glance.':'Votre identité professionnelle en un regard.'
    ,'Add a short introduction to explain your professional background, strengths and the direction you want to take.':'Ajoutez une courte présentation de votre parcours, de vos points forts et de vos aspirations.'
    ,'WHAT I CAN BRING':'CE QUE JE PEUX APPORTER'
    ,'WHAT I AM LOOKING FOR':'CE QUE JE RECHERCHE'
    ,'INTERESTS':'CENTRES D’INTÉRÊT'
    ,'WEBSITE':'SITE INTERNET'
    ,'Not defined yet':'À compléter'
    ,'Not added yet':'Non renseigné'
    ,'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.':'Votre profil évolue avec vos compétences, vos réalisations et vos aspirations. Sélectionnez un signal pour explorer chaque dimension.'
    ,'CAPABILITY FIELD':'CHAMP DES COMPÉTENCES'
    ,'What can you actually do?':'Que savez-vous concrètement faire ?'
    ,'verified':'vérifiée'
    ,'self-declared':'déclarée'
    ,'evidence record(s)':'réalisation(s) associée(s)'
    ,'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.':'Votre espace de compétences est vide. Ajoutez les compétences que vous souhaitez valoriser, puis associez-y des réalisations.'
    ,'PROOF LAYER':'ESPACE DES RÉALISATIONS'
    ,'Show the work behind the claim.':'Montrez ce qui illustre votre expérience.'
    ,'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.':'Aucune réalisation pour le moment. Projets, certifications, publications et exemples de travail rendent vos compétences concrètes.'
    ,'TRAJECTORY':'PARCOURS'
    ,'Where have you been — where next?':'D’où venez-vous et où souhaitez-vous aller ?'
    ,'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.':'Votre parcours continue de s’écrire. Présentez vos expériences, les défis relevés et les directions que vous souhaitez explorer.'
    ,'The profile should reveal a direction, not just a chronology.':'Votre profil doit révéler une trajectoire, pas seulement une chronologie.'
    ,'INTENT FIELD':'ESPACE DES ASPIRATIONS'
    ,'What do you want to make possible?':'Que souhaitez-vous rendre possible ?'
    ,'You are open to new opportunities.':'Vous êtes à l’écoute de nouvelles opportunités.'
    ,'You are open to selective connections.':'Vous privilégiez les mises en relation ciblées.'
    ,'You are not looking for opportunities right now.':'Vous ne recherchez pas d’opportunités actuellement.'
    ,'These signals help the network surface complementary people — not rank people by popularity.':'Ces informations aident le réseau à faire émerger des complémentarités, sans classement fondé sur la popularité.'
    ,'MEMBER NETWORK':'RÉSEAU DE MEMBRES'
    ,'Discover the people around your orbit.':'Découvrez les personnes qui gravitent autour de votre univers.'
    ,'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.':'Chaque membre connecté peut découvrir les profils des autres membres. Recherchez par nom, compétence ou lieu, puis explorez leur univers professionnel.'
    ,'Search members, skills or places':'Rechercher des membres, des compétences ou des lieux'
    ,'Search ↗':'Rechercher ↗'
    ,'Loading member profiles…':'Chargement des profils…'
    ,'OPPORTUNITY CONSTELLATION':'CONSTELLATION DES OPPORTUNITÉS'
    ,'What is orbiting your next move?':'Quelles opportunités accompagnent votre prochaine étape ?'
    ,'Company':'Entreprise'
    ,'Explore this opportunity and inspect its requirements.':'Explorez cette opportunité et consultez ses critères.'
    ,'Express interest ↗':'Manifester mon intérêt ↗'
    ,'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.':'Aucune opportunité ne gravite encore autour de votre profil. Les offres pertinentes apparaîtront ici avec les raisons de leur correspondance avec vos compétences et vos aspirations.'
    ,'No hiring score. No popularity ranking. You remain in control of your visibility.':'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.'
    ,'IMPACT SIGNAL':'SIGNAL D’IMPACT'
    ,'Make contribution visible.':'Rendez vos contributions visibles.'
    ,'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.':'Mettez en avant vos résultats, pas seulement vos intitulés. Cet espace reliera projets, contributions et réalisations vérifiables.'
    ,'Add a capability':'Ajouter une compétence'
    ,'Add evidence':'Ajouter une réalisation'
    ,'Edit identity':'Modifier mon profil'
    ,'Edit identity ↗':'Modifier mon profil ↗'
    ,'Search member profiles':'Rechercher des profils de membres'
    ,'Unable to load more profiles.':'Impossible de charger davantage de profils.'
    ,'Member professional identity':'Identité professionnelle du membre'
    ,'Primary navigation':'Navigation principale'
    ,'Log in':'Se connecter'
    ,'Join ZERILYS':'Rejoindre ZERILYS'
    ,'Notifications':'Notifications'
    ,'Close dialog':'Fermer la fenêtre'
    ,'YOUR NETWORK':'VOTRE RÉSEAU'
    ,'Read':'Lu'
    ,'Mark read':'Marquer comme lu'
    ,'You are all caught up.':'Vous êtes à jour.'
    ,'COMPANY UNIVERSE':'UNIVERS DE L’ENTREPRISE'
    ,'VERIFIED COMPANY':'ENTREPRISE VÉRIFIÉE'
    ,'NOT VERIFIED · OPPORTUNITIES HIDDEN':'NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES'
    ,'Location not specified':'Lieu non renseigné'
    ,'This company has not added an overview yet.':'Cette entreprise n’a pas encore ajouté de présentation.'
    ,'Company website ↗':'Site internet de l’entreprise ↗'
    ,'Published opportunities':'Opportunités publiées'
    ,'No published opportunities at the moment.':'Aucune opportunité publiée pour le moment.'
    ,'This company page is not available.':'Cette page entreprise est indisponible.'
    ,'Connections are temporarily unavailable.':'Les relations sont temporairement indisponibles.'
    ,'Connection response saved.':'Réponse à la demande enregistrée.'
    ,'Interest sent ✓':'Intérêt envoyé ✓'
    ,'Your professional profile has been shared with this company for this opportunity.':'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.'
    ,'Interest sent. The project owner can review your application.':'Votre intérêt a été transmis. Le responsable du projet peut consulter votre candidature.'
    ,'Report sent to the moderation team.':'Votre signalement a été transmis à l’équipe de modération.'
    ,'Member blocked.':'Membre bloqué.'
    ,'Member unblocked.':'Membre débloqué.'
    ,'This identity is not available.':'Ce profil n’est pas disponible.'
    ,'Share is unavailable in this browser.':'Le partage n’est pas disponible dans ce navigateur.'
    ,'Evidence submitted for independent review.':'Votre réalisation a été transmise pour examen indépendant.'
    ,'Your intentional connection request has been sent.':'Votre demande de mise en relation a été envoyée.'
    ,'Connection response saved.':'Votre réponse à la demande a été enregistrée.'
    ,'This company page is not available.':'Cette page entreprise n’est pas disponible.'
    ,'Your interest was withdrawn and access to your profile for this application was revoked.':'Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué.'
    ,'Company workspace unavailable: ':'Espace entreprise indisponible : '
    ,'Offer status updated.':'Le statut de l’opportunité a été mis à jour.'
    ,'Internal note saved.':'La note interne a été enregistrée.'
    ,'Candidate status updated.':'Le statut du candidat a été mis à jour.'
    ,'Team access removed.':'L’accès de ce membre à l’équipe a été retiré.'
    ,'Please provide a review note of at least 20 characters.':'Veuillez saisir une note d’examen d’au moins 20 caractères.'
    ,'Company verified. Its published opportunities are now discoverable.':'Entreprise vérifiée. Ses opportunités publiées sont désormais visibles.'
    ,'Company verification rejected.':'La vérification de l’entreprise a été refusée.'
    ,'Tester feedback updated.':'Le retour du testeur a été mis à jour.'
    ,'Manual invitation tokens copied.':'Les codes d’invitation manuels ont été copiés.'
    ,'Clipboard unavailable. Copy the tokens individually.':'Presse-papiers indisponible. Copiez les codes individuellement.'
    ,'Invitation revoked.':'Invitation révoquée.'
    ,'Report review saved.':'L’examen du signalement a été enregistré.'
    ,'Evidence review saved.':'L’examen de la réalisation a été enregistré.'
    ,'Interest sent. The project owner can review your application.':'Votre intérêt a été transmis. Le responsable du projet peut consulter votre candidature.'
    ,'Your account is ready. Check your email to confirm your address.':'Votre compte est prêt. Consultez votre messagerie pour confirmer votre adresse.'
    ,'Your account is ready, but the confirmation email could not be sent. You can try again from your settings.':'Votre compte est prêt, mais l’e-mail de confirmation n’a pas pu être envoyé. Vous pourrez réessayer depuis vos paramètres.'
    ,'Password updated. Sign in with your new password.':'Mot de passe mis à jour. Connectez-vous avec votre nouveau mot de passe.'
    ,'Your beta consent has been saved.':'Votre consentement à la bêta a été enregistré.'
    ,'A new confirmation link has been sent to your email address.':'Un nouveau lien de confirmation a été envoyé à votre adresse e-mail.'
    ,'Password changed successfully.':'Votre mot de passe a été modifié.'
    ,'Your account deletion request has been processed.':'Votre demande de suppression du compte a été traitée.'
    ,'Company identity updated.':'Les informations de l’entreprise ont été mises à jour.'
    ,'Company verification request submitted.':'La demande de vérification de l’entreprise a été envoyée.'
    ,'Opportunity published. Its match signals are now available to candidates.':'L’opportunité est publiée. Ses critères de correspondance sont désormais visibles des candidats.'
    ,'Choose an image smaller than 15 MB.':'Choisissez une image de moins de 15 Mo.'
    ,'Choose a JPG, PNG or WebP image.':'Choisissez une image au format JPG, PNG ou WebP.'
    ,'Profile photo updated.':'La photo de profil a été mise à jour.'
    ,'Profile photo removed.':'La photo de profil a été supprimée.'
    ,'Capability added. Add evidence to strengthen its signal.':'Compétence ajoutée. Associez-y une réalisation pour étayer votre profil.'
    ,'Evidence added as self-attested. It is not independently verified.':'Réalisation ajoutée sur déclaration. Elle n’a pas fait l’objet d’une vérification indépendante.'
    ,'Your collaboration is live.':'Votre projet collaboratif est publié.'
    ,'Email address confirmed.':'Votre adresse e-mail est confirmée.'
    ,'Unable to load more profiles.':'Impossible de charger davantage de profils.'
    ,'unknown':'inconnu'
    ,'hours':'heures'
    ,'RELEASE':'VERSION'
    ,'STORAGE':'STOCKAGE'
    ,'DATA FILE':'FICHIER DE DONNÉES'
    ,'MEMBERS':'MEMBRES'
    ,'MODERATION QUEUE':'FILE DE MODÉRATION'
    ,'PERSONAL INVITATIONS':'INVITATIONS PERSONNELLES'
    ,'COMPANY VERIFICATION':'VÉRIFICATION DES ENTREPRISES'
    ,'LOCAL BACKUP':'SAUVEGARDE LOCALE'
    ,'Verified':'Vérifiée'
    ,'Checksum mismatch':'Somme de contrôle incorrecte'
    ,'No backup found':'Aucune sauvegarde trouvée'
    ,'Off-site: not configured':'Sauvegarde externe : non configurée'
    ,'DATA INTEGRITY':'INTÉGRITÉ DES DONNÉES'
    ,'PASS':'CONFORME'
    ,'error(s)':'erreur(s)'
    ,'warning(s)':'avertissement(s)'
    ,'COMPANY':'ENTREPRISE'
    ,'Location not provided':'Lieu non renseigné'
    ,'Open company website ↗':'Ouvrir le site de l’entreprise ↗'
    ,'Business email:':'E-mail professionnel :'
    ,'Verify company':'Vérifier l’entreprise'
    ,'Reject request':'Refuser la demande'
    ,'No company verification requests.':'Aucune demande de vérification d’entreprise.'
    ,'Member profile':'Profil membre'
    ,'Reported by':'Signalé par'
    ,'Mark reviewed':'Marquer comme examiné'
    ,'Dismiss':'Ignorer'
    ,'No open reports. The queue is clear.':'Aucun signalement en attente.'
    ,'No description supplied.':'Aucune description fournie.'
    ,'Submitted by':'Transmis par'
    ,'Open submitted source ↗':'Ouvrir la source transmise ↗'
    ,'Verify evidence':'Vérifier la réalisation'
    ,'Reject evidence':'Refuser la réalisation'
    ,'No evidence awaiting review.':'Aucune réalisation en attente d’examen.'
    ,'Beta tester':'Testeur bêta'
    ,'Accept for follow-up':'Accepter pour suivi'
    ,'Not selected':'Non retenu'
    ,'No open tester feedback.':'Aucun retour de testeur en attente.'
    ,'total invitations':'invitations au total'
    ,'registered':'inscrits'
    ,'pending':'en attente'
    ,'expired':'expirées'
    ,'invitations':'invitations'
    ,'expires':'expire le'
    ,'Batch':'Lot'
    ,'revoked':'révoquées'
    ,'No bulk invitation batches yet.':'Aucun lot d’invitations pour le moment.'
    ,'Revoke':'Révoquer'
    ,'No pending personal invitations.':'Aucune invitation personnelle en attente.'
    ,'Invitation email sent to':'E-mail d’invitation envoyé à'
    ,'One use only':'Utilisable une seule fois'
    ,'Invitation created for':'Invitation créée pour'
    ,'Email delivery failed;':'Échec de l’envoi de l’e-mail ;'
    ,'Send this token privately:':'Transmettez ce code de manière confidentielle :'
    ,'manual delivery.':'transmission manuelle.'
    ,'Enter between 1 and 50 email addresses, one per line.':'Saisissez de 1 à 50 adresses e-mail, à raison d’une par ligne.'
    ,'Creating invitations…':'Création des invitations…'
    ,'invitations created':'invitations créées'
    ,'emails sent':'e-mails envoyés'
    ,'tokens for private manual delivery.':'codes à transmettre individuellement.'
    ,'Copy manual tokens ↗':'Copier les codes manuels ↗'
    ,'Manual invitation tokens copied.':'Les codes d’invitation manuels ont été copiés.'
    ,'Clipboard unavailable. Copy the tokens individually.':'Presse-papiers indisponible. Copiez les codes individuellement.'
    ,'Your email address is confirmed.':'Votre adresse e-mail est confirmée.'
    ,'Your email address is not confirmed yet. Check your inbox for the confirmation link.':'Votre adresse e-mail n’est pas encore confirmée. Consultez votre messagerie pour retrouver le lien de confirmation.'
    ,'Email confirmation is not configured on this service yet.':'La confirmation par e-mail n’est pas encore configurée sur ce service.'
    ,'Current beta terms and privacy notice have not been accepted.':'Les conditions de bêta et la notice de confidentialité en vigueur n’ont pas été acceptées.'
    ,'The new passwords do not match.':'Les nouveaux mots de passe ne correspondent pas.'
    ,'Password updated.':'Mot de passe mis à jour.'
    ,'other session(s) were signed out.':'autre(s) session(s) ont été déconnectées.'
    ,'Permanently delete your ZERILYS account and associated operational data?':'Supprimer définitivement votre compte ZERILYS et les données opérationnelles associées ?'
    ,'Your account deletion request has been processed.':'Votre demande de suppression du compte a été traitée.'
    ,'Your beta consent has been saved.':'Votre consentement à la bêta a été enregistré.'
    ,'Your account is ready. Check your email to confirm your address.':'Votre compte est prêt. Consultez votre messagerie pour confirmer votre adresse.'
    ,'Your account is ready, but the confirmation email could not be sent. You can try again from your settings.':'Votre compte est prêt, mais l’e-mail de confirmation n’a pas pu être envoyé. Vous pourrez réessayer depuis vos paramètres.'
    ,'What are you building?':'Quel projet souhaitez-vous construire ?'
    ,'Describe the challenge and the contribution you need (at least 30 characters).':'Décrivez le défi et la contribution recherchée (30 caractères minimum).'
    ,'Skills needed, separated by commas (optional)':'Compétences recherchées, séparées par des virgules (facultatif)'
    ,'Choose an image smaller than 15 MB.':'Choisissez une image de moins de 15 Mo.'
    ,'Choose a JPG, PNG or WebP image.':'Choisissez une image au format JPG, PNG ou WebP.'
    ,'Preparing photo…':'Préparation de la photo…'
    ,'Image dimensions are too large. Choose a smaller photo.':'Les dimensions de l’image sont trop importantes. Choisissez une photo plus petite.'
    ,'Photo too large after compression. Choose a smaller image.':'La photo reste trop volumineuse après compression. Choisissez une image plus petite.'
    ,'Photo updated.':'Photo mise à jour.'
    ,'Photo removed.':'Photo supprimée.'
    ,'Profile photo updated.':'La photo de profil a été mise à jour.'
    ,'Profile photo removed.':'La photo de profil a été supprimée.'
    ,'Capability added. Add evidence to strengthen its signal.':'Compétence ajoutée. Associez-y une réalisation pour étayer votre profil.'
    ,'Evidence added as self-attested. It is not independently verified.':'Réalisation ajoutée sur déclaration. Elle n’a pas fait l’objet d’une vérification indépendante.'
    ,'Your collaboration is live.':'Votre projet collaboratif est publié.'
    ,'The new passwords do not match.':'Les nouveaux mots de passe ne correspondent pas.'
    ,'Sign out every other active session?':'Déconnecter toutes les autres sessions actives ?'
    ,'A new confirmation link has been sent to your email address.':'Un nouveau lien de confirmation a été envoyé à votre adresse e-mail.'
    ,'Your account deletion request has been processed.':'Votre demande de suppression du compte a été traitée.'
    ,'Company identity updated.':'Les informations de l’entreprise ont été mises à jour.'
    ,'Company verification request submitted.':'La demande de vérification de l’entreprise a été envoyée.'
    ,'Opportunity published. Its match signals are now available to candidates.':'L’opportunité est publiée. Ses critères de correspondance sont désormais visibles des candidats.'
    ,'The new passwords do not match.':'Les nouveaux mots de passe ne correspondent pas.'
    ,'Your account deletion request has been processed.':'Votre demande de suppression du compte a été traitée.'
    ,'THE GLOBAL NETWORK':'AU-DELÀ DU CV.'
    ,'YOUR IDENTITY FIELD':'VOTRE ESPACE IDENTITÉ'
    ,'YOUR PROFESSIONAL IDENTITY':'VOTRE IDENTITÉ PROFESSIONNELLE'
    ,'One space. Your whole potential.':'Un espace. Tout votre potentiel.'
    ,'YOUR PROFESSIONAL IDENTITY':'VOTRE IDENTITÉ PROFESSIONNELLE'
    ,'Not a CV. A living map of what you are, what you can prove, and what you could create next.':'Pas un CV. Une cartographie vivante de votre identité, de vos réalisations et de vos projets.'
    ,'Focus mode':'Mode concentration'
    ,'Connections':'Relations'
    ,'Share identity':'Partager mon profil'
    ,'Data & privacy':'Données et confidentialité'
    ,'Share beta feedback':'Donner mon avis sur la bêta'
    ,'YOUR CORE SIGNAL':'VOTRE IDENTITÉ'
    ,'Make your capabilities visible.':'Rendez vos compétences visibles.'
    ,'Explore the orbit around your identity. Every signal connects a claim to context, evidence or intent.':'Explorez votre univers professionnel. Chaque élément relie vos compétences à votre parcours, vos réalisations ou vos aspirations.'
    ,'Explore capabilities ↗':'Explorer mes compétences ↗'
    ,'CAPABILITIES':'COMPÉTENCES'
    ,'PROOF':'RÉALISATIONS'
    ,'TRAJECTORY':'PARCOURS'
    ,'INTENT':'ASPIRATIONS'
    ,'NETWORK':'RÉSEAU'
    ,'OPPORTUNITIES':'OPPORTUNITÉS'
    ,'IMPACT':'IMPACT'
    ,'Experience & direction':'Expérience et orientation'
    ,'What comes next':'La suite de votre parcours'
    ,'People & proximity':'Personnes et proximité'
    ,'Work that matters':'Des réalisations qui comptent'
    ,'SELECT A SIGNAL OR CAPABILITY TO EXPLORE':'SÉLECTIONNEZ UN ÉLÉMENT POUR L’EXPLORER'
    ,'IDENTITY CONSOLE':'ESPACE IDENTITÉ'
    ,'PRIVATE TO YOU':'VISIBLE PAR VOUS SEUL'
    ,'ZERIH / IDENTITY OS':'ZERIH / ESPACE IDENTITÉ'
    ,'OPEN TO OPPORTUNITIES':'À L’ÉCOUTE D’OPPORTUNITÉS'
    ,'PROFILE COMPLETED':'PROFIL COMPLÉTÉ'
    ,'YOUR IDENTITY':'VOTRE IDENTITÉ'
    ,'Your professional universe.':'Votre univers professionnel.'
    ,'Add or change your profile photo':'Ajouter ou modifier votre photo de profil'
    ,'Close dialog':'Fermer la fenêtre'
    ,'Close':'Fermer'
    ,'IDENTITY CONFIGURATION':'CONFIGURATION DE L’IDENTITÉ'
    ,'Shape your signal.':'Donnez forme à votre identité.'
    ,'Profile photo':'Photo de profil'
    ,'Use a clear portrait. JPG, PNG or WebP · up to 500 KB.':'Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum.'
    ,'Add / change photo':'Ajouter / modifier la photo'
    ,'Remove photo':'Supprimer la photo'
    ,'Name':'Nom'
    ,'Professional headline':'Intitulé professionnel'
    ,'Location':'Lieu'
    ,'Availability':'Disponibilité'
    ,'Open to opportunities':'À l’écoute d’opportunités'
    ,'Selective':'À l’écoute de propositions ciblées'
    ,'Not looking right now':'Pas de recherche actuellement'
    ,'Profile visibility':'Visibilité du profil'
    ,'Public — discoverable by other members':'Public — visible par les autres membres'
    ,'Private — members only; hidden from public links':'Privé — réservé aux membres, absent des liens publics'
    ,'About your work':'À propos de votre activité'
    ,'What do you know how to do? What are you curious to build?':'Que savez-vous faire ? Quels projets souhaitez-vous construire ?'
    ,'What can you bring?':'Ce que vous pouvez apporter'
    ,'Separate items with commas':'Séparez les éléments par des virgules'
    ,'What are you looking for?':'Ce que vous recherchez'
    ,'Interests and themes':'Centres d’intérêt et thématiques'
    ,'Website (HTTPS only)':'Site web (HTTPS uniquement)'
    ,'Save identity ↗':'Enregistrer mon profil ↗'
    ,'Capabilities':'Compétences'
    ,'Add a skill, e.g. Product strategy':'Ajouter une compétence, ex. stratégie produit'
    ,'Practitioner':'Pratique confirmée'
    ,'Learning':'En apprentissage'
    ,'Advanced':'Avancé'
    ,'Expert':'Expert'
    ,'Add':'Ajouter'
    ,'Evidence of your work':'Réalisations et justificatifs'
    ,'Project, credential or achievement':'Projet, certification ou réussite'
    ,'Connect to a capability (optional)':'Associer à une compétence (facultatif)'
    ,'What did you contribute or demonstrate?':'Quelle a été votre contribution ou qu’avez-vous démontré ?'
    ,'Add evidence':'Ajouter une réalisation'
    ,'Your connection field.':'Vos relations professionnelles.'
    ,'A CONNECTION WITH INTENT':'UNE RENCONTRE QUI A DU SENS'
    ,'Why should your paths cross?':'Pourquoi vos chemins devraient-ils se croiser ?'
    ,'Write a short, personal reason. The recipient sees your context before deciding.':'Expliquez brièvement votre démarche. Le destinataire disposera de ce contexte avant de répondre.'
    ,'Send intentional connection ↗':'Envoyer une demande motivée ↗'
    ,'No social feed · no personal posts · only professional opportunities':'Pas de fil d’actualité · pas de publications personnelles · des opportunités professionnelles'
    ,'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.':'Votre profil évolue avec vos compétences, vos réalisations et vos aspirations. Sélectionnez un élément pour explorer chaque dimension.'
    ,'My profile':'Mon profil'
    ,'Open your candidate profile':'Ouvrir mon profil professionnel'
    ,'Open my candidate profile':'Ouvrir mon profil professionnel'
    ,'Building their next chapter':'Prépare la suite de son parcours'
    ,'Location not shared':'Lieu non communiqué'
    ,'evidence item':'réalisation'
    ,'evidence items':'réalisations'
    ,'Profile in progress':'Profil en cours de création'
    ,'COMPLEMENTARITY SIGNAL':'POINT DE COMPLÉMENTARITÉ'
    ,'Discover this identity':'Découvrir ce profil'
    ,'Explore ↗':'Découvrir ↗'
    ,'Connect with intent':'Envoyer une demande motivée'
    ,'The network is taking shape. Be among the first to create a profile.':'Le réseau se construit. Soyez parmi les premiers à créer votre profil.'
    ,'The network is temporarily unavailable.':'Le réseau est momentanément indisponible.'
    ,'Searching the member network…':'Recherche dans le réseau…'
    ,'No matching profiles. Try another name, skill or location.':'Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu.'
    ,'Professional member':'Membre du réseau professionnel'
    ,'profiles':'profils'
    ,'Loading…':'Chargement…'
    ,'Load next profiles ↓':'Afficher les profils suivants ↓'
    ,'Unable to load more profiles.':'Impossible de charger davantage de profils.'
    ,'No open collaborations yet. Be the first to start one.':'Aucune collaboration ouverte pour le moment. Soyez le premier à en proposer une.'
    ,'Explore collaboration ↗':'Découvrir la collaboration ↗'
    ,'Collaborations are temporarily unavailable.':'Les collaborations sont momentanément indisponibles.'
    ,'YOUR CAPABILITIES':'VOS COMPÉTENCES'
    ,'Add skills to activate your field':'Ajoutez des compétences pour activer votre constellation'
    ,'linked evidence records':'réalisations associées'
    ,'CAPABILITY / SIGNAL':'COMPÉTENCE / SIGNAL'
    ,'INDEPENDENTLY VERIFIED':'VÉRIFIÉ INDÉPENDAMMENT'
    ,'SELF-DESCRIBED CAPABILITY':'COMPÉTENCE DÉCLARÉE'
    ,'Level:':'Niveau :'
    ,'This capability is part of your living identity.':'Cette compétence fait partie de votre identité professionnelle évolutive.'
    ,'linked evidence record':'réalisation associée'
    ,'No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.':'Aucune réalisation associée. Reliez un projet, une certification ou un exemple de travail pour illustrer cette compétence.'
    ,'Link evidence ↗':'Associer une réalisation ↗',
    'YOUR CORE SIGNAL': 'VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'Your identity at a glance.': 'Votre identité en un coup d’œil.',
    'Add a short introduction to explain your professional background, strengths and the direction you want to take.': 'Ajoutez une courte présentation de votre parcours, de vos points forts et de vos aspirations.',
    'WHAT I CAN BRING': 'CE QUE JE PEUX APPORTER',
    'WHAT I AM LOOKING FOR': 'CE QUE JE RECHERCHE',
    'INTERESTS': 'CENTRES D’INTÉRÊT',
    'WEBSITE': 'SITE WEB',
    'Not defined yet': 'Non renseigné',
    'Not added yet': 'Non ajouté',
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.': 'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.',
    'CAPABILITY FIELD': 'CHAMP DE COMPÉTENCES',
    'What can you actually do?': 'Que savez-vous concrètement faire ?',
    'verified': 'vérifiée',
    'self-declared': 'déclarée',
    'evidence record(s)': 'réalisation(s) associée(s)',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.': 'Votre champ de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez des réalisations pour étayer votre profil.',
    'PROOF LAYER': 'RÉALISATIONS',
    'Show the work behind the claim.': 'Montrez ce qui donne corps à vos compétences.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.': 'Aucune réalisation n’a encore été ajoutée. Projets, certifications, publications et exemples de travaux permettent de rendre vos compétences concrètes.',
    'TRAJECTORY': 'PARCOURS',
    'Where have you been — where next?': 'D’où venez-vous et où souhaitez-vous aller ?',
    'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.': 'Votre parcours continue de s’écrire. Présentez votre expérience, les défis relevés et les directions que vous souhaitez explorer.',
    'The profile should reveal a direction, not just a chronology.': 'Votre profil doit révéler une direction, pas seulement une chronologie.',
    'INTENT FIELD': 'ASPIRATIONS',
    'What do you want to make possible?': 'Qu’aimeriez-vous rendre possible ?',
    'You are open to new opportunities.': 'Vous êtes ouvert aux nouvelles opportunités.',
    'You are open to selective connections.': 'Vous privilégiez les mises en relation ciblées.',
    'You are not looking for opportunities right now.': 'Vous ne recherchez pas d’opportunités pour le moment.',
    'These signals help the network surface complementary people — not rank people by popularity.': 'Ces informations aident le réseau à faire émerger des profils complémentaires, sans classement par popularité.',
    'MEMBER NETWORK': 'RÉSEAU DE MEMBRES',
    'Discover the people around your orbit.': 'Découvrez les personnes qui gravitent dans votre univers.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.': 'Chaque membre connecté peut explorer les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.',
    'Search members, skills or places': 'Rechercher des membres, des compétences ou des lieux',
    'Search member profiles': 'Rechercher des profils de membres',
    'Search ↗': 'Rechercher ↗',
    'Loading member profiles…': 'Chargement des profils…',
    'OPPORTUNITY CONSTELLATION': 'CONSTELLATION DES OPPORTUNITÉS',
    'What is orbiting your next move?': 'Quelles opportunités accompagnent votre prochaine étape ?',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'Explore this opportunity and inspect its requirements.': 'Découvrez cette opportunité et consultez ses critères.',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.': 'Aucune opportunité n’est encore associée à votre profil. Lorsque des entreprises publieront leurs offres, les opportunités pertinentes apparaîtront ici avec les raisons de leur adéquation avec vos compétences et aspirations.',
    'No hiring score. No popularity ranking. You remain in control of your visibility.': 'Aucune note de recrutement. Aucun classement par popularité. Vous gardez le contrôle de votre visibilité.',
    'IMPACT SIGNAL': 'SIGNAL D’IMPACT',
    'Make contribution visible.': 'Rendez votre contribution visible.',
    'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.': 'Mettez en avant les résultats, pas seulement les intitulés. L’impact reliera vos projets, vos contributions et des réalisations pouvant être examinées indépendamment.',
    'Add a capability': 'Ajouter une compétence',
    'Add evidence': 'Ajouter une réalisation',
    'Edit identity': 'Modifier mon identité',
    'Interest sent ✓': 'Intérêt envoyé ✓',
    'Block': 'Bloquer',
    'Unblock': 'Débloquer',
    'Block this member? You will no longer see each other in discovery or be able to connect.': 'Bloquer ce membre ? Vous ne vous verrez plus dans les recherches et ne pourrez plus vous contacter.',
    'Member blocked.': 'Membre bloqué.',
    'Member unblocked.': 'Membre débloqué.',
    'COMPANY UNIVERSE': 'UNIVERS DE L’ENTREPRISE',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES',
    'Location not specified': 'Lieu non précisé',
    'This company has not added an overview yet.': 'Cette entreprise n’a pas encore renseigné sa présentation.',
    'Company website ↗': 'Site web de l’entreprise ↗',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'YOUR NETWORK': 'VOTRE RÉSEAU',
    'Notifications': 'Notifications',
    'Read': 'Lu',
    'Mark read': 'Marquer comme lu',
    'You are all caught up.': 'Vous êtes à jour.',
    'No published opportunities yet. Company opportunities will appear here when they are available.': 'Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur mise en ligne.',
    'Location flexible': 'Lieu flexible',
    'Explore this opportunity. Matching signals will appear as your skills and intentions become more specific.': 'Consultez cette opportunité. Les points de correspondance se préciseront à mesure que vous renseignerez vos compétences et vos aspirations.',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'Your professional profile has been shared with this company for this opportunity only.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.',
    'Company page is not available.': 'La page de cette entreprise est indisponible.',
    'This company page is not available.': 'La page de cette entreprise est indisponible.',
    'This identity is not available.': 'Ce profil est indisponible.',
    'Identity link copied.': 'Lien du profil copié.',
    'Explore this professional identity on ZERILYS': 'Découvrez ce profil professionnel sur ZERILYS',
    'No evidence has been linked publicly to this capability yet.': 'Aucune réalisation n’est publiquement associée à cette compétence.',
    'This identity is still taking shape. Its next signals will appear here.': 'Cette identité est en cours de construction. Ses prochains éléments apparaîtront ici.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'Connecté',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre espace de relations est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.',
    'Connections are temporarily unavailable.': 'Les relations sont temporairement indisponibles.',
    'Notifications': 'Notifications',
    'You are all caught up.': 'Vous êtes à jour.',
    'Mark read': 'Marquer comme lu',
    'Read': 'Lu',
    'Company universe': 'Univers de l’entreprise',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES',
    'Location not specified': 'Lieu non précisé',
    'This company has not added an overview yet.': 'Cette entreprise n’a pas encore ajouté de présentation.',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'Your professional profile has been shared with this company for this opportunity.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.',
    'Report sent to the moderation team.': 'Signalement transmis à l’équipe de modération.',
    'Describe the issue (at least 20 characters). This report will be sent to the moderation team.': 'Décrivez le problème (20 caractères minimum). Ce signalement sera transmis à l’équipe de modération.',
    'Share is unavailable in this browser.': 'Le partage n’est pas disponible dans ce navigateur.',
    'Identity link copied.': 'Lien du profil copié.',
    'Explore this professional identity on ZERILYS': 'Découvrez ce profil professionnel sur ZERILYS',
    // 0.82 — native French for remaining member-facing dynamic states.
    "Create your identity":"Créer mon profil",
    "Welcome back":"Bon retour",
    "Join a network built around what you can do.":"Rejoignez un réseau qui valorise vos compétences et vos réalisations.",
    "Continue building what comes next.":"Continuez à construire la suite de votre parcours.",
    "Already a member? Log in":"Déjà membre ? Se connecter",
    "New to ZERILYS? Create an identity":"Nouveau sur ZERILYS ? Créer un profil",
    "Create account ↗":"Créer mon compte ↗",
    "Log in ↗":"Se connecter ↗",
    "Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.":"Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.",
    "Your identity at a glance.":"Votre identité en un coup d’œil.",
    "WHAT I CAN BRING":"CE QUE JE PEUX APPORTER",
    "WHAT I AM LOOKING FOR":"CE QUE JE RECHERCHE",
    "INTERESTS":"CENTRES D’INTÉRÊT",
    "Not defined yet":"À définir",
    "Not added yet":"Non renseigné",
    "What can you actually do?":"Que savez-vous concrètement faire ?",
    "Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.":"Votre espace de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez-y des réalisations.",
    "Show the work behind the claim.":"Montrez ce qui démontre vos compétences.",
    "No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.":"Aucune réalisation n’a encore été ajoutée. Des projets, diplômes, publications ou exemples de travaux peuvent rendre vos compétences plus concrètes.",
    "Where have you been — where next?":"D’où venez-vous et où souhaitez-vous aller ?",
    "Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.":"Votre parcours continue de s’écrire. Présentez votre expérience, les défis relevés et la direction que vous souhaitez explorer.",
    "What do you want to make possible?":"Que souhaitez-vous rendre possible ?",
    "You are open to new opportunities.":"Vous êtes ouvert aux nouvelles opportunités.",
    "You are open to selective connections.":"Vous privilégiez les mises en relation ciblées.",
    "You are not looking for opportunities right now.":"Vous ne recherchez pas d’opportunités pour le moment.",
    "Connect to a capability (optional)":"Associer à une compétence (facultatif)",
    "Add projects, credentials or work that demonstrates your capabilities.":"Ajoutez des projets, diplômes ou travaux qui illustrent vos compétences.",
    "Submit for review ↗":"Soumettre pour examen ↗",
    "Evidence submitted for independent review.":"Réalisation soumise à une vérification indépendante.",
    "Your intentional connection request has been sent.":"Votre demande de mise en relation a été envoyée.",
    "Your connection request has been sent.":"Votre demande de connexion a été envoyée.",
    "INCOMING SIGNAL":"DEMANDE REÇUE",
    "OUTGOING SIGNAL":"DEMANDE ENVOYÉE",
    "Accept":"Accepter",
    "Decline":"Refuser",
    "Connected":"En relation",
    "Declined":"Refusée",
    "Awaiting response":"En attente de réponse",
    "Connection response saved.":"Réponse à la demande enregistrée.",
    "Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.":"Votre réseau est encore vide. Consultez un profil et envoyez une invitation personnalisée pour commencer.",
    "No published opportunities yet. Company opportunities will appear here when they are available.":"Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur mise en ligne.",
    "Express interest ↗":"Manifester mon intérêt ↗",
    "Your professional profile has been shared with this company for this opportunity.":"Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.",
    "Interest already sent ✓":"Intérêt déjà transmis ✓",
    "Your opportunity journey will appear here.":"Le suivi de vos démarches apparaîtra ici.",
    "Withdraw your interest? The company will no longer be able to view your application details.":"Retirer votre candidature ? L’entreprise ne pourra plus consulter les détails de votre dossier.",
    "Your interest was withdrawn and access to your profile for this application was revoked.":"Votre intérêt a été retiré et l’accès à votre profil pour cette candidature a été révoqué.",
    "Notifications":"Notifications",
    "Mark read":"Marquer comme lu",
    "You are all caught up.":"Vous êtes à jour.",
    "Read":"Lu",
    "This company has not added an overview yet.":"Cette entreprise n’a pas encore renseigné sa présentation.",
    "Published opportunities":"Opportunités publiées",
    "No published opportunities at the moment.":"Aucune opportunité publiée actuellement.",
    "Company website ↗":"Site de l’entreprise ↗",
    "Your network":"Votre réseau",
    "Your profile is temporarily unavailable.":"Votre profil est momentanément indisponible.",
    "The network is temporarily unavailable.":"Le réseau est momentanément indisponible.",
    "Connections are temporarily unavailable.":"Les relations sont momentanément indisponibles.",
    "Opportunity signals are temporarily unavailable.":"Les opportunités sont momentanément indisponibles.",
    "Location not specified":"Localisation non renseignée",
    "Building their next chapter":"Prépare la suite de son parcours",
    "Profile in progress":"Profil en cours de création",
    "Explore this identity":"Découvrir ce profil",
    "Discover this identity":"Découvrir ce profil",
    "Connect with intent":"Proposer une mise en relation",
    "COMPLEMENTARITY SIGNAL":"POTENTIEL DE COMPLÉMENTARITÉ",
    "Level:":"Niveau :",
    "verified":"vérifiée",
    "self-declared":"déclarée",
    "evidence record":"réalisation associée",
    "evidence records":"réalisations associées",
    "Link evidence ↗":"Associer une réalisation ↗",
    "No evidence linked yet. Connect a project, credential or work sample to make this capability more tangible.":"Aucune réalisation associée. Reliez un projet, un diplôme ou un exemple de travail pour illustrer cette compétence.",
    'My profile':'Mon profil',
    'Open your candidate profile':'Ouvrir mon profil professionnel',
    'Open my candidate profile':'Ouvrir mon profil professionnel',
    'The network is taking shape. Be among the first to create a profile.':'Le réseau se construit. Soyez parmi les premiers à créer votre profil.',
    'Building their next chapter':'Prépare la suite de son parcours',
    'Location not shared':'Localisation non communiquée',
    'evidence item':'réalisation associée',
    'evidence items':'réalisations associées',
    'Profile in progress':'Profil en cours de création',
    'Discover this identity':'Découvrir ce profil',
    'connection potential':'potentiel de mise en relation',
    'Explore':'Découvrir',
    'Connect with intent':'Proposer une mise en relation',
    'The network is temporarily unavailable.':'Le réseau est momentanément indisponible.',
    'Searching the member network…':'Recherche dans le réseau des membres…',
    'No matching profiles. Try another name, skill or location.':'Aucun profil correspondant. Essayez un autre nom, une autre compétence ou un lieu.',
    'Professional member':'Membre du réseau professionnel',
    'profiles':'profils',
    'of':'sur',
    'Loading…':'Chargement…',
    'Load next profiles ↓':'Afficher les profils suivants ↓',
    'Unable to load more profiles.':'Impossible de charger davantage de profils.',
    'The member network is temporarily unavailable.':'Le réseau des membres est momentanément indisponible.',
    'No open collaborations yet. Be the first to start one.':'Aucune collaboration ouverte pour le moment. Soyez le premier à proposer un projet.',
    'Explore collaboration ↗':'Découvrir la collaboration ↗',
    'Collaborations are temporarily unavailable.':'Les collaborations sont momentanément indisponibles.',
    'interested':'intéressé(s)',
    'By':'Par',
    'Create your identity':'Créer mon profil',
    'Welcome back':'Ravi de vous retrouver',
    'Join a network built around what you can do.':'Rejoignez un réseau qui valorise vos compétences et vos réalisations.',
    'Continue building what comes next.':'Poursuivez la construction de votre parcours.',
    'Create account ↗':'Créer mon compte ↗',
    'Log in ↗':'Se connecter ↗',
    'Already a member? Log in':'Déjà membre ? Se connecter',
    'New to ZERILYS? Create an identity':'Nouveau sur ZERILYS ? Créer mon profil',
    'Registration is paused until the beta legal review is complete.':'Les inscriptions sont suspendues dans l’attente de la validation juridique de la bêta.',
    'Your email address is confirmed.':'Votre adresse e-mail est confirmée.',
    'Your email address is not confirmed yet. Check your inbox for the confirmation link.':'Votre adresse e-mail n’est pas encore confirmée. Consultez votre boîte de réception.',
    'Email confirmation is not configured on this service yet.':'La confirmation par e-mail n’est pas encore configurée sur ce service.',
    'Your account deletion request has been processed.':'Votre demande de suppression de compte a été prise en compte.',
    'The new passwords do not match.':'Les nouveaux mots de passe ne correspondent pas.',
    'Password changed successfully.':'Mot de passe modifié avec succès.',
    'Company identity updated.':'Profil de l’entreprise mis à jour.',
    'Company verification request submitted.':'Demande de vérification de l’entreprise envoyée.',
    'Opportunity published. Its match signals are now available to candidates.':'Opportunité publiée. Les indicateurs de pertinence sont désormais accessibles aux candidats.',
    'What are you building?':'Quel projet souhaitez-vous développer ?',
    'Describe the challenge and the contribution you need (at least 30 characters).':'Décrivez le défi et la contribution recherchée (30 caractères minimum).',
    'Skills needed, separated by commas (optional)':'Compétences recherchées, séparées par des virgules (facultatif)',
    'Your collaboration is live.':'Votre collaboration est publiée.',
    'Find the people behind': 'Trouvez les personnes qui font avancer',
    "what's possible.": 'les idées et les projets.',
    'Discover people by what they know, what they have built, and what they want to make possible next.': 'Découvrez les compétences, les réalisations et les projets de celles et ceux qui font partie du réseau.',
    'Every signed-in member can explore every other member profile. Private mode only limits anonymous discovery and public profile links.': 'Chaque membre connecté peut consulter les profils des autres membres. Le mode privé limite uniquement la visibilité pour les personnes non connectées et les liens publics.',
    'Search skills, people, disciplines or places': 'Rechercher une compétence, une personne, un domaine ou un lieu',
    'Explore network ↗': 'Explorer le réseau ↗',
    'Let the right opportunities': 'Faites émerger les opportunités',
    'find their orbit.': 'qui vous correspondent.',
    'Structured opportunities from companies. Relevant signals, explained through skills and intent — never an opaque hiring score.': 'Des opportunités proposées par les entreprises. Leur pertinence repose sur vos compétences et vos aspirations, jamais sur une note de recrutement opaque.',
    'NO SOCIAL FEED · NO PERSONAL POSTS · ONLY PROFESSIONAL OPPORTUNITIES': 'PAS DE FIL D’ACTUALITÉ · PAS DE PUBLICATIONS PERSONNELLES · DES OPPORTUNITÉS PROFESSIONNELLES',
    'Refresh opportunities ↻': 'Actualiser les opportunités ↻',
    'Expressing interest shares your professional profile with that company for this opportunity only. You can withdraw at any time.': 'En manifestant votre intérêt, vous partagez votre profil professionnel avec cette entreprise pour cette seule opportunité. Vous pouvez retirer votre candidature à tout moment.',
    'Your interests and application progress': 'Vos intérêts et le suivi de vos candidatures',
    'Company identity': 'Identité de l’entreprise',
    'Company name': 'Nom de l’entreprise',
    'Industry': 'Secteur d’activité',
    'Website (HTTPS)': 'Site web (HTTPS)',
    'Headquarters / operating locations': 'Siège social / lieux d’activité',
    'What the company does, its mission and areas of activity': 'Présentez l’activité, la mission et les domaines d’intervention de l’entreprise',
    'Save company identity': 'Enregistrer l’identité de l’entreprise',
    'Company verification': 'Vérification de l’entreprise',
    'Opportunities become visible to candidates only after a reviewer confirms the organization. This is a human review, not an automated badge.': 'Les opportunités ne sont visibles des candidats qu’après validation de l’organisation par un membre de l’équipe de modération. Cette vérification est humaine, et non un badge automatique.',
    'Business email address': 'Adresse e-mail professionnelle',
    'Point reviewers to public evidence they can independently check (company registry, official site, public profile…).': 'Indiquez des éléments publics que l’équipe pourra vérifier de manière indépendante (registre officiel, site de l’entreprise, profil public…).',
    'Submit for verification ↗': 'Soumettre à vérification ↗',
    'Publish a structured opportunity': 'Publier une opportunité détaillée',
    'Role or opportunity title': 'Intitulé du poste ou de l’opportunité',
    'Describe the mission, expected contribution and context (30+ characters)': 'Décrivez la mission, la contribution attendue et le contexte (30 caractères minimum)',
    'Required skills, separated by commas': 'Compétences requises, séparées par des virgules',
    'Job': 'Emploi',
    'Internship': 'Stage',
    'Apprenticeship': 'Alternance',
    'Collaboration': 'Collaboration',
    'Hybrid': 'Hybride',
    'Remote': 'À distance',
    'On-site': 'Sur site',
    'Publish opportunity ↗': 'Publier l’opportunité ↗',
    'Your published opportunities': 'Vos opportunités publiées',
    'Candidate interests': 'Manifestations d’intérêt des candidats',
    'Why should your paths cross?': 'Pourquoi souhaitez-vous entrer en contact ?',
    'Write a short, personal reason. The recipient sees your context before deciding.': 'Expliquez brièvement et personnellement votre démarche. Votre interlocuteur prendra connaissance du contexte avant de répondre.',
    'I noticed your work in… I think we could…': 'J’ai découvert votre travail sur… Je pense que nous pourrions…',
    'Send intentional connection ↗': 'Envoyer la demande de mise en relation ↗',
    'Your connection field.': 'Vos mises en relation',
    'Every request carries context. No empty invitations, no popularity mechanics.': 'Chaque demande est contextualisée. Pas d’invitation impersonnelle ni de mécanisme de popularité.',
    'Data & privacy.': 'Données et confidentialité.',
    'Your account information and the visibility of your professional identity.': 'Les informations de votre compte et la visibilité de votre identité professionnelle.',
    'ACCOUNT EMAIL': 'ADRESSE E-MAIL DU COMPTE',
    'PROFILE VISIBILITY': 'VISIBILITÉ DU PROFIL',
    'Email address': 'Adresse e-mail',
    'Email verification status unavailable.': 'Statut de vérification de l’adresse e-mail indisponible.',
    'Resend confirmation email': 'Renvoyer l’e-mail de confirmation',
    'Beta terms & privacy': 'Conditions de la bêta et confidentialité',
    'Consent status unavailable.': 'Statut du consentement indisponible.',
    'Private Beta Terms': 'Conditions de la bêta privée',
    'Privacy Notice': 'Notice de confidentialité',
    'Account security': 'Sécurité du compte',
    'Manage active sign-in sessions. A maximum of ten active sessions is allowed per account.': 'Gérez les sessions ouvertes sur votre compte. Dix sessions actives au maximum sont autorisées par compte.',
    'Loading sessions…': 'Chargement des sessions…',
    'Sign out other sessions': 'Fermer les autres sessions',
    'Change password': 'Modifier le mot de passe',
    'Current password': 'Mot de passe actuel',
    'New password (12–128 characters)': 'Nouveau mot de passe (12 à 128 caractères)',
    'Confirm new password': 'Confirmer le nouveau mot de passe',
    'Update password': 'Mettre à jour le mot de passe',
    'Close dialog': 'Fermer la fenêtre',
    'Close member profile': 'Fermer le profil',
    'IDENTITY CONFIGURATION': 'CONFIGURATION DE L’IDENTITÉ',
    'Shape your signal.': 'Donnez forme à votre identité.',
    'Profile photo': 'Photo de profil',
    'Use a clear portrait. JPG, PNG or WebP · up to 500 KB.': 'Choisissez un portrait net. JPG, PNG ou WebP · 500 Ko maximum.',
    'Add / change photo': 'Ajouter / modifier la photo',
    'Remove photo': 'Supprimer la photo',
    'Name': 'Nom',
    'Professional headline': 'Accroche professionnelle',
    'Climate strategist · Product builder': 'Stratégie climat · Développement de produits',
    'Location': 'Localisation',
    'Availability': 'Disponibilité',
    'Open to opportunities': 'À l’écoute d’opportunités',
    'Selective': 'Ouvert aux propositions ciblées',
    'Not looking right now': 'Pas de recherche actuellement',
    'Profile visibility': 'Visibilité du profil',
    'Public — discoverable by other members': 'Public — visible par les autres membres',
    'Private — members only; hidden from public links': 'Privé — réservé aux membres, masqué des liens publics',
    'About your work': 'À propos de votre activité',
    'What do you know how to do? What are you curious to build?': 'Que savez-vous faire ? Quels projets aimeriez-vous développer ?',
    'What can you bring?': 'Ce que vous pouvez apporter',
    'Separate items with commas': 'Séparez les éléments par des virgules',
    'What are you looking for?': 'Ce que vous recherchez',
    'Interests and themes': 'Centres d’intérêt et thématiques',
    'Climate, education, open source, health': 'Climat, éducation, logiciels libres, santé',
    'Website (HTTPS only)': 'Site web (HTTPS uniquement)',
    'Save identity ↗': 'Enregistrer mon profil ↗',
    'Capabilities': 'Compétences',
    'Add a skill, e.g. Product strategy': 'Ajouter une compétence, ex. : stratégie produit',
    'Practitioner': 'Opérationnel',
    'Learning': 'En apprentissage',
    'Advanced': 'Avancé',
    'Expert': 'Expert',
    'Add': 'Ajouter',
    'Evidence of your work': 'Réalisations',
    'Project, credential or achievement': 'Projet, certification ou réalisation',
    'https:// link (optional)': 'Lien HTTPS (facultatif)',
    'Connect to a capability (optional)': 'Associer à une compétence (facultatif)',
    'What did you contribute or demonstrate?': 'Quelle a été votre contribution ? Qu’avez-vous démontré ?',
    'Add evidence': 'Ajouter une réalisation',
    'YOUR OPPORTUNITY PATH': 'VOTRE PARCOURS D’OPPORTUNITÉS',
    'COMPANY STUDIO': 'ESPACE ENTREPRISE',
    'YOUR DATA / YOUR CONTROL': 'VOS DONNÉES, VOTRE CONTRÔLE',
    'PRIVATE TO YOU': 'VISIBLE UNIQUEMENT PAR VOUS',
    'IDENTITY CONSOLE': 'ESPACE IDENTITÉ',
    'PROOF': 'RÉALISATIONS',
    'TRAJECTORY': 'PARCOURS',
    'INTENT': 'ASPIRATIONS',
    'NETWORK': 'RÉSEAU',
    'IMPACT': 'IMPACT',
    'OPPORTUNITIES': 'OPPORTUNITÉS',
    'SELECT A SIGNAL OR CAPABILITY TO EXPLORE': 'SÉLECTIONNEZ UN SIGNAL OU UNE COMPÉTENCE POUR EXPLORER VOTRE PROFIL',
    'Experience & direction': 'Expérience et perspectives',
    'What comes next': 'La suite de votre parcours',
    'People & proximity': 'Personnes et proximité',
    'Work that matters': 'Des réalisations qui comptent',
    '0 signals': '0 compétence',
    '0 records': '0 réalisation',
    'Profile photo updated.': 'Photo de profil mise à jour.',
    'Your professional profile has been saved and refreshed.': 'Votre profil professionnel a été enregistré et actualisé.',
    'evidence': 'réalisation(s)',
    'CAPABILITY SIGNAL': 'SIGNAL DE COMPÉTENCE',
    'Independently verified': 'Vérifiée indépendamment',
    'Self-described': 'Déclarée par le membre',
    'No evidence has been linked publicly to this capability yet.': 'Aucune réalisation n’est encore associée publiquement à cette compétence.',
    'This identity is still taking shape. Its next signals will appear here.': 'Cette identité professionnelle se construit. Ses prochains éléments apparaîtront ici.',
    'ZERILYS / LIVING IDENTITY': 'ZERILYS / IDENTITÉ ÉVOLUTIVE',
    'Human potential in motion': 'Le potentiel professionnel en mouvement',
    'Location not shared': 'Lieu non communiqué',
    'A professional identity is not a list. It is a field of capabilities, proof and possibilities.': 'Une identité professionnelle ne se résume pas à une liste. Elle révèle des compétences, des réalisations et des possibilités.',
    'HUMAN SIGNAL': 'SIGNAL HUMAIN',
    'CAPABILITY FIELD': 'UNIVERS DES COMPÉTENCES',
    'Signals will appear here': 'Les signaux apparaîtront ici',
    'linked evidence record(s)': 'réalisation(s) associée(s)',
    'Join to connect ↗': 'Rejoindre pour échanger ↗',
    '⟡ Connect with intent': '⟡ Proposer une mise en relation',
    'Report': 'Signaler',
    'Block': 'Bloquer',
    'Unblock': 'Débloquer',
    '↗ Share this identity': '↗ Partager ce profil',
    '↗ Share public profile': '↗ Partager le profil public',
    '↗ Share member link': '↗ Partager le lien membre',
    'Public profile link shared.': 'Lien du profil public partagé.',
    'Member-only link shared. Only signed-in members can open it.': 'Lien réservé aux membres partagé. Seuls les membres connectés peuvent l’ouvrir.',
    'Member-only link copied. Only signed-in members can open it.': 'Lien réservé aux membres copié. Seuls les membres connectés peuvent l’ouvrir.',
    'Describe the issue (at least 20 characters). This report will be sent to the moderation team.': 'Décrivez le problème (20 caractères minimum). Ce signalement sera transmis à l’équipe de modération.',
    'Report sent to the moderation team.': 'Signalement transmis à l’équipe de modération.',
    'Block this member? You will no longer see each other in discovery or be able to connect.': 'Bloquer ce membre ? Vous ne vous verrez plus dans la découverte du réseau et ne pourrez plus entrer en relation.',
    'Member blocked.': 'Membre bloqué.',
    'Member unblocked.': 'Membre débloqué.',
    'COMPANY UNIVERSE': 'UNIVERS DE L’ENTREPRISE',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OPPORTUNITÉS MASQUÉES',
    'Location not specified': 'Lieu non précisé',
    'This company has not added an overview yet.': 'Cette entreprise n’a pas encore renseigné sa présentation.',
    'Company website ↗': 'Site web de l’entreprise ↗',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'YOUR NETWORK': 'VOTRE RÉSEAU',
    'Notifications': 'Notifications',
    'Read': 'Lu',
    'Mark read': 'Marquer comme lu',
    'You are all caught up.': 'Vous êtes à jour.',
    'No published opportunities yet. Company opportunities will appear here when they are available.': 'Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur mise en ligne.',
    'Location flexible': 'Lieu flexible',
    'Explore this opportunity. Matching signals will appear as your skills and intentions become more specific.': 'Consultez cette opportunité. Les points de correspondance se préciseront à mesure que vous renseignerez vos compétences et vos aspirations.',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'Your professional profile has been shared with this company for this opportunity only.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité uniquement.',
    'Company page is not available.': 'La page de cette entreprise est indisponible.',
    'This company page is not available.': 'La page de cette entreprise est indisponible.',
    'This identity is not available.': 'Ce profil est indisponible.',
    'Identity link copied.': 'Lien du profil copié.',
    'Explore this professional identity on ZERILYS': 'Découvrez ce profil professionnel sur ZERILYS',
    'Share is unavailable in this browser.': 'Le partage n’est pas disponible dans ce navigateur.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'ZERILYS member': 'Membre ZERILYS',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'En relation',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Connections are temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'Your intentional connection request has been sent.': 'Votre demande de mise en relation a été envoyée.',
    'Your intentional connection request has been sent.': 'Votre demande de mise en relation a été envoyée.',
    'Share is unavailable in this browser.': 'Le partage n’est pas disponible dans ce navigateur.',
    'Building their next chapter': 'Prépare la suite de son parcours',
    'Location not shared': 'Lieu non communiqué',
    'evidence item': 'réalisation',
    'evidence items': 'réalisations',
    'Profile in progress': 'Profil en construction',
    'COMPLEMENTARITY SIGNAL': 'SIGNAL DE COMPLÉMENTARITÉ',
    'connection potential': 'potentiel de mise en relation',
    'Discover this identity': 'Découvrir ce profil',
    'Explore': 'Explorer',
    'Connect with intent': 'Entrer en contact',
    'The network is taking shape. Be among the first to create a profile.': 'Le réseau se construit. Soyez parmi les premiers à créer votre profil.',
    'The network is temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'YOUR CORE SIGNAL': 'VOTRE IDENTITÉ EN UN COUP D’ŒIL',
    'Your identity at a glance.': 'Votre identité professionnelle en un coup d’œil.',
    'WHAT I CAN BRING': 'CE QUE JE PEUX APPORTER',
    'WHAT I AM LOOKING FOR': 'CE QUE JE RECHERCHE',
    'Not defined yet': 'À renseigner',
    'Not added yet': 'Non renseigné',
    'What can you actually do?': 'Que savez-vous concrètement faire ?',
    'verified': 'vérifiée',
    'self-declared': 'déclarée',
    'evidence record(s)': 'réalisation(s) associée(s)',
    'Your capability field is empty. Add the skills you want to be discovered for, then attach evidence to strengthen each signal.': 'Votre univers de compétences est vide. Ajoutez les compétences pour lesquelles vous souhaitez être identifié, puis associez des réalisations pour les étayer.',
    'Show the work behind the claim.': 'Donnez à voir le concret derrière vos compétences.',
    'No evidence has been added yet. Projects, credentials, publications and work samples can make your capabilities tangible.': 'Aucune réalisation n’a encore été ajoutée. Des projets, diplômes, publications ou exemples de travaux peuvent rendre vos compétences plus tangibles.',
    'Where have you been — where next?': 'D’où venez-vous et où souhaitez-vous aller ?',
    'Your story is still being written. Add context about your work, the challenges you have handled and the direction you want to explore.': 'Votre parcours continue de s’écrire. Présentez vos expériences, les défis que vous avez relevés et les directions que vous souhaitez explorer.',
    'The profile should reveal a direction, not just a chronology.': 'Votre profil doit révéler une trajectoire, pas seulement une chronologie.',
    'What do you want to make possible?': 'Qu’aimeriez-vous rendre possible ?',
    'You are open to new opportunities.': 'Vous êtes ouvert aux nouvelles opportunités.',
    'You are open to selective connections.': 'Vous privilégiez les mises en relation ciblées.',
    'You are not looking for opportunities right now.': 'Vous ne recherchez pas d’opportunité pour le moment.',
    'Discover the people around your orbit.': 'Découvrez les personnes qui gravitent dans votre univers.',
    'Every signed-in member can explore every other candidate profile. Search by name, skill or location — then open their professional universe.': 'Chaque membre connecté peut consulter les profils des autres membres. Recherchez par nom, compétence ou lieu, puis découvrez leur univers professionnel.',
    'Search members, skills or places': 'Rechercher des membres, des compétences ou des lieux',
    'Search member profiles': 'Rechercher des profils de membres',
    'Loading member profiles…': 'Chargement des profils des membres…',
    'What is orbiting your next move?': 'Quelles opportunités accompagnent votre prochaine étape ?',
    'Explore this opportunity and inspect its requirements.': 'Consultez cette opportunité et prenez connaissance de ses critères.',
    'Express interest ↗': 'Manifester mon intérêt ↗',
    'No opportunity signals are orbiting your identity yet. As companies publish structured offers, relevant opportunities will appear here with the reasons they match your skills and intentions.': 'Aucune opportunité ne gravite encore autour de votre profil. Lorsque des entreprises publieront des offres détaillées, les opportunités correspondant à vos compétences et à vos aspirations apparaîtront ici, avec les raisons de leur pertinence.',
    'No hiring score. No popularity ranking. You remain in control of your visibility.': 'Aucune note de recrutement. Aucun classement de popularité. Vous gardez le contrôle de votre visibilité.',
    'Make contribution visible.': 'Rendez votre contribution visible.',
    'Show outcomes, not just titles. Impact will become a structured layer connecting projects, contributions and independently reviewable evidence.': 'Montrez les résultats, pas seulement les intitulés. Le signal d’impact reliera les projets, les contributions et les réalisations pouvant être examinées indépendamment.',
    'Shape your signal.': 'Donnez forme à votre identité.',
    'Activate your capabilities.': 'Mettez vos compétences en valeur.',
    'Show the work behind your claims.': 'Illustrez vos compétences par des réalisations.',
    'Tell the story of your trajectory.': 'Racontez votre parcours.',
    'Define what comes next.': 'Définissez la suite de votre parcours.',
    'Make your contribution visible.': 'Rendez votre contribution visible.',
    'Your profile has been saved.': 'Votre profil a bien été enregistré.',
    'Your professional profile has been shared with this company for this opportunity.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'En relation',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Connections are temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'Your intentional connection request has been sent.': 'Votre demande de mise en relation a été envoyée.',
    'COMPANY UNIVERSE': 'UNIVERS DE L’ENTREPRISE',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OFFRES MASQUÉES',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'Company website ↗': 'Site web de l’entreprise ↗',
    'This company has not added an overview yet.': 'Cette entreprise n’a pas encore renseigné sa présentation.',
    'No published opportunities yet. Company opportunities will appear here when they are available.': 'Aucune opportunité publiée pour le moment. Les offres de l’entreprise apparaîtront ici dès leur publication.',
    'Your profile updates as you add skills, evidence and intentions. Select a signal to explore each dimension.': 'Votre profil évolue à mesure que vous ajoutez des compétences, des réalisations et des aspirations. Sélectionnez un signal pour explorer chaque dimension.',
    'Open your candidate profile': 'Ouvrir mon profil',
    'Open my candidate profile': 'Ouvrir mon profil',
    'My profile': 'Mon profil',
    'Create your identity': 'Créer mon profil',
    'Welcome back': 'Heureux de vous revoir',
    'Join a network built around what you can do.': 'Rejoignez un réseau qui valorise ce que vous savez faire.',
    'Continue building what comes next.': 'Poursuivez la construction de votre parcours.',
    'Create account ↗': 'Créer mon compte ↗',
    'Log in ↗': 'Se connecter ↗',
    'Already a member? Log in': 'Déjà membre ? Se connecter',
    'New to ZERILYS? Create an identity': 'Nouveau sur ZERILYS ? Créer un profil',
    'Registration is paused until the beta legal review is complete.': 'Les inscriptions sont suspendues dans l’attente de la validation juridique de la bêta.',
    'The network is taking shape. Be among the first to create a profile.': 'Le réseau se construit. Soyez parmi les premiers à créer votre profil.',
    'Building their next chapter': 'Prépare la suite de son parcours',
    'Location not shared': 'Lieu non communiqué',
    'Profile in progress': 'Profil en cours de création',
    'COMPLEMENTARITY SIGNAL': 'SIGNAUX DE COMPLÉMENTARITÉ',
    'Discover this identity': 'Découvrir ce profil',
    'connection potential': 'potentiel de mise en relation',
    'Explore ↗': 'Découvrir ↗',
    '⟡ Connect with intent': '⟡ Entrer en contact',
    'The network is temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'Searching the member network…': 'Recherche dans le réseau…',
    'No matching profiles. Try another name, skill or location.': 'Aucun profil correspondant. Essayez un autre nom, une compétence ou un lieu.',
    'Professional member': 'Membre du réseau',
    'Loading…': 'Chargement…',
    'Load next profiles ↓': 'Afficher les profils suivants ↓',
    'No open collaborations yet. Be the first to start one.': 'Aucune collaboration ouverte pour le moment. Soyez le premier à en proposer une.',
    'Collaborations are temporarily unavailable.': 'Les collaborations sont momentanément indisponibles.',
    'Explore collaboration ↗': 'Découvrir la collaboration ↗',
    'Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.': 'Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.',
    'INCOMING SIGNAL': 'DEMANDE REÇUE',
    'OUTGOING SIGNAL': 'DEMANDE ENVOYÉE',
    'Accept': 'Accepter',
    'Decline': 'Refuser',
    'Connected': 'En relation',
    'Awaiting response': 'En attente de réponse',
    'Connection response saved.': 'Réponse à la demande enregistrée.',
    'Connections are temporarily unavailable.': 'Le réseau est momentanément indisponible.',
    'COMPANY UNIVERSE': 'UNIVERS DE L’ENTREPRISE',
    'VERIFIED COMPANY': 'ENTREPRISE VÉRIFIÉE',
    'NOT VERIFIED · OPPORTUNITIES HIDDEN': 'NON VÉRIFIÉE · OFFRES MASQUÉES',
    'Published opportunities': 'Opportunités publiées',
    'No published opportunities at the moment.': 'Aucune opportunité publiée pour le moment.',
    'Company website ↗': 'Site web de l’entreprise ↗',
    'Notifications': 'Notifications',
    'YOUR NETWORK': 'VOTRE RÉSEAU',
    'Mark read': 'Marquer comme lu',
    'You are all caught up.': 'Vous êtes à jour.',
    'Read': 'Lu',
    'Mark reviewed': 'Marquer comme traité',
    'Dismiss': 'Écarter',
    'No open reports. The queue is clear.': 'Aucun signalement en attente.',
    'Your profile has been saved.': 'Votre profil a bien été enregistré.',
    'Profile photo': 'Photo de profil',
    'Remove skill': 'Supprimer cette compétence',
    'Add the capabilities you want to be known for.': 'Ajoutez les compétences que vous souhaitez mettre en avant.',
    'Add projects, credentials or work that demonstrates your capabilities.': 'Ajoutez des projets, certifications ou réalisations qui illustrent vos compétences.',
    'Connect to a capability (optional)': 'Associer à une compétence (facultatif)',
    'Submit for review ↗': 'Soumettre pour examen ↗',
    'Evidence submitted for independent review.': 'Réalisation transmise pour examen indépendant.',
    'Your professional profile has been shared with this company for this opportunity.': 'Votre profil professionnel a été transmis à cette entreprise pour cette opportunité.',
    "interested":"personnes intéressées"
    ,"of":"sur"
    ,"By":"Par"
    ,"ZERILYS member":"Membre ZERILYS"
    ,"part_time":"à temps partiel"
    ,"few_hours":"quelques heures par semaine"
    ,"full_time":"à temps plein"
    ,"flexible":"flexible"
    ,"short_term":"à court terme"
    ,"long_term":"à long terme"
    ,"The network is temporarily unavailable.":"Le réseau est momentanément indisponible."
    ,"Collaborations are temporarily unavailable.":"Les collaborations sont momentanément indisponibles."
    ,"No open collaborations yet. Be the first to start one.":"Aucun projet ouvert pour le moment. Soyez le premier à en lancer un."
    ,"Explore collaboration ↗":"Découvrir le projet ↗"
    ,"No evidence has been linked publicly to this capability yet.":"Aucune réalisation n’est encore associée publiquement à cette compétence."
    ,"This identity is still taking shape. Its next signals will appear here.":"Cette identité se construit progressivement. De nouveaux éléments apparaîtront ici."
    ,"A professional identity is not a list. It is a field of capabilities, proof and possibilities.":"Une identité professionnelle ne se résume pas à une liste. Elle révèle des compétences, des réalisations et des possibilités."
    ,"INDEPENDENTLY VERIFIED":"VÉRIFIÉE INDÉPENDAMMENT"
    ,"SELF-DESCRIBED CAPABILITY":"COMPÉTENCE DÉCLARÉE"
    ,"linked evidence record(s)":"réalisation(s) associée(s)"
    ,"Location not shared":"Lieu non communiqué"
    ,"Location flexible":"Lieu flexible"
    ,"Share public profile":"Partager le profil public"
    ,"Share member link":"Partager le lien membre"
    ,"Public profile link shared.":"Lien du profil public partagé."
    ,"Member-only link shared. Only signed-in members can open it.":"Lien réservé aux membres partagé. Seuls les membres connectés peuvent l’ouvrir."
    ,"Join to connect ↗":"Rejoindre le réseau ↗"
    ,"Connect with intent":"Entrer en contact"
    ,"Report":"Signaler"
    ,"Block":"Bloquer"
    ,"Unblock":"Débloquer"
    ,"Describe the issue (at least 20 characters). This report will be sent to the moderation team.":"Décrivez le problème (20 caractères minimum). Ce signalement sera transmis à l’équipe de modération."
    ,"Report sent to the moderation team.":"Signalement transmis à l’équipe de modération."
    ,"Block this member? You will no longer see each other in discovery or be able to connect.":"Bloquer ce membre ? Vous ne vous verrez plus dans la découverte et ne pourrez plus entrer en contact."
    ,"Member blocked.":"Membre bloqué."
    ,"Member unblocked.":"Membre débloqué."
    ,"Your network":"Votre réseau"
    ,"Notifications":"Notifications"
    ,"Read":"Lue"
    ,"Mark read":"Marquer comme lue"
    ,"You are all caught up.":"Vous êtes à jour."
    ,"Company website ↗":"Site de l’entreprise ↗"
    ,"Published opportunities":"Opportunités publiées"
    ,"No published opportunities at the moment.":"Aucune opportunité publiée pour le moment."
    ,"This company page is not available.":"Cette page entreprise n’est pas disponible."
    ,"Your identity is not available.":"Ce profil n’est pas disponible."
    ,"Your identity is not available.":"Ce profil n’est pas disponible."
    ,"Incoming signal":"Demande reçue"
    ,"Outgoing signal":"Demande envoyée"
    ,"Accept":"Accepter"
    ,"Decline":"Refuser"
    ,"Connected":"En relation"
    ,"Awaiting response":"En attente de réponse"
    ,"Connection response saved.":"Réponse à la demande enregistrée."
    ,"Connections are temporarily unavailable.":"Les relations sont momentanément indisponibles."
    ,"Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.":"Votre réseau est encore vide. Découvrez des profils et envoyez une invitation personnalisée pour commencer."
    ,"evidence records":"réalisations"
    ,"LIVING IDENTITY":"IDENTITÉ VIVANTE"
    ,"Signals will appear here":"Les signaux apparaîtront ici"
    ,"Share this identity":"Partager ce profil"
    ,"Company website ↗":"Site de l’entreprise ↗"
  };
  // Native English copy for French-authored interface fragments. The English
  // dictionary is seeded from the reverse of the reviewed French glossary,
  // then overridden where a natural product-language rendering is preferable.
  const en = Object.fromEntries(Object.entries(fr).map(([source, translated]) => [translated, source]));
  Object.assign(fr, {
    'Find the right people': 'Trouvez les bonnes personnes',
    'to build with.': 'pour construire ensemble.',
    'From idea': 'De l’idée', 'to team.': 'à l’équipe.',
    'Opportunities that': 'Des opportunités', 'match your expertise.': 'adaptées à votre expertise.',
    'Search by skills.': 'Recherchez par compétences.', 'Not just job titles.': 'Au-delà des intitulés de poste.',
    'Skills backed': 'Des compétences', 'by evidence.': 'étayées par des preuves.',
    'Your next opportunity': 'Votre prochaine opportunité', 'starts here.': 'commence ici.',
    'Explore specialist': 'Explorez des profils', 'profiles.': 'spécialisés.',
    'what comes next.': 'vos prochains défis.',
    'Finance & audit': 'Finance & audit', 'IA & informatique': 'IA & informatique', 'Data & statistiques': 'Data & statistiques',
    'Ingénierie & industrie': 'Ingénierie & industrie', 'Commerce & stratégie': 'Commerce & stratégie',
    'Les compétences réelles.': 'Les compétences réelles.', 'Au-delà du CV.': 'Au-delà du CV.',
    'Créer un compte': 'Créer un compte', 'Opportunités': 'Opportunités', 'Intelligence marché': 'Intelligence du marché',
    'Collaborations': 'Collaborations', 'Talents': 'Talents',
    'À distance': 'À distance', 'Publier une opportunité': 'Publier une opportunité',
    'Publier l’opportunité ↗': 'Publier l’opportunité ↗', 'Vos opportunités publiées': 'Vos opportunités publiées',
    'Candidatures et intérêts reçus': 'Candidatures et intérêts reçus', 'Parcours professionnel': 'Parcours professionnel',
    'Ajouter une expérience': 'Ajouter une expérience', 'Vérifier mon diplôme ou mon équivalence': 'Vérifier mon diplôme ou mon équivalence',
    'Ajouter une formation': 'Ajouter une formation', 'Formation': 'Formation',
    'Les éléments qui donnent de la profondeur à votre profil': 'Les éléments qui donnent de la profondeur à votre profil',
    'Chaque élément enrichit votre identité professionnelle.': 'Chaque élément enrichit votre identité professionnelle.',
    'Modifier mon profil': 'Modifier mon profil', 'Compléter mon profil ↗': 'Compléter mon profil ↗',
    '✓ Parcours vérifié': '✓ Parcours vérifié', 'Lieu non renseigné': 'Lieu non renseigné',
    'Tests & résultats': 'Tests et résultats', 'ÉQUIPE': 'ÉQUIPE', 'Sur mesure': 'Sur mesure',
    'Hypothèse tarifaire à valider en pilote': 'Hypothèse tarifaire à valider en pilote',
    'Déploiement et accompagnement dédiés': 'Déploiement et accompagnement dédiés',
    'Paramétrage selon les besoins': 'Paramétrage selon les besoins', 'Conditions et support spécifiques': 'Conditions et support spécifiques',
    'Étude au cas par cas': 'Étude au cas par cas', 'Premiers partenaires recherchés pour co-construire l’offre.': 'Premiers partenaires recherchés pour co-construire l’offre.',
    'Emploi (CDI / CDD)': 'Emploi (CDI / CDD)', 'Stage': 'Stage', 'Alternance': 'Alternance',
    'Projet / collaboration': 'Projet / collaboration', 'Graduate programme': 'Programme jeunes diplômés',
    'Projet de recherche': 'Projet de recherche', 'Hybride': 'Hybride', 'Sur site': 'Sur site',
    'Politique d’utilisation de l’intelligence artificielle': 'Politique d’utilisation de l’intelligence artificielle',
    'Début : ': 'Début : ', 'Durée : ': 'Durée : ', 'Rémunération : ': 'Rémunération : '
  });
  Object.assign(en, Object.fromEntries(Object.entries(fr).map(([source, translated]) => [translated, source])));
  Object.assign(fr, {
  "INGÉNIERIE · SCIENCES · FINANCE · COMMERCE · RECHERCHE": "ENGINEERING · SCIENCE · FINANCE · BUSINESS · RESEARCH",
  "Graduate programme": "Programme jeunes diplômés",
  "TALENT INTELLIGENCE": "INTELLIGENCE DES TALENTS",
  "EVIDENCE": "RÉALISATIONS",
  "ASSESSMENTS": "ÉVALUATIONS",
  "YOUR PROFILE FIELD": "VOTRE UNIVERS PROFESSIONNEL",
  "YOUR PROFESSIONAL PROFILE": "VOTRE PROFIL PROFESSIONNEL",
  "PROFILE CONSOLE": "ESPACE PROFIL",
  "ZERIH / PROFILE OS": "ZERIH / ESPACE PROFIL",
  "PROFILE CONFIGURATION": "CONFIGURATION DU PROFIL",
  "YOUR PROFILE": "VOTRE PROFIL",
  "Already a member? Connexion": "Déjà membre ? Connexion",
  "Finance · AI · Data · Talent": "Finance · IA · Data · Talents",
  "Recruiter Team": "Équipe de recrutement",
  "Enterprise": "Entreprise",
  "© 2026 ZERILYS. Beyond the CV.": "© 2026 ZERILYS. Au-delà du CV.",
  "YOUR CAPABILITIES": "VOS COMPÉTENCES",
  "Add skills to activate your field": "Ajoutez des compétences pour activer votre univers",
  "VERIFIED WITH EVIDENCE": "ÉTAYÉE PAR DES PREUVES",
  "linked item": "élément associé",
  "linked items": "éléments associés",
  "No evidence linked yet. Add a project, credential or work sample to support this capability.": "Aucune preuve associée pour le moment. Ajoutez un projet, une certification ou un exemple de réalisation pour étayer cette compétence.",
  "No evidence has been linked publicly to this capability yet.": "Aucune preuve n’a encore été associée publiquement à cette compétence.",
  "This identity is still taking shape. Its next signals will appear here.": "Cette identité professionnelle se construit. Ses prochains éléments apparaîtront ici.",
  "Verified qualification": "Parcours vérifié",
  "Add the capabilities you want to be known for.": "Ajoutez les compétences que vous souhaitez mettre en avant.",
  "Connect to a capability (optional)": "Associer à une compétence (facultatif)",
  "Add projects, credentials or work that demonstrates your capabilities.": "Ajoutez des projets, certifications ou réalisations qui démontrent vos compétences.",
  "Your connection field is empty. Explore a profile and send a thoughtful invitation to begin.": "Votre réseau est encore vide. Découvrez un profil et envoyez une invitation personnalisée pour commencer.",
  "Connections are temporarily unavailable.": "Les relations sont momentanément indisponibles.",
  "No published opportunities yet. Company opportunities will appear here when they are available.": "Aucune opportunité publiée pour le moment. Les offres des entreprises apparaîtront ici dès leur mise en ligne.",
  "Opportunity signals are temporarily unavailable.": "Les opportunités sont momentanément indisponibles.",
  "VERIFIED COMPANY": "ENTREPRISE VÉRIFIÉE",
  "Company identity reviewed by the ZERILYS trust team.": "Identité de l’entreprise contrôlée par l’équipe de confiance ZERILYS.",
  "REVIEW PENDING": "VÉRIFICATION EN ATTENTE",
  "Your opportunities are not yet visible to candidates.": "Vos opportunités ne sont pas encore visibles par les candidats.",
  "No team members yet.": "Aucun membre dans l’équipe pour le moment.",
  "Close offer": "Clôturer l’offre",
  "No opportunity published yet.": "Aucune opportunité publiée pour le moment.",
  "You have not sent any feedback yet.": "Vous n’avez pas encore transmis de retour.",
  "No active sessions found.": "Aucune session active trouvée.",
  "No company verification requests.": "Aucune demande de vérification d’entreprise.",
  "No open reports. The queue is clear.": "Aucun signalement en attente.",
  "No evidence awaiting review.": "Aucun justificatif en attente de vérification.",
  "No open tester feedback.": "Aucun retour de testeur en attente.",
  "Optional internal review note.": "Note interne facultative pour la revue.",
  "No bulk invitation batches yet.": "Aucun lot d’invitations groupées pour le moment.",
  "No pending personal invitations.": "Aucune invitation individuelle en attente.",
  "Revoke this pending invitation?": "Révoquer cette invitation en attente ?",
  "Explore field": "Explorer votre univers",
  "Not specified": "Non précisé",
  "ÉTAYÉE PAR DES PREUVES": "SUPPORTED BY EVIDENCE",
  "Opportunités": "Opportunities",
  "Intelligence marché": "Market intelligence",
  "Créer un compte": "Create account",
  "INTELLIGENCE DES TALENTS": "TALENT INTELLIGENCE",
  "RÉALISATIONS": "EVIDENCE",
  "ÉVALUATIONS": "ASSESSMENTS",
  "VOTRE UNIVERS PROFESSIONNEL": "YOUR PROFESSIONAL FIELD",
  "VOTRE PROFIL PROFESSIONNEL": "YOUR PROFESSIONAL PROFILE",
  "ESPACE PROFIL": "PROFILE CONSOLE",
  "CONFIGURATION DU PROFIL": "PROFILE CONFIGURATION",
  "Équipe de recrutement": "Recruiting team",
  "Entreprise": "Company",
  "Intelligence des talents": "Talent Intelligence",
  "VOTRE PROFIL": "YOUR PROFILE",
  "VOTRE UNIVERS": "YOUR PROFESSIONAL SPACE",
  "preuves associées": "linked evidence",
  "En apprentissage": "Learning",
  "↗ Partager mon profil public": "↗ Share my public profile",
  "↗ Partager mon lien membre": "↗ Share my member link",
  "Votre nom": "Your name",
  "PAS EN RECHERCHE ACTUELLEMENT": "NOT LOOKING RIGHT NOW",
  "En revue humaine": "Under human review",
  "Aucun justificatif soumis.": "No supporting document submitted.",
  "Aucun cas pratique en attente.": "No practical cases awaiting review.",
  "Impossible d’enregistrer le profil.": "Unable to save your profile.",
  "COMPÉTENCE / SIGNAL": "SKILL / SIGNAL",
  "Opérationnel": "Operational",
  "Avancé": "Advanced",
  "Non précisé": "Not specified",
  "COMPÉTENCE DÉCLARÉE": "SELF-DESCRIBED SKILL",
  "élément associé": "linked item",
  "éléments associés": "linked items",
  "Cette compétence fait partie de votre identité professionnelle.": "This skill is part of your professional identity.",
  "Aucune preuve associée pour le moment. Ajoutez un projet, un diplôme ou un exemple de réalisation pour étayer cette compétence.": "No evidence is linked yet. Add a project, qualification or work sample to support this skill.",
  "L’identité de votre entreprise est distincte de votre profil personnel. Les opportunités ne sont visibles qu’après vérification de l’entreprise.": "Your company identity is separate from your personal profile. Opportunities appear only after company verification.",
  "Votre profil est visible par les membres connectés de ZERILYS. Le mode privé le masque des liens publics et de la découverte anonyme.": "Your profile is visible to signed-in ZERILYS members. Private mode hides it from public links and anonymous discovery.",
  "Votre profil est visible par les membres de ZERILYS et via son lien public. Vous pouvez limiter sa découverte anonyme à tout moment.": "Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.",
  "Au moins un diplôme ou une équivalence a été vérifié par un évaluateur habilité.": "At least one degree or equivalent qualification has been verified by an authorised reviewer.",
  "Aucun diplôme ou équivalence vérifié.": "No degree or equivalent qualification has been verified.",
  "Ajoutez un intitulé professionnel": "Add a professional headline",
  "Localisation non renseignée": "Location not provided",
  "OUVERT AUX OPPORTUNITÉS": "OPEN TO OPPORTUNITIES",
  "OUVERT AUX ÉCHANGES CIBLÉS": "OPEN TO SELECTIVE CONNECTIONS",
  "compétences": "skills",
  "réalisations": "evidence",
  "Démontrez vos compétences.": "Demonstrate your skills.",
  "Cas pratiques · preuves de mise en situation": "Practical cases · applied evidence",
  "Ces exercices sont individualisés. Ils sont examinés par un humain : aucun score automatique ne prétend mesurer votre performance.": "These exercises are tailored to each candidate and reviewed by a person. No automated score claims to measure your performance.",
  "Preuve validée": "Evidence validated",
  "Complément demandé": "Further information requested",
  "Preuve non validée": "Evidence not validated",
  "Revue terminée": "Review completed",
  "Aucun dépôt": "No submission yet",
  "Votre réponse": "Your response",
  "Présentez votre démarche, vos hypothèses, vos calculs ou éléments de preuve, vos limites et vos recommandations…": "Explain your approach, assumptions, calculations or supporting evidence, limitations and recommendations…",
  "Vous pouvez structurer votre réponse avec des titres.": "You may structure your response with headings.",
  "Déclarez votre usage de l’IA": "Declare your use of AI",
  "Je n’ai pas utilisé d’IA": "I did not use AI",
  "J’ai utilisé une IA comme assistance": "I used AI as an aid",
  "Je préfère ne pas répondre": "I prefer not to say",
  "Critères de revue": "Review criteria",
  "Les critères sont communiqués à l’avance. Aucun score automatique n’est attribué.": "The criteria are shared in advance. No automated score is assigned.",
  "Soumettre mon cas ↗": "Submit my case ↗",
  "Annuler": "Cancel",
  "Aucun résultat partagé.": "No results shared.",
  "Vos choix de partage ont été enregistrés.": "Your sharing choices have been saved.",
  "Autorisation de partage retirée.": "Sharing permission withdrawn.",
  "Votre intérêt a été transmis à l’entreprise.": "Your expression of interest has been sent to the company.",
  "Les résultats d’évaluation restent privés. Vous pourrez choisir précisément ceux à partager après l’envoi de votre intérêt.": "Your assessment results remain private. After expressing interest, you can choose exactly which results to share.",
  "Exprimer mon intérêt ↗": "Express interest ↗",
  "Résultats techniques non partagés par le candidat.": "Technical results have not been shared by the candidate.",
  "Revu par un évaluateur": "Reviewed by an assessor",
  "Plan d’évaluation enregistré.": "Assessment plan saved.",
  "Vérification du parcours enregistrée.": "Qualification review saved.",
  "Le serveur n’a pas confirmé l’enregistrement. Réessayez.": "The server did not confirm the save. Please try again.",
  "Votre profil a bien été enregistré et actualisé dans vos espaces.": "Your profile has been saved and updated across your workspaces.",
  "Impossible d’enregistrer votre langue préférée.": "Your language preference could not be saved.",
  "Joignez un justificatif PDF, JPG ou PNG.": "Attach a supporting document in PDF, JPG or PNG format.",
  "Le justificatif doit faire moins de 650 Ko.": "The supporting document must be smaller than 650 KB.",
  "Quel a été votre usage de l’intelligence artificielle pour ce test ?": "How did you use artificial intelligence for this assessment?",
  "Valider mes réponses ↗": "Submit my answers ↗",
  "Impossible d’enregistrer le résultat.": "Unable to save the result.",
  "IA utilisée": "AI used",
  "Aucune IA déclarée": "No AI use declared",
  "Non renseignée": "Not provided",
  "À renforcer": "Needs improvement",
  "Maîtrisé": "Proficient",
  "Très bien maîtrisé": "Highly proficient",
  "Choisir une décision": "Select a decision",
  "Synthèse motivée": "Reasoned summary",
  "ÉQUIVALENCE": "EQUIVALENCY",
  "DIPLÔME": "DEGREE",
  "Déjà membre ? Connexion": "Already a member? Log in"
});
  Object.assign(en, {
  "Opportunités": "Opportunities",
  "Intelligence marché": "Market intelligence",
  "Créer un compte": "Create account",
  "Les compétences réelles.": "Real-world skills.",
  "Au-delà du CV.": "Beyond the CV.",
  "Révélez vos compétences, trouvez un stage, une alternance, un emploi ou des partenaires de projet.": "Show what you can do. Find an internship, apprenticeship, job or project partners.",
  "Créer mon profil": "Create my profile",
  "Découvrez des profils": "Discover talent",
  "aux compétences vérifiables.": "with demonstrable skills.",
  "Ingénieurs, scientifiques, financiers, managers, chercheurs et jeunes diplômés : explorez les talents par compétences et réalisations.": "Explore engineers, scientists, finance professionals, managers, researchers and graduates by skills and proven work.",
  "DOMAINES À EXPLORER": "EXPLORE SPECIALISATIONS",
  "Ingénierie & industrie": "Engineering & industry",
  "Commerce & stratégie": "Business & strategy",
  "À distance": "Remote",
  "Publier une opportunité": "Post an opportunity",
  "Publier l’opportunité ↗": "Publish opportunity ↗",
  "Vos opportunités publiées": "Your published opportunities",
  "Candidatures et intérêts reçus": "Applications and expressions of interest",
  "RECRUTEMENT SPÉCIALISÉ · OFFRE ENTREPRISE": "SPECIALIST RECRUITMENT · EMPLOYER OFFER",
  "Un espace conçu pour identifier des expertises rares, comprendre les compétences démontrées et suivre les échanges avec les talents.": "A workspace to identify rare expertise, understand demonstrated skills and manage conversations with talent.",
  "Identité professionnelle": "Professional identity",
  "Profil professionnel évolutif": "Evolving professional profile",
  "Compétences et réalisations": "Skills and evidence",
  "Découverte et opportunités": "Discovery and opportunities",
  "Accès candidat envisagé": "Proposed candidate access",
  "Recherche spécialisée de talents": "Specialist talent search",
  "Profils, compétences et preuves": "Profiles, skills and evidence",
  "Publication et suivi des opportunités": "Opportunity publishing and tracking",
  "Hypothèse tarifaire à valider en pilote": "Indicative pricing to validate in a pilot",
  "ÉQUIPE": "TEAM",
  "Espace de recrutement partagé": "Shared recruitment workspace",
  "Rôles recruteur et consultation": "Recruiter and viewer roles",
  "Coordination des opportunités": "Opportunity coordination",
  "Gestion d’équipe": "Team management",
  "Sur mesure": "Tailored",
  "Déploiement et accompagnement dédiés": "Dedicated rollout and support",
  "Paramétrage selon les besoins": "Configuration to fit your needs",
  "Conditions et support spécifiques": "Tailored terms and support",
  "Étude au cas par cas": "Reviewed case by case",
  "Ces montants sont des hypothèses de travail, pas des tarifs contractuels. Aucun paiement ni abonnement n’est activé dans cette version. Les offres seront ajustées après entretiens et pilotes payants.": "These figures are working assumptions, not contractual prices. Payments and subscriptions are not enabled in this release. Offers will be refined after customer interviews and paid pilots.",
  "Créer un compte entreprise ↗": "Create an employer account ↗",
  "Premiers partenaires recherchés pour co-construire l’offre.": "We are looking for our first partners to shape the offer together.",
  "✓ Parcours vérifié": "✓ Verified qualifications",
  "Lieu non renseigné": "Location not provided",
  "Tests & résultats": "Assessments & results",
  "Les éléments qui donnent de la profondeur à votre profil": "The details that bring your profile to life",
  "Chaque élément enrichit votre identité professionnelle.": "Every detail adds depth to your professional identity.",
  "PROFIL COMPLÉTÉ": "PROFILE COMPLETION",
  "Compléter mon profil ↗": "Complete my profile ↗",
  "Modifier mon profil": "Edit my profile",
  "Ajouter une expérience": "Add experience",
  "Vérifier mon diplôme ou mon équivalence": "Verify my degree or equivalent qualification",
  "Ajouter une formation": "Add education",
  "Formation": "Education",
  "Parcours professionnel": "Professional experience",
  "Emploi (CDI / CDD)": "Employment (permanent / fixed-term)",
  "Stage": "Internship",
  "Alternance": "Apprenticeship",
  "Projet / collaboration": "Project / collaboration",
  "Projet de recherche": "Research project",
  "Hybride": "Hybrid",
  "Sur site": "On-site",
  "Politique d’utilisation de l’intelligence artificielle": "AI use policy",
  "Diplôme obtenu ou en cours": "Degree completed or in progress",
  "Équivalence par expérience / certification": "Equivalent qualification through experience / certification",
  "Soumettre le justificatif pour vérification": "Submit evidence for verification",
  "Le badge « Parcours vérifié » n’est attribué qu’après contrôle humain du justificatif. Vous pouvez masquer les informations non nécessaires avant l’envoi.": "The “Verified qualifications” badge is awarded only after a human review of your supporting document. You may hide information that is not needed before submitting it.",
  "Déjà membre ? Connexion": "Déjà membre ? Connexion",
  "INTELLIGENCE DES TALENTS": "TALENT INTELLIGENCE",
  "RÉALISATIONS": "EVIDENCE",
  "ÉVALUATIONS": "ASSESSMENTS",
  "VOTRE UNIVERS PROFESSIONNEL": "YOUR PROFESSIONAL FIELD",
  "VOTRE PROFIL PROFESSIONNEL": "YOUR PROFESSIONAL PROFILE",
  "ESPACE PROFIL": "PROFILE CONSOLE",
  "CONFIGURATION DU PROFIL": "PROFILE CONFIGURATION",
  "Équipe de recrutement": "Recruiting team",
  "Entreprise": "Company",
  "Intelligence des talents": "Talent Intelligence",
  "Début : ": "Start date: ",
  "Durée : ": "Duration: ",
  "Rémunération : ": "Compensation: ",
  "HT / mois / utilisateur": "HT / mois / utilisateur",
  "HT / mois": "HT / mois",
  "VOTRE PROFIL": "VOTRE PROFIL",
  "VOTRE UNIVERS": "VOTRE UNIVERS",
  "preuves associées": "linked evidence",
  "En apprentissage": "Learning",
  "↗ Partager mon profil public": "↗ Share my public profile",
  "↗ Partager mon lien membre": "↗ Share my member link",
  "Votre nom": "Your name",
  "PAS EN RECHERCHE ACTUELLEMENT": "NOT LOOKING RIGHT NOW",
  "En revue humaine": "Under human review",
  "Aucun justificatif soumis.": "No supporting document submitted.",
  "Aucun cas pratique en attente.": "No practical cases awaiting review.",
  "Impossible d’enregistrer le profil.": "Unable to save your profile.",
  "COMPÉTENCE / SIGNAL": "SKILL / SIGNAL",
  "Opérationnel": "Operational",
  "Avancé": "Advanced",
  "Non précisé": "Not specified",
  "COMPÉTENCE DÉCLARÉE": "DECLARED SKILL",
  "élément associé": "linked item",
  "éléments associés": "linked items",
  "Cette compétence fait partie de votre identité professionnelle.": "This skill is part of your professional identity.",
  "Aucune preuve associée pour le moment. Ajoutez un projet, un diplôme ou un exemple de réalisation pour étayer cette compétence.": "No evidence is linked yet. Add a project, qualification or work sample to support this skill.",
  "L’identité de votre entreprise est distincte de votre profil personnel. Les opportunités ne sont visibles qu’après vérification de l’entreprise.": "Your company identity is separate from your personal profile. Opportunities become visible only after the company has been verified.",
  "Votre profil est visible par les membres connectés de ZERILYS. Le mode privé le masque des liens publics et de la découverte anonyme.": "Your profile is visible to signed-in ZERILYS members. Private mode hides it from public links and anonymous discovery.",
  "Votre profil est visible par les membres de ZERILYS et via son lien public. Vous pouvez limiter sa découverte anonyme à tout moment.": "Your profile is visible to ZERILYS members and through its public link. You can limit anonymous discovery at any time.",
  "Au moins un diplôme ou une équivalence a été vérifié par un évaluateur habilité.": "At least one degree or equivalent qualification has been verified by an authorised reviewer.",
  "Aucun diplôme ou équivalence vérifié.": "No degree or equivalent qualification has been verified.",
  "Ajoutez un intitulé professionnel": "Add a professional headline",
  "Localisation non renseignée": "Location not provided",
  "OUVERT AUX OPPORTUNITÉS": "OPEN TO OPPORTUNITIES",
  "OUVERT AUX ÉCHANGES CIBLÉS": "OPEN TO SELECTIVE CONNECTIONS",
  "compétences": "skills",
  "réalisations": "evidence",
  "Démontrez vos compétences.": "Demonstrate your skills.",
  "Cas pratiques · preuves de mise en situation": "Practical cases · applied evidence",
  "Ces exercices sont individualisés. Ils sont examinés par un humain : aucun score automatique ne prétend mesurer votre performance.": "These exercises are tailored to each candidate and reviewed by a person. No automated score claims to measure your performance.",
  "Preuve validée": "Evidence validated",
  "Complément demandé": "Further information requested",
  "Preuve non validée": "Evidence not validated",
  "Revue terminée": "Review completed",
  "Aucun dépôt": "No submission yet",
  "Votre réponse": "Your response",
  "Présentez votre démarche, vos hypothèses, vos calculs ou éléments de preuve, vos limites et vos recommandations…": "Explain your approach, assumptions, calculations or supporting evidence, limitations and recommendations…",
  "Vous pouvez structurer votre réponse avec des titres.": "You may structure your response with headings.",
  "Déclarez votre usage de l’IA": "Declare your use of AI",
  "Je n’ai pas utilisé d’IA": "I did not use AI",
  "J’ai utilisé une IA comme assistance": "I used AI as an aid",
  "Je préfère ne pas répondre": "I prefer not to say",
  "Critères de revue": "Review criteria",
  "Les critères sont communiqués à l’avance. Aucun score automatique n’est attribué.": "The criteria are shared in advance. No automated score is assigned.",
  "Soumettre mon cas ↗": "Submit my case ↗",
  "Annuler": "Cancel",
  "Aucun résultat partagé.": "No results shared.",
  "Vos choix de partage ont été enregistrés.": "Your sharing choices have been saved.",
  "Autorisation de partage retirée.": "Sharing permission withdrawn.",
  "Votre intérêt a été transmis à l’entreprise.": "Your expression of interest has been sent to the company.",
  "Les résultats d’évaluation restent privés. Vous pourrez choisir précisément ceux à partager après l’envoi de votre intérêt.": "Your assessment results remain private. After expressing interest, you can choose exactly which results to share.",
  "Exprimer mon intérêt ↗": "Express interest ↗",
  "Résultats techniques non partagés par le candidat.": "Technical results have not been shared by the candidate.",
  "Revu par un évaluateur": "Reviewed by an assessor",
  "Plan d’évaluation enregistré.": "Assessment plan saved.",
  "Vérification du parcours enregistrée.": "Qualification review saved.",
  "Le serveur n’a pas confirmé l’enregistrement. Réessayez.": "The server did not confirm the save. Please try again.",
  "Votre profil a bien été enregistré et actualisé dans vos espaces.": "Your profile has been saved and updated across your workspaces.",
  "Impossible d’enregistrer votre langue préférée.": "Your language preference could not be saved.",
  "Joignez un justificatif PDF, JPG ou PNG.": "Attach a supporting document in PDF, JPG or PNG format.",
  "Le justificatif doit faire moins de 650 Ko.": "The supporting document must be smaller than 650 KB.",
  "Quel a été votre usage de l’intelligence artificielle pour ce test ?": "How did you use artificial intelligence for this assessment?",
  "Valider mes réponses ↗": "Submit my answers ↗",
  "Impossible d’enregistrer le résultat.": "Unable to save the result.",
  "IA utilisée": "AI used",
  "Aucune IA déclarée": "No AI use declared",
  "Non renseignée": "Not provided",
  "À renforcer": "Needs improvement",
  "Maîtrisé": "Proficient",
  "Très bien maîtrisé": "Highly proficient",
  "Choisir une décision": "Select a decision",
  "Synthèse motivée": "Reasoned summary",
  "ÉQUIVALENCE": "EQUIVALENCY",
  "DIPLÔME": "DEGREE",
  "Graduate programme": "Graduate programme",
  "Already a member? Connexion": "Déjà membre ? Connexion",
  "Finance · AI · Data · Talent": "Finance · IA · Data · Talents",
  "© 2026 ZERILYS. Beyond the CV.": "© 2026 ZERILYS. Au-delà du CV."
});;
  Object.assign(fr, { 'Already a member? Connexion': 'Déjà membre ? Connexion' });
  Object.assign(en, {
    'Already a member? Connexion': 'Already a member? Log in', 'Connexion': 'Log in',
    'Français': 'French', 'IA autorisée pendant les évaluations': 'AI is allowed during assessments',
    'IA non autorisée pendant les évaluations': 'AI is not allowed during assessments',
    'Usage de l’IA attendu et évalué': 'AI use is expected and will be assessed',
    'Cette règle sera affichée au candidat avant sa candidature. Elle concerne les évaluations liées à cette offre, pas l’ensemble du travail dans le poste.': 'This policy is shown to candidates before they apply. It applies to assessments for this opportunity, not to the job itself.',
    'Gestion d’équipe': 'Team management', "Gestion d'équipe": 'Team management',
    'Créer un compte ↗': 'Create account ↗'
  });
  let language = "fr";
  const originalText = new WeakMap();
  const originalAttrs = new WeakMap();
  const exact = (text) => {
    const trimmed = text.trim();
    const translated = language === "fr" ? fr[trimmed] : en[trimmed];
    if (!translated) return text;
    const lead = text.match(/^\s*/)?.[0] || "";
    const tail = text.match(/\s*$/)?.[0] || "";
    return lead + translated + tail;

  };
  const attrs = ["placeholder", "aria-label", "title", "alt"];
  function translateElement(root) {
    // Always walk the tree: switching back to English must restore the exact
    // source strings captured before French translation, including attributes.
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      if (!node.nodeValue || !node.nodeValue.trim() || node.parentElement?.closest("#languageToggle")) continue;
      if (!originalText.has(node)) originalText.set(node, node.nodeValue);
      const source = originalText.get(node);
      const next = exact(source);
      if (next !== node.nodeValue) node.nodeValue = next;
    }
    const elements = root.nodeType === Node.ELEMENT_NODE ? [root, ...root.querySelectorAll("*")] : [...root.querySelectorAll?.("*") || []];
    for (const el of elements) {
      if (el.id === "languageToggle") continue;
      for (const attr of attrs) {
        if (!el.hasAttribute?.(attr)) continue;
        let saved = originalAttrs.get(el);
        if (!saved) { saved = {}; originalAttrs.set(el, saved); }
        if (!(attr in saved)) saved[attr] = el.getAttribute(attr);
        const source = saved[attr];
        const after = exact(source);
        if (after !== el.getAttribute(attr)) el.setAttribute(attr, after);
      }
    }
  }
  function chooseInitialLanguage() {
    let saved = null;
    try { saved = localStorage.getItem(STORAGE_KEY); } catch {}
    if (supported.has(saved)) return saved;
    // French is the product launch language. Browser language must not silently
    // switch a first-time visitor to English; users can still choose English.
    return "fr";
  }
  function setLanguage(next, persist = true, manual = persist) {
    language = supported.has(next) ? next : "fr";
    document.documentElement.lang = language;
    document.title = language === "fr" ? "ZERILYS — Talent Intelligence" : "ZERILYS — Talent Intelligence";
    const description = document.querySelector('meta[name="description"]');
    if (description) description.content = language === "fr" ? "La plateforme spécialisée pour identifier, valoriser et recruter les talents en finance, intelligence artificielle et data." : "The specialist talent platform for finance, AI and data.";
    const select = document.getElementById("languageSelect");
    if (select && select.value !== language) select.value = language;
    const toggle = document.getElementById("languageToggle");
    if (toggle) { toggle.textContent = language === "fr" ? "🇬🇧" : "🇫🇷"; toggle.setAttribute("aria-label", language === "fr" ? "Switch to English" : "Passer en français"); toggle.title = language === "fr" ? "English" : "Français"; }
    if (persist) { try { localStorage.setItem(STORAGE_KEY, language); } catch {} }
    translateElement(document.body);
    document.dispatchEvent(new CustomEvent("zerihlink:languagechange", { detail: { language, manual } }));
  }
  const initial = chooseInitialLanguage();
  const observer = new MutationObserver(records => {
    for (const record of records) {
      if (record.type === "characterData") translateElement(record.target.parentElement || document.body);
      else if (record.type === "attributes") {
        const saved = originalAttrs.get(record.target);
        if (saved && record.attributeName in saved) {
          const current = record.target.getAttribute(record.attributeName);
          const expected = language === "fr" ? exact(saved[record.attributeName]) : saved[record.attributeName];
          if (current !== expected) saved[record.attributeName] = current;
        }
        translateElement(record.target);
      }
      else for (const node of record.addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE) translateElement(node);
        else if (node.nodeType === Node.TEXT_NODE && node.parentElement) translateElement(node.parentElement);
      }
    }
  });
  document.addEventListener("DOMContentLoaded", () => {
    const select = document.getElementById("languageSelect");
    if (select) select.addEventListener("change", () => setLanguage(select.value));
    document.getElementById("languageToggle")?.addEventListener("click", () => setLanguage(language === "fr" ? "en" : "fr"));
    setLanguage(initial, false);
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeOldValue: true, attributeFilter: attrs });
  }, { once: true });
  window.ZERIHLINK_I18N = Object.freeze({ get language() { return language; }, get locale() { return language === "fr" ? "fr-FR" : "en-GB"; }, setLanguage, supported: [...supported], translate: exact });
})();
