# Revue humaine des cas pratiques — alpha.7

## Accès

La file de revue et les décisions sont réservées aux comptes dont l'adresse figure dans `ZERIHLINK_REVIEWER_EMAILS`. L'accès est contrôlé côté serveur à chaque requête. Les candidats et les comptes entreprise ne peuvent pas consulter la file interne.

## Travail du réviseur

Pour chaque dépôt, le réviseur voit le cas et sa version, les paramètres individualisés, la déclaration d'usage de l'IA et la réponse intégrale. Il renseigne chaque critère de la grille avec une appréciation de 1 à 4 et un commentaire factuel d'au moins cinq caractères. Il choisit ensuite une décision — preuve validée, complément demandé ou preuve non validée — et rédige une synthèse motivée d'au moins vingt caractères.

Il n'existe pas de note globale calculée automatiquement. Les critères restent visibles et interprétables séparément. Une décision enregistrée est définitive dans cette version ; une seconde tentative de modification renvoie un conflit. Toute correction ultérieure nécessitera un workflow explicite d'annulation/contre-revue et une piste d'audit dédiée.

## Retour candidat

Le candidat voit l'état de sa revue, la décision, la synthèse, les notes par critère et les commentaires dans son historique privé. Ces informations ne sont pas ajoutées à la sérialisation publique du profil.

## Limites

- Le workflow est une première version interne, pas un processus d'accréditation ni de certification professionnelle.
- La qualité et la cohérence des notes dépendent encore de la formation des réviseurs et de leur calibration.
- Pas encore de contre-revue, d'arbitrage, d'anonymisation des copies ni de partage sélectif avec une entreprise.
- Aucun code candidat n'est exécuté. Les exercices SQL/Python interactifs attendent une isolation dédiée.
- Les tests effectués sont locaux et automatisés ; aucune infrastructure de production n'a été mise en service.
