# Release manifest — 1.9.0-alpha.20

- Version : `1.9.0-alpha.20`
- Positionnement : talents qualifiés Bac+4 à recherche avancée, toutes grandes familles de métiers.
- Évaluations : 9 questionnaires de connaissances versionnés, plus 4 cas pratiques individualisés (finance, commerce, recherche, ingénierie) et une file de revue humaine avec retour candidat.
- Cas pratiques : paramètres individuels côté serveur, consignes et rubriques transparentes, soumission conservée dans l'historique privé du candidat, revue humaine obligatoire, notation critère par critère, commentaire et synthèse motivée ; aucun score automatique global.
- Usage de l'IA : déclaration associée à chaque questionnaire ou cas pratique ; déclarative uniquement, non vérifiée techniquement.
- Opportunités : emploi, stage, alternance, collaboration, graduate programme, VIE et projet de recherche.
- Partage des évaluations : choix explicite par évaluation et par candidature, consentement versionné, révocation immédiate de l’accès futur, aucune exposition des autres résultats privés.
- Vérification des diplômes : dépôt privé d’un justificatif, revue humaine motivée, badge public minimal uniquement après validation ; fichier supprimé du stockage actif après décision. Pas de décision IA.
- Revue des cas pratiques à l’aveugle : identité et déclaration d’usage IA masquées dans la file, référence de dossier opaque, repères communs de notation 1–4 ; les indices auto-identifiants contenus dans une réponse restent possibles.
- Calibration : guide critère par critère pour les quatre cas pratiques ; base éditoriale pilote, pas une validation psychométrique.
- Exercices Python/SQL : dépôt de code avec revue humaine ; passerelle vers un exécuteur externe ajoutée, désactivée par défaut. Aucun code candidat n'est exécuté localement. Aucun runner distant n'est livré ou activé.
- Sécurité runner : HTTPS obligatoire, secret long, délai de 5 secondes, cinq appels/minute/candidat, payload sans identifiant candidat, sorties bornées, filtre SQL défensif. Une sandbox externe éphémère, sans réseau, secrets ou données de production, avec permissions SQL read-only, doit être déployée et auditée avant activation.
- Matching : Match Parcours et Match Technique restent séparés ; aucune note combinée.
- Documents : `BILINGUAL_LANGUAGE_ALPHA15.md`, `CODE_EXERCISES_ALPHA12.md`, `CODE_RUNNER_GATEWAY_ALPHA13.md`, `BLIND_REVIEW_ALPHA10.md`, `QUALIFICATION_VERIFICATION_ALPHA9.md`, `PRACTICAL_REVIEW_WORKFLOW_ALPHA7.md`.
- Langues : français natif par défaut et anglais natif sélectionnable depuis un bouton compact à drapeau britannique ; le drapeau français permet de revenir au français. Les textes statiques, attributs accessibles et contenus dynamiques connus sont traduits dans les deux sens ; la préférence reste enregistrée au compte. Les contenus saisis par les membres ne sont jamais traduits automatiquement.
- Interface : la console d’administration / modération en bas de la page d’accueil a été retirée. Les sections publiques de découverte, collaborations, opportunités et intelligence ont reçu une densité visuelle accrue, des espacements verticaux réduits et une hiérarchie typographique plus compacte. Les API de revue restent protégées côté serveur, mais aucune interface de modération n’est exposée dans cette page.
- Statut : alpha de développement ; pas d'autorisation de lancement public ni de mise en production.
- Commercialisation : aucun processeur de paiement ni abonnement en production n'est activé ; les tarifs restent des hypothèses à valider.
- Commercial status: no payment processor or live subscription is enabled.
- Lancement : inscriptions fermées en production jusqu'aux validations juridiques, sécurité et infrastructure.

- Passerelle runner alpha.16 : redirections refusées, réponse JSON obligatoire et lecture plafonnée à 64 Ko ; les réponses invalides/surdimensionnées échouent de manière fermée.
- Validation alpha.16 : 234/234 tests unitaires passés ; `npm run check` et les smoke tests ciblés (runner, évaluations, HTTP, bêta, cohorte 50, langue, inscriptions, avatar, sauvegardes, export/migration PostgreSQL, intégrité, préflight, vérification locale et e-mail) réussis individuellement. Le lanceur global `npm run test:release` atteint sa limite d’exécution après le PASS du dernier smoke HTTP ; son code de sortie global n’est donc pas certifié.


- Conservation alpha.17 : purge au démarrage des sessions et jetons d'authentification expirés ; retrait des hashes de secrets d'invitations inutilisables ; purge des métadonnées d'invitations anciennes après 90 jours. Les données de profil, candidatures, évaluations, justificatifs et audits ne sont pas purgées automatiquement faute de calendrier juridique validé.
- Portabilité alpha.17 : export de compte JSON v1.1 incluant l'historique privé des évaluations, les vérifications de diplôme et les justificatifs encore stockés (Base64 + format + empreinte SHA-256).
- Préparation commerciale alpha.17 : guide de pilotes concierge, segment initial finance/risque, data/IA et ingénierie, protocole de mesure de pertinence et critères de décision avant tarification publique.
- Validation alpha.17 : 239/239 tests unitaires réussis ; `npm run check` et smokes général, évaluations, bêta, cohorte 50, langue, sauvegardes, export/migration PostgreSQL, intégrité, préflight, vérification locale, e-mail et durcissement HTTP réussis individuellement.

- Project Labs alpha.18 : typologie des projets collectif, pédagogique, recherche et défi d'entreprise ; fiches enrichies avec durée, taille d'équipe, compétences, livrables et compensation.
- Protection des candidats alpha.18 : un défi d'entreprise commercial ne peut être publié sans rémunération ou prise en charge des frais explicitement déclarée.
- Constitution d'équipe alpha.18 : le créateur occupe une place ; le serveur refuse les acceptations qui dépasseraient la capacité maximale déclarée.
- Interface alpha.18 : cartes projets enrichies, formulaire de création structuré et libellés français natifs pour les catégories, durées, capacités et compensations.
- Validation alpha.18 : 244/244 tests unitaires réussis ; `npm run check` réussi ; smokes général, évaluations, bêta, avatars, cohortes 50, langue, limitation d’inscription, sauvegardes, export/migration PostgreSQL, intégrité, préflight, acceptation locale, e-mail et durcissement HTTP réussis individuellement. La séquence complète a atteint sa limite d’exécution après le smoke d’acceptation locale ; les deux derniers smokes e-mail et HTTP ont ensuite été exécutés séparément et ont réussi.

- Project Labs alpha.19 : tableau de tâches privé par équipe avec attribution, échéance et statut ; accès réservé au propriétaire et aux membres acceptés ; réattribution réservée au propriétaire ; limite de 200 tâches ; journal d'audit ; tâches exclues des listes publiques.
- Validation alpha.19 : 247 tests unitaires, dont 3 nouveaux tests Project Labs ; contrôles de syntaxe et smokes à finaliser avant distribution.

- Project Labs alpha.20 : formulaire de création bilingue, espace projet interactif, consultation des candidatures réservée au propriétaire, acceptation/refus depuis l'interface, tableau de tâches privé pour les équipes constituées, création de tâches, attribution, échéances et suivi des statuts. Les tâches ne sont jamais exposées dans les listes publiques.
- Validation alpha.20 : 249/249 tests unitaires réussis ; contrôle syntaxique réussi. Les smokes de release doivent être exécutés avant toute ouverture publique.
