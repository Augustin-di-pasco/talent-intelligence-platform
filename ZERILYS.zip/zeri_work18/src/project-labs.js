const PROJECT_TYPES = new Set(['community','learning','research','company_challenge']);
const COMMITMENTS = new Set(['few_hours','part_time','full_time']);
const COMPENSATION = new Set(['not_applicable','unpaid_learning','paid','equity','expenses']);
const clean = (value, max) => String(value ?? '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, max);

export function normalizeProjectInput(input = {}, owner = {}) {
  const title = clean(input.title, 100);
  const description = clean(input.description, 1500);
  if (title.length < 5 || description.length < 30) return { error: 'PROJECT_DETAILS_REQUIRED' };
  const type = PROJECT_TYPES.has(input.projectType) ? input.projectType : 'community';
  if (type === 'company_challenge' && owner.accountType !== 'company') return { error: 'COMPANY_ACCOUNT_REQUIRED' };
  const compensation = COMPENSATION.has(input.compensation) ? input.compensation : (type === 'learning' ? 'unpaid_learning' : 'not_applicable');
  if (type === 'company_challenge' && compensation !== 'paid' && compensation !== 'expenses') {
    return { error: 'COMMERCIAL_CHALLENGE_MUST_BE_COMPENSATED', message: 'Un défi produisant une valeur commerciale pour une entreprise doit prévoir une rémunération ou une compensation explicite.' };
  }
  const maxTeamSize = Number.isInteger(input.maxTeamSize) ? Math.max(2, Math.min(20, input.maxTeamSize)) : 5;
  const durationWeeks = Number.isInteger(input.durationWeeks) ? Math.max(1, Math.min(52, input.durationWeeks)) : null;
  const skills = [...new Set((Array.isArray(input.skills) ? input.skills : []).slice(0, 12).map(x => clean(x, 50)).filter(Boolean))];
  const deliverables = [...new Set((Array.isArray(input.deliverables) ? input.deliverables : []).slice(0, 8).map(x => clean(x, 120)).filter(Boolean))];
  return { project: {
    title, description, projectType: type, compensation,
    commitment: COMMITMENTS.has(input.commitment) ? input.commitment : 'part_time',
    durationWeeks, maxTeamSize, skills, deliverables,
    ownerType: owner.accountType === 'company' ? 'company' : 'member',
    status: 'open', createdAt: new Date().toISOString(),
  } };
}

export function canAcceptProjectApplication(project, applications = [], applicationId) {
  const max = Number.isInteger(project?.maxTeamSize) ? project.maxTeamSize : 5;
  const accepted = applications.filter(item => item.projectId === project.id && item.status === 'accepted' && item.id !== applicationId).length;
  return accepted < Math.max(1, max - 1); // the owner occupies one team seat
}

export function normalizeProjectTask(input = {}, project, actorId, members = []) {
  const title = clean(input.title, 100);
  const description = clean(input.description, 500);
  if (title.length < 3) return { error: 'TASK_TITLE_REQUIRED' };
  const assigneeId = input.assigneeId ? String(input.assigneeId) : actorId;
  if (!members.includes(assigneeId)) return { error: 'TASK_ASSIGNEE_NOT_IN_TEAM' };
  let dueDate = null;
  if (input.dueDate) {
    const parsed = new Date(input.dueDate);
    if (Number.isNaN(parsed.getTime())) return { error: 'INVALID_TASK_DUE_DATE' };
    dueDate = parsed.toISOString();
  }
  return { task: { id: input.id || null, title, description, assigneeId, status: 'todo', dueDate, createdBy: actorId, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } };
}

export function canManageProjectTask(task, actorId, ownerId) {
  return actorId === ownerId || task?.createdBy === actorId || task?.assigneeId === actorId;
}
