
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const empty = () => ({ users: [], sessions: [], emailVerificationTokens: [], projects: [], applications: [], evidence: [], connections: [], reports: [], blocks: [], companies: [], offers: [], offerApplications: [], notifications: [], companyMembers: [], companyInvitations: [], betaInvitations: [], betaFeedback: [], passwordResets: [], audit: [] });

export class Store {
  static async open(dir) {
    const store = new Store(dir);
    if (process.env.ZERIHLINK_STORAGE === "postgres") await store.connectPostgres();
    return store;
  }
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, "zerihlink.json");
    fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(this.file)) fs.writeFileSync(this.file, JSON.stringify(empty(), null, 2));
    this.state = JSON.parse(fs.readFileSync(this.file, "utf8"));
    for (const k of Object.keys(empty())) this.state[k] ??= [];
    // Backward-compatible account and avatar migrations.
    let migrated=false;
    this.avatarDir=path.join(dir,"avatars");
    for (const user of this.state.users) {
      user.accountType ??= "candidate";
      user.preferredLanguage ??= null;
      user.emailVerifiedAt ??= null;
      user.experiences ??= [];
      user.education ??= [];
      user.qualificationVerifications ??= [];
      user.achievements ??= [];
      user.assessments ??= [];
      user.missions ??= [];
      user.companyName ??= "";
      user.companyIndustry ??= "";
      user.companyWebsite ??= "";
      if(user.accountType==="company") user.companyVerification ??= {status:"unverified"};
      if(typeof user.avatarDataUrl==="string"&&!user.avatarFile){
        const match=user.avatarDataUrl.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
        if(match){
          const bytes=Buffer.from(match[2],"base64"),ext={jpeg:"jpg",png:"png",webp:"webp"}[match[1]];
          const valid=match[1]==="jpeg"?bytes.subarray(0,3).equals(Buffer.from([0xff,0xd8,0xff])):match[1]==="png"?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):bytes.subarray(0,4).toString()==="RIFF"&&bytes.subarray(8,12).toString()==="WEBP";
          if(valid&&bytes.length>=100&&bytes.length<=520000){
            fs.mkdirSync(this.avatarDir,{recursive:true,mode:0o700});
            const key=crypto.randomUUID(),filename=`${key}.${ext}`,tmp=path.join(this.avatarDir,filename+".tmp");
            fs.writeFileSync(tmp,bytes,{mode:0o600,flag:"wx"});fs.renameSync(tmp,path.join(this.avatarDir,filename));user.avatarFile=filename;
          }
        }
        delete user.avatarDataUrl;migrated=true;
      }
    }
    if(migrated)this.saveLocal();
    this.pool = null;
    this.revision = 1;
    this.saveQueue = Promise.resolve();
  }
  async connectPostgres() {
    if (!process.env.DATABASE_URL) throw new Error("ZERIHLINK_STORAGE=postgres exige DATABASE_URL.");
    const { Pool } = await import("pg");
    this.pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: true }, max: 5, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000, application_name: "zerihlink" });
    await this.pool.query(`CREATE TABLE IF NOT EXISTS zerihlink_runtime_state (singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton), state jsonb NOT NULL, revision bigint NOT NULL DEFAULT 1, updated_at timestamptz NOT NULL DEFAULT now())`);
    const result = await this.pool.query("SELECT state, revision FROM zerihlink_runtime_state WHERE singleton = true");
    if (result.rowCount) {
      this.state = result.rows[0].state;
      for (const key of Object.keys(empty())) this.state[key] ??= [];
      this.revision = Number(result.rows[0].revision);
    } else {
      await this.pool.query("INSERT INTO zerihlink_runtime_state(singleton,state,revision) VALUES(true,$1::jsonb,1) ON CONFLICT(singleton) DO NOTHING", [JSON.stringify(this.state)]);
      const fresh = await this.pool.query("SELECT state, revision FROM zerihlink_runtime_state WHERE singleton = true");
      this.state = fresh.rows[0].state;
      for (const key of Object.keys(empty())) this.state[key] ??= [];
      this.revision = Number(fresh.rows[0].revision);
    }
    console.log(`ZERILYS storage: PostgreSQL (revision ${this.revision})`);
  }
  saveLocal() {
    const tmp = this.file + "." + crypto.randomUUID() + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(this.state, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, this.file);
  }
  save() {
    const snapshot = JSON.stringify(this.state);
    if (!this.pool) { this.saveLocal(); return Promise.resolve(); }
    this.saveQueue = this.saveQueue.catch(() => {}).then(async () => {
      const expectedRevision = this.revision;
      const result = await this.pool.query("UPDATE zerihlink_runtime_state SET state=$1::jsonb, revision=revision+1, updated_at=now() WHERE singleton=true AND revision=$2 RETURNING revision", [snapshot, expectedRevision]);
      if (!result.rowCount) throw new Error(`PostgreSQL runtime state row is missing or revision changed (expected ${expectedRevision}); refusing to overwrite a newer snapshot. Restart this instance to reload the authoritative state.`);
      this.revision = Number(result.rows[0].revision);
      this.saveLocal();
    });
    return this.saveQueue;
  }
  async close() { if (this.pool) await this.pool.end(); }
  audit(actorId, action, targetType, targetId, metadata={}) {
    const previous = this.state.audit.at(-1)?.hash || "GENESIS";
    const entry = { id: crypto.randomUUID(), actorId: actorId || null, action, targetType, targetId, metadata, at: new Date().toISOString(), previous };
    entry.hash = crypto.createHash("sha256").update(JSON.stringify(entry)).digest("hex");
    this.state.audit.push(entry);
    if (this.state.audit.length > 10000) this.state.audit.shift();
  }
  userByEmail(email) { return this.state.users.find(u => u.email === email.toLowerCase()); }
  publicUser(u) {
    if (!u) return null;
    const { passwordHash, passwordSalt, email, ...safe } = u;
    return safe;
  }
}
