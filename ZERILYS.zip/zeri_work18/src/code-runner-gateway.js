import crypto from 'node:crypto';

const MAX_SOURCE = 12_000;
const MAX_RUNNER_RESPONSE_BYTES = 64 * 1024;
const ALLOWED = new Map([
  ['python-data-cleaning-code', { language: 'python', version: '1.0.0' }],
  ['sql-analytics-query-code', { language: 'sql', version: '1.0.0' }],
]);

export function runnerConfiguration(env = process.env) {
  const rawUrl = String(env.ZERIHLINK_RUNNER_URL || '').trim();
  const token = String(env.ZERIHLINK_RUNNER_TOKEN || '');
  if (!rawUrl && !token) return { enabled: false, reason: 'RUNNER_NOT_CONFIGURED' };
  if (!rawUrl || token.length < 32) return { enabled: false, reason: 'RUNNER_CONFIGURATION_INCOMPLETE' };
  let url;
  try { url = new URL(rawUrl); } catch { return { enabled: false, reason: 'RUNNER_URL_INVALID' }; }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) {
    return { enabled: false, reason: 'RUNNER_URL_MUST_BE_HTTPS' };
  }
  return { enabled: true, url: url.toString().replace(/\/$/, ''), token };
}

export function validateCodeRun({ slug, language, source }) {
  const exercise = ALLOWED.get(String(slug || ''));
  if (!exercise) return { error: 'CODE_EXERCISE_NOT_FOUND' };
  if (language !== exercise.language) return { error: 'CODE_LANGUAGE_MISMATCH' };
  if (typeof source !== 'string' || source.trim().length < 1) return { error: 'CODE_REQUIRED' };
  if (source.length > MAX_SOURCE) return { error: 'CODE_TOO_LONG' };
  if (language === 'sql' && /\b(insert|update|delete|drop|alter|create|replace|attach|detach|pragma|vacuum|load_extension|grant|revoke|truncate)\b/i.test(source)) {
    return { error: 'SQL_READ_ONLY_POLICY', message: 'Seules les requêtes analytiques en lecture sont autorisées.' };
  }
  return { exercise, source };
}

function boundedText(value, max) {
  return typeof value === 'string' ? value.slice(0, max) : '';
}

async function readBoundedJson(response) {
  const contentType = String(response.headers?.get?.('content-type') || '').toLowerCase();
  if (!contentType.includes('application/json')) throw new Error('RUNNER_CONTENT_TYPE_INVALID');
  const declaredLength = Number(response.headers?.get?.('content-length'));
  if (Number.isFinite(declaredLength) && declaredLength > MAX_RUNNER_RESPONSE_BYTES) throw new Error('RUNNER_RESPONSE_TOO_LARGE');
  if (!response.body?.getReader) throw new Error('RUNNER_BODY_UNAVAILABLE');
  const reader = response.body.getReader();
  const chunks = []; let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_RUNNER_RESPONSE_BYTES) { await reader.cancel(); throw new Error('RUNNER_RESPONSE_TOO_LARGE'); }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock?.(); }
  try { return JSON.parse(Buffer.concat(chunks, total).toString('utf8')); }
  catch { throw new Error('RUNNER_JSON_INVALID'); }
}

export async function executeInIsolatedRunner({ slug, language, source, variant, env = process.env, fetchImpl = fetch }) {
  const config = runnerConfiguration(env);
  if (!config.enabled) return { error: config.reason || 'RUNNER_UNAVAILABLE', status: 503 };
  const valid = validateCodeRun({ slug, language, source });
  if (valid.error) return { error: valid.error, message: valid.message, status: 400 };
  const jobId = crypto.randomUUID();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5_000);
  try {
    const response = await fetchImpl(`${config.url}/v1/execute`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${config.token}` },
      body: JSON.stringify({
        jobId,
        exercise: { slug, version: valid.exercise.version, language },
        source,
        fixtureVariant: variant,
        limits: { wallTimeMs: 3_000, cpuTimeMs: 2_000, memoryMb: 128, pids: 32, outputBytes: 16_384, network: false, filesystem: 'ephemeral-readonly-fixture' },
      }),
      signal: controller.signal,
      redirect: 'error',
    });
    if (!response.ok) return { error: 'RUNNER_REJECTED', status: 502 };
    let result;
    try { result = await readBoundedJson(response); }
    catch { return { error: 'RUNNER_INVALID_RESPONSE', status: 502 }; }
    if (!result || result.jobId !== jobId || !['completed', 'timeout', 'rejected'].includes(result.status)) return { error: 'RUNNER_INVALID_RESPONSE', status: 502 };
    const tests = Array.isArray(result.tests) ? result.tests.slice(0, 30).map(t => ({ name: boundedText(t?.name, 120), passed: t?.passed === true })) : [];
    return { result: { status: result.status, stdout: boundedText(result.stdout, 16_384), stderr: boundedText(result.stderr, 4_000), tests, durationMs: Number.isFinite(result.durationMs) ? Math.max(0, Math.min(3_000, result.durationMs)) : null } };
  } catch (error) {
    return { error: error?.name === 'AbortError' ? 'RUNNER_TIMEOUT' : 'RUNNER_UNAVAILABLE', status: 503 };
  } finally {
    clearTimeout(timeout);
  }
}
