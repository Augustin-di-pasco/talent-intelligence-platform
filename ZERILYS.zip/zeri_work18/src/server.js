
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { Store } from "./store.js";
import { inspectStore } from "./data-integrity.js";
import { emailDeliveryConfig, sendTransactionalEmail } from "./email-delivery.js";
const escapeHtml = value => String(value??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;");
import { hashPassword, verifyPassword, token, id, cleanText, emailValid } from "./security.js";
import { complementarity } from "./matching.js";
import { profileMatchesQuery } from "./skill-intelligence.js";
import { assessmentCatalog, gradeAssessment, recommendAssessments, practicalCaseCatalog, getPracticalCase, submitPracticalCase, reviewPracticalCase, blindPracticalReviewPayload } from "./assessment-engine.js";
import { matchOpportunity } from "./dual-match.js";
import { executeInIsolatedRunner } from "./code-runner-gateway.js";
import { cleanupExpiredData } from "./data-retention.js";
import { normalizeProjectInput, canAcceptProjectApplication, normalizeProjectTask, canManageProjectTask } from "./project-labs.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const DATA = path.resolve(process.env.ZERIHLINK_DATA_DIR || process.env.NEXUS_DATA_DIR || path.join(ROOT, "data"));
const PORT = Number(process.env.PORT || 8787);
const SESSION_SECRET = process.env.ZERIHLINK_SESSION_SECRET || process.env.NEXUS_SESSION_SECRET || "development-only-change-this-secret-before-launch-2026";
const HOST = process.env.HOST || (process.env.NODE_ENV === "production" ? "0.0.0.0" : "127.0.0.1");
const VERSION = "1.9.0-alpha.20";
const BETA_TERMS_VERSION = "0.1";
const PRIVACY_NOTICE_VERSION = "0.1";
// Local-only beta testing switch. It is deliberately ignored in production.
// Public production registration remains gated by the explicit legal approval flag.
const LOCAL_BETA_TEST_MODE = process.env.NODE_ENV !== "production" && process.env.ZERIHLINK_LOCAL_BETA_TEST_MODE === "true";
const BETA_LEGAL_APPROVED = process.env.ZERIHLINK_BETA_LEGAL_APPROVED === "true" || LOCAL_BETA_TEST_MODE;
const ALLOW_SIGNUP = LOCAL_BETA_TEST_MODE || (process.env.ZERIHLINK_ALLOW_SIGNUP ?? process.env.NEXUS_ALLOW_SIGNUP) === "true";
if (process.env.NODE_ENV === "production" && (SESSION_SECRET.length < 32 || SESSION_SECRET.startsWith("development-only"))) {
  throw new Error("ZERIHLINK_SESSION_SECRET must be a unique secret of at least 32 characters in production.");
}
const LOCK_FILE = path.join(DATA, ".zerihlink.lock");
function acquireInstanceLock() {
  fs.mkdirSync(DATA,{recursive:true});
  if(fs.existsSync(LOCK_FILE)) {
    let existing=null;
    try{existing=JSON.parse(fs.readFileSync(LOCK_FILE,"utf8"));}catch{}
    if(existing?.pid) {
      try{process.kill(existing.pid,0);throw new Error(`Another ZERILYS instance is already using this data directory (PID ${existing.pid}).`);}
      catch(e){if(e.code!=="ESRCH")throw e;}
    } else {
      throw new Error("A ZERILYS data lock exists but cannot be validated. Inspect and remove it manually only after confirming no instance is running.");
    }
    try{fs.unlinkSync(LOCK_FILE);}catch{}
  }
  let fd;
  try{fd=fs.openSync(LOCK_FILE,"wx",0o600);}catch(e){if(e.code==="EEXIST")throw new Error("Another ZERILYS instance is acquiring this data directory.");throw e;}
  fs.writeFileSync(fd,JSON.stringify({pid:process.pid,startedAt:new Date().toISOString()}));
  fs.closeSync(fd);
  const release=()=>{try{const current=JSON.parse(fs.readFileSync(LOCK_FILE,"utf8"));if(current.pid===process.pid)fs.unlinkSync(LOCK_FILE);}catch{}};
  process.on("exit",release);
  process.on("SIGINT",()=>process.exit(130));
  process.on("SIGTERM",()=>process.exit(143));
}
acquireInstanceLock();
const store = await Store.open(DATA);
const retentionCleanup = cleanupExpiredData(store);
if (retentionCleanup.changed) await store.save();
const REVIEWERS = new Set((process.env.ZERIHLINK_REVIEWER_EMAILS || process.env.NEXUS_REVIEWER_EMAILS || "").split(",").map(x=>x.trim().toLowerCase()).filter(Boolean));
const rateBuckets = new Map();
const codeRunBuckets = new Map();
const SAFE_METHODS = new Set(["GET","HEAD","OPTIONS"]);
function clientAddress(req) {
  if(process.env.ZERIHLINK_TRUST_PROXY==="true") {
    const forwarded=String(req.headers["x-forwarded-for"]||"").split(",").map(x=>x.trim()).filter(Boolean);
    const candidate=forwarded.at(-1);
    if(candidate&&candidate.length<=64&&/^[0-9a-fA-F:.]+$/.test(candidate)) return candidate;
  }
  return req.socket.remoteAddress||"unknown";
}
function rateLimit(req, res) {
  const key = `${clientAddress(req)}:${req.method}:${new URL(req.url,"http://localhost").pathname}`;
  const now = Date.now(), bucket = rateBuckets.get(key) || { start: now, count: 0 };
  if (now - bucket.start > 60_000) { bucket.start = now; bucket.count = 0; }
  bucket.count++; rateBuckets.set(key,bucket);
  const requestPath=new URL(req.url,"http://localhost").pathname;
  const limit=requestPath==="/api/auth/register"?20:(key.includes("/auth/") || key.includes("/password") ? 8 : 120);
  if (bucket.count > limit) { json(res,429,{error:"RATE_LIMITED",message:"Trop de requêtes. Réessaie dans une minute."}); return false; }
  if (rateBuckets.size > 5000) for (const [k,v] of rateBuckets) if (now-v.start > 120_000) rateBuckets.delete(k);
  return true;
}
function csrfCookie(res) { const value=token(); const secure=process.env.NODE_ENV==="production"?"; Secure":""; res.setHeader("Set-Cookie",`zerihlink_csrf=${value}; SameSite=Strict; Path=/; Max-Age=86400${secure}`); return value; }
function validCsrf(req) { const c=cookie(req,"zerihlink_csrf"), h=req.headers["x-csrf-token"]; return !!c && !!h && c.length===h.length && crypto.timingSafeEqual(Buffer.from(c),Buffer.from(h)); }
const mime = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".svg":"image/svg+xml",".png":"image/png",".ico":"image/x-icon"};

function json(res, status, body) {
  res.writeHead(status, {"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let raw="", size=0;
    req.on("data", chunk=>{ size += chunk.length; if(size > 1024*1024){ reject(new Error("BODY_TOO_LARGE")); req.destroy(); } else raw += chunk; });
    req.on("end",()=>{ try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error("INVALID_JSON")); } });
    req.on("error",reject);
  });
}
function cookie(req, name) {
  const part=(req.headers.cookie||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(name+"="));
  return part ? decodeURIComponent(part.slice(name.length+1)) : "";
}
function sign(value) { return crypto.createHmac("sha256",SESSION_SECRET).update(value).digest("base64url"); }
function sessionCookie(raw) {
  const payload = Buffer.from(JSON.stringify({raw, exp:Date.now()+1000*60*60*24*14})).toString("base64url");
  return payload+"."+sign(payload);
}
function currentSession(req) {
  const c=cookie(req,"zerihlink_session"); if(!c) return null;
  const [payload,sig]=c.split(".");
  if(!payload || !sig) return null;
  const expected=Buffer.from(sign(payload)), supplied=Buffer.from(sig);
  if(supplied.length!==expected.length || !crypto.timingSafeEqual(supplied,expected)) return null;
  try {
    const data=JSON.parse(Buffer.from(payload,"base64url").toString());
    if(data.exp<Date.now()) return null;
    const hash=crypto.createHash("sha256").update(data.raw).digest("hex");
    const session=store.state.sessions.find(x=>x.tokenHash===hash);
    if(!session || session.expiresAt<Date.now()) return null;
    return session;
  } catch { return null; }
}
function currentUser(req) {
  const session=currentSession(req);
  return session?store.state.users.find(u=>u.id===session.userId)||null:null;
}
function addSession(userId, raw) {
  const now=Date.now();
  store.state.sessions=store.state.sessions.filter(x=>x.expiresAt>now);
  const own=store.state.sessions.filter(x=>x.userId===userId).sort((a,b)=>(a.createdAt||"").localeCompare(b.createdAt||""));
  while(own.length>=10){const oldest=own.shift();store.state.sessions=store.state.sessions.filter(x=>x.id!==oldest.id);}
  const session={id:id(),userId,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),expiresAt:now+1000*60*60*24*14,createdAt:new Date(now).toISOString()};
  store.state.sessions.push(session);
  return session;
}
function hasLegalConsent(user) {
  return user?.legalConsent?.termsVersion===BETA_TERMS_VERSION&&user?.legalConsent?.privacyVersion===PRIVACY_NOTICE_VERSION;
}
function requireUser(req,res) {
  const u=currentUser(req);
  if(!u){ json(res,401,{error:"AUTH_REQUIRED",message:"Connecte-toi pour continuer."}); return null; }
  const pathname=new URL(req.url,"http://localhost").pathname;
  const consentException=(pathname==="/api/me"&&["GET","DELETE"].includes(req.method))||(pathname==="/api/me/consent"&&req.method==="POST")||(pathname==="/api/me/export"&&req.method==="GET")||(pathname==="/api/auth/logout"&&req.method==="POST");
  if(!hasLegalConsent(u)&&!consentException){
    json(res,428,{error:"LEGAL_CONSENT_REQUIRED",message:"Accept the current beta terms and privacy notice to continue."});return null;
  }
  return u;
}
function publicProfile(u) {
  if (!u) return null;
  const evidence = store.state.evidence.filter(e=>e.userId===u.id);
  const skills = (u.skills||[]).map(skill => { const linked=evidence.filter(e=>e.skillId===skill.id); return {...skill, evidenceCount:linked.length, verifiedEvidenceCount:linked.filter(e=>e.status==="verified").length}; });
  const {legalConsent,companyVerification,preferredLanguage,emailVerifiedAt,assessments,qualificationVerifications,...profile}=store.publicUser(u);
  const avatarUrl=u.avatarFile?`/api/media/avatars/${encodeURIComponent(u.id)}?v=${encodeURIComponent(u.updatedAt||"")}`:null;
  const qualificationBadge=(u.qualificationVerifications||[]).some(x=>x.status==="verified");
  return {...profile,avatarUrl,skills,evidenceCount:evidence.length,qualificationBadge};
}
function avatarDataUrlForExport(user){
  if(!user)return null;
  if(typeof user.avatarDataUrl==="string")return user.avatarDataUrl;
  if(!user.avatarFile||! /^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(user.avatarFile))return null;
  const file=path.join(store.avatarDir,user.avatarFile);
  if(!fs.existsSync(file))return null;
  const ext=path.extname(file).slice(1),mime=ext==="jpg"?"jpeg":ext;
  return `data:image/${mime};base64,${fs.readFileSync(file).toString("base64")}`;
}
function companyRole(user, companyId) {
  if (!user || !companyId) return null;
  if (user.id === companyId && user.accountType === "company") return "owner";
  const membership = store.state.companyMembers.find(m => m.companyId === companyId && m.userId === user.id && m.status === "active");
  return membership?.role || null;
}
function companyCanRead(user, companyId) {
  return ["owner","recruiter","viewer"].includes(companyRole(user, companyId));
}
function companyCanRecruit(user, companyId) {
  return ["owner","recruiter"].includes(companyRole(user, companyId));
}
function matchScore(a,b) {
  const mine=new Set((a.skills||[]).map(s=>s.name.toLowerCase()));
  const theirs=(b.skills||[]).map(s=>s.name.toLowerCase());
  const overlap=theirs.filter(x=>mine.has(x)).length;
  return Math.round((overlap/Math.max(1,new Set([...mine,...theirs]).size))*100);
}
async function issueEmailVerification(user) {
  const config=emailDeliveryConfig();
  if(!config.configured)return {enabled:false,sent:false,verified:!!user.emailVerifiedAt};
  const raw=token(),now=Date.now();
  store.state.emailVerificationTokens=store.state.emailVerificationTokens.filter(x=>x.userId!==user.id&&x.expiresAt>Date.now());
  store.state.emailVerificationTokens.push({id:id(),userId:user.id,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),createdAt:new Date(now).toISOString(),expiresAt:now+24*60*60*1000});
  await store.save();
  const link=`${config.appUrl.replace(/\/+$/ ,"")}/?verifyEmail=${encodeURIComponent(raw)}`;
  const text=`Bienvenue sur ZERILYS.

Pour confirmer votre adresse e-mail, ouvrez ce lien : ${link}

Ce lien est valable 24 heures. Si vous n’avez pas créé ce compte, ignorez ce message.`;
  const html=`<p>Bienvenue sur ZERILYS.</p><p><a href="${escapeHtml(link)}">Confirmer mon adresse e-mail</a></p><p>Ce lien est valable 24 heures. Si vous n’avez pas créé ce compte, ignorez ce message.</p>`;
  try {
    await sendTransactionalEmail({to:user.email,subject:"Confirmez votre adresse e-mail — ZERILYS",text,html});
    store.audit(user.id,"auth.email_verification.sent","user",user.id);await store.save();
    return {enabled:true,sent:true,verified:!!user.emailVerifiedAt};
  } catch {
    store.audit(user.id,"auth.email_verification.delivery_failed","user",user.id);await store.save();
    return {enabled:true,sent:false,verified:!!user.emailVerifiedAt};
  }
}
async function api(req,res,url) {
  const method=req.method, p=url.pathname;
  if(method==="GET" && p==="/api/health") return json(res,200,{ok:true,service:"ZERILYS",version:VERSION,storage:process.env.ZERIHLINK_STORAGE === "postgres" ? "postgres" : "json",time:new Date().toISOString()});
  if(method==="GET" && p==="/api/config") { const csrf=csrfCookie(res); return json(res,200,{signupEnabled:ALLOW_SIGNUP,inviteRequired:false,personalInvitationsEnabled:true,betaTermsVersion:BETA_TERMS_VERSION,privacyNoticeVersion:PRIVACY_NOTICE_VERSION,betaLegalApproved:BETA_LEGAL_APPROVED,emailDeliveryConfigured:emailDeliveryConfig().configured,emailVerificationEnabled:emailDeliveryConfig().configured,csrfToken:csrf,productName:"ZERILYS",version:VERSION}); }
  if(method==="POST" && p==="/api/auth/register") {
    if(!ALLOW_SIGNUP) return json(res,403,{error:"SIGNUP_CLOSED"});
    if(!BETA_LEGAL_APPROVED) return json(res,503,{error:"BETA_LEGAL_REVIEW_PENDING",message:"Registration is paused until the beta terms and privacy notice have been legally approved."});
    const b=await readBody(req), email=cleanText(b.email,254).toLowerCase(), password=String(b.password||"");
    if(b.betaTermsAccepted!==true||b.privacyNoticeAcknowledged!==true) return json(res,400,{error:"LEGAL_CONSENT_REQUIRED",message:"You must accept the beta terms and acknowledge the privacy notice."});
    const personalToken=String(b.betaInvitationToken||"").trim();
    let betaInvitation=null;
    if(personalToken){
      const tokenHash=crypto.createHash("sha256").update(personalToken).digest("hex");
      betaInvitation=store.state.betaInvitations.find(i=>i.tokenHash===tokenHash&&i.status==="pending");
      if(!betaInvitation||betaInvitation.expiresAt<Date.now()) return json(res,403,{error:"BETA_INVITATION_INVALID",message:"Cette invitation personnelle est invalide, expirée ou déjà utilisée."});
      if(betaInvitation.email!==email) return json(res,403,{error:"BETA_INVITATION_EMAIL_MISMATCH",message:"Cette invitation est réservée à une autre adresse e-mail."});
    }
    if(!emailValid(email)) return json(res,400,{error:"INVALID_EMAIL",message:"Adresse e-mail invalide."});
    if(password.length<12 || password.length>128) return json(res,400,{error:"WEAK_PASSWORD",message:"Choisis un mot de passe de 12 à 128 caractères."});
    if(store.userByEmail(email)) return json(res,409,{error:"EMAIL_EXISTS",message:"Cette adresse possède déjà un compte."});
    const now=new Date().toISOString(),h=hashPassword(password),accountType=betaInvitation?.accountType||(["candidate","company"].includes(b.accountType)?b.accountType:"candidate"), user={id:id(),email,passwordHash:h.hash,passwordSalt:h.salt,legalConsent:{termsVersion:BETA_TERMS_VERSION,termsAcceptedAt:now,privacyVersion:PRIVACY_NOTICE_VERSION,privacyAcknowledgedAt:now},createdAt:now,updatedAt:now,name:cleanText(b.name,80)||"Nouveau membre",headline:"",location:"",about:"",website:"",visibility:"private",preferredLanguage:null,emailVerifiedAt:null,skills:[],experiences:[],education:[],achievements:[],assessments:[],missions:[],availability:"open",verified:false,accountType,companyVerification:accountType==="company"?{status:"unverified"}:null,companyName:cleanText(b.companyName,100),companyIndustry:cleanText(b.companyIndustry,100),companyWebsite:cleanText(b.companyWebsite,200)};
    store.state.users.push(user);
    if(betaInvitation){betaInvitation.status="accepted";betaInvitation.acceptedBy=user.id;betaInvitation.acceptedAt=new Date().toISOString();delete betaInvitation.tokenHash;}
    const raw=token(); addSession(user.id,raw);
    store.audit(user.id,"account.created","user",user.id); await store.save();
    const emailVerification=await issueEmailVerification(user);
    res.setHeader("Set-Cookie",`zerihlink_session=${encodeURIComponent(sessionCookie(raw))}; HttpOnly; SameSite=Strict; Path=/; Max-Age=1209600${process.env.NODE_ENV==="production"?"; Secure":""}`);
    return json(res,201,{user:publicProfile(user),emailVerification});
  }
  if(method==="POST" && p==="/api/auth/email-verification/confirm") {
    const b=await readBody(req),raw=String(b.token||"");
    if(raw.length<32||raw.length>256)return json(res,400,{error:"INVALID_EMAIL_VERIFICATION_TOKEN",message:"Ce lien de confirmation est invalide ou expiré."});
    const hash=crypto.createHash("sha256").update(raw).digest("hex"),entry=store.state.emailVerificationTokens.find(x=>x.tokenHash===hash&&x.expiresAt>Date.now());
    if(!entry)return json(res,400,{error:"INVALID_EMAIL_VERIFICATION_TOKEN",message:"Ce lien de confirmation est invalide ou expiré."});
    const user=store.state.users.find(x=>x.id===entry.userId);if(!user)return json(res,400,{error:"INVALID_EMAIL_VERIFICATION_TOKEN",message:"Ce lien de confirmation est invalide ou expiré."});
    user.emailVerifiedAt=new Date().toISOString();user.updatedAt=user.emailVerifiedAt;store.state.emailVerificationTokens=store.state.emailVerificationTokens.filter(x=>x.userId!==user.id);store.audit(user.id,"auth.email_verification.completed","user",user.id);await store.save();
    return json(res,200,{ok:true,emailVerified:true});
  }
  if(method==="POST" && p==="/api/auth/email-verification/request") {
    const user=requireUser(req,res);if(!user)return;
    if(user.emailVerifiedAt)return json(res,200,{ok:true,alreadyVerified:true,emailVerified:true});
    if(!emailDeliveryConfig().configured)return json(res,503,{error:"EMAIL_DELIVERY_NOT_CONFIGURED",message:"La confirmation par e-mail n’est pas disponible pour le moment."});
    const result=await issueEmailVerification(user);
    if(!result.sent)return json(res,502,{error:"EMAIL_DELIVERY_FAILED",message:"L’e-mail de confirmation n’a pas pu être envoyé. Réessayez dans quelques instants."});
    return json(res,200,{ok:true,sent:true,emailVerified:false});
  }
  if(method==="POST" && p==="/api/auth/password-reset/request") {
    const b=await readBody(req),email=cleanText(b.email,254).toLowerCase(),u=store.userByEmail(email);
    if(u&&emailValid(email)&&emailDeliveryConfig().configured){
      const raw=token(),now=Date.now();
      store.state.passwordResets=store.state.passwordResets.filter(x=>x.userId!==u.id);
      store.state.passwordResets.push({id:id(),userId:u.id,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),createdAt:new Date(now).toISOString(),expiresAt:now+30*60*1000});
      await store.save();
      const appUrl=emailDeliveryConfig().appUrl;
      const text=`A password reset was requested for your ZERILYS account.\n\nPassword reset token: ${raw}\n\nOpen ${appUrl}, choose Forgot password and enter the token. It expires in 30 minutes. If you did not request this, ignore this message.`;
      const html=`<p>A password reset was requested for your ZERILYS account.</p><p>Password reset token: <code>${escapeHtml(raw)}</code></p><p>Open <a href="${escapeHtml(appUrl)}">${escapeHtml(appUrl)}</a>, choose Forgot password and enter the token. It expires in 30 minutes. If you did not request this, ignore this message.</p>`;
      try{await sendTransactionalEmail({to:email,subject:"Reset your ZERILYS password",text,html});store.audit(u.id,"auth.password_reset.requested","user",u.id);await store.save();}
      catch{store.state.passwordResets=store.state.passwordResets.filter(x=>x.userId!==u.id);await store.save();}
    }
    return json(res,200,{ok:true,message:"If an account exists for that address and email delivery is available, a reset token will be sent."});
  }
  if(method==="POST" && p==="/api/auth/password-reset/confirm") {
    const b=await readBody(req),raw=String(b.token||""),password=String(b.newPassword||"");
    if(password.length<12||password.length>128)return json(res,400,{error:"INVALID_PASSWORD"});
    if(raw.length<32||raw.length>256)return json(res,400,{error:"INVALID_OR_EXPIRED_RESET_TOKEN"});
    const hash=crypto.createHash("sha256").update(raw).digest("hex");
    const reset=store.state.passwordResets.find(x=>x.tokenHash===hash&&x.expiresAt>Date.now());
    if(!reset)return json(res,400,{error:"INVALID_OR_EXPIRED_RESET_TOKEN"});
    const u=store.state.users.find(x=>x.id===reset.userId);if(!u)return json(res,400,{error:"INVALID_OR_EXPIRED_RESET_TOKEN"});
    const h=hashPassword(password);u.passwordHash=h.hash;u.passwordSalt=h.salt;u.updatedAt=new Date().toISOString();
    store.state.sessions=store.state.sessions.filter(x=>x.userId!==u.id);
    store.state.passwordResets=store.state.passwordResets.filter(x=>x.userId!==u.id);
    store.audit(u.id,"auth.password_reset.completed","user",u.id);
    await store.save();
    res.setHeader("Set-Cookie","zerihlink_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0");
    return json(res,200,{ok:true,message:"Password updated. Please sign in again."});
  }
  if(method==="POST" && p==="/api/auth/login") {
    const b=await readBody(req), u=store.userByEmail(cleanText(b.email,254).toLowerCase());
    if(!u || !verifyPassword(String(b.password||""),u.passwordSalt,u.passwordHash)) return json(res,401,{error:"INVALID_CREDENTIALS",message:"Identifiants incorrects."});
    const raw=token(); addSession(u.id,raw);
    store.audit(u.id,"session.created","user",u.id); await store.save();
    res.setHeader("Set-Cookie",`zerihlink_session=${encodeURIComponent(sessionCookie(raw))}; HttpOnly; SameSite=Strict; Path=/; Max-Age=1209600${process.env.NODE_ENV==="production"?"; Secure":""}`);
    return json(res,200,{user:publicProfile(u)});
  }
  if(method==="POST" && p==="/api/auth/logout") {
    const u=currentUser(req); const c=cookie(req,"zerihlink_session");
    if(c){try{const [payload]=c.split(".");const raw=JSON.parse(Buffer.from(payload,"base64url").toString()).raw;const h=crypto.createHash("sha256").update(raw).digest("hex");store.state.sessions=store.state.sessions.filter(s=>s.tokenHash!==h);await store.save();}catch{}}
    res.setHeader("Set-Cookie","zerihlink_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0");
    return json(res,200,{ok:true});
  }
  if(method==="POST" && p==="/api/me/consent") {
    const u=requireUser(req,res);if(!u)return;
    if(!BETA_LEGAL_APPROVED) return json(res,503,{error:"BETA_LEGAL_REVIEW_PENDING",message:"Consent is paused until the beta terms and privacy notice are legally approved."});
    const b=await readBody(req);
    if(b.betaTermsAccepted!==true||b.privacyNoticeAcknowledged!==true) return json(res,400,{error:"LEGAL_CONSENT_REQUIRED"});
    const now=new Date().toISOString();
    u.legalConsent={termsVersion:BETA_TERMS_VERSION,termsAcceptedAt:now,privacyVersion:PRIVACY_NOTICE_VERSION,privacyAcknowledgedAt:now};
    store.audit(u.id,"legal.beta_consent.accepted","user",u.id,{termsVersion:BETA_TERMS_VERSION,privacyNoticeVersion:PRIVACY_NOTICE_VERSION});
    await store.save();
    return json(res,200,{ok:true,legalConsent:u.legalConsent,consentRequired:false});
  }
  if(method==="GET" && p==="/api/me/readiness") {
    const u=requireUser(req,res); if(!u)return;
    let items=[];
    if(u.accountType==="company"){
      const offers=store.state.offers.filter(o=>o.companyId===u.id&&o.status==="published");
      items=[
        {key:"companyIdentity",label:"Describe your company",complete:!!(u.companyName&&u.companyIndustry&&String(u.about||"").length>=40),detail:"Company name, activity and a clear description."},
        {key:"firstOffer",label:"Publish a first opportunity",complete:offers.length>0,detail:"A structured job, internship, apprenticeship or collaboration."},
        {key:"offerSkills",label:"Define required capabilities",complete:offers.some(o=>(o.skills||[]).length>0),detail:"Skills make opportunity relevance understandable."}
      ];
    }else{
      const evidence=store.state.evidence.filter(e=>e.userId===u.id);
      items=[
        {key:"identity",label:"Define your professional identity",complete:!!(u.headline&&u.location&&String(u.about||"").length>=40),detail:"A clear headline, location and short professional introduction."},
        {key:"capabilities",label:"Map your capabilities",complete:(u.skills||[]).length>=3,detail:"Add at least three skills with realistic proficiency levels."},
        {key:"evidence",label:"Attach evidence to your skills",complete:evidence.length>0,detail:"Add one concrete project, result or reference."},
        {key:"intent",label:"Make your intentions visible",complete:!!(u.canOffer||u.lookingFor||u.interests),detail:"Explain what you can contribute or what you are looking for."},
        {key:"visibility",label:"Choose your discoverability",complete:["public","private"].includes(u.visibility),detail:"You remain in control: public discovery is optional."}
      ];
    }
    const completed=items.filter(x=>x.complete).length;
    return json(res,200,{accountType:u.accountType,completed,total:items.length,items});
  }
  if(method==="POST" && p==="/api/me/avatar") {
    const u=requireUser(req,res); if(!u)return;
    const b=await readBody(req), image=typeof b.imageDataUrl==="string"?b.imageDataUrl:"";
    const match=image.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
    if(!match) return json(res,400,{error:"INVALID_AVATAR_FORMAT",message:"Utilise une image JPG, PNG ou WebP."});
    const bytes=Buffer.from(match[2],"base64");
    if(bytes.length<100 || bytes.length>520000) return json(res,413,{error:"AVATAR_SIZE_LIMIT",message:"La photo doit faire moins de 500 Ko après compression."});
    const signatures={jpeg:bytes.subarray(0,3).equals(Buffer.from([0xff,0xd8,0xff])),png:bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),webp:bytes.subarray(0,4).toString()==="RIFF"&&bytes.subarray(8,12).toString()==="WEBP"};
    if(!signatures[match[1]]) return json(res,400,{error:"AVATAR_CONTENT_MISMATCH",message:"Le contenu du fichier ne correspond pas à son format."});
    const ext={jpeg:"jpg",png:"png",webp:"webp"}[match[1]],filename=`${crypto.randomUUID()}.${ext}`;
    fs.mkdirSync(store.avatarDir,{recursive:true,mode:0o700});
    const target=path.join(store.avatarDir,filename),tmp=target+".tmp";
    fs.writeFileSync(tmp,bytes,{mode:0o600,flag:"wx"});fs.renameSync(tmp,target);
    const previous=u.avatarFile;u.avatarFile=filename;delete u.avatarDataUrl;u.updatedAt=new Date().toISOString();
    store.audit(u.id,"profile.avatar.updated","user",u.id,{format:match[1],bytes:bytes.length}); await store.save();
    if(previous&&/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(previous)){try{fs.unlinkSync(path.join(store.avatarDir,previous));}catch{}}
    return json(res,200,{user:publicProfile(u)});
  }
  if(method==="DELETE" && p==="/api/me/avatar") {
    const u=requireUser(req,res); if(!u)return;
    const previous=u.avatarFile;delete u.avatarFile;delete u.avatarDataUrl;u.updatedAt=new Date().toISOString(); store.audit(u.id,"profile.avatar.removed","user",u.id); await store.save();
    if(previous&&/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(previous)){try{fs.unlinkSync(path.join(store.avatarDir,previous));}catch{}}
    return json(res,200,{user:publicProfile(u)});
  }
  if(method==="GET" && p.match(/^\/api\/media\/avatars\/[^/]+$/)) {
    const uid=p.split("/").at(-1),viewer=currentUser(req),owner=store.state.users.find(x=>x.id===uid);
    if(!owner||!owner.avatarFile||(!viewer&&owner.visibility!=="public"))return json(res,404,{error:"NOT_FOUND"});
    if(owner.visibility!=="public"&&viewer&&!hasLegalConsent(viewer))return json(res,428,{error:"LEGAL_CONSENT_REQUIRED"});
    if(viewer&&store.state.blocks.some(b=>(b.blockerId===viewer.id&&b.blockedId===uid)||(b.blockerId===uid&&b.blockedId===viewer.id)))return json(res,404,{error:"NOT_FOUND"});
    if(!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(owner.avatarFile))return json(res,404,{error:"NOT_FOUND"});
    const file=path.join(store.avatarDir,owner.avatarFile);if(!fs.existsSync(file))return json(res,404,{error:"NOT_FOUND"});
    const ext=path.extname(file),contentType=ext===".jpg"?"image/jpeg":ext===".png"?"image/png":"image/webp";
    res.writeHead(200,{"Content-Type":contentType,"Content-Length":fs.statSync(file).size,"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff","Cross-Origin-Resource-Policy":"same-origin"});return res.end(fs.readFileSync(file));
  }
  if(method==="PATCH" && p==="/api/me/preferences") {
    const u=requireUser(req,res);if(!u)return;
    const b=await readBody(req),language=String(b.preferredLanguage||"").toLowerCase();
    if(!["fr","en"].includes(language))return json(res,400,{error:"INVALID_LANGUAGE",message:"Choisis une langue prise en charge."});
    u.preferredLanguage=language;u.updatedAt=new Date().toISOString();store.audit(u.id,"account.language.updated","user",u.id,{language});await store.save();
    return json(res,200,{preferredLanguage:u.preferredLanguage});
  }
  if(method==="GET" && p==="/api/assessments/practical-cases") return json(res,200,{cases:practicalCaseCatalog()});
  if(method==="GET" && p.match(/^\/api\/assessments\/practical-cases\/[a-z0-9-]+$/)) {
    const u=requireUser(req,res);if(!u)return;if(u.accountType!=="candidate")return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const result=getPracticalCase(p.split("/").at(-1),u.id);return json(res,result.error?404:200,result);
  }
  if(method==="POST" && p.match(/^\/api\/me\/assessments\/practical-cases\/[a-z0-9-]+\/run$/)) {
    const u=requireUser(req,res);if(!u)return;if(u.accountType!=="candidate")return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const slug=p.split("/").at(-2),exercise=getPracticalCase(slug,u.id);if(exercise.error)return json(res,404,{error:exercise.error});
    if(exercise.submissionMode!=="code")return json(res,400,{error:"CODE_EXERCISE_REQUIRED"});
    const now=Date.now(),bucket=codeRunBuckets.get(u.id)||{start:now,count:0};if(now-bucket.start>60_000){bucket.start=now;bucket.count=0;}bucket.count++;codeRunBuckets.set(u.id,bucket);if(bucket.count>5)return json(res,429,{error:"CODE_RUN_RATE_LIMIT",message:"Limite de cinq exécutions par minute atteinte."});
    const body=await readBody(req),run=await executeInIsolatedRunner({slug,language:exercise.language,source:body.source,variant:exercise.variant});
    if(run.error)return json(res,run.status||400,{error:run.error,message:run.message});
    store.audit(u.id,"assessment.code_executed","code_exercise",slug,{language:exercise.language,status:run.result.status,durationMs:run.result.durationMs});
    return json(res,200,{execution:run.result,notice:"Exécution réalisée dans un service isolé distinct. Le code n'est pas exécuté par le serveur de la plateforme."});
  }
  if(method==="POST" && p.match(/^\/api\/me\/assessments\/practical-cases\/[a-z0-9-]+\/attempt$/)) {
    const u=requireUser(req,res);if(!u)return;if(u.accountType!=="candidate")return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const slug=p.split("/").at(-2),body=await readBody(req),result=submitPracticalCase(slug,u.id,body,new Date());if(result.error){const status=result.error==="PRACTICAL_CASE_NOT_FOUND"?404:400;return json(res,status,{error:result.error});}
    u.practicalAssessments??=[];const prior=u.practicalAssessments.filter(x=>x.caseSlug===slug).length;if(prior>=3)return json(res,429,{error:"PRACTICAL_ATTEMPT_LIMIT"});result.attemptNumber=prior+1;u.practicalAssessments.push(result);store.audit(u.id,"assessment.practical_submitted","practical_assessment",result.id,{slug,version:result.version,attemptNumber:result.attemptNumber});await store.save();return json(res,201,{assessment:result});
  }
  if(method==="GET" && p==="/api/me/assessments/practical-cases") {const u=requireUser(req,res);if(!u)return;return json(res,200,{assessments:(u.practicalAssessments||[]).slice().sort((a,b)=>b.completedAt.localeCompare(a.completedAt)).map(({response,...x})=>x)});}
  if(method==="GET" && p==="/api/assessments/catalog") return json(res,200,{assessments:assessmentCatalog()});
  if(method==="GET" && p==="/api/me/assessments") {
    const u=requireUser(req,res); if(!u)return;
    return json(res,200,{assessments:(u.assessments||[]).slice().sort((a,b)=>b.completedAt.localeCompare(a.completedAt))});
  }
  if(method==="POST" && p.match(/^\/api\/me\/assessments\/[a-z0-9-]+\/attempt$/)) {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="candidate") return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const slug=p.split("/").at(-2), body=await readBody(req);
    const rationale=String(body.rationale||"").trim();
    if(rationale.length<40)return json(res,400,{error:"REASONING_REQUIRED",message:"Explique brièvement votre raisonnement en 40 caractères minimum."});
    if(rationale.length>1500)return json(res,400,{error:"REASONING_TOO_LONG",message:"Votre explication est limitée à 1 500 caractères."});
    if(!["not_used","used","prefer_not_to_say"].includes(body.aiUseDeclaration))return json(res,400,{error:"AI_DISCLOSURE_REQUIRED",message:"Indiquez votre usage de l’IA pour cette évaluation."});
    const result=gradeAssessment(slug,body.answers,new Date(),{rationale,aiUseDeclaration:body.aiUseDeclaration});
    if(result.error) return json(res,result.error==="ASSESSMENT_NOT_FOUND"?404:400,{error:result.error});
    u.assessments??=[];
    const prior=u.assessments.filter(x=>x.assessmentSlug===slug).length;
    if(prior>=5) return json(res,429,{error:"ASSESSMENT_ATTEMPT_LIMIT",message:"Limite de cinq tentatives atteinte pour cette version du test."});
    result.attemptNumber=prior+1; u.assessments.push(result);
    for(const skillName of result.skills){const skill=(u.skills||[]).find(x=>x.name.toLowerCase()===skillName.toLowerCase());if(skill){skill.lastAssessedAt=result.completedAt;skill.assessmentCount=(skill.assessmentCount||0)+1;}}
    store.audit(u.id,"assessment.completed","assessment",result.id,{slug,version:result.version,score:result.score,attemptNumber:result.attemptNumber});
    await store.save();
    return json(res,201,{assessment:result});
  }
  if(method==="GET" && p==="/api/me") { const u=requireUser(req,res); if(!u)return; return json(res,200,{user:{...publicProfile(u),email:u.email,preferredLanguage:u.preferredLanguage||null,emailVerified:!!u.emailVerifiedAt,emailVerificationEnabled:emailDeliveryConfig().configured,legalConsent:u.legalConsent||null,companyVerification:u.accountType==="company"?(u.companyVerification||{status:"unverified"}):null},consentRequired:!hasLegalConsent(u),betaTermsVersion:BETA_TERMS_VERSION,privacyNoticeVersion:PRIVACY_NOTICE_VERSION}); }
  if(method==="POST" && p==="/api/me/feedback") {
    const u=requireUser(req,res); if(!u)return;
    const b=await readBody(req), message=cleanText(b.message,2000), category=["bug","confusing","idea","other"].includes(b.category)?b.category:"other";
    if(message.length<20) return json(res,400,{error:"FEEDBACK_TOO_SHORT",message:"Décris ton retour en au moins 20 caractères."});
    const feedback={id:id(),userId:u.id,category,area:cleanText(b.area,100),message,status:"open",createdAt:new Date().toISOString()};
    store.state.betaFeedback.push(feedback);store.audit(u.id,"beta.feedback.submitted","beta_feedback",feedback.id,{category,area:feedback.area});await store.save();
    return json(res,201,{feedback:{id:feedback.id,category:feedback.category,area:feedback.area,status:feedback.status,createdAt:feedback.createdAt}});
  }
  if(method==="GET" && p==="/api/me/feedback") {
    const u=requireUser(req,res); if(!u)return;
    return json(res,200,{feedback:store.state.betaFeedback.filter(f=>f.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(({userId,reviewNote,reviewedBy,...f})=>f)});
  }
  if(method==="GET" && p==="/api/review/practical-assessments") {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const attempts=[];for(const owner of store.state.users){for(const a of owner.practicalAssessments||[]){const blind=blindPracticalReviewPayload(a);if(blind)attempts.push(blind);}}
    return json(res,200,{reviewMode:"blind",anonymization:"identity_and_ai_declaration_hidden",assessments:attempts.sort((a,b)=>a.completedAt.localeCompare(b.completedAt))});
  }
  if(method==="PATCH" && p.match(/^\/api\/review\/practical-assessments\/[^/]+$/)) {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const attemptId=p.split("/").at(-1),owner=store.state.users.find(x=>(x.practicalAssessments||[]).some(a=>a.id===attemptId));if(!owner)return json(res,404,{error:"PRACTICAL_ATTEMPT_NOT_FOUND"});
    const attempt=owner.practicalAssessments.find(a=>a.id===attemptId),body=await readBody(req),result=reviewPracticalCase(attempt,body,u.id,new Date());if(result.error)return json(res,result.error==="PRACTICAL_ATTEMPT_ALREADY_REVIEWED"?409:400,{error:result.error});
    attempt.status=result.status;attempt.review=result.review;store.audit(u.id,"assessment.practical_reviewed","practical_assessment",attempt.id,{decision:result.review.decision,criteriaCount:result.review.criteria.length});await store.save();return json(res,200,{assessment:{id:attempt.id,status:attempt.status,review:attempt.review}});
  }
  if(method==="GET" && p==="/api/review/feedback") {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    return json(res,200,{feedback:store.state.betaFeedback.filter(f=>f.status==="open").map(f=>({...f,user:publicProfile(store.state.users.find(x=>x.id===f.userId))})).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});
  }
  if(method==="PATCH" && p.match(/^\/api\/review\/feedback\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    const feedback=store.state.betaFeedback.find(f=>f.id===p.split("/").at(-1));if(!feedback) return json(res,404,{error:"FEEDBACK_NOT_FOUND"});
    if(feedback.status!=="open") return json(res,409,{error:"FEEDBACK_NOT_OPEN"});
    const b=await readBody(req);if(!["reviewed","accepted","declined"].includes(b.status)) return json(res,400,{error:"INVALID_FEEDBACK_STATUS"});
    feedback.status=b.status;feedback.reviewedAt=new Date().toISOString();feedback.reviewedBy=u.id;feedback.reviewNote=cleanText(b.note,500);
    store.audit(u.id,`beta.feedback.${b.status}`,"beta_feedback",feedback.id);await store.save();
    return json(res,200,{feedback});
  }
  if(method==="GET" && p==="/api/me/sessions") {
    const u=requireUser(req,res); if(!u)return;
    const active=store.state.sessions.filter(x=>x.userId===u.id&&x.expiresAt>Date.now());
    const current=currentSession(req);
    return json(res,200,{sessions:active.map(x=>({id:x.id,createdAt:x.createdAt||null,expiresAt:x.expiresAt,current:x.id===current?.id})).sort((a,b)=>(b.createdAt||"").localeCompare(a.createdAt||""))});
  }
  if(method==="DELETE" && p==="/api/me/sessions") {
    const u=requireUser(req,res); if(!u)return;
    const current=currentSession(req), before=store.state.sessions.length;
    store.state.sessions=store.state.sessions.filter(x=>x.userId!==u.id||(current&&x.id===current.id));
    const revoked=before-store.state.sessions.length;
    store.audit(u.id,"sessions.other_sessions.revoked","user",u.id,{revoked});
    await store.save(); return json(res,200,{ok:true,revoked});
  }
  if(method==="PATCH" && p==="/api/me/password") {
    const u=requireUser(req,res); if(!u)return;
    const b=await readBody(req), currentPassword=String(b.currentPassword||""), newPassword=String(b.newPassword||"");
    if(!verifyPassword(currentPassword,u.passwordSalt,u.passwordHash)) return json(res,403,{error:"CURRENT_PASSWORD_INVALID",message:"Le mot de passe actuel est incorrect."});
    if(newPassword.length<12||newPassword.length>128) return json(res,400,{error:"WEAK_PASSWORD",message:"Le nouveau mot de passe doit contenir entre 12 et 128 caractères."});
    if(newPassword===currentPassword) return json(res,400,{error:"PASSWORD_UNCHANGED"});
    const hashed=hashPassword(newPassword);u.passwordHash=hashed.hash;u.passwordSalt=hashed.salt;u.updatedAt=new Date().toISOString();
    const current=currentSession(req), before=store.state.sessions.length;
    store.state.sessions=store.state.sessions.filter(x=>x.userId!==u.id||(current&&x.id===current.id));
    const revoked=before-store.state.sessions.length;
    store.audit(u.id,"account.password.changed","user",u.id,{revokedSessions:revoked});
    await store.save(); return json(res,200,{ok:true,revokedSessions:revoked});
  }
  if(method==="PATCH" && p==="/api/me") {
    const u=requireUser(req,res); if(!u)return; const b=await readBody(req);
    if("availability" in b && !["open","selective","not_now"].includes(b.availability)) return json(res,400,{error:"INVALID_PROFILE_AVAILABILITY",message:"Choisissez une disponibilité proposée."});
    if("visibility" in b && !["public","private"].includes(b.visibility)) return json(res,400,{error:"INVALID_PROFILE_VISIBILITY",message:"Choisissez un niveau de visibilité proposé."});
    if("website" in b) {
      const website=cleanText(b.website,180);
      if(website) {
        try { const parsed=new URL(website); if(parsed.protocol!=="https:"||!parsed.hostname||parsed.username||parsed.password) throw new Error("invalid"); }
        catch { return json(res,400,{error:"INVALID_PROFILE_WEBSITE",message:"Le site du profil doit être une adresse HTTPS valide, sans identifiant intégré."}); }
      }
    }
    for(const k of ["name","headline","location","about","website","availability","visibility","canOffer","lookingFor","interests"]) if(k in b) u[k]=cleanText(b[k],k==="about"?1200:["canOffer","lookingFor","interests"].includes(k)?400:k==="headline"?140:180);
    u.updatedAt=new Date().toISOString(); store.audit(u.id,"profile.updated","user",u.id); await store.save();
    return json(res,200,{user:publicProfile(u)});
  }
  if(method==="POST" && p==="/api/me/qualifications") {
    const u=requireUser(req,res);if(!u)return;const b=await readBody(req);
    const title=cleanText(b.title,120),institution=cleanText(b.institution,120),level=cleanText(b.level,40),qualificationType=["degree","equivalence"].includes(b.qualificationType)?b.qualificationType:"degree";
    const data=typeof b.documentDataUrl==="string"?b.documentDataUrl:"";const m=data.match(/^data:application\/pdf;base64,([A-Za-z0-9+/]+={0,2})$/)||data.match(/^data:image\/(jpeg|png);base64,([A-Za-z0-9+/]+={0,2})$/);
    if(title.length<2||institution.length<2||!level||!m)return json(res,400,{error:"QUALIFICATION_DETAILS_AND_DOCUMENT_REQUIRED",message:"Renseignez le diplôme, l'établissement et joignez un justificatif PDF, JPG ou PNG."});
    const b64=m.length===2?m[1]:m[2],bytes=Buffer.from(b64,"base64");if(bytes.length<100||bytes.length>650000)return json(res,413,{error:"QUALIFICATION_DOCUMENT_SIZE",message:"Le justificatif doit peser moins de 650 Ko."});
    const isPdf=data.startsWith("data:application/pdf"),valid=isPdf?bytes.subarray(0,5).toString()==="%PDF-":m[1]==="jpeg"?bytes.subarray(0,3).equals(Buffer.from([255,216,255])):bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
    if(!valid)return json(res,400,{error:"QUALIFICATION_DOCUMENT_INVALID",message:"Le contenu du fichier ne correspond pas à son format."});
    u.qualificationVerifications??=[];if(u.qualificationVerifications.some(x=>x.status==="pending"))return json(res,409,{error:"QUALIFICATION_REVIEW_PENDING",message:"Un justificatif est déjà en cours de vérification."});
    const ext=isPdf?"pdf":m[1]==="jpeg"?"jpg":"png",filename=`${crypto.randomUUID()}.${ext}`,dir=path.join(DATA,"qualification-documents");fs.mkdirSync(dir,{recursive:true,mode:0o700});fs.writeFileSync(path.join(dir,filename),bytes,{mode:0o600,flag:"wx"});
    const item={id:id(),title,institution,level,qualificationType,documentFile:filename,documentFormat:ext,documentBytes:bytes.length,documentSha256:crypto.createHash("sha256").update(bytes).digest("hex"),status:"pending",submittedAt:new Date().toISOString(),reviewedAt:null,reviewedBy:null,reviewerNote:null};u.qualificationVerifications.push(item);store.audit(u.id,"qualification.verification.submitted","qualification",item.id,{level,qualificationType,format:ext,bytes:bytes.length});await store.save();return json(res,201,{qualification:{id:item.id,title:item.title,institution:item.institution,level:item.level,status:item.status,submittedAt:item.submittedAt}});
  }
  if(method==="GET" && p==="/api/me/qualifications") {const u=requireUser(req,res);if(!u)return;return json(res,200,{qualifications:(u.qualificationVerifications||[]).map(({documentFile,documentSha256,documentBytes,...x})=>x)});}
  if(method==="POST" && p==="/api/me/trajectory") {
    const u=requireUser(req,res);if(!u)return;const b=await readBody(req),kind=b.kind;
    if(!["experience","education"].includes(kind))return json(res,400,{error:"INVALID_TRAJECTORY_KIND"});
    const entry=kind==="experience"?{id:id(),title:cleanText(b.title,100),company:cleanText(b.company,100),domain:cleanText(b.domain,80),description:cleanText(b.description,500),startDate:cleanText(b.startDate,20),endDate:cleanText(b.endDate,20),createdAt:new Date().toISOString()}:{id:id(),title:cleanText(b.title,120),institution:cleanText(b.institution,120),field:cleanText(b.field,100),level:cleanText(b.level,80),createdAt:new Date().toISOString()};
    if(entry.title.length<2||(kind==="experience"&&!entry.company)||(kind==="education"&&!entry.institution))return json(res,400,{error:"TRAJECTORY_DETAILS_REQUIRED",message:kind==="experience"?"Renseigne au minimum un intitulé et une organisation.":"Renseigne au minimum un diplôme et un établissement."});
    const key=kind==="experience"?"experiences":"education";u[key]??=[];if(u[key].length>=30)return json(res,429,{error:"TRAJECTORY_LIMIT"});u[key].push(entry);u.updatedAt=new Date().toISOString();store.audit(u.id,`profile.${kind}.added`,kind,entry.id);await store.save();return json(res,201,{user:publicProfile(u),entry});
  }
  if(method==="DELETE" && p.match(/^\/api\/me\/trajectory\/[^/]+$/)) {
    const u=requireUser(req,res);if(!u)return;const entryId=p.split("/").at(-1);let removed=false;
    for(const key of ["experiences","education"]){const before=(u[key]||[]).length;u[key]=(u[key]||[]).filter(x=>x.id!==entryId);removed=removed||u[key].length!==before;}
    if(!removed)return json(res,404,{error:"TRAJECTORY_ENTRY_NOT_FOUND"});u.updatedAt=new Date().toISOString();store.audit(u.id,"profile.trajectory.removed","trajectory",entryId);await store.save();return json(res,200,{user:publicProfile(u)});
  }
  if(method==="POST" && p==="/api/me/skills") {
    const u=requireUser(req,res); if(!u)return; const b=await readBody(req);
    const name=cleanText(b.name,60), level=["learning","practitioner","advanced","expert"].includes(b.level)?b.level:"practitioner";
    if(name.length<2) return json(res,400,{error:"INVALID_SKILL"});
    const existing=u.skills.find(s=>s.name.toLowerCase()===name.toLowerCase());
    if(existing) return json(res,409,{error:"SKILL_EXISTS"});
    u.skills.push({id:id(),name,level,addedAt:new Date().toISOString(),verified:false});
    store.audit(u.id,"skill.added","skill",name); await store.save(); return json(res,201,{user:publicProfile(u)});
  }
  if(method==="DELETE" && p.startsWith("/api/me/skills/")) {
    const u=requireUser(req,res); if(!u)return; const sid=p.split("/").at(-1);
    u.skills=u.skills.filter(s=>s.id!==sid); store.audit(u.id,"skill.removed","skill",sid); await store.save(); return json(res,200,{user:publicProfile(u)});
  }
  if(method==="POST" && p==="/api/me/evidence") {
    const u=requireUser(req,res); if(!u)return; const b=await readBody(req);
    const title=cleanText(b.title,100), description=cleanText(b.description,500), urlValue=cleanText(b.url,300);
    if(title.length<3) return json(res,400,{error:"INVALID_EVIDENCE"});
    if(urlValue && !/^https:\/\/[^\s]+$/i.test(urlValue)) return json(res,400,{error:"HTTPS_REQUIRED"});
    const skillId=cleanText(b.skillId,80);
    if(skillId && !(u.skills||[]).some(skill=>skill.id===skillId)) return json(res,400,{error:"INVALID_SKILL_LINK",message:"Cette compétence ne fait pas partie de ton identité."});
    const e={id:id(),userId:u.id,skillId:skillId||null,title,description,url:urlValue,kind:["project","credential","work","publication"].includes(b.kind)?b.kind:"project",status:"self_attested",createdAt:new Date().toISOString()};
    store.state.evidence.push(e); store.audit(u.id,"evidence.added","evidence",e.id); await store.save(); return json(res,201,{evidence:e});
  }
  if(method==="POST" && p.match(/^\/api\/me\/evidence\/[^/]+\/submit$/)) {
    const u=requireUser(req,res); if(!u)return; const eid=p.split("/").at(-2), e=store.state.evidence.find(x=>x.id===eid && x.userId===u.id);
    if(!e) return json(res,404,{error:"EVIDENCE_NOT_FOUND"});
    if(e.status!=="self_attested" && e.status!=="rejected") return json(res,409,{error:"EVIDENCE_NOT_SUBMITTABLE"});
    e.status="pending_review"; e.submittedAt=new Date().toISOString(); store.audit(u.id,"evidence.submitted","evidence",e.id); await store.save(); return json(res,200,{evidence:e});
  }
  if(method==="PATCH" && p.match(/^\/api\/review\/evidence\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    const e=store.state.evidence.find(x=>x.id===p.split("/").at(-1)); if(!e) return json(res,404,{error:"EVIDENCE_NOT_FOUND"});
    const b=await readBody(req); if(!["verified","rejected"].includes(b.status)) return json(res,400,{error:"INVALID_REVIEW_STATUS"});
    if(e.status!=="pending_review") return json(res,409,{error:"EVIDENCE_NOT_PENDING"});
    e.status=b.status; e.reviewedAt=new Date().toISOString(); e.reviewedBy=u.id; e.reviewNote=cleanText(b.note,500); store.audit(u.id,`evidence.${b.status}`,"evidence",e.id); await store.save(); return json(res,200,{evidence:e});
  }
  if(method==="GET" && p==="/api/review/company-verifications") {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const companies=store.state.users.filter(x=>x.accountType==="company"&&x.companyVerification?.status==="pending").map(x=>({id:x.id,name:x.companyName,industry:x.companyIndustry,website:x.companyWebsite,location:x.location,verification:x.companyVerification,createdAt:x.createdAt}));
    return json(res,200,{companies});
  }
  if(method==="PATCH" && p.match(/^\/api\/review\/company-verifications\/[^/]+$/)) {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const company=store.state.users.find(x=>x.id===p.split("/").at(-1)&&x.accountType==="company");if(!company)return json(res,404,{error:"COMPANY_NOT_FOUND"});
    if(company.companyVerification?.status!=="pending")return json(res,409,{error:"COMPANY_VERIFICATION_NOT_PENDING"});
    const b=await readBody(req);if(!["verified","rejected"].includes(b.status)||cleanText(b.note,500).length<20)return json(res,400,{error:"REVIEW_DECISION_AND_NOTE_REQUIRED"});
    company.companyVerification={...company.companyVerification,status:b.status,reviewedAt:new Date().toISOString(),reviewedBy:u.id,reviewerNote:cleanText(b.note,500),...(b.status==="verified"?{verifiedAt:new Date().toISOString()}: {})};
    store.audit(u.id,`company.verification.${b.status}`,"company",company.id);await store.save();
    return json(res,200,{companyVerification:{status:company.companyVerification.status,reviewedAt:company.companyVerification.reviewedAt}});
  }
  if(method==="GET" && p==="/api/review/qualifications") {const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});const items=store.state.users.flatMap(owner=>(owner.qualificationVerifications||[]).filter(x=>x.status==="pending").map(({documentFile,documentSha256,documentBytes,...x})=>({...x,candidate:{id:owner.id,name:owner.name,email:owner.email}})));return json(res,200,{qualifications:items});}
  if(method==="GET" && p.match(/^\/api\/review\/qualifications\/[^/]+\/document$/)) {const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});const qid=p.split("/").at(-2),owner=store.state.users.find(x=>(x.qualificationVerifications||[]).some(q=>q.id===qid&&q.status==="pending"));const q=owner?.qualificationVerifications.find(x=>x.id===qid);if(!q)return json(res,404,{error:"QUALIFICATION_NOT_FOUND"});const file=path.join(DATA,"qualification-documents",q.documentFile);if(!fs.existsSync(file))return json(res,404,{error:"DOCUMENT_NOT_FOUND"});const ext=q.documentFormat,mimeType=ext==="pdf"?"application/pdf":ext==="jpg"?"image/jpeg":"image/png";res.writeHead(200,{"Content-Type":mimeType,"Content-Length":fs.statSync(file).size,"Content-Disposition":`inline; filename=qualification.${ext}`,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});return fs.createReadStream(file).pipe(res);}
  if(method==="PATCH" && p.match(/^\/api\/review\/qualifications\/[^/]+$/)) {const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});const qid=p.split("/").at(-1),owner=store.state.users.find(x=>(x.qualificationVerifications||[]).some(q=>q.id===qid));const q=owner?.qualificationVerifications.find(x=>x.id===qid);if(!q)return json(res,404,{error:"QUALIFICATION_NOT_FOUND"});if(q.status!=="pending")return json(res,409,{error:"QUALIFICATION_ALREADY_REVIEWED"});const b=await readBody(req),note=cleanText(b.note,700);if(!["verified","rejected","needs_info"].includes(b.status)||note.length<20)return json(res,400,{error:"QUALIFICATION_REVIEW_NOTE_REQUIRED",message:"Choisissez une décision et justifiez-la en au moins 20 caractères."});q.status=b.status;q.reviewedAt=new Date().toISOString();q.reviewedBy=u.id;q.reviewerNote=note;if(q.documentFile&&/^[a-f0-9-]{36}\.(pdf|jpg|png)$/.test(q.documentFile)){try{fs.unlinkSync(path.join(DATA,"qualification-documents",q.documentFile));}catch{}delete q.documentFile;q.documentRetained=false;}store.audit(u.id,`qualification.verification.${b.status}`,"qualification",qid,{candidateId:owner.id});await store.save();return json(res,200,{qualification:{id:qid,status:q.status,reviewedAt:q.reviewedAt}});}
  if(method==="GET" && p==="/api/review/evidence") {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    return json(res,200,{evidence:store.state.evidence.filter(e=>e.status==="pending_review").map(e=>({...e,owner:publicProfile(store.state.users.find(x=>x.id===e.userId))}))});
  }

  // Company identity and structured opportunity marketplace. No social-post endpoint exists.
  // Company workspace: owner-controlled invitations and least-privilege team roles.
  if(method==="POST" && p==="/api/company/team/invitations") {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="company") return json(res,403,{error:"COMPANY_ACCOUNT_REQUIRED"});
    const b=await readBody(req), email=cleanText(b.email,254).toLowerCase();
    const role=["recruiter","viewer"].includes(b.role)?b.role:"viewer";
    if(!emailValid(email)) return json(res,400,{error:"INVALID_EMAIL"});
    if(email===u.email) return json(res,400,{error:"CANNOT_INVITE_OWNER"});
    const existingUser=store.userByEmail(email);
    if(existingUser && companyRole(existingUser,u.id)) return json(res,409,{error:"ALREADY_A_TEAM_MEMBER"});
    const pending=store.state.companyInvitations.find(i=>i.companyId===u.id&&i.email===email&&i.status==="pending"&&i.expiresAt>Date.now());
    if(pending) return json(res,409,{error:"INVITATION_ALREADY_PENDING"});
    const raw=token(), now=Date.now();
    const invitation={id:id(),companyId:u.id,email,role,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),status:"pending",createdAt:new Date(now).toISOString(),expiresAt:now+7*24*60*60*1000,invitedBy:u.id};
    store.state.companyInvitations.push(invitation);
    store.audit(u.id,"company.team.invitation.created","company",u.id,{email,role});
    await store.save();
    return json(res,201,{invitation:{id:invitation.id,email,role,status:invitation.status,expiresAt:invitation.expiresAt},invitationToken:raw,delivery:"manual"});
  }
  if(method==="POST" && p==="/api/company/team/accept") {
    const u=requireUser(req,res); if(!u)return;
    const b=await readBody(req), supplied=String(b.invitationToken||"");
    if(supplied.length<20) return json(res,400,{error:"INVALID_INVITATION"});
    const hash=crypto.createHash("sha256").update(supplied).digest("hex");
    const invitation=store.state.companyInvitations.find(i=>i.tokenHash===hash&&i.status==="pending");
    if(!invitation || invitation.expiresAt<Date.now()) return json(res,404,{error:"INVITATION_NOT_FOUND_OR_EXPIRED"});
    if(u.email!==invitation.email) return json(res,403,{error:"INVITATION_EMAIL_MISMATCH"});
    if(u.id===invitation.companyId) return json(res,400,{error:"INVALID_TEAM_MEMBER"});
    const prior=store.state.companyMembers.find(m=>m.companyId===invitation.companyId&&m.userId===u.id);
    if(prior){ prior.role=invitation.role; prior.status="active"; prior.updatedAt=new Date().toISOString(); }
    else store.state.companyMembers.push({id:id(),companyId:invitation.companyId,userId:u.id,role:invitation.role,status:"active",createdAt:new Date().toISOString(),invitedBy:invitation.invitedBy});
    invitation.status="accepted"; invitation.acceptedBy=u.id; invitation.acceptedAt=new Date().toISOString(); delete invitation.tokenHash;
    store.audit(u.id,"company.team.invitation.accepted","company",invitation.companyId,{role:invitation.role});
    await store.save();
    return json(res,200,{membership:store.state.companyMembers.find(m=>m.companyId===invitation.companyId&&m.userId===u.id)});
  }
  if(method==="GET" && p==="/api/company/team") {
    const u=requireUser(req,res); if(!u)return;
    const memberships=store.state.companyMembers.filter(m=>m.userId===u.id&&m.status==="active");
    const requestedCompanyId=url.searchParams.get("companyId");
    const companyId=requestedCompanyId||(u.accountType==="company"?u.id:(memberships.length===1?memberships[0].companyId:null));
    if(!companyId && memberships.length>1) return json(res,200,{workspaces:memberships.map(m=>({companyId:m.companyId,role:m.role,companyName:store.state.users.find(x=>x.id===m.companyId)?.companyName||"Company"}))});
    if(!companyId || !companyCanRead(u,companyId)) return json(res,403,{error:"COMPANY_ACCESS_REQUIRED"});
    const company=store.state.users.find(x=>x.id===companyId&&x.accountType==="company");
    if(!company) return json(res,404,{error:"COMPANY_NOT_FOUND"});
    const members=store.state.companyMembers.filter(m=>m.companyId===companyId&&m.status==="active").map(m=>({id:m.id,userId:m.userId,role:m.role,createdAt:m.createdAt,user:(()=>{const x=store.state.users.find(z=>z.id===m.userId);return x?{id:x.id,name:x.name,email:x.email}:null;})()})).filter(m=>m.user);
    const invitations=companyId===u.id?store.state.companyInvitations.filter(i=>i.companyId===companyId&&i.status==="pending").map(({tokenHash,...i})=>i):[];
    return json(res,200,{companyId,role:companyRole(u,companyId),members,invitations});
  }
  if(method==="DELETE" && p.match(/^\/api\/company\/team\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="company") return json(res,403,{error:"COMPANY_ACCOUNT_REQUIRED"});
    const memberId=p.split("/").at(-1), member=store.state.companyMembers.find(m=>m.companyId===u.id&&m.userId===memberId&&m.status==="active");
    if(!member) return json(res,404,{error:"TEAM_MEMBER_NOT_FOUND"});
    member.status="removed"; member.removedAt=new Date().toISOString();
    store.audit(u.id,"company.team.member.removed","company",u.id,{memberId});
    await store.save(); return json(res,200,{ok:true});
  }
  if(method==="PATCH" && p==="/api/company") {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="company") return json(res,403,{error:"COMPANY_ACCOUNT_REQUIRED"});
    const b=await readBody(req),identityBefore=[u.companyName,u.companyIndustry,u.companyWebsite].join("|");
    for(const [key,max] of [["companyName",100],["companyIndustry",100],["companyWebsite",200],["location",180],["about",1200]]) if(key in b) u[key]=cleanText(b[key],max);
    const identityAfter=[u.companyName,u.companyIndustry,u.companyWebsite].join("|");
    if(identityBefore!==identityAfter&&u.companyVerification?.status&&u.companyVerification.status!=="unverified"){u.companyVerification={status:"unverified",invalidatedAt:new Date().toISOString()};store.audit(u.id,"company.verification.invalidated","company",u.id,{reason:"identity_changed"});}
    if(!u.companyName || !u.companyIndustry) return json(res,400,{error:"COMPANY_IDENTITY_INCOMPLETE",message:"Le nom et le secteur de l’entreprise sont requis."});
    if(u.companyWebsite && !/^https:\/\//i.test(u.companyWebsite)) return json(res,400,{error:"INVALID_COMPANY_WEBSITE",message:"Le site de l’entreprise doit commencer par https://."});
    u.updatedAt=new Date().toISOString(); store.audit(u.id,"company.profile.updated","company",u.id); await store.save();
    return json(res,200,{company:publicProfile(u)});
  }
  if(method==="POST" && p==="/api/company/verification") {
    const u=requireUser(req,res);if(!u)return;
    if(u.accountType!=="company")return json(res,403,{error:"COMPANY_ACCOUNT_REQUIRED"});
    if(["pending","verified"].includes(u.companyVerification?.status))return json(res,409,{error:"COMPANY_VERIFICATION_ALREADY_ACTIVE"});
    const b=await readBody(req),businessEmail=cleanText(b.businessEmail,254).toLowerCase(),proofNote=cleanText(b.proofNote,1200);
    if(!emailValid(businessEmail)||!u.companyName||!u.companyIndustry||!/^https:\/\//i.test(u.companyWebsite||"")||proofNote.length<30)return json(res,400,{error:"COMPANY_VERIFICATION_DETAILS_REQUIRED",message:"Provide a business email, HTTPS company website and at least 30 characters explaining the public evidence reviewers can check."});
    u.companyVerification={status:"pending",businessEmail,proofNote,submittedAt:new Date().toISOString()};
    store.audit(u.id,"company.verification.submitted","company",u.id);await store.save();
    return json(res,201,{companyVerification:{status:"pending",submittedAt:u.companyVerification.submittedAt}});
  }
  if(method==="POST" && p==="/api/company/offers") {
    const u=requireUser(req,res); if(!u)return;
    const companyId=u.accountType==="company"?u.id:store.state.companyMembers.find(m=>m.userId===u.id&&m.status==="active"&&m.role==="recruiter")?.companyId;
    if(!companyId || !companyCanRecruit(u,companyId)) return json(res,403,{error:"COMPANY_RECRUITER_REQUIRED"});
    const company=store.state.users.find(x=>x.id===companyId&&x.accountType==="company");
    if(!company?.companyName || !company?.companyIndustry) return json(res,400,{error:"COMPANY_IDENTITY_INCOMPLETE"});
    const b=await readBody(req), title=cleanText(b.title,120), description=cleanText(b.description,1800);
    const skills=[...new Set((Array.isArray(b.skills)?b.skills:[]).map(x=>cleanText(x,60)).filter(Boolean))].slice(0,12);
    const type=["job","internship","apprenticeship","collaboration","graduate_program","vie","research_project"].includes(b.type)?b.type:"job";
    if(title.length<4 || description.length<30) return json(res,400,{error:"OFFER_CONTENT_REQUIRED",message:"Ajoute un intitulé et une description suffisamment précise."});
    const recommendedAssessments=recommendAssessments(skills);
    const keywords=value=>[...new Set((Array.isArray(value)?value:String(value||"").split(/[,;]+/)).map(x=>cleanText(x,60)).filter(Boolean))].slice(0,10);
    const experienceKeywords=keywords(b.experienceKeywords),educationKeywords=keywords(b.educationKeywords),targetStudyLevels=keywords(b.targetStudyLevels);
    const startDate=cleanText(b.startDate,40),duration=cleanText(b.duration,80),rhythm=cleanText(b.rhythm,80),compensation=cleanText(b.compensation,200),supervision=cleanText(b.supervision,120);
    const aiPolicy=["allowed","prohibited","expected"].includes(b.aiPolicy)?b.aiPolicy:"allowed";
    const aiPolicyNote=cleanText(b.aiPolicyNote,300);
    if(["internship","apprenticeship"].includes(type)&&(!startDate||!duration||!compensation))return json(res,400,{error:"EARLY_CAREER_OFFER_DETAILS_REQUIRED",message:"Pour publier un stage ou une alternance, indique la date de début, la durée et les conditions de gratification ou de rémunération."});
    const offer={id:id(),companyId,title,description,type,targetStudyLevels,startDate,duration,rhythm,compensation,supervision,location:cleanText(b.location,120),workMode:["onsite","hybrid","remote"].includes(b.workMode)?b.workMode:"hybrid",aiPolicy,aiPolicyNote,skills,experienceKeywords,educationKeywords,recommendedAssessments,assessmentSlugs:recommendedAssessments.map(x=>x.slug),assessmentPlanReviewed:false,status:"published",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    store.state.offers.push(offer); store.audit(u.id,"offer.published","offer",offer.id,{type,companyId}); await store.save();
    return json(res,201,{offer});
  }
  if(method==="GET" && p.match(/^\/api\/companies\/[^/]+$/)) {
    const companyId=p.split("/").at(-1), company=store.state.users.find(x=>x.id===companyId&&x.accountType==="company");
    if(!company) return json(res,404,{error:"COMPANY_NOT_FOUND"});
    const viewer=currentUser(req);
    if(viewer && store.state.blocks.some(b=>(b.blockerId===viewer.id&&b.blockedId===company.id)||(b.blockerId===company.id&&b.blockedId===viewer.id))) return json(res,404,{error:"COMPANY_NOT_FOUND"});
    const verified=company.companyVerification?.status==="verified";
    const offers=verified?store.state.offers.filter(o=>o.companyId===company.id&&o.status==="published").map(({id,title,description,type,targetStudyLevels,startDate,duration,rhythm,compensation,supervision,location,workMode,aiPolicy,aiPolicyNote,skills,createdAt})=>({id,title,description,type,targetStudyLevels,startDate,duration,rhythm,compensation,supervision,location,workMode,aiPolicy,aiPolicyNote,skills,createdAt})):[];
    return json(res,200,{company:{id:company.id,name:company.companyName||company.name,industry:company.companyIndustry,website:company.companyWebsite,location:company.location,about:company.about,verificationStatus:company.companyVerification?.status||"unverified",verified},offers});
  }
  if(method==="GET" && p==="/api/me/notifications") {
    const u=requireUser(req,res); if(!u)return;
    const notifications=store.state.notifications.filter(n=>n.recipientId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50);
    return json(res,200,{notifications,unreadCount:notifications.filter(n=>!n.readAt).length});
  }
  if(method==="PATCH" && p.match(/^\/api\/me\/notifications\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    const n=store.state.notifications.find(x=>x.id===p.split("/").at(-1)&&x.recipientId===u.id);
    if(!n) return json(res,404,{error:"NOTIFICATION_NOT_FOUND"});
    n.readAt ||= new Date().toISOString(); await store.save(); return json(res,200,{notification:n});
  }
  if(method==="GET" && p==="/api/offers") {
    const viewer=currentUser(req), companyId=url.searchParams.get("companyId");
    const offers=store.state.offers.filter(o=>o.status==="published"&&store.state.users.some(c=>c.id===o.companyId&&c.accountType==="company"&&c.companyVerification?.status==="verified")&&(!companyId||o.companyId===companyId)&&(!viewer||!store.state.blocks.some(b=>(b.blockerId===viewer.id&&b.blockedId===o.companyId)||(b.blockerId===o.companyId&&b.blockedId===viewer.id)))).map(o=>{
      const company=store.state.users.find(x=>x.id===o.companyId);
      const userSkills=new Set((viewer?.skills||[]).map(s=>s.name.toLowerCase()));
      const matched=o.skills.filter(s=>userSkills.has(s.toLowerCase()));
      const intentText=[viewer?.lookingFor,viewer?.canOffer,viewer?.interests].join(" ").toLowerCase();
      const intentHits=[...new Set([...(viewer?.lookingFor||"").split(/[,;]+/),...(viewer?.interests||"").split(/[,;]+/)].map(x=>x.trim()).filter(x=>x.length>2&&o.description.toLowerCase().includes(x.toLowerCase())))];
      const reasons=[]; if(matched.length) reasons.push("Compétences correspondantes : "+matched.slice(0,4).join(", "));
      if(intentHits.length) reasons.push("Votre intention rejoint cette offre : "+intentHits.slice(0,2).join(", "));
      const dualMatch=viewer?.accountType==="candidate"?matchOpportunity({...viewer,assessments:viewer.assessments||[],missions:viewer.missions||[]},{skills:o.skills,experienceKeywords:o.experienceKeywords||[],educationKeywords:o.educationKeywords||[],achievementKeywords:o.achievementKeywords||[],targetStudyLevels:o.targetStudyLevels||[]}):null;
      return {...o,company:company?{id:company.id,name:company.companyName||company.name,industry:company.companyIndustry,location:company.location,verified:true}:null,match:{matchedSkills:matched,reasons,signalCount:matched.length+intentHits.length,parcours:dualMatch?.parcours||null,technique:dualMatch?.technique||null}};
    }).filter(o=>o.company).sort((a,b)=>b.match.signalCount-a.match.signalCount).slice(0,100);
    return json(res,200,{offers});
  }
  if(method==="POST" && p.match(/^\/api\/offers\/[^/]+\/interest$/)) {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="candidate") return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const offer=store.state.offers.find(x=>x.id===p.split("/")[3]&&x.status==="published");
    if(!offer) return json(res,404,{error:"OFFER_NOT_FOUND"});
    const offerCompany=store.state.users.find(x=>x.id===offer.companyId);
    if(offerCompany?.companyVerification?.status!=="verified")return json(res,404,{error:"OFFER_NOT_FOUND"});
    const blocked=store.state.blocks.some(b=>(b.blockerId===u.id&&b.blockedId===offer.companyId)||(b.blockerId===offer.companyId&&b.blockedId===u.id));
    if(blocked) return json(res,403,{error:"INTERACTION_BLOCKED"});
    const existing=store.state.offerApplications.find(x=>x.offerId===offer.id&&x.candidateId===u.id);
    if(existing) return json(res,409,{error:"INTEREST_ALREADY_SENT"});
    // Profile sharing is offer-specific; assessment results require a separate, explicit opt-in.
    await readBody(req);const now=new Date().toISOString();
    const application={id:id(),offerId:offer.id,candidateId:u.id,status:"interest_sent",consentAt:now,assessmentConsentAt:null,assessmentSharing:{version:"1.0",assessmentIds:[],grantedAt:null,revokedAt:null},aiPolicyAtApplication:offer.aiPolicy||"allowed",aiPolicyNoteAtApplication:offer.aiPolicyNote||"",createdAt:now,updatedAt:now,statusHistory:[{status:"interest_sent",at:now,actorType:"candidate"}],privateNotes:[]};
    store.state.offerApplications.push(application);
    store.state.notifications.push({id:id(),recipientId:offer.companyId,type:"candidate_interest",title:"New candidate interest",body:`A candidate expressed interest in “${offer.title}”.`,targetType:"application",targetId:application.id,createdAt:new Date().toISOString(),readAt:null});
    store.audit(u.id,"offer.interest.sent","offer",offer.id); await store.save();
    return json(res,201,{application});
  }
  if(method==="GET" && p==="/api/company/applications") {
    const u=requireUser(req,res); if(!u)return;
    const companyIds=new Set([...(u.accountType==="company"?[u.id]:[]),...store.state.companyMembers.filter(m=>m.userId===u.id&&m.status==="active").map(m=>m.companyId)].filter(id=>companyCanRead(u,id)));
    if(!companyIds.size) return json(res,403,{error:"COMPANY_ACCESS_REQUIRED"});
    const owned=new Set(store.state.offers.filter(o=>companyIds.has(o.companyId)).map(o=>o.id));
    const applications=store.state.offerApplications.filter(a=>owned.has(a.offerId)&&a.status!=="withdrawn").map(a=>{const candidate=store.state.users.find(x=>x.id===a.candidateId),offer=store.state.offers.find(o=>o.id===a.offerId);const parcours=matchOpportunity(candidate||{},offer||{}).parcours;const sharing=a.assessmentSharing||{assessmentIds:[],grantedAt:a.assessmentConsentAt||null};const allowed=new Set(sharing.revokedAt?[]:(sharing.assessmentIds||[]));const sharedAssessments=(candidate?.assessments||[]).filter(x=>allowed.has(x.id)).map(x=>({id:x.id,title:x.title,domain:x.domain,skills:x.skills,version:x.version,score:x.score,status:x.status,correct:x.correct,total:x.total,completedAt:x.completedAt,reasoningEvidence:x.reasoningEvidence,aiUseDeclaration:x.aiUseDeclaration,evidenceType:x.evidenceType}));const sharedPracticalAssessments=(candidate?.practicalAssessments||[]).filter(x=>allowed.has(x.id)).map(x=>({id:x.id,title:x.title,domain:x.domain,skills:x.skills,version:x.version,completedAt:x.completedAt,response:x.response,aiUseDeclaration:x.aiUseDeclaration,review:x.review,status:x.status,evidenceType:x.evidenceType}));const technique=allowed.size?matchOpportunity({...candidate,assessments:sharedAssessments,missions:[]},offer||{}).technique:{score:null,status:"non_partage",coverage:0,skills:[],explanation:"Aucune évaluation autorisée par le candidat."};return {...a,assessmentSharing:{version:sharing.version||"1.0",assessmentIds:[...allowed],grantedAt:sharing.grantedAt||null,revokedAt:sharing.revokedAt||null},sharedAssessments,sharedPracticalAssessments,offer,candidate:publicProfile(candidate),match:{parcours,technique,assessmentShared:allowed.size>0},statusHistory:a.statusHistory||[],privateNotes:a.privateNotes||[]};});
    return json(res,200,{applications});
  }
  if(method==="PATCH" && p.match(/^\/api\/company\/applications\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    const app=store.state.offerApplications.find(a=>a.id===p.split("/").at(-1));
    const offer=app&&store.state.offers.find(o=>o.id===app.offerId);
    if(offer&&!companyCanRecruit(u,offer.companyId)) return json(res,403,{error:"COMPANY_RECRUITER_REQUIRED"});
    if(!app||!offer) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(app.status==="withdrawn") return json(res,409,{error:"APPLICATION_WITHDRAWN"});
    const b=await readBody(req);
    if(!["reviewing","interview","declined"].includes(b.status)) return json(res,400,{error:"INVALID_APPLICATION_STATUS"});
    const previousStatus=app.status; app.status=b.status; app.updatedAt=new Date().toISOString();
    app.statusHistory??=[]; if(previousStatus!==b.status) app.statusHistory.push({status:b.status,at:app.updatedAt,actorType:"company"});
    delete app.companyNote;
    if(previousStatus!==b.status) store.state.notifications.push({id:id(),recipientId:app.candidateId,type:"application_status",title:"Application status updated",body:`Your application for “${offer.title}” is now: ${b.status}.`,targetType:"application",targetId:app.id,createdAt:app.updatedAt,readAt:null});
    store.audit(u.id,"application.status.updated","application",app.id,{status:b.status});await store.save();
    return json(res,200,{application:app});
  }
  if(method==="POST" && p.match(/^\/api\/company\/applications\/[^/]+\/notes$/)) {
    const u=requireUser(req,res); if(!u)return;
    const appId=p.split("/").at(-2), app=store.state.offerApplications.find(a=>a.id===appId);
    const offer=app&&store.state.offers.find(o=>o.id===app.offerId);
    if(!app||!offer) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(!companyCanRecruit(u,offer.companyId)) return json(res,403,{error:"COMPANY_RECRUITER_REQUIRED"});
    if(app.status==="withdrawn") return json(res,409,{error:"APPLICATION_WITHDRAWN"});
    const b=await readBody(req), note=cleanText(b.note,1000);
    if(note.length<3) return json(res,400,{error:"NOTE_TOO_SHORT"});
    app.privateNotes??=[]; const entry={id:id(),authorId:u.id,note,createdAt:new Date().toISOString()};
    app.privateNotes.push(entry); store.audit(u.id,"application.private_note.added","application",app.id); await store.save();
    return json(res,201,{note:entry});
  }
  if(method==="PATCH" && p.match(/^\/api\/me\/applications\/[^/]+\/assessment-sharing$/)) {
    const u=requireUser(req,res);if(!u)return;
    if(u.accountType!=="candidate")return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const app=store.state.offerApplications.find(a=>a.id===p.split("/").at(-2)&&a.candidateId===u.id);
    if(!app)return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(app.status==="withdrawn")return json(res,409,{error:"APPLICATION_WITHDRAWN"});
    const body=await readBody(req),ids=body.assessmentIds;
    if(!Array.isArray(ids)||ids.length>30||ids.some(x=>typeof x!=="string"||x.length>100))return json(res,400,{error:"INVALID_ASSESSMENT_SELECTION"});
    const available=new Map([...(u.assessments||[]),...(u.practicalAssessments||[])].map(x=>[x.id,x]));
    if(ids.some(x=>!available.has(x)))return json(res,400,{error:"ASSESSMENT_NOT_OWNED"});
    const unique=[...new Set(ids)],now=new Date().toISOString(),previous=app.assessmentSharing||{assessmentIds:[]};
    app.assessmentSharing={version:"1.0",assessmentIds:unique,grantedAt:unique.length?(previous.grantedAt||now):null,revokedAt:unique.length?null:now,updatedAt:now};
    app.assessmentConsentAt=unique.length?app.assessmentSharing.grantedAt:null;app.updatedAt=now;
    store.audit(u.id,unique.length?"application.assessments.shared":"application.assessments.revoked","application",app.id,{assessmentIds:unique,consentVersion:"1.0"});
    await store.save();return json(res,200,{assessmentSharing:app.assessmentSharing});
  }
  if(method==="GET" && p==="/api/me/applications") {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="candidate") return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const applications=store.state.offerApplications.filter(a=>a.candidateId===u.id).map(a=>{ const {privateNotes,...safeApp}=a; const offer=store.state.offers.find(o=>o.id===a.offerId); const companyUser=store.state.users.find(x=>x.id===offer?.companyId); return {...safeApp,assessmentSharing:a.assessmentSharing||{version:"1.0",assessmentIds:[],grantedAt:a.assessmentConsentAt||null,revokedAt:null},statusHistory:a.statusHistory||[],offer,company:companyUser?{name:companyUser.companyName||companyUser.name,industry:companyUser.companyIndustry}:null}; });
    return json(res,200,{applications});
  }
  if(method==="PATCH" && p.match(/^\/api\/me\/applications\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="candidate") return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const app=store.state.offerApplications.find(a=>a.id===p.split("/").at(-1)&&a.candidateId===u.id);
    if(!app) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(app.status==="withdrawn") return json(res,409,{error:"APPLICATION_ALREADY_WITHDRAWN"});
    app.status="withdrawn";app.withdrawnAt=new Date().toISOString();app.updatedAt=app.withdrawnAt;delete app.companyNote;app.privateNotes=[];app.statusHistory??=[];app.statusHistory.push({status:"withdrawn",at:app.withdrawnAt,actorType:"candidate"});
    store.audit(u.id,"application.withdrawn","application",app.id);await store.save();
    return json(res,200,{application:app});
  }
  if(method==="PATCH" && p.match(/^\/api\/company\/offers\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    const offer=store.state.offers.find(o=>o.id===p.split("/").at(-1));
    if(offer&&!companyCanRecruit(u,offer.companyId)) return json(res,403,{error:"COMPANY_RECRUITER_REQUIRED"});
    if(!offer) return json(res,404,{error:"OFFER_NOT_FOUND"});
    const b=await readBody(req);
    if("status" in b){if(!["published","closed"].includes(b.status)) return json(res,400,{error:"INVALID_OFFER_STATUS"});offer.status=b.status;}
    if("aiPolicy" in b){if(!["allowed","prohibited","expected"].includes(b.aiPolicy))return json(res,400,{error:"INVALID_AI_POLICY"});offer.aiPolicy=b.aiPolicy;offer.aiPolicyNote=cleanText(b.aiPolicyNote,300);}
    if("assessmentSlugs" in b){
      if(!Array.isArray(b.assessmentSlugs)||b.assessmentSlugs.length>10||b.assessmentSlugs.some(x=>typeof x!=="string"||!assessmentCatalog().some(a=>a.slug===x)))return json(res,400,{error:"INVALID_ASSESSMENT_PLAN"});
      offer.assessmentSlugs=[...new Set(b.assessmentSlugs)];offer.assessmentPlanReviewed=true;
      offer.recommendedAssessments=assessmentCatalog().filter(a=>offer.assessmentSlugs.includes(a.slug)).map(({slug,title,domain,level,version,skills})=>({slug,title,domain,level,version,skills}));
    }
    if(!("status" in b)&&!("assessmentSlugs" in b)&&!("aiPolicy" in b))return json(res,400,{error:"NO_OFFER_CHANGES"});
    offer.updatedAt=new Date().toISOString();store.audit(u.id,"offer.updated","offer",offer.id,{status:offer.status,assessmentPlanReviewed:offer.assessmentPlanReviewed,aiPolicy:offer.aiPolicy||"allowed"});await store.save();
    return json(res,200,{offer});
  }
  if(method==="GET" && p==="/api/me/offers") {
    const u=requireUser(req,res); if(!u)return;
    const companyIds=new Set([...(u.accountType==="company"?[u.id]:[]),...store.state.companyMembers.filter(m=>m.userId===u.id&&m.status==="active").map(m=>m.companyId)].filter(id=>companyCanRead(u,id)));
    if(!companyIds.size) return json(res,403,{error:"COMPANY_ACCESS_REQUIRED"});
    const offers=store.state.offers.filter(o=>companyIds.has(o.companyId));
    return json(res,200,{offers});
  }
  if(method==="GET" && p==="/api/discover") {
    const u=currentUser(req);if(u&&!hasLegalConsent(u))return json(res,428,{error:"LEGAL_CONSENT_REQUIRED"});
    const q=cleanText(url.searchParams.get("q"),80).toLowerCase();
    const requestedLimit=url.searchParams.has("limit")?Number(url.searchParams.get("limit")):50,cursorToken=url.searchParams.get("cursor");
    if(!Number.isSafeInteger(requestedLimit)||requestedLimit<1||requestedLimit>100)return json(res,400,{error:"INVALID_DISCOVERY_PAGE"});
    const limit=Math.min(50,requestedLimit);let after=null;
    if(cursorToken){try{if(cursorToken.length>512)throw new Error("cursor too long");after=JSON.parse(Buffer.from(cursorToken,"base64url").toString("utf8"));}catch{return json(res,400,{error:"INVALID_DISCOVERY_PAGE"});}if(!after||!Number.isFinite(after.score)||typeof after.name!=="string"||after.name.length>160||typeof after.id!=="string"||after.id.length>80)return json(res,400,{error:"INVALID_DISCOVERY_PAGE"});}
    const blockedIds=u?new Set(store.state.blocks.filter(b=>b.blockerId===u.id||b.blockedId===u.id).flatMap(b=>[b.blockerId===u.id?b.blockedId:b.blockerId])):new Set();
    const compareDiscovery=(a,b)=>b.matchScore-a.matchScore||a.name.localeCompare(b.name)||a.id.localeCompare(b.id);
    const allUsers=store.state.users.filter(x=>x.accountType!=="company" && (u ? (x.id!==u.id && !blockedIds.has(x.id)) : x.visibility==="public")).map(x=>({ ...publicProfile(x),...(u?complementarity(u,x):{matchScore:0,matchReasons:[]}) }))
      .filter(x=>profileMatchesQuery(x,q))
      .sort(compareDiscovery);
    const total=allUsers.length,afterIndex=after?allUsers.findIndex(x=>compareDiscovery(x,{matchScore:after.score,name:after.name,id:after.id})>0):-1,start=after?(afterIndex<0?total:afterIndex):0,users=allUsers.slice(start,start+limit),last=users.at(-1);
    const nextCursor=start+users.length<total&&last?Buffer.from(JSON.stringify({score:last.matchScore,name:last.name,id:last.id})).toString("base64url"):null;
    return json(res,200,{users,total,nextCursor,hasMore:!!nextCursor,connectionCount:u?store.state.connections.filter(c=>c.status==="accepted"&&(c.fromUserId===u.id||c.toUserId===u.id)).length:0});
  }

  if(method==="POST" && p.match(/^\/api\/profiles\/[^/]+\/connect$/)) {
    const u=requireUser(req,res); if(!u)return;
    const targetId=p.split("/")[3], target=store.state.users.find(x=>x.id===targetId);
    if(!target) return json(res,404,{error:"PROFILE_NOT_FOUND"});
    if(store.state.blocks.some(b=>(b.blockerId===u.id&&b.blockedId===target.id)||(b.blockerId===target.id&&b.blockedId===u.id))) return json(res,403,{error:"INTERACTION_BLOCKED"});
    if(target.id===u.id) return json(res,400,{error:"SELF_CONNECTION"});
    const b=await readBody(req), reason=cleanText(b.reason,500);
    if(reason.length<20) return json(res,400,{error:"CONNECTION_CONTEXT_REQUIRED",message:"Explique en au moins 20 caractères pourquoi cette rencontre aurait du sens."});
    const existing=store.state.connections.find(c=>((c.fromUserId===u.id && c.toUserId===target.id)||(c.fromUserId===target.id && c.toUserId===u.id)) && ["pending","accepted"].includes(c.status));
    if(existing) return json(res,409,{error:"CONNECTION_EXISTS",message:"Une demande ou une connexion existe déjà entre ces deux membres."});
    const connection={id:id(),fromUserId:u.id,toUserId:target.id,reason,status:"pending",createdAt:new Date().toISOString()};
    store.state.connections.push(connection); store.audit(u.id,"connection.requested","connection",connection.id); await store.save();
    return json(res,201,{connection});
  }
  if(method==="GET" && p==="/api/me/connections") {
    const u=requireUser(req,res); if(!u)return;
    const blockedIds=new Set(store.state.blocks.filter(b=>b.blockerId===u.id||b.blockedId===u.id).map(b=>b.blockerId===u.id?b.blockedId:b.blockerId));
    const connections=store.state.connections.filter(c=>(c.fromUserId===u.id||c.toUserId===u.id)&&!blockedIds.has(c.fromUserId===u.id?c.toUserId:c.fromUserId)).map(c=>({...c,from:publicProfile(store.state.users.find(x=>x.id===c.fromUserId)),to:publicProfile(store.state.users.find(x=>x.id===c.toUserId)),direction:c.fromUserId===u.id?"outgoing":"incoming"}));
    return json(res,200,{connections});
  }
  if(method==="PATCH" && p.match(/^\/api\/me\/connections\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return;
    const c=store.state.connections.find(x=>x.id===p.split("/").at(-1));
    if(!c) return json(res,404,{error:"CONNECTION_NOT_FOUND"});
    if(c.toUserId!==u.id) return json(res,403,{error:"CONNECTION_RECIPIENT_ONLY"});
    if(c.status!=="pending") return json(res,409,{error:"CONNECTION_NOT_PENDING"});
    const b=await readBody(req); if(!["accepted","rejected"].includes(b.status)) return json(res,400,{error:"INVALID_CONNECTION_STATUS"});
    c.status=b.status; c.respondedAt=new Date().toISOString(); store.audit(u.id,`connection.${b.status}`,"connection",c.id); await store.save();
    return json(res,200,{connection:c});
  }
  if(method==="GET" && p.startsWith("/api/profiles/")) {
    const uid=p.split("/").at(-1), viewer=currentUser(req),candidate=store.state.users.find(x=>x.id===uid);
    if(viewer&&!hasLegalConsent(viewer)&&candidate?.visibility!=="public")return json(res,428,{error:"LEGAL_CONSENT_REQUIRED"});
    const blocked=viewer&&store.state.blocks.some(b=>(b.blockerId===viewer.id&&b.blockedId===uid)||(b.blockerId===uid&&b.blockedId===viewer.id)); const u=store.state.users.find(x=>x.id===uid && (x.visibility==="public" || !!viewer));
    if(blocked) return json(res,404,{error:"NOT_FOUND"});
    if(!u) return json(res,404,{error:"NOT_FOUND"});
    return json(res,200,{user:publicProfile(u),evidence:store.state.evidence.filter(e=>e.userId===u.id).map(({url,...e})=>({...e,url}))});
  }

  if(method==="POST" && p.match(/^\/api\/profiles\/[^/]+\/report$/)) {
    const u=requireUser(req,res); if(!u)return;
    const targetId=p.split("/")[3], target=store.state.users.find(x=>x.id===targetId && x.id!==u.id);
    if(!target) return json(res,404,{error:"PROFILE_NOT_FOUND"});
    const b=await readBody(req), reason=cleanText(b.reason,1000), category=["harassment","impersonation","spam","misleading","other"].includes(b.category)?b.category:"other";
    if(reason.length<20) return json(res,400,{error:"REPORT_CONTEXT_REQUIRED",message:"Décris le problème en au moins 20 caractères."});
    const duplicate=store.state.reports.find(r=>r.reporterId===u.id&&r.targetUserId===targetId&&r.status==="open");
    if(duplicate) return json(res,409,{error:"REPORT_ALREADY_OPEN"});
    const report={id:id(),reporterId:u.id,targetUserId:targetId,category,reason,status:"open",createdAt:new Date().toISOString()};
    store.state.reports.push(report); store.audit(u.id,"profile.reported","user",targetId,{reportId:report.id,category}); await store.save();
    return json(res,201,{report:{id:report.id,status:report.status}});
  }
  if(method==="POST" && p.match(/^\/api\/me\/blocks\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; const targetId=p.split("/").at(-1);
    if(targetId===u.id || !store.state.users.some(x=>x.id===targetId)) return json(res,404,{error:"MEMBER_NOT_FOUND"});
    if(store.state.blocks.some(b=>b.blockerId===u.id&&b.blockedId===targetId)) return json(res,409,{error:"ALREADY_BLOCKED"});
    store.state.blocks.push({id:id(),blockerId:u.id,blockedId:targetId,createdAt:new Date().toISOString()});
    store.state.connections=store.state.connections.filter(c=>!((c.fromUserId===u.id&&c.toUserId===targetId)||(c.fromUserId===targetId&&c.toUserId===u.id)));
    store.audit(u.id,"member.blocked","user",targetId); await store.save(); return json(res,201,{ok:true});
  }
  if(method==="DELETE" && p.match(/^\/api\/me\/blocks\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; const targetId=p.split("/").at(-1);
    const before=store.state.blocks.length; store.state.blocks=store.state.blocks.filter(b=>!(b.blockerId===u.id&&b.blockedId===targetId));
    if(before===store.state.blocks.length) return json(res,404,{error:"BLOCK_NOT_FOUND"});
    store.audit(u.id,"member.unblocked","user",targetId); await store.save(); return json(res,200,{ok:true});
  }
  if(method==="GET" && p==="/api/me/blocks") {
    const u=requireUser(req,res); if(!u)return;
    return json(res,200,{blocks:store.state.blocks.filter(b=>b.blockerId===u.id).map(b=>({id:b.id,user:publicProfile(store.state.users.find(x=>x.id===b.blockedId)),createdAt:b.createdAt}))});
  }
  if(method==="GET" && p==="/api/review/health") {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    let dataBytes=0;try{dataBytes=fs.statSync(store.file).size;}catch{}
    const backupDir=path.join(DATA,"backups");
    let backup={available:false,verified:false,createdAt:null,ageHours:null,offsite:false};
    try{
      const files=fs.readdirSync(backupDir).filter(n=>n.endsWith(".json")&&!n.endsWith(".manifest.json")).sort().reverse();
      if(files.length){
        const file=path.join(backupDir,files[0]),bytes=fs.readFileSync(file),manifest=JSON.parse(fs.readFileSync(file+".manifest.json","utf8"));
        const verified=crypto.createHash("sha256").update(bytes).digest("hex")===manifest.sha256&&bytes.length===manifest.bytes;
        const createdAt=manifest.createdAt||null;
        backup={available:true,verified,createdAt,ageHours:createdAt?Math.round((Date.now()-Date.parse(createdAt))/3600000*10)/10:null,offsite:false};
      }
    }catch{}
    return json(res,200,{service:"ZERILYS",version:VERSION,storage:{backend:"JSON file",singleInstance:true,dataBytes},rateLimitMode:process.env.ZERIHLINK_TRUST_PROXY==="true"?"trusted reverse-proxy client IP":"socket peer IP",integrity:inspectStore(store.state),counts:{users:store.state.users.length,candidates:store.state.users.filter(x=>x.accountType!=="company").length,companies:store.state.users.filter(x=>x.accountType==="company").length,activeSessions:store.state.sessions.filter(x=>x.expiresAt>Date.now()).length,pendingReports:store.state.reports.filter(x=>x.status==="open").length,pendingEvidence:store.state.evidence.filter(x=>x.status==="pending_review").length,pendingBetaInvitations:store.state.betaInvitations.filter(x=>x.status==="pending"&&x.expiresAt>Date.now()).length,pendingCompanyVerifications:store.state.users.filter(x=>x.accountType==="company"&&x.companyVerification?.status==="pending").length},backup});
  }
  if(method==="POST" && p==="/api/review/invitations/bulk") {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const b=await readBody(req),rawEmails=Array.isArray(b.emails)?b.emails:[];
    if(!rawEmails.length||rawEmails.length>50)return json(res,400,{error:"INVITATION_BATCH_SIZE_INVALID",message:"Provide between 1 and 50 email addresses."});
    const emails=rawEmails.map(value=>cleanText(value,254).toLowerCase());
    if(emails.some(email=>!emailValid(email)))return json(res,400,{error:"INVALID_EMAIL",invalidEmails:emails.filter(email=>!emailValid(email))});
    if(new Set(emails).size!==emails.length)return json(res,400,{error:"DUPLICATE_EMAILS"});
    const conflicts=emails.filter(email=>store.userByEmail(email)||store.state.betaInvitations.some(i=>i.email===email&&i.status==="pending"&&i.expiresAt>Date.now()));
    if(conflicts.length)return json(res,409,{error:"INVITATION_CONFLICTS",conflicts});
    const accountType=["candidate","company"].includes(b.accountType)?b.accountType:"candidate",days=Math.min(30,Math.max(1,Number.isInteger(b.validDays)?b.validDays:14)),createdAt=new Date().toISOString(),expiresAt=Date.now()+days*24*60*60*1000,batchId=id();
    const created=emails.map(email=>{const raw=token(),invitation={id:id(),batchId,email,accountType,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),status:"pending",createdAt,expiresAt,createdBy:u.id};store.state.betaInvitations.push(invitation);store.audit(u.id,"beta.invitation.created","beta_invitation",invitation.id,{email,accountType,validDays:days,batch:true,batchId});return{invitation,raw,delivery:"manual"};});
    await store.save();const deliveryConfig=emailDeliveryConfig();
    if(deliveryConfig.configured){for(let i=0;i<created.length;i+=5){await Promise.all(created.slice(i,i+5).map(async item=>{const text=`You are invited to the ZERILYS private beta.\n\nYour one-time invitation token: ${item.raw}\n\nOpen ${deliveryConfig.appUrl}, choose Create account and enter this token. It expires in ${days} day(s). If you did not expect this invitation, ignore this message.`;const html=`<p>You are invited to the ZERILYS private beta.</p><p>Your one-time invitation token:</p><p><code>${escapeHtml(item.raw)}</code></p><p>Open <a href="${escapeHtml(deliveryConfig.appUrl)}">${escapeHtml(deliveryConfig.appUrl)}</a>, choose Create account and enter this token. It expires in ${days} day(s).</p><p>If you did not expect this invitation, ignore this message.</p>`;try{await sendTransactionalEmail({to:item.invitation.email,subject:"Your ZERILYS private beta invitation",text,html});item.delivery="email";store.audit(u.id,"beta.invitation.email_sent","beta_invitation",item.invitation.id,{email:item.invitation.email,batch:true});}catch{item.delivery="manual_fallback";store.audit(u.id,"beta.invitation.email_failed","beta_invitation",item.invitation.id,{email:item.invitation.email,batch:true});}}));}await store.save();}
    const results=created.map(({invitation,raw,delivery})=>({invitation:{id:invitation.id,email:invitation.email,accountType:invitation.accountType,status:invitation.status,expiresAt:invitation.expiresAt},delivery,...(delivery==="email"?{}:{invitationToken:raw})}));
    return json(res,201,{batchId,created:results.length,delivered:results.filter(x=>x.delivery==="email").length,manual:results.filter(x=>x.delivery!=="email").length,results});
  }
  if(method==="POST" && p==="/api/review/invitations") {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    const b=await readBody(req), email=cleanText(b.email,254).toLowerCase();
    const accountType=["candidate","company"].includes(b.accountType)?b.accountType:"candidate";
    if(!emailValid(email)) return json(res,400,{error:"INVALID_EMAIL"});
    if(store.userByEmail(email)) return json(res,409,{error:"EMAIL_EXISTS"});
    const pending=store.state.betaInvitations.find(i=>i.email===email&&i.status==="pending"&&i.expiresAt>Date.now());
    if(pending) return json(res,409,{error:"BETA_INVITATION_ALREADY_PENDING"});
    const days=Math.min(30,Math.max(1,Number.isInteger(b.validDays)?b.validDays:14));
    const raw=token(),invitation={id:id(),email,accountType,tokenHash:crypto.createHash("sha256").update(raw).digest("hex"),status:"pending",createdAt:new Date().toISOString(),expiresAt:Date.now()+days*24*60*60*1000,createdBy:u.id};
    store.state.betaInvitations.push(invitation);store.audit(u.id,"beta.invitation.created","beta_invitation",invitation.id,{email,accountType,validDays:days});await store.save();
    let delivery="manual";
    if(emailDeliveryConfig().configured){
      const appUrl=emailDeliveryConfig().appUrl;
      const text=`You are invited to the ZERILYS private beta.\n\nYour one-time invitation token: ${raw}\n\nOpen ${appUrl}, choose Create account and enter this token. It expires in ${days} day(s). If you did not expect this invitation, ignore this message.`;
      const html=`<p>You are invited to the ZERILYS private beta.</p><p>Your one-time invitation token:</p><p><code>${escapeHtml(raw)}</code></p><p>Open <a href="${escapeHtml(appUrl)}">${escapeHtml(appUrl)}</a>, choose Create account and enter this token. It expires in ${days} day(s).</p><p>If you did not expect this invitation, ignore this message.</p>`;
      try{await sendTransactionalEmail({to:email,subject:"Your ZERILYS private beta invitation",text,html});delivery="email";store.audit(u.id,"beta.invitation.email_sent","beta_invitation",invitation.id,{email});await store.save();}
      catch{delivery="manual_fallback";store.audit(u.id,"beta.invitation.email_failed","beta_invitation",invitation.id,{email});await store.save();}
    }
    return json(res,201,{invitation:{id:invitation.id,email,accountType,status:invitation.status,expiresAt:invitation.expiresAt},...(delivery==="email"?{}:{invitationToken:raw}),delivery});
  }
  if(method==="GET" && p==="/api/review/invitations") {
    const u=requireUser(req,res);if(!u)return;if(!REVIEWERS.has(u.email))return json(res,403,{error:"REVIEWER_REQUIRED"});
    const own=store.state.betaInvitations,now=Date.now(),pending=own.filter(i=>i.status==="pending"&&i.expiresAt>now).map(({tokenHash,...i})=>i).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)),groups=new Map();
    for(const invitation of own){if(!invitation.batchId)continue;let group=groups.get(invitation.batchId);if(!group){group={batchId:invitation.batchId,createdAt:invitation.createdAt,accountType:invitation.accountType,total:0,pending:0,accepted:0,revoked:0,expired:0};groups.set(invitation.batchId,group);}group.total++;const status=invitation.status==="pending"&&invitation.expiresAt<=now?"expired":invitation.status;if(Object.prototype.hasOwnProperty.call(group,status))group[status]++;}
    const batches=[...groups.values()].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,25),recent=own.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,100).map(({tokenHash,...i})=>({...i,effectiveStatus:i.status==="pending"&&i.expiresAt<=now?"expired":i.status}));
    return json(res,200,{invitations:pending,batches,recent,summary:{total:own.length,pending:own.filter(i=>i.status==="pending"&&i.expiresAt>now).length,accepted:own.filter(i=>i.status==="accepted").length,revoked:own.filter(i=>i.status==="revoked").length,expired:own.filter(i=>i.status==="pending"&&i.expiresAt<=now).length}});
  }
  if(method==="DELETE" && p.match(/^\/api\/review\/invitations\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    const invitation=store.state.betaInvitations.find(i=>i.id===p.split("/").at(-1)&&i.status==="pending");
    if(!invitation) return json(res,404,{error:"INVITATION_NOT_FOUND"});
    invitation.status="revoked";invitation.revokedAt=new Date().toISOString();delete invitation.tokenHash;
    store.audit(u.id,"beta.invitation.revoked","beta_invitation",invitation.id);await store.save();
    return json(res,200,{ok:true});
  }
  if(method==="GET" && p==="/api/review/reports") {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    return json(res,200,{reports:store.state.reports.filter(r=>r.status==="open").map(r=>({...r,reporter:publicProfile(store.state.users.find(x=>x.id===r.reporterId)),target:store.state.users.find(x=>x.id===r.targetUserId)?{id:r.targetUserId,name:store.state.users.find(x=>x.id===r.targetUserId).name}:null}))});
  }
  if(method==="PATCH" && p.match(/^\/api\/review\/reports\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; if(!REVIEWERS.has(u.email)) return json(res,403,{error:"REVIEWER_REQUIRED"});
    const report=store.state.reports.find(r=>r.id===p.split("/").at(-1)); if(!report) return json(res,404,{error:"REPORT_NOT_FOUND"});
    if(report.status!=="open") return json(res,409,{error:"REPORT_NOT_OPEN"});
    const b=await readBody(req); if(!["reviewed","dismissed"].includes(b.status)) return json(res,400,{error:"INVALID_REPORT_STATUS"});
    report.status=b.status; report.reviewedAt=new Date().toISOString(); report.reviewedBy=u.id; report.reviewNote=cleanText(b.note,500);
    store.audit(u.id,`report.${b.status}`,"report",report.id,{targetUserId:report.targetUserId}); await store.save(); return json(res,200,{report});
  }
  if(method==="GET" && p==="/api/projects") {
    const projects=store.state.projects.filter(x=>x.status==="open").map(({tasks,...x})=>({...x,owner:publicProfile(store.state.users.find(u=>u.id===x.ownerId)),applicationsCount:store.state.applications.filter(a=>a.projectId===x.id).length}));
    return json(res,200,{projects});
  }
  if(method==="POST" && p==="/api/projects") {
    const u=requireUser(req,res); if(!u)return; const b=await readBody(req);
    const normalized=normalizeProjectInput(b,u);
    if(normalized.error) return json(res,400,{error:normalized.error,message:normalized.message});
    const project={id:id(),ownerId:u.id,...normalized.project};
    store.state.projects.push(project); store.audit(u.id,"project.created","project",project.id,{projectType:project.projectType,compensation:project.compensation}); await store.save(); return json(res,201,{project});
  }
  if(method==="POST" && p.match(/^\/api\/projects\/[^/]+\/apply$/)) {
    const u=requireUser(req,res); if(!u)return; const pid=p.split("/")[3], project=store.state.projects.find(x=>x.id===pid && x.status==="open");
    if(!project) return json(res,404,{error:"PROJECT_NOT_FOUND"});
    if(project.ownerId===u.id) return json(res,400,{error:"OWN_PROJECT"});
    if(store.state.applications.some(a=>a.projectId===pid && a.userId===u.id)) return json(res,409,{error:"ALREADY_APPLIED"});
    const b=await readBody(req), app={id:id(),projectId:pid,userId:u.id,message:cleanText(b.message,500),status:"pending",createdAt:new Date().toISOString()};
    store.state.applications.push(app); store.audit(u.id,"project.application.created","application",app.id); await store.save(); return json(res,201,{application:app});
  }
  if(method==="GET" && p.match(/^\/api\/projects\/[^/]+\/applications$/)) {
    const u=requireUser(req,res); if(!u)return;
    const project=store.state.projects.find(x=>x.id===p.split("/")[3]);
    if(!project)return json(res,404,{error:"PROJECT_NOT_FOUND"});
    if(project.ownerId!==u.id)return json(res,403,{error:"PROJECT_OWNER_REQUIRED"});
    const applications=store.state.applications.filter(a=>a.projectId===project.id).map(a=>({...a,applicant:publicProfile(store.state.users.find(x=>x.id===a.userId))}));
    return json(res,200,{applications});
  }
  if(method==="PATCH" && p.match(/^\/api\/projects\/[^/]+\/applications\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; const parts=p.split("/"), pid=parts[3], aid=parts[5], project=store.state.projects.find(x=>x.id===pid && x.ownerId===u.id), app=store.state.applications.find(x=>x.id===aid && x.projectId===pid);
    if(!project) return json(res,404,{error:"PROJECT_NOT_FOUND"}); if(!app) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    const b=await readBody(req); if(!["accepted","rejected"].includes(b.status)) return json(res,400,{error:"INVALID_APPLICATION_STATUS"});
    if(b.status==="accepted"&&!canAcceptProjectApplication(project,store.state.applications,app.id)) return json(res,409,{error:"PROJECT_TEAM_FULL",message:"La capacité maximale de l'équipe est atteinte."});
    app.status=b.status; app.reviewedAt=new Date().toISOString(); store.audit(u.id,`application.${b.status}`,"application",app.id); await store.save(); return json(res,200,{application:app});
  }
  if(method==="GET" && p.match(/^\/api\/projects\/[^/]+\/tasks$/)) {
    const u=requireUser(req,res); if(!u)return; const project=store.state.projects.find(x=>x.id===p.split("/")[3]); if(!project)return json(res,404,{error:"PROJECT_NOT_FOUND"});
    const memberIds=new Set([project.ownerId,...store.state.applications.filter(a=>a.projectId===project.id&&a.status==="accepted").map(a=>a.userId)]);
    if(!memberIds.has(u.id))return json(res,403,{error:"PROJECT_TEAM_ACCESS_REQUIRED"});
    return json(res,200,{tasks:project.tasks||[],members:[...memberIds].map(uid=>{const m=store.state.users.find(x=>x.id===uid);return m?{id:m.id,name:m.name}:null;}).filter(Boolean)});
  }
  if(method==="POST" && p.match(/^\/api\/projects\/[^/]+\/tasks$/)) {
    const u=requireUser(req,res); if(!u)return; const project=store.state.projects.find(x=>x.id===p.split("/")[3]&&x.status==="open"); if(!project)return json(res,404,{error:"PROJECT_NOT_FOUND"});
    const memberIds=[project.ownerId,...store.state.applications.filter(a=>a.projectId===project.id&&a.status==="accepted").map(a=>a.userId)];
    if(!memberIds.includes(u.id))return json(res,403,{error:"PROJECT_TEAM_ACCESS_REQUIRED"});
    const b=await readBody(req), normalized=normalizeProjectTask(b,project,u.id,memberIds); if(normalized.error)return json(res,400,{error:normalized.error});
    project.tasks=project.tasks||[]; if(project.tasks.length>=200)return json(res,409,{error:"PROJECT_TASK_LIMIT_REACHED"});
    const task={...normalized.task,id:id()}; project.tasks.push(task); store.audit(u.id,"project.task.created","project_task",task.id,{projectId:project.id}); await store.save(); return json(res,201,{task});
  }
  if(method==="PATCH" && p.match(/^\/api\/projects\/[^/]+\/tasks\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; const parts=p.split("/"), project=store.state.projects.find(x=>x.id===parts[3]), task=project?.tasks?.find(x=>x.id===parts[5]); if(!project||!task)return json(res,404,{error:"TASK_NOT_FOUND"});
    const memberIds=[project.ownerId,...store.state.applications.filter(a=>a.projectId===project.id&&a.status==="accepted").map(a=>a.userId)]; if(!memberIds.includes(u.id))return json(res,403,{error:"PROJECT_TEAM_ACCESS_REQUIRED"});
    if(!canManageProjectTask(task,u.id,project.ownerId))return json(res,403,{error:"TASK_ACCESS_DENIED"});
    const b=await readBody(req); if(b.status!==undefined){if(!["todo","in_progress","done"].includes(b.status))return json(res,400,{error:"INVALID_TASK_STATUS"});task.status=b.status;}
    if(b.title!==undefined){if(u.id!==project.ownerId&&u.id!==task.createdBy)return json(res,403,{error:"TASK_EDIT_DENIED"});const title=cleanText(b.title,100);if(title.length<3)return json(res,400,{error:"TASK_TITLE_REQUIRED"});task.title=title;}
    if(b.assigneeId!==undefined){if(u.id!==project.ownerId)return json(res,403,{error:"TASK_REASSIGN_OWNER_REQUIRED"});if(!memberIds.includes(b.assigneeId))return json(res,400,{error:"TASK_ASSIGNEE_NOT_IN_TEAM"});task.assigneeId=b.assigneeId;}
    task.updatedAt=new Date().toISOString();store.audit(u.id,"project.task.updated","project_task",task.id,{projectId:project.id,status:task.status});await store.save();return json(res,200,{task});
  }
  if(method==="PATCH" && p.match(/^\/api\/projects\/[^/]+\/close$/)) {
    const u=requireUser(req,res); if(!u)return; const project=store.state.projects.find(x=>x.id===p.split("/")[3] && x.ownerId===u.id); if(!project) return json(res,404,{error:"PROJECT_NOT_FOUND"});
    project.status="closed"; project.closedAt=new Date().toISOString(); store.audit(u.id,"project.closed","project",project.id); await store.save(); return json(res,200,{project});
  }
  if(method==="DELETE" && p.match(/^\/api\/me\/applications\/[^/]+$/)) {
    const u=requireUser(req,res); if(!u)return; const aid=p.split("/").at(-1), app=store.state.applications.find(x=>x.id===aid && x.userId===u.id); if(!app) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    store.state.applications=store.state.applications.filter(x=>x.id!==aid); store.audit(u.id,"application.withdrawn","application",aid); await store.save(); return json(res,200,{ok:true});
  }
  if(method==="GET" && p==="/api/me/export") {
    const u=requireUser(req,res); if(!u)return;
    const ownedOffers=store.state.offers.filter(o=>o.companyId===u.id), ownedOfferIds=new Set(ownedOffers.map(o=>o.id));
    const ownOfferApplications=store.state.offerApplications.filter(a=>a.candidateId===u.id).map(({privateNotes,...a})=>({...a,offer:store.state.offers.find(o=>o.id===a.offerId)||null}));
    const companyApplications=store.state.offerApplications.filter(a=>ownedOfferIds.has(store.state.offers.find(o=>o.id===a.offerId)?.id)).map(a=>({...a,candidate:publicProfile(store.state.users.find(x=>x.id===a.candidateId))}));
    const ownProjectIds=new Set(store.state.projects.filter(x=>x.ownerId===u.id).map(x=>x.id));
    const data={
      schemaVersion:"1.1",generatedAt:new Date().toISOString(),profile:{...publicProfile(u),avatarDataUrl:avatarDataUrlForExport(u)},email:u.email,emailVerifiedAt:u.emailVerifiedAt||null,preferences:{preferredLanguage:u.preferredLanguage||null},legalConsent:u.legalConsent||null,companyVerification:u.accountType==="company"?(u.companyVerification||{status:"unverified"}):null,
      privateAssessmentHistory:u.assessments||[],qualificationVerifications:(u.qualificationVerifications||[]).map(({documentFile,documentSha256,documentBytes,...item})=>item),
      qualificationDocuments:(u.qualificationVerifications||[]).filter(item=>item.documentFile&&/^[a-f0-9-]{36}\.(pdf|jpg|png)$/.test(item.documentFile)).map(item=>{const file=path.join(DATA,"qualification-documents",item.documentFile);if(!fs.existsSync(file))return null;const ext=item.documentFormat||path.extname(file).slice(1),mimeType=ext==="pdf"?"application/pdf":ext==="jpg"?"image/jpeg":"image/png";return{id:item.id,format:ext,mimeType,sha256:item.documentSha256||null,dataBase64:fs.readFileSync(file).toString("base64")};}).filter(Boolean),
      evidence:store.state.evidence.filter(e=>e.userId===u.id),
      offerApplications:ownOfferApplications,companyOffers:ownedOffers,companyApplications,
      projectApplications:store.state.applications.filter(a=>a.userId===u.id||ownProjectIds.has(a.projectId)),
      projects:store.state.projects.filter(x=>x.ownerId===u.id),
      connections:store.state.connections.filter(c=>c.fromUserId===u.id||c.toUserId===u.id),
      notifications:store.state.notifications.filter(n=>n.recipientId===u.id),
      blocks:store.state.blocks.filter(b=>b.blockerId===u.id||b.blockedId===u.id),
      reports:store.state.reports.filter(r=>r.reporterId===u.id||r.targetUserId===u.id),
      companyMemberships:store.state.companyMembers.filter(m=>m.userId===u.id||m.companyId===u.id),
      companyInvitations:store.state.companyInvitations.filter(i=>i.companyId===u.id||i.email===u.email).map(({tokenHash,...i})=>i),
      betaInvitations:store.state.betaInvitations.filter(i=>i.createdBy===u.id||i.email===u.email).map(({tokenHash,...i})=>i),
      betaFeedback:store.state.betaFeedback.filter(f=>f.userId===u.id).map(({reviewNote,reviewedBy,...f})=>f),
      auditEvents:store.state.audit.filter(a=>a.actorId===u.id||a.targetId===u.id)
    };
    res.setHeader("Content-Disposition","attachment; filename=zerihlink-account-export.json"); return json(res,200,data);
  }
  if(method==="DELETE" && p==="/api/me") {
    const u=requireUser(req,res); if(!u)return; const b=await readBody(req);
    if(b.confirmEmail?.toLowerCase()!==u.email) return json(res,400,{error:"CONFIRMATION_REQUIRED"});
    const uid=u.id, ownedProjectIds=new Set(store.state.projects.filter(x=>x.ownerId===uid).map(x=>x.id)),avatarToDelete=u.avatarFile;for(const q of u.qualificationVerifications||[])if(q.documentFile&&/^[a-f0-9-]{36}\.(pdf|jpg|png)$/.test(q.documentFile)){try{fs.unlinkSync(path.join(DATA,"qualification-documents",q.documentFile));}catch{}}
    const ownedOfferIds=new Set(store.state.offers.filter(o=>o.companyId===uid).map(o=>o.id));
    const removedOfferAppIds=new Set(store.state.offerApplications.filter(a=>a.candidateId===uid||ownedOfferIds.has(a.offerId)).map(a=>a.id));
    store.state.users=store.state.users.filter(x=>x.id!==uid);
    store.state.sessions=store.state.sessions.filter(x=>x.userId!==uid);
    store.state.evidence=store.state.evidence.filter(x=>x.userId!==uid);
    store.state.applications=store.state.applications.filter(x=>x.userId!==uid&&!ownedProjectIds.has(x.projectId));
    store.state.connections=store.state.connections.filter(x=>x.fromUserId!==uid&&x.toUserId!==uid);
    store.state.projects=store.state.projects.filter(x=>x.ownerId!==uid);
    store.state.offers=store.state.offers.filter(o=>o.companyId!==uid);
    store.state.offerApplications=store.state.offerApplications.filter(a=>a.candidateId!==uid&&!ownedOfferIds.has(a.offerId));
    store.state.notifications=store.state.notifications.filter(n=>n.recipientId!==uid&&!(n.targetType==="application"&&removedOfferAppIds.has(n.targetId))&&!(n.targetType==="offer"&&ownedOfferIds.has(n.targetId)));
    store.state.blocks=store.state.blocks.filter(b=>b.blockerId!==uid&&b.blockedId!==uid);
    store.state.reports=store.state.reports.filter(r=>r.reporterId!==uid&&r.targetUserId!==uid);
    store.state.companyMembers=store.state.companyMembers.filter(m=>m.companyId!==uid&&m.userId!==uid);
    store.state.companyInvitations=store.state.companyInvitations.filter(i=>i.companyId!==uid&&i.email!==u.email&&i.invitedBy!==uid);
    store.state.betaInvitations=store.state.betaInvitations.filter(i=>i.createdBy!==uid&&i.email!==u.email);
    store.state.betaFeedback=store.state.betaFeedback.filter(f=>f.userId!==uid);
    store.state.passwordResets=store.state.passwordResets.filter(r=>r.userId!==uid);
    store.state.emailVerificationTokens=store.state.emailVerificationTokens.filter(v=>v.userId!==uid);
    for(const app of store.state.offerApplications) app.privateNotes=(app.privateNotes||[]).filter(n=>n.authorId!==uid);
    for(const evidence of store.state.evidence) if(evidence.reviewedBy===uid) evidence.reviewedBy=null;
    for(const report of store.state.reports) if(report.reviewedBy===uid) report.reviewedBy=null;
    for(const company of store.state.users) if(company.companyVerification?.reviewedBy===uid) company.companyVerification={status:"unverified",invalidatedAt:new Date().toISOString()};
    for(const feedback of store.state.betaFeedback) if(feedback.reviewedBy===uid) feedback.reviewedBy=null;
    for(const member of store.state.companyMembers) if(member.invitedBy===uid) member.invitedBy=null;
    store.audit(uid,"account.deleted","user",uid,{removedOffers:ownedOfferIds.size,removedProjects:ownedProjectIds.size,removedOfferApplications:removedOfferAppIds.size});
    await store.save();
    if(avatarToDelete&&/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(avatarToDelete)){try{fs.unlinkSync(path.join(store.avatarDir,avatarToDelete));}catch{}}
    res.setHeader("Set-Cookie","zerihlink_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
    return json(res,200,{ok:true,deleted:true,retainedAuditEvents:store.state.audit.filter(a=>a.actorId===uid||a.targetId===uid).length});
  }
  if(method==="GET" && p==="/api/me/evidence/list") { const u=requireUser(req,res); if(!u)return; return json(res,200,{evidence:store.state.evidence.filter(e=>e.userId===u.id)}); }
  if(method==="POST" && p.match(/^\/api\/company\/applications\/[^/]+\/notes$/)) {
    const u=requireUser(req,res); if(!u)return;
    if(u.accountType!=="company") return json(res,403,{error:"COMPANY_ACCOUNT_REQUIRED"});
    const appId=p.split("/").at(-2), app=store.state.offerApplications.find(a=>a.id===appId);
    const offer=app&&store.state.offers.find(o=>o.id===app.offerId&&o.companyId===u.id);
    if(!app||!offer) return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(app.status==="withdrawn") return json(res,409,{error:"APPLICATION_WITHDRAWN"});
    const b=await readBody(req), note=cleanText(b.note,1000);
    if(note.length<3) return json(res,400,{error:"NOTE_TOO_SHORT"});
    app.privateNotes??=[]; const entry={id:id(),authorId:u.id,note,createdAt:new Date().toISOString()};
    app.privateNotes.push(entry); store.audit(u.id,"application.private_note.added","application",app.id); await store.save();
    return json(res,201,{note:entry});
  }
  if(method==="PATCH" && p.match(/^\/api\/me\/applications\/[^/]+\/assessment-sharing$/)) {
    const u=requireUser(req,res);if(!u)return;
    if(u.accountType!=="candidate")return json(res,403,{error:"CANDIDATE_ACCOUNT_REQUIRED"});
    const app=store.state.offerApplications.find(a=>a.id===p.split("/").at(-2)&&a.candidateId===u.id);
    if(!app)return json(res,404,{error:"APPLICATION_NOT_FOUND"});
    if(app.status==="withdrawn")return json(res,409,{error:"APPLICATION_WITHDRAWN"});
    const body=await readBody(req),ids=body.assessmentIds;
    if(!Array.isArray(ids)||ids.length>30||ids.some(x=>typeof x!=="string"||x.length>100))return json(res,400,{error:"INVALID_ASSESSMENT_SELECTION"});
    const available=new Map([...(u.assessments||[]),...(u.practicalAssessments||[])].map(x=>[x.id,x]));
    if(ids.some(x=>!available.has(x)))return json(res,400,{error:"ASSESSMENT_NOT_OWNED"});
    const unique=[...new Set(ids)],now=new Date().toISOString(),previous=app.assessmentSharing||{assessmentIds:[]};
    app.assessmentSharing={version:"1.0",assessmentIds:unique,grantedAt:unique.length?(previous.grantedAt||now):null,revokedAt:unique.length?null:now,updatedAt:now};
    app.assessmentConsentAt=unique.length?app.assessmentSharing.grantedAt:null;app.updatedAt=now;
    store.audit(u.id,unique.length?"application.assessments.shared":"application.assessments.revoked","application",app.id,{assessmentIds:unique,consentVersion:"1.0"});
    await store.save();return json(res,200,{assessmentSharing:app.assessmentSharing});
  }
  if(method==="GET" && p==="/api/me/applications") {
    const u=requireUser(req,res); if(!u)return;
    return json(res,200,{applications:store.state.applications.filter(a=>a.userId===u.id || store.state.projects.some(p=>p.id===a.projectId && p.ownerId===u.id)).map(a=>({...a,project:store.state.projects.find(p=>p.id===a.projectId),applicant:publicProfile(store.state.users.find(x=>x.id===a.userId))}))});
  }
  return json(res,404,{error:"NOT_FOUND"});
}

const server=http.createServer(async(req,res)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","DENY");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=()");
  res.setHeader("Cross-Origin-Resource-Policy","same-origin");
  res.setHeader("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  if(process.env.NODE_ENV==="production") res.setHeader("Strict-Transport-Security","max-age=31536000; includeSubDomains");
  const url=new URL(req.url,"http://localhost");
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Methods":"GET,POST,PATCH,DELETE,OPTIONS","Access-Control-Allow-Headers":"Content-Type"});return res.end();}
  if(url.pathname.startsWith("/api/")){
    try { if (!rateLimit(req,res)) return; if (!SAFE_METHODS.has(req.method) && !validCsrf(req)) return json(res,403,{error:"CSRF_INVALID",message:"Actualise la page et réessaie."}); await api(req,res,url); } catch(e){ console.error("API error",e); if(!res.headersSent) json(res,e.message==="INVALID_JSON"?400:500,{error:e.message==="INVALID_JSON"?"INVALID_JSON":"INTERNAL_ERROR"}); }
    return;
  }
  let pathname;
  try { pathname=decodeURIComponent(url.pathname); }
  catch { res.writeHead(400,{"Content-Type":"text/plain; charset=utf-8","X-Content-Type-Options":"nosniff"}); return res.end("Bad request"); }
  const shareMatch=pathname.match(/^\/p\/([a-f0-9-]{36})$/i);
  if(req.method==="GET"&&shareMatch){
    const user=store.state.users.find(x=>x.id===shareMatch[1]&&x.accountType!=="company"&&x.visibility==="public");
    if(!user){res.writeHead(404,{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});return res.end("Profile not found");}
    const proto=String(req.headers["x-forwarded-proto"]||(req.socket.encrypted?"https":"http")).split(",")[0].trim().toLowerCase()==="https"?"https":"http";
    const host=String(req.headers["x-forwarded-host"]||req.headers.host||`localhost:${PORT}`).split(",")[0].trim();
    let origin;try{origin=new URL(process.env.ZERIHLINK_PUBLIC_URL||`${proto}://${host}`).origin;}catch{origin=`${proto}://localhost:${PORT}`;}
    const profile=publicProfile(user),title=escapeHtml(`${user.name} — ZERILYS professional identity`),description=escapeHtml(cleanText(user.about||user.headline||`Explore ${user.name}'s professional universe on ZERILYS.`,180));
    const canonical=`${origin}/p/${encodeURIComponent(user.id)}`,imageUrl=profile.avatarUrl?`${origin}${profile.avatarUrl}`:"";
    const imageTags=imageUrl?`<meta property="og:image" content="${escapeHtml(imageUrl)}"><meta property="og:image:alt" content="${escapeHtml(`${user.name}'s profile photo`)}"><meta property="og:image:width" content="512"><meta property="og:image:height" content="512">`:"";
    const shareTags=`<meta name="description" content="${description}"><title>${title}</title><link rel="canonical" href="${escapeHtml(canonical)}"><meta property="og:type" content="profile"><meta property="og:site_name" content="ZERILYS"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:url" content="${escapeHtml(canonical)}">${imageTags}<meta name="twitter:card" content="${imageUrl?"summary_large_image":"summary"}"><meta name="twitter:title" content="${title}"><meta name="twitter:description" content="${description}">${imageUrl?`<meta name="twitter:image" content="${escapeHtml(imageUrl)}">`:""}`;
    const html=fs.readFileSync(path.join(PUBLIC,"index.html"),"utf8").replace(/<meta name="description"[^>]*>/,`<meta name="description" content="${description}">`).replace(/<title>[^<]*<\/title>/,`<title>${title}</title>`).replace("</head>",`${shareTags}</head>`);
    res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin"});return res.end(html);
  }
  if(pathname==="/" || pathname==="/index.html") pathname="/index.html";
  const target=path.resolve(PUBLIC,"."+pathname);
  if(!target.startsWith(PUBLIC+path.sep) && target!==path.join(PUBLIC,"index.html")) return json(res,403,{error:"FORBIDDEN"});
  fs.readFile(target,(err,data)=>{
    if(err){res.writeHead(err.code==="ENOENT"?404:500,{"Content-Type":"text/plain; charset=utf-8","X-Content-Type-Options":"nosniff","Cache-Control":"no-store"});res.end(err.code==="ENOENT"?"Not found":"Unable to read resource");return;}
    res.writeHead(200,{"Content-Type":mime[path.extname(target)]||"application/octet-stream","X-Content-Type-Options":"nosniff","Referrer-Policy":"strict-origin-when-cross-origin"});res.end(data);
  });
});
server.listen(PORT,HOST,()=>console.log(`ZERILYS ${VERSION} listening on ${HOST}:${PORT}`));
for (const signal of ["SIGINT", "SIGTERM"]) process.once(signal, async () => {
  server.close(async () => { await store.close().catch(error => console.error("Storage shutdown error", error)); process.exit(0); });
});
