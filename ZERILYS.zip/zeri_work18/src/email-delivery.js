const validEmail=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||""));
export function emailDeliveryConfig(){
 const url=process.env.ZERIHLINK_EMAIL_WEBHOOK_URL||"",secret=process.env.ZERIHLINK_EMAIL_WEBHOOK_SECRET||"",from=process.env.ZERIHLINK_EMAIL_FROM||"",appUrl=process.env.ZERIHLINK_APP_URL||"";
 let validUrl=false,validAppUrl=false;
 try{const u=new URL(url);validUrl=u.protocol==="https:"||(process.env.NODE_ENV!=="production"&&["localhost","127.0.0.1","::1"].includes(u.hostname));}catch{}
 try{const u=new URL(appUrl);validAppUrl=u.protocol==="https:"||(process.env.NODE_ENV!=="production"&&["localhost","127.0.0.1","::1"].includes(u.hostname));}catch{}
 return {configured:validUrl&&secret.length>=32&&validEmail(from)&&validAppUrl,from,appUrl};
}
export async function sendTransactionalEmail({to,subject,text,html}){
 const config=emailDeliveryConfig();
 if(!config.configured)return {sent:false,configured:false};
 const url=process.env.ZERIHLINK_EMAIL_WEBHOOK_URL,secret=process.env.ZERIHLINK_EMAIL_WEBHOOK_SECRET;
 const response=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${secret}`},body:JSON.stringify({from:config.from,to,subject,text,html}),signal:AbortSignal.timeout(8000)});
 if(!response.ok)throw new Error(`Email delivery webhook returned HTTP ${response.status}.`);
 let result={};try{result=await response.json()}catch{}
 return {sent:true,providerMessageId:typeof result.id==="string"?result.id:null};
}
