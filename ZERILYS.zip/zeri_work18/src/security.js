
import crypto from "node:crypto";

export function hashPassword(password, salt=crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { salt, hash };
}
export function verifyPassword(password, salt, hash) {
  const actual = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(actual, Buffer.from(hash, "hex"));
}
export function token() { return crypto.randomBytes(32).toString("base64url"); }
export function id() { return crypto.randomUUID(); }
export function cleanText(v, max=500) {
  return String(v ?? "").replace(/[<>]/g, "").trim().slice(0, max);
}
export function emailValid(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
