import crypto from "node:crypto";

const requiredArrays=["users","sessions","projects","applications","evidence","connections","reports","blocks","companies","offers","offerApplications","notifications","companyMembers","companyInvitations","betaInvitations","betaFeedback","audit"];
const emailValid=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||""));
const idSet=items=>new Set((items||[]).map(x=>x?.id).filter(Boolean));
export function inspectStore(state){
 const errors=[],warnings=[];
 const error=(code,detail)=>errors.push({code,detail});
 if(!state||typeof state!=="object")return {ok:false,errors:[{code:"STORE_NOT_OBJECT",detail:"Store root must be an object."}],warnings:[],stats:{}};
 for(const key of requiredArrays)if(!Array.isArray(state[key]))error("COLLECTION_INVALID",key);
 for(const key of requiredArrays)if(!Array.isArray(state[key]))state={...state,[key]:[]};
 if(!Array.isArray(state.passwordResets))state={...state,passwordResets:[]};
 const users=state.users,byUser=new Map(users.map(u=>[u.id,u])),offers=state.offers,byOffer=new Map(offers.map(o=>[o.id,o])),projects=state.projects,byProject=new Map(projects.map(p=>[p.id,p]));
 const userExists=id=>!!byUser.get(id);
 const unique=(items,key,code)=>{const seen=new Set();for(const item of items){const v=key(item);if(v===undefined||v===null)continue;if(seen.has(v))error(code,String(v));seen.add(v);}};
 unique(users,u=>u.id,"DUPLICATE_USER_ID");unique(users,u=>String(u.email||"").toLowerCase(),"DUPLICATE_USER_EMAIL");
 for(const u of users){if(!emailValid(u.email))error("INVALID_USER_EMAIL",u.id||"unknown");if(!["candidate","company"].includes(u.accountType||"candidate"))error("INVALID_ACCOUNT_TYPE",u.id||"unknown");if(!Array.isArray(u.skills))error("USER_SKILLS_INVALID",u.id||"unknown");if(!u.legalConsent)warnings.push({code:"LEGAL_CONSENT_MISSING",detail:u.id||"unknown"});if(u.accountType==="company"){const v=u.companyVerification||{status:"unverified"};if(!["unverified","pending","verified","rejected"].includes(v.status))error("COMPANY_VERIFICATION_STATUS_INVALID",u.id);if(v.status==="pending"&&(!emailValid(v.businessEmail)||String(v.proofNote||"").length<30))error("COMPANY_VERIFICATION_REQUEST_INVALID",u.id);if(v.status==="verified"&&(!userExists(v.reviewedBy)||String(v.reviewerNote||"").length<20))error("COMPANY_VERIFICATION_REVIEW_INVALID",u.id);}}
 for(const s of state.sessions)if(!userExists(s.userId))error("ORPHAN_SESSION",s.id||"unknown");
 unique(state.sessions,s=>s.tokenHash,"DUPLICATE_SESSION_TOKEN_HASH");
 for(const u of users){const seenSkills=new Set();for(const sk of u.skills||[]){if(!sk.id)error("SKILL_ID_MISSING",u.id);if(seenSkills.has(String(sk.name||"").toLowerCase()))error("DUPLICATE_SKILL_NAME",u.id);seenSkills.add(String(sk.name||"").toLowerCase());}}
 unique(state.evidence,e=>e.id,"DUPLICATE_EVIDENCE_ID");
 for(const e of state.evidence){const owner=byUser.get(e.userId);if(!owner)error("ORPHAN_EVIDENCE",e.id);else if(e.skillId&&!(owner.skills||[]).some(sk=>sk.id===e.skillId))error("ORPHAN_EVIDENCE_SKILL",e.id);if(!["self_attested","pending_review","verified","rejected"].includes(e.status||"self_attested"))error("EVIDENCE_STATUS_INVALID",e.id);if(e.reviewedBy&&!userExists(e.reviewedBy))error("EVIDENCE_REVIEWER_INVALID",e.id);}
 unique(offers,o=>o.id,"DUPLICATE_OFFER_ID");
 for(const o of offers){const company=byUser.get(o.companyId);if(!company||company.accountType!=="company")error("OFFER_COMPANY_INVALID",o.id);if(!["published","closed","draft"].includes(o.status||"published"))error("OFFER_STATUS_INVALID",o.id);if(!["job","internship","apprenticeship","collaboration","graduate_program","vie","research_project"].includes(o.type||"job"))error("OFFER_TYPE_INVALID",o.id);}
 unique(state.offerApplications,a=>a.id,"DUPLICATE_OFFER_APPLICATION_ID");
 const applicationPairs=new Set();
 for(const a of state.offerApplications){
  const candidate=byUser.get(a.candidateId),offer=byOffer.get(a.offerId);
  if(!candidate||candidate.accountType!=="candidate")error("APPLICATION_CANDIDATE_INVALID",a.id);
  if(!offer)error("APPLICATION_OFFER_INVALID",a.id);
  const pair=`${a.offerId}:${a.candidateId}`;if(applicationPairs.has(pair))error("DUPLICATE_OFFER_APPLICATION",pair);applicationPairs.add(pair);
  if(!["interest_sent","reviewing","interview","declined","withdrawn"].includes(a.status))error("APPLICATION_STATUS_INVALID",a.id);
  if(!Array.isArray(a.statusHistory))warnings.push({code:"APPLICATION_HISTORY_MISSING",detail:a.id});
  if(a.status==="withdrawn"&&(a.privateNotes||[]).length)error("WITHDRAWN_APPLICATION_HAS_NOTES",a.id);
  for(const n of a.privateNotes||[]){if(!userExists(n.authorId))error("PRIVATE_NOTE_AUTHOR_INVALID",n.id||a.id);if(String(n.note||"").length<3||String(n.note||"").length>1000)error("PRIVATE_NOTE_LENGTH_INVALID",n.id||a.id);}
 }
 unique(projects,p=>p.id,"DUPLICATE_PROJECT_ID");
 for(const p of projects){if(!userExists(p.ownerId))error("PROJECT_OWNER_INVALID",p.id);if(!["open","closed"].includes(p.status||"open"))error("PROJECT_STATUS_INVALID",p.id);}
 const projectPairs=new Set();for(const a of state.applications){if(!byProject.has(a.projectId)||!userExists(a.userId))error("PROJECT_APPLICATION_REFERENCE_INVALID",a.id);if(!["pending","accepted","rejected"].includes(a.status||"pending"))error("PROJECT_APPLICATION_STATUS_INVALID",a.id);const pair=`${a.projectId}:${a.userId}`;if(projectPairs.has(pair))error("DUPLICATE_PROJECT_APPLICATION",pair);projectPairs.add(pair);}
 const connectionPairs=new Set();for(const c of state.connections){if(!userExists(c.fromUserId)||!userExists(c.toUserId)||c.fromUserId===c.toUserId)error("CONNECTION_REFERENCE_INVALID",c.id);if(!["pending","accepted","rejected"].includes(c.status))error("CONNECTION_STATUS_INVALID",c.id);const pair=[c.fromUserId,c.toUserId].sort().join(":");if(connectionPairs.has(pair))error("DUPLICATE_CONNECTION_PAIR",pair);connectionPairs.add(pair);}
 const blockPairs=new Set();for(const b of state.blocks){if(!userExists(b.blockerId)||!userExists(b.blockedId)||b.blockerId===b.blockedId)error("BLOCK_REFERENCE_INVALID",b.id);const pair=`${b.blockerId}:${b.blockedId}`;if(blockPairs.has(pair))error("DUPLICATE_BLOCK",pair);blockPairs.add(pair);}
 for(const r of state.reports){if(!userExists(r.reporterId)||!userExists(r.targetUserId)||r.reporterId===r.targetUserId)error("REPORT_REFERENCE_INVALID",r.id);if(!["open","reviewed","dismissed"].includes(r.status))error("REPORT_STATUS_INVALID",r.id);if(r.reviewedBy&&!userExists(r.reviewedBy))error("REPORT_REVIEWER_INVALID",r.id);}
 const memberPairs=new Set();for(const m of state.companyMembers){const company=byUser.get(m.companyId);if(!company||company.accountType!=="company"||!userExists(m.userId)||m.userId===m.companyId||!["recruiter","viewer"].includes(m.role)||!["active","removed"].includes(m.status))error("COMPANY_MEMBER_INVALID",m.id);const pair=`${m.companyId}:${m.userId}`;if(memberPairs.has(pair))error("DUPLICATE_COMPANY_MEMBER",pair);memberPairs.add(pair);if(m.invitedBy&&!userExists(m.invitedBy))error("COMPANY_MEMBER_INVITER_INVALID",m.id);}
 const companyInvitePairs=new Set();for(const i of state.companyInvitations){const company=byUser.get(i.companyId);if(!company||company.accountType!=="company"||!emailValid(i.email)||!["recruiter","viewer"].includes(i.role)||!["pending","accepted","revoked","expired"].includes(i.status))error("COMPANY_INVITATION_INVALID",i.id);if(i.status==="pending"&&!i.tokenHash)error("COMPANY_INVITATION_TOKEN_MISSING",i.id);if(i.invitedBy&&!userExists(i.invitedBy))error("COMPANY_INVITATION_CREATOR_INVALID",i.id);const pair=`${i.companyId}:${i.email}`;if(i.status==="pending"&&companyInvitePairs.has(pair))error("DUPLICATE_COMPANY_INVITATION",pair);if(i.status==="pending")companyInvitePairs.add(pair);}
 const betaInviteEmails=new Set();for(const i of state.betaInvitations){if(!emailValid(i.email)||!["candidate","company"].includes(i.accountType)||!["pending","accepted","revoked"].includes(i.status))error("BETA_INVITATION_INVALID",i.id);if(i.status==="pending"&&!i.tokenHash)error("BETA_INVITATION_TOKEN_MISSING",i.id);if(i.createdBy&&!userExists(i.createdBy))error("BETA_INVITATION_CREATOR_INVALID",i.id);if(i.acceptedBy&&!userExists(i.acceptedBy))error("BETA_INVITATION_ACCEPTOR_INVALID",i.id);if(i.status==="pending"&&betaInviteEmails.has(i.email))error("DUPLICATE_BETA_INVITATION",i.email);if(i.status==="pending")betaInviteEmails.add(i.email);}
 for(const f of state.betaFeedback){if(!userExists(f.userId))error("FEEDBACK_AUTHOR_INVALID",f.id);if(!["bug","confusing","idea","other"].includes(f.category)||String(f.message||"").length<20||!["open","reviewed","accepted","declined"].includes(f.status))error("FEEDBACK_CONTENT_INVALID",f.id);if(f.reviewedBy&&!userExists(f.reviewedBy))error("FEEDBACK_REVIEWER_INVALID",f.id);}
 for(const n of state.notifications)if(!userExists(n.recipientId))error("NOTIFICATION_RECIPIENT_INVALID",n.id);
 unique(state.passwordResets,x=>x.tokenHash,"DUPLICATE_PASSWORD_RESET_TOKEN");
 for(const r of state.passwordResets){if(!userExists(r.userId))error("PASSWORD_RESET_USER_INVALID",r.id);if(!/^[a-f0-9]{64}$/i.test(String(r.tokenHash||"")))error("PASSWORD_RESET_HASH_INVALID",r.id);if(!Number.isFinite(Number(r.expiresAt))||Number(r.expiresAt)<=Date.now())warnings.push({code:"PASSWORD_RESET_EXPIRED",detail:r.id||"unknown"});}

 // Audit records are append-only. The first retained record may point to a trimmed historical anchor.
 let previous=null;
 for(let i=0;i<state.audit.length;i++){
  const event=state.audit[i],{hash,...payload}=event;
  if(!hash||crypto.createHash("sha256").update(JSON.stringify(payload)).digest("hex")!==hash)error("AUDIT_HASH_INVALID",event.id||String(i));
  if(previous&&event.previous!==previous)error("AUDIT_CHAIN_BROKEN",event.id||String(i));
  previous=hash||null;
 }
 const stats={users:users.length,candidates:users.filter(u=>(u.accountType||"candidate")==="candidate").length,companies:users.filter(u=>u.accountType==="company").length,offers:offers.length,offerApplications:state.offerApplications.length,evidence:state.evidence.length,openReports:state.reports.filter(r=>r.status==="open").length,pendingEvidence:state.evidence.filter(e=>e.status==="pending_review").length,openFeedback:state.betaFeedback.filter(f=>f.status==="open").length};
 return {ok:errors.length===0,errors,warnings,stats};
}
