const DAY = 24 * 60 * 60 * 1000;
const timestamp = value => {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Date.parse(value || '');
  return Number.isFinite(parsed) ? parsed : null;
};

/**
 * Conservative cleanup of short-lived authentication material.
 * User submissions, qualification evidence, applications and audit history are
 * deliberately excluded: they need an explicit, legally reviewed retention schedule.
 */
export function cleanupExpiredData(store, { now = Date.now(), invitationRetentionDays = 90 } = {}) {
  const before = {};
  const after = {};
  let invitationSecretsRemoved = 0;
  const count = key => store.state[key]?.length || 0;
  for (const key of ['sessions', 'emailVerificationTokens', 'passwordResets', 'companyInvitations', 'betaInvitations']) before[key] = count(key);

  store.state.sessions = (store.state.sessions || []).filter(item => timestamp(item.expiresAt) > now);
  store.state.emailVerificationTokens = (store.state.emailVerificationTokens || []).filter(item => timestamp(item.expiresAt) > now);
  store.state.passwordResets = (store.state.passwordResets || []).filter(item => timestamp(item.expiresAt) > now);

  const retention = invitationRetentionDays * DAY;
  store.state.companyInvitations = (store.state.companyInvitations || []).filter(item => {
    const expiry = timestamp(item.expiresAt);
    const expired = expiry === null || expiry <= now;
    const old = timestamp(item.createdAt) !== null && now - timestamp(item.createdAt) > retention;
    if ((item.status !== 'pending' || expired) && item.tokenHash) { delete item.tokenHash; invitationSecretsRemoved++; }
    return !(old && (item.status !== 'pending' || expired));
  });
  store.state.betaInvitations = (store.state.betaInvitations || []).filter(item => {
    const expiry = timestamp(item.expiresAt);
    const expired = expiry === null || expiry <= now;
    const old = timestamp(item.createdAt) !== null && now - timestamp(item.createdAt) > retention;
    if ((item.status !== 'pending' || expired) && item.tokenHash) { delete item.tokenHash; invitationSecretsRemoved++; }
    return !(old && (item.status !== 'pending' || expired));
  });

  for (const key of Object.keys(before)) after[key] = count(key);
  const removed = Object.fromEntries(Object.keys(before).map(key => [key, before[key] - after[key]]));
  return { changed: Object.values(removed).some(Boolean) || invitationSecretsRemoved > 0, removed, tokensRedacted: invitationSecretsRemoved };
}
