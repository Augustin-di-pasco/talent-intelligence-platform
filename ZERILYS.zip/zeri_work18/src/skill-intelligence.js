const normalize = value => String(value ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9+#.]+/g, " ").trim();

// Curated vocabulary for the initial finance / AI / data specialist market.
// This is transparent synonym matching, not an ML model or an employability score.
const DOMAINS = [
  ["quantitative finance", ["quant", "quantitative analyst", "quant researcher", "quantitative research", "financial engineering", "financial mathematics", "mathematical finance", "pricing models", "derivatives pricing"]],
  ["algorithmic trading", ["algo trading", "algorithmic trading", "systematic trading", "trading algorithms", "execution algorithms", "hft", "high frequency trading"]],
  ["risk modelling", ["risk", "risk management", "market risk", "credit risk", "model risk", "risk modelling", "risk modeling", "var", "value at risk", "stress testing"]],
  ["data science", ["data scientist", "data science", "statistical learning", "predictive analytics", "applied statistics", "statistics"]],
  ["machine learning", ["ml", "machine learning", "deep learning", "neural networks", "scikit learn", "pytorch", "tensorflow"]],
  ["artificial intelligence", ["ai", "artificial intelligence", "generative ai", "llm", "large language models", "natural language processing", "nlp", "computer vision"]],
  ["data engineering", ["data engineer", "data engineering", "etl", "elt", "data pipelines", "dbt", "data warehouse", "spark", "kafka"]],
  ["business intelligence", ["bi", "business intelligence", "power bi", "tableau", "looker", "data visualisation", "data visualization"]],
  ["fintech engineering", ["fintech", "financial technology", "payments", "payment systems", "banking technology", "open banking", "api banking"]],
  ["blockchain", ["web3", "blockchain", "smart contracts", "solidity", "distributed ledger"]],
  ["portfolio management", ["portfolio", "portfolio management", "asset allocation", "investment management", "multi asset", "multi-asset"]],
  ["financial analysis", ["financial analyst", "financial analysis", "valuation", "equity research", "corporate finance", "financial modelling", "financial modeling"]],
  ["cybersecurity", ["cyber security", "cybersecurity", "information security", "appsec", "penetration testing", "security engineering"]],
  ["cloud infrastructure", ["cloud", "cloud engineering", "aws", "azure", "gcp", "kubernetes", "devops", "platform engineering"]],
];
const entries = DOMAINS.flatMap(([canonical, aliases]) => aliases.map(alias => ({ canonical, alias: normalize(alias) })));

export function semanticTerms(query) {
  const q = normalize(query);
  if (!q) return [];
  const found = entries.filter(({ alias }) => alias === q || (q.length >= 4 && (alias.includes(q) || q.includes(alias))));
  return [...new Set([q, ...found.flatMap(x => [x.canonical, x.alias])])];
}

export function profileMatchesQuery(profile, query) {
  const q = normalize(query);
  if (!q) return true;
  const fields = [profile.name, profile.headline, profile.location, profile.canOffer, profile.lookingFor, profile.interests, ...(profile.skills || []).map(s => s.name)];
  const haystack = normalize(fields.filter(Boolean).join(" "));
  if (haystack.includes(q)) return true;
  const terms = semanticTerms(q);
  if (terms.length <= 1) return false;
  const skillText = normalize((profile.skills || []).map(s => s.name).join(" "));
  const intentText = normalize([profile.headline, profile.canOffer, profile.lookingFor, profile.interests].join(" "));
  return terms.slice(1).some(term => skillText.includes(term) || intentText.includes(term));
}

export function semanticSkillOverlap(a, b) {
  const canon = user => new Set((user.skills || []).flatMap(skill => {
    const name = normalize(skill.name);
    const hits = entries.filter(({ alias }) => name === alias || (name.length >= 4 && (name.includes(alias) || alias.includes(name))));
    return hits.map(hit => hit.canonical);
  }));
  const left = canon(a), right = canon(b);
  return [...left].filter(x => right.has(x));
}
