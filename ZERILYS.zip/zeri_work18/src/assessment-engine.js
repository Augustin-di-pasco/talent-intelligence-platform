import crypto from 'node:crypto';

// Small, versioned pilot library. Answers stay server-side; only questions/options are public.
const LIBRARY = [
  { slug:'sql-foundations-v1', title:'SQL — fondamentaux', domain:'Data', level:'Fondamental', durationMinutes:8, version:'1.0.0', skills:['SQL','Data analysis'], questions:[
    {id:'q1',prompt:'Quelle clause filtre les lignes avant le regroupement ?',options:[{id:'a',label:'HAVING'},{id:'b',label:'WHERE'},{id:'c',label:'ORDER BY'}],answer:'b'},
    {id:'q2',prompt:'Quelle jointure conserve toutes les lignes de la table de gauche ?',options:[{id:'a',label:'INNER JOIN'},{id:'b',label:'CROSS JOIN'},{id:'c',label:'LEFT JOIN'}],answer:'c'},
    {id:'q3',prompt:'Que retourne COUNT(*) ?',options:[{id:'a',label:'Le nombre de lignes'},{id:'b',label:'Le nombre de valeurs distinctes'},{id:'c',label:'La somme des colonnes numériques'}],answer:'a'}
  ]},
  { slug:'python-data-v1', title:'Python — manipulation de données', domain:'Data / IA', level:'Intermédiaire', durationMinutes:8, version:'1.0.0', skills:['Python','Data analysis'], questions:[
    {id:'q1',prompt:'Quel type Python est mutable ?',options:[{id:'a',label:'tuple'},{id:'b',label:'list'},{id:'c',label:'str'}],answer:'b'},
    {id:'q2',prompt:'Quelle expression crée une copie superficielle d’une liste appelée data ?',options:[{id:'a',label:'data.copy()'},{id:'b',label:'copy(data, deep=True)'},{id:'c',label:'data.freeze()'}],answer:'a'},
    {id:'q3',prompt:'Quel outil est couramment utilisé pour manipuler des tableaux de données tabulaires ?',options:[{id:'a',label:'asyncio'},{id:'b',label:'tkinter'},{id:'c',label:'pandas'}],answer:'c'}
  ]},
  { slug:'risk-foundations-v1', title:'Risque financier — fondamentaux', domain:'Finance / Risque', level:'Fondamental', durationMinutes:8, version:'1.0.0', skills:['Financial risk','Risk management'], questions:[
    {id:'q1',prompt:'Que cherche principalement à mesurer la Value at Risk (VaR) ?',options:[{id:'a',label:'Une perte potentielle sur un horizon et un niveau de confiance donnés'},{id:'b',label:'Le rendement garanti d’un portefeuille'},{id:'c',label:'La liquidité quotidienne d’un actif'}],answer:'a'},
    {id:'q2',prompt:'Une hausse de la corrélation entre deux actifs tend, toutes choses égales par ailleurs, à…',options:[{id:'a',label:'Augmenter le bénéfice de diversification'},{id:'b',label:'Réduire le bénéfice de diversification'},{id:'c',label:'Supprimer le risque de marché'}],answer:'b'},
    {id:'q3',prompt:'Le risque de contrepartie correspond au risque…',options:[{id:'a',label:'D’une variation des taux sans risque'},{id:'b',label:'D’une erreur de valorisation uniquement'},{id:'c',label:'Que l’autre partie ne respecte pas ses obligations'}],answer:'c'}
  ]},
  { slug:'accounting-finance-v1', title:'Comptabilité & analyse financière', domain:'Finance / Gestion', level:'Fondamental', durationMinutes:10, version:'1.0.0', skills:['Accounting','Financial analysis','Corporate finance'], questions:[
    {id:'q1',prompt:'Quel état financier présente les actifs, les passifs et les capitaux propres à une date donnée ?',options:[{id:'a',label:'Le bilan'},{id:'b',label:'Le compte de résultat'},{id:'c',label:'Le tableau des flux uniquement'}],answer:'a'},
    {id:'q2',prompt:'Un EBITDA positif signifie nécessairement que…',options:[{id:'a',label:'Le résultat net est positif'},{id:'b',label:'La trésorerie est positive'},{id:'c',label:'Aucune de ces deux conclusions n’est garantie'}],answer:'c'},
    {id:'q3',prompt:'Le besoin en fonds de roulement augmente généralement lorsque…',options:[{id:'a',label:'Les délais clients s’allongent sans compensation'},{id:'b',label:'Les stocks diminuent fortement'},{id:'c',label:'Les fournisseurs accordent des délais plus longs'}],answer:'a'}
  ]},
  { slug:'statistics-methods-v1', title:'Statistiques & raisonnement quantitatif', domain:'Sciences / Data', level:'Fondamental', durationMinutes:10, version:'1.0.0', skills:['Statistics','Quantitative analysis','Data analysis'], questions:[
    {id:'q1',prompt:'La médiane est particulièrement utile lorsqu’une distribution comporte…',options:[{id:'a',label:'Des valeurs extrêmes'},{id:'b',label:'Uniquement des valeurs identiques'},{id:'c',label:'Aucune observation'}],answer:'a'},
    {id:'q2',prompt:'Une corrélation statistique permet à elle seule de conclure que…',options:[{id:'a',label:'X cause Y'},{id:'b',label:'Y cause X'},{id:'c',label:'Aucune relation causale n’est démontrée'}],answer:'c'},
    {id:'q3',prompt:'À taille d’échantillon égale, un intervalle de confiance à 95 % est généralement…',options:[{id:'a',label:'Plus large qu’un intervalle à 90 %'},{id:'b',label:'Plus étroit qu’un intervalle à 90 %'},{id:'c',label:'Toujours de largeur nulle'}],answer:'a'}
  ]},
  { slug:'engineering-systems-v1', title:'Ingénierie — systèmes & conception', domain:'Ingénierie', level:'Fondamental', durationMinutes:10, version:'1.0.0', skills:['Engineering','Systems engineering','Technical design'], questions:[
    {id:'q1',prompt:'Quelle démarche aide à vérifier qu’un système répond aux besoins définis ?',options:[{id:'a',label:'La traçabilité des exigences et la validation'},{id:'b',label:'La suppression des critères de test'},{id:'c',label:'Le choix du fournisseur avant toute exigence'}],answer:'a'},
    {id:'q2',prompt:'Dans une analyse de défaillance, la criticité combine généralement…',options:[{id:'a',label:'Gravité, occurrence et détectabilité'},{id:'b',label:'Coût marketing et délai commercial'},{id:'c',label:'Masse et couleur uniquement'}],answer:'a'},
    {id:'q3',prompt:'Pourquoi documenter les hypothèses de conception ?',options:[{id:'a',label:'Pour faciliter leur revue et leur révision'},{id:'b',label:'Pour éviter toute vérification'},{id:'c',label:'Pour remplacer les essais'}],answer:'a'}
  ]},
  { slug:'business-strategy-v1', title:'Stratégie & analyse de marché', domain:'Commerce / Conseil', level:'Fondamental', durationMinutes:10, version:'1.0.0', skills:['Business strategy','Market analysis','Consulting'], questions:[
    {id:'q1',prompt:'Une segmentation de marché sert principalement à…',options:[{id:'a',label:'Regrouper des clients aux besoins similaires'},{id:'b',label:'Fixer un prix identique pour tous'},{id:'c',label:'Éliminer toute étude client'}],answer:'a'},
    {id:'q2',prompt:'Un avantage concurrentiel durable repose plutôt sur…',options:[{id:'a',label:'Une capacité difficile à reproduire et créatrice de valeur'},{id:'b',label:'Une baisse ponctuelle de prix uniquement'},{id:'c',label:'Un slogan sans preuve'}],answer:'a'},
    {id:'q3',prompt:'Quel indicateur mesure le taux de conversion ?',options:[{id:'a',label:'Conversions divisées par le nombre d’opportunités ou visiteurs concernés'},{id:'b',label:'Chiffre d’affaires divisé par les effectifs'},{id:'c',label:'Dépenses fixes divisées par le stock'}],answer:'a'}
  ]},
  { slug:'research-methods-v1', title:'Méthodologie de recherche', domain:'Recherche / Sciences', level:'Avancé', durationMinutes:10, version:'1.0.0', skills:['Research methodology','Scientific writing','Critical thinking'], questions:[
    {id:'q1',prompt:'Une hypothèse scientifique utile doit être…',options:[{id:'a',label:'Testable et réfutable'},{id:'b',label:'Impossible à confronter aux données'},{id:'c',label:'Vraie par définition'}],answer:'a'},
    {id:'q2',prompt:'La revue par les pairs vise principalement à…',options:[{id:'a',label:'Évaluer la qualité et la cohérence d’un travail'},{id:'b',label:'Garantir l’absence absolue d’erreur'},{id:'c',label:'Remplacer la reproductibilité'}],answer:'a'},
    {id:'q3',prompt:'La reproductibilité d’une étude suppose notamment…',options:[{id:'a',label:'Une description suffisante des méthodes et données utilisées'},{id:'b',label:'L’absence de protocole'},{id:'c',label:'La suppression des résultats négatifs'}],answer:'a'}
  ]},
  { slug:'project-management-v1', title:'Gestion de projet & coordination', domain:'Management', level:'Fondamental', durationMinutes:10, version:'1.0.0', skills:['Project management','Stakeholder management','Agile'], questions:[
    {id:'q1',prompt:'Un risque projet doit être suivi en priorité selon…',options:[{id:'a',label:'Sa probabilité et son impact'},{id:'b',label:'La longueur de son intitulé'},{id:'c',label:'L’ancienneté du chef de projet uniquement'}],answer:'a'},
    {id:'q2',prompt:'Un jalon projet correspond à…',options:[{id:'a',label:'Un point significatif de contrôle ou de décision'},{id:'b',label:'Une tâche nécessairement quotidienne'},{id:'c',label:'Un budget sans date'}],answer:'a'},
    {id:'q3',prompt:'La gestion des parties prenantes consiste à…',options:[{id:'a',label:'Identifier leurs attentes et organiser leur implication'},{id:'b',label:'Les exclure des décisions'},{id:'c',label:'Éviter toute communication'}],answer:'a'}
  ]}
];
const safeId = x => String(x ?? '').slice(0,80);
export function assessmentCatalog(){ return LIBRARY.map(({slug,title,domain,level,durationMinutes,version,skills,questions})=>({slug,title,domain,level,durationMinutes,version,skills,format:'questionnaire_de_connaissances',audiences:['étudiants','alternants','stagiaires','jeunes diplômés','professionnels','experts'],questionCount:questions.length,questions:questions.map(({id,prompt,options})=>({id,prompt,options}))})); }
export function gradeAssessment(slug, answers, now=new Date(), evidence={}) {
  const test=LIBRARY.find(x=>x.slug===slug); if(!test) return {error:'ASSESSMENT_NOT_FOUND'};
  if(!Array.isArray(answers)||answers.length!==test.questions.length) return {error:'ANSWERS_INCOMPLETE'};
  const submitted=new Map(answers.map(x=>[safeId(x.questionId),safeId(x.optionId)]));
  if(new Set(submitted.keys()).size!==test.questions.length) return {error:'ANSWERS_INVALID'};
  if(test.questions.some(q=>!q.options.some(o=>o.id===submitted.get(q.id)))) return {error:'ANSWERS_INVALID'};
  const details=test.questions.map(q=>({questionId:q.id,correct:submitted.get(q.id)===q.answer}));
  const correct=details.filter(x=>x.correct).length;
  const rationale=String(evidence?.rationale??'').trim().slice(0,1500);
  const aiUse=['not_used','used','prefer_not_to_say'].includes(evidence?.aiUseDeclaration)?evidence.aiUseDeclaration:'prefer_not_to_say';
  return {id:crypto.randomUUID(),assessmentSlug:test.slug,title:test.title,domain:test.domain,skills:test.skills,version:test.version,score:Math.round(correct/test.questions.length*100),correct,total:test.questions.length,status:'completed',completedAt:now.toISOString(),evidenceType:'platform_assessment',details,reasoningEvidence:{text:rationale||null,evaluation:'human_review_required',scored:false},aiUseDeclaration:aiUse};
}

export function recommendAssessments(skills=[]) {
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const wanted = (Array.isArray(skills)?skills:[]).map(normalize);
  return LIBRARY.filter(item=>item.skills.some(skill=>wanted.some(value=>value && (value===normalize(skill)||value.includes(normalize(skill))||normalize(skill).includes(value)))))
    .map(({slug,title,domain,level,version,skills})=>({slug,title,domain,level,version,skills}));
}

// Practical case studies are reviewed by people: no opaque AI grading and no arbitrary code execution.
const PRACTICAL_CASES = [
 {slug:'finance-cashflow-case',title:'Finance — diagnostic de trésorerie',domain:'Finance / Gestion',level:'Intermédiaire',durationMinutes:25,version:'1.0.0',skills:['Financial analysis','Cash flow','Working capital'],scenario:'Une PME industrielle réalise 12 M€ de chiffre d’affaires annuel. Les ventes progressent, mais la trésorerie se tend. La direction vous demande un diagnostic rapide et trois actions prioritaires.',task:'Analysez les causes possibles, proposez les données complémentaires à demander, puis formulez trois actions classées par impact, délai et risque.',variant:{clientDays:[48,62,75],inventoryDays:[55,68,82],supplierDays:[35,42,50]},deliverables:['Diagnostic structuré','Données à demander et limites','Trois recommandations hiérarchisées'],rubric:[['Diagnostic','Relie croissance, BFR et trésorerie sans confondre rentabilité et cash'],['Méthode','Demande les données nécessaires et explicite les hypothèses'],['Priorisation','Classe des actions réalistes avec impacts et risques'],['Communication','Présente une synthèse claire pour une direction']]},
 {slug:'business-market-case',title:'Commerce — lancement sur un nouveau marché',domain:'Commerce / Conseil',level:'Intermédiaire',durationMinutes:25,version:'1.0.0',skills:['Market analysis','Business strategy','Go-to-market'],scenario:'Une entreprise B2B française envisage de lancer une solution logicielle dans un nouveau segment. Le budget commercial est limité et les données de marché sont incomplètes.',task:'Construisez une démarche de validation du marché, proposez une segmentation, un test commercial à faible coût et des critères de décision go/no-go.',variant:{budgetK:[35,50,70],pilotWeeks:[6,8,10],targetAccounts:[40,60,90]},deliverables:['Hypothèses et segmentation','Plan de test commercial','Indicateurs et seuils de décision'],rubric:[['Segmentation','Définit des segments fondés sur des besoins et usages'],['Validation','Propose des tests permettant de réduire les incertitudes'],['Mesure','Choisit des indicateurs et seuils cohérents'],['Décision','Relie les résultats à une décision explicite']]},
 {slug:'research-protocol-case',title:'Recherche — critique d’un protocole',domain:'Recherche / Sciences',level:'Avancé',durationMinutes:30,version:'1.0.0',skills:['Research methodology','Critical thinking','Scientific writing'],scenario:'Une équipe observe une association entre une exposition environnementale et un indicateur biologique dans une étude observationnelle monocentrique. L’échantillon est modeste et certaines variables de confusion sont incomplètes.',task:'Identifiez les menaces à la validité, proposez un plan d’analyse prudent et décrivez les informations nécessaires pour rendre l’étude reproductible.',variant:{sampleSize:[120,180,240],missingRate:[8,14,20],followupMonths:[6,9,12]},deliverables:['Critique méthodologique','Plan d’analyse et limites','Plan de reproductibilité'],rubric:[['Validité','Distingue association et causalité et identifie les biais'],['Analyse','Propose une analyse proportionnée aux données'],['Transparence','Explicite limites, données manquantes et incertitudes'],['Reproductibilité','Décrit méthodes, variables et documentation']]},
 {slug:'engineering-failure-case',title:'Ingénierie — analyse d’une défaillance',domain:'Ingénierie / Industrie',level:'Intermédiaire',durationMinutes:30,version:'1.0.0',skills:['Engineering','Root cause analysis','Quality'],scenario:'Une ligne de production connaît des arrêts intermittents après une modification de cadence. Les incidents semblent liés à une sous-ensemble mécanique, mais aucune cause n’est confirmée.',task:'Proposez une démarche de diagnostic sûre, formulez des hypothèses testables et définissez les critères de validation avant remise en production.',variant:{stopRate:[2.5,4,6],shiftCount:[2,3],daysObserved:[5,8,12]},deliverables:['Hypothèses classées','Plan de tests sécurisé','Critères de validation et prévention'],rubric:[['Sécurité','Intègre consignation et maîtrise des risques avant intervention'],['Diagnostic','Hiérarchise les causes et propose des tests discriminants'],['Validation','Définit des critères mesurables avant redémarrage'],['Prévention','Propose traçabilité et actions correctives']]}
 ,
 {slug:'python-data-cleaning-code',title:'Python — nettoyage et contrôle de données',domain:'Data / IA',level:'Intermédiaire',durationMinutes:35,version:'1.0.0',skills:['Python','Data quality','Data analysis'],submissionMode:'code',language:'python',scenario:'Vous recevez un extrait de données clients avec des doublons, des valeurs manquantes et des montants importés sous forme de texte.',task:'Écrivez une fonction Python qui nettoie les lignes, normalise les montants, signale les enregistrements incomplets et retourne un résumé de qualité. Expliquez vos choix et les cas limites.',variant:{rowCount:[120,180,240],missingRate:[8,12,16]},starterCode:'def clean_records(records):\n    # records: liste de dictionnaires\n    # TODO: normaliser, dédupliquer et produire un rapport\n    pass',deliverables:['Code lisible et structuré','Gestion des valeurs manquantes et doublons','Explication des hypothèses et limites'],rubric:[['Correction','Traite les cas attendus et les entrées imparfaites'],['Robustesse','Gère les valeurs manquantes, formats et doublons'],['Lisibilité','Structure le code et nomme clairement les éléments'],['Raisonnement','Explique les choix, limites et tests utiles']]},
 {slug:'sql-analytics-query-code',title:'SQL — analyse de commandes',domain:'Data / Analyse',level:'Intermédiaire',durationMinutes:30,version:'1.0.0',skills:['SQL','Data analysis','Analytical thinking'],submissionMode:'code',language:'sql',scenario:'Une base contient les tables customers(id, region) et orders(id, customer_id, order_date, amount, status).',task:'Rédigez une requête qui calcule, par région et par mois, le chiffre d’affaires des commandes validées, le nombre de clients actifs et le panier moyen. Évitez de compter plusieurs fois un client dans un même mois. Expliquez vos choix de jointure et d’agrégation.',variant:{periodMonths:[3,6,12],regions:[3,4,5]},starterCode:'-- Écrivez votre requête SQL ici\nWITH ...',deliverables:['Requête SQL complète','Agrégations correctes et absence de double comptage','Explication des hypothèses et limites'],rubric:[['Correction','Joint les tables et filtre les commandes attendues'],['Agrégation','Calcule CA, clients distincts et panier moyen correctement'],['Précision','Gère le regroupement mensuel et les doublons'],['Raisonnement','Explique les choix et les cas limites']]}
];
function variantFor(candidateId, item){
 const digest=crypto.createHash('sha256').update(`${candidateId}:${item.slug}:v${item.version}`).digest();
 const variant={};for(const [key,values] of Object.entries(item.variant))variant[key]=values[digest.readUInt32BE(Object.keys(variant).length*4)%values.length];return variant;
}
export function practicalCaseCatalog(){return PRACTICAL_CASES.map(({slug,title,domain,level,durationMinutes,version,skills,submissionMode,language})=>({slug,title,domain,level,durationMinutes,version,skills,format:submissionMode==='code'?'exercice_code_revue_humaine':'cas_pratique_revue_humaine',submissionMode:submissionMode||'written',language:language||null}));}
export function getPracticalCase(slug,candidateId){const item=PRACTICAL_CASES.find(x=>x.slug===slug);if(!item)return {error:'PRACTICAL_CASE_NOT_FOUND'};return {slug:item.slug,title:item.title,domain:item.domain,level:item.level,durationMinutes:item.durationMinutes,version:item.version,skills:item.skills,scenario:item.scenario,task:item.task,variant:variantFor(candidateId,item),deliverables:item.deliverables,rubric:item.rubric.map(([criterion,description])=>({criterion,description})),submissionMode:item.submissionMode||'written',language:item.language||null,starterCode:item.starterCode||null,execution:{enabled:false,mode:'human_review_only',notice:'Le code est conservé comme livrable et n’est jamais exécuté par le serveur applicatif.'},scoring:'human_review_only'};}
export function submitPracticalCase(slug,candidateId,body,now=new Date()){
 const item=PRACTICAL_CASES.find(x=>x.slug===slug);if(!item)return {error:'PRACTICAL_CASE_NOT_FOUND'};
 const response=String(body?.response??'').trim();if(response.length<100)return {error:'PRACTICAL_RESPONSE_TOO_SHORT'};if(response.length>12000)return {error:'PRACTICAL_RESPONSE_TOO_LONG'};
 if(!['not_used','used','prefer_not_to_say'].includes(body?.aiUseDeclaration))return {error:'AI_DISCLOSURE_REQUIRED'};
 const variant=variantFor(candidateId,item);
 return {id:crypto.randomUUID(),caseSlug:item.slug,title:item.title,domain:item.domain,version:item.version,skills:item.skills,variant,response,aiUseDeclaration:body.aiUseDeclaration,status:'submitted_for_human_review',score:null,review:{required:true,scored:false,rubric:item.rubric.map(([criterion])=>({criterion,score:null,comment:null}))},completedAt:now.toISOString(),evidenceType:'practical_case'};
}

// Blind-review projection: never expose candidate identity or declared AI use to the reviewer queue.
// The opaque dossier reference is derived from the attempt ID and cannot be reversed to a user ID.
export function blindPracticalReviewPayload(attempt) {
 if(!attempt || attempt.evidenceType!=="practical_case" || attempt.status==="reviewed") return null;
 const digest=crypto.createHash("sha256").update(String(attempt.id||"")).digest("hex").slice(0,8).toUpperCase();
 return {id:attempt.id,blindReference:`DOSSIER-${digest}`,title:attempt.title,domain:attempt.domain,version:attempt.version,variant:attempt.variant,response:attempt.response,review:attempt.review,completedAt:attempt.completedAt};
}

export function reviewPracticalCase(attempt, body, reviewerId, now=new Date()) {
 if(!attempt || attempt.evidenceType!=="practical_case") return {error:"PRACTICAL_ATTEMPT_NOT_FOUND"};
 if(attempt.status==="reviewed") return {error:"PRACTICAL_ATTEMPT_ALREADY_REVIEWED"};
 const rubric=attempt.review?.rubric;
 if(!Array.isArray(rubric)||!rubric.length||!Array.isArray(body?.criteria)||body.criteria.length!==rubric.length) return {error:"PRACTICAL_REVIEW_RUBRIC_REQUIRED"};
 const byName=new Map(body.criteria.map(x=>[String(x.criterion||""),x]));
 const reviewed=[];
 for(const item of rubric){const entry=byName.get(item.criterion);const score=Number(entry?.score);const comment=String(entry?.comment||"").trim().slice(0,1000);if(!Number.isInteger(score)||score<1||score>4||comment.length<5)return {error:"PRACTICAL_REVIEW_CRITERIA_INVALID"};reviewed.push({criterion:item.criterion,score,comment});}
 const decision=body.decision;if(!["validated","needs_revision","not_validated"].includes(decision))return {error:"PRACTICAL_REVIEW_DECISION_INVALID"};
 const summary=String(body.summary||"").trim().slice(0,2000);if(summary.length<20)return {error:"PRACTICAL_REVIEW_SUMMARY_REQUIRED"};
 return {status:"reviewed",review:{required:false,scored:true,criteria:reviewed,decision,summary,reviewedAt:now.toISOString(),reviewedBy:reviewerId,method:"human_review"}};
}
