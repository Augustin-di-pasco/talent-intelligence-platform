const clamp = (n, min=0, max=100) => Math.max(min, Math.min(max, n));
const norm = value => String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
const unique = values => [...new Set((values || []).map(norm).filter(Boolean))];

/**
 * Explainable two-axis opportunity matching.
 * Missing evidence is unknown (null), never a zero. Years of experience are context,
 * not a hard gate. This module deliberately does not produce a blended hiring score.
 */
export function matchParcours(candidate={}, role={}) {
  const required = unique(role.skills);
  const declared = unique((candidate.skills || []).map(s => typeof s === "string" ? s : s.name));
  const skillHits = required.filter(r => declared.some(s => s === r || s.includes(r) || r.includes(s)));
  const experience = Array.isArray(candidate.experiences) ? candidate.experiences : [];
  const education = Array.isArray(candidate.education) ? candidate.education : [];
  const achievements = Array.isArray(candidate.achievements) ? candidate.achievements : [];
  const evidence = Array.isArray(candidate.evidence) ? candidate.evidence : [];
  const dimensions = [];
  if (required.length) dimensions.push({key:"skills",label:"Compétences déclarées",weight:0.45,score:100*skillHits.length/required.length,detail:`${skillHits.length}/${required.length} compétences du poste retrouvées dans le profil`});
  if (role.targetStudyLevels?.length) {
    const levels = unique(education.map(x=>x.level));
    const targets = unique(role.targetStudyLevels);
    if (levels.length) {
      const hits = targets.filter(target=>levels.some(level=>level===target || level.includes(target) || target.includes(level)));
      dimensions.push({key:"study_level",label:"Niveau de formation renseigné",weight:0.1,score:100*hits.length/targets.length,detail:`${hits.length}/${targets.length} niveaux recherchés documentés ; ce critère n’exclut jamais automatiquement un profil`});
    }
  }
  if (role.educationKeywords?.length) {
    const haystack = norm(education.map(x=>[x.title,x.field,x.institution].join(" ")).join(" "));
    const hits = unique(role.educationKeywords).filter(k=>haystack.includes(k));
    dimensions.push({key:"education",label:"Formation",weight:0.2,score:100*hits.length/unique(role.educationKeywords).length,detail:`${hits.length}/${unique(role.educationKeywords).length} critères de formation documentés`});
  }
  if (role.experienceKeywords?.length) {
    const haystack = norm(experience.map(x=>[x.title,x.company,x.description,x.domain].join(" ")).join(" "));
    const hits = unique(role.experienceKeywords).filter(k=>haystack.includes(k));
    dimensions.push({key:"experience",label:"Expérience pertinente",weight:0.25,score:100*hits.length/unique(role.experienceKeywords).length,detail:`${hits.length}/${unique(role.experienceKeywords).length} éléments de parcours pertinents`});
  } else if (experience.length) {
    dimensions.push({key:"experience",label:"Expérience",weight:0.25,score:Math.min(100,experience.length*25),detail:`${experience.length} expérience(s) renseignée(s), à examiner dans leur contexte`});
  }
  if (role.achievementKeywords?.length) {
    const haystack = norm([...achievements,...evidence].map(x=>[x.title,x.description,x.result,x.type].join(" ")).join(" "));
    const hits = unique(role.achievementKeywords).filter(k=>haystack.includes(k));
    dimensions.push({key:"achievements",label:"Réalisations et preuves de parcours",weight:0.1,score:100*hits.length/unique(role.achievementKeywords).length,detail:`${hits.length}/${unique(role.achievementKeywords).length} éléments retrouvés`});
  }
  if (!dimensions.length) return {score:null,status:"non_evaluable",coverage:0,dimensions:[],explanation:"Le poste ou le profil ne contient pas encore assez d'informations structurées."};
  const weight = dimensions.reduce((s,d)=>s+d.weight,0);
  const score = Math.round(dimensions.reduce((s,d)=>s+d.score*d.weight,0)/weight);
  const coverage = Math.round(Math.min(1,dimensions.reduce((s,d)=>s+d.weight,0))*100);
  return {score,status:"indicatif",coverage,dimensions:dimensions.map(({key,label,score,detail})=>({key,label,score:Math.round(score),detail})),explanation:"Indicateur descriptif fondé sur les informations de parcours renseignées. Il ne mesure ni le potentiel ni la performance future."};
}

function freshnessFactor(date, now) {
  if (!date) return 0.75;
  const ageDays = Math.max(0,(now-Date.parse(date))/86400000);
  if (!Number.isFinite(ageDays)) return 0.75;
  if (ageDays <= 180) return 1;
  if (ageDays <= 365) return 0.9;
  if (ageDays <= 730) return 0.78;
  return 0.65;
}

/** Tests: {skill, score, completedAt, status, version}; mission proofs: {skills, score, completedAt, status}. */
export function matchTechnique(candidate={}, role={}, options={}) {
  const required = unique(role.skills);
  if (!required.length) return {score:null,status:"non_evaluable",coverage:0,skills:[],explanation:"Aucune compétence technique n'est définie pour ce poste."};
  const now = options.now ? new Date(options.now).getTime() : Date.now();
  const tests = (candidate.assessments || []).filter(x=>x.status==="completed" && Number.isFinite(Number(x.score)));
  const missions = (candidate.missions || []).filter(x=>x.status==="validated" && Number.isFinite(Number(x.score)));
  const results = required.map(skill=>{
    const matchingTests=tests.filter(t=>[t.skill,...(Array.isArray(t.skills)?t.skills:[])].some(value=>{const n=norm(value);return n&&(n===skill||n.includes(skill)||skill.includes(n));}));
    const matchingMissions=missions.filter(m=>(m.skills||[]).some(s=>norm(s)===skill || norm(s).includes(skill) || skill.includes(norm(s))));
    const proofs=[...matchingTests.map(x=>({score:clamp(Number(x.score)),date:x.completedAt,source:"test"})),...matchingMissions.map(x=>({score:clamp(Number(x.score)),date:x.completedAt,source:"mission"}))];
    if(!proofs.length) return {skill,score:null,evidenceCount:0,status:"non_evalue"};
    const weighted=proofs.map(p=>({...p,weight:freshnessFactor(p.date,now)*(p.source==="mission"?1.2:1)}));
    const total=weighted.reduce((s,p)=>s+p.weight,0);
    return {skill,score:Math.round(weighted.reduce((s,p)=>s+p.score*p.weight,0)/total),evidenceCount:proofs.length,status:"evalue",sources:[...new Set(proofs.map(p=>p.source))]};
  });
  const evaluated=results.filter(x=>x.score!==null);
  if(!evaluated.length) return {score:null,status:"non_evalue",coverage:0,skills:results,explanation:"Aucune évaluation technique exploitable pour les compétences demandées. L'absence de test n'est pas une note nulle."};
  const score=Math.round(evaluated.reduce((s,x)=>s+x.score,0)/evaluated.length);
  const coverage=Math.round(evaluated.length/required.length*100);
  return {score,status:coverage===100?"evalue":"partiel",coverage,skills:results,explanation:`Résultats observés sur ${evaluated.length}/${required.length} compétences. Couverture et niveau de preuve restent visibles séparément.`};
}

export function matchOpportunity(candidate, role, options={}) {
  return {parcours:matchParcours(candidate,role),technique:matchTechnique(candidate,role,options),decision:"human_review_required",combinedScore:null};
}
