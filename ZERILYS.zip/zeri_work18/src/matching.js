const norm = value => String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[,;\n|]+/).map(x=>x.trim()).filter(x=>x.length>1);
const skills = user => (user.skills || []).map(x=>String(x.name || "").toLowerCase().trim()).filter(Boolean);

/** Transparent, symmetric complementarity score. It is a discovery hint, never a hiring verdict. */
export function complementarity(a,b) {
  const aSkills=skills(a), bSkills=skills(b);
  const aOffer=norm(a.canOffer), bOffer=norm(b.canOffer);
  const aNeed=norm(a.lookingFor), bNeed=norm(b.lookingFor);
  const aInterests=norm(a.interests), bInterests=norm(b.interests);
  const matches=(need,offer,skillSet)=>need.filter(n=>[...offer,...skillSet].some(s=>s===n || s.includes(n) || n.includes(s)));
  const aGets=matches(aNeed,bOffer,bSkills), bGets=matches(bNeed,aOffer,aSkills);
  const shared=aInterests.filter(x=>bInterests.some(y=>x===y || x.includes(y) || y.includes(x)));
  const reasons=[];
  if(aGets.length) reasons.push(`${b.name || "This member"} can contribute to: ${[...new Set(aGets)].slice(0,2).join(", ")}`);
  if(bGets.length) reasons.push(`You can contribute to: ${[...new Set(bGets)].slice(0,2).join(", ")}`);
  if(shared.length) reasons.push(`Shared interests: ${[...new Set(shared)].slice(0,2).join(", ")}`);
  const score=Math.min(99,Math.round((Math.min(aGets.length,3)*24)+(Math.min(bGets.length,3)*24)+(Math.min(shared.length,3)*10)));
  return {matchScore:score,matchReasons:reasons,matchType:score>=48?"strong_complementarity":score>0?"emerging_complementarity":"not_enough_shared_intent"};
}
