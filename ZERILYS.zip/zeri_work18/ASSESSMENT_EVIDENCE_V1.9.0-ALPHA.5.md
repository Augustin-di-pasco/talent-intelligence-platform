# Évaluations — preuve de raisonnement et transparence IA

## Objectif
Compléter les questionnaires de connaissances par une trace déclarative du raisonnement du candidat. Le score de connaissances et l'explication restent deux éléments distincts.

## Parcours candidat
1. Le candidat répond aux questions objectives.
2. Il rédige une explication de 40 à 1 500 caractères décrivant sa méthode, ses hypothèses et ses vérifications.
3. Il déclare son usage de l'IA : non utilisée, utilisée comme assistance, ou préfère ne pas répondre.
4. Il soumet l'ensemble ; le serveur note uniquement les réponses objectives.

## Données conservées
- `reasoningEvidence.text` : explication libre du candidat.
- `reasoningEvidence.evaluation` : `human_review_required`.
- `reasoningEvidence.scored` : toujours `false` dans cette version.
- `aiUseDeclaration` : `not_used`, `used` ou `prefer_not_to_say`.

## Garanties et limites
- Le texte libre n'est jamais noté automatiquement et ne déclenche pas de soupçon de fraude.
- La déclaration IA n'est pas une preuve de l'usage réel d'un outil.
- Aucune détection automatique d'IA n'est mise en place.
- Les explications ne doivent être partagées à un employeur qu'avec le consentement prévu pour les résultats d'évaluation ; l'accès doit rester limité aux personnes habilitées.
- Les questionnaires restent des évaluations de connaissances, pas des certifications professionnelles.

## Suite recommandée
Introduire des cas pratiques versionnés, des variantes individualisées côté serveur, des questions de justification contextualisées, puis une revue orale courte et accessible. Tout exercice doit prévoir des aménagements raisonnables et des alternatives aux dispositifs de surveillance intrusive.
