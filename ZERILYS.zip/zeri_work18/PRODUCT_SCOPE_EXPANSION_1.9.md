# Élargissement du périmètre produit — 1.9.0-alpha.7

## Positionnement
La plateforme devient une infrastructure de découverte, de démonstration et de mise en relation des talents qualifiés, du Bac+4 à la recherche avancée. Elle n'est plus limitée à la finance, à l'IA et à la data. Le Bac+4 est un niveau de cible initial, pas un filtre universel ni une équivalence automatique entre diplôme et compétence.

## Publics
- Étudiants de fin de cursus (Bac+4/Bac+5 et équivalents) : stages, alternances, projets de fin d'études et premiers emplois.
- Jeunes diplômés : premiers postes, graduate programmes, missions et collaborations.
- Professionnels : mobilité, recrutement, missions et reconversion.
- Experts, doctorants et docteurs (Bac+8 et au-delà) : R&D, recherche appliquée, expertise, innovation et collaborations scientifiques.

## Familles métiers de lancement élargi
1. Ingénierie et industrie : mécanique, électrique/électronique, systèmes, procédés, matériaux, énergie, génie civil, qualité, automatisation.
2. Informatique et numérique : logiciel, cybersécurité, cloud, systèmes, data, IA/ML, produit numérique.
3. Finance et gestion : comptabilité, audit, contrôle de gestion, trésorerie, finance d'entreprise, marchés, risques, conformité.
4. Commerce, management et conseil : stratégie, marketing, vente B2B, achats, opérations, gestion de projet, conseil.
5. Sciences et recherche : mathématiques, physique, chimie, biologie, environnement, santé/recherche (sans traiter de données de santé sensibles dans le produit), sciences humaines et sociales, méthodes de recherche.

## Types d'opportunités
- Stage, alternance, CDI, CDD, graduate programme, VIE, mission rémunérée, projet de recherche, collaboration, projet étudiant encadré.
- Pour toute mission produisant une valeur commerciale exploitable, rémunération ou compensation équitable obligatoire. Les exercices de sélection restent fictifs, simulés ou strictement bornés.
- Les offres de stage et d’alternance demandent désormais date de début, durée et conditions de gratification/rémunération ; rythme et encadrement peuvent également être renseignés. Le niveau de formation visé reste indicatif. Les informations de contrat, gratification et conformité légale doivent être vérifiées par l’employeur et validées juridiquement avant lancement.

## Architecture des évaluations
La bibliothèque actuelle comporte neuf questionnaires de connaissances courts couvrant SQL, Python/data, risque financier, comptabilité/analyse financière, statistiques, ingénierie systèmes, stratégie/étude de marché, méthodologie de recherche et gestion de projet. Ce sont des diagnostics de connaissances, pas des preuves suffisantes de maîtrise professionnelle.

### Étapes de validation à construire
- Niveau 1 — connaissances : QCM adaptatifs, contrôle de notions et raisonnement.
- Niveau 2 — mise en pratique : notebooks Python, requêtes SQL en environnement isolé, cas comptables, conception technique, analyse marketing, analyse de données, protocole de recherche.
- Niveau 3 — mission : livrable contextualisé, démarche, arbitrages, qualité, restitution et éventuellement travail collectif.

Les tests doivent être versionnés, réutilisables, reliés à des compétences atomiques, calibrés par niveau et datés. Les résultats affichent score, couverture, date, version et type de preuve. Un résultat absent reste « non évalué ». Prévoir des aménagements raisonnables, des alternatives de preuve et un contrôle humain.

## Matching
- Match Parcours : formation, expériences, réalisations et compétences déclarées.
- Match Technique : évaluations et missions vérifiées.
- Afficher séparément les deux dimensions, leur couverture et les preuves. Ne jamais générer un score combiné opaque.
- Le niveau de diplôme recherché par une offre est indicatif et explicable, jamais une règle automatique d'exclusion. L'expérience n'est pas un filtre dur.

## Stratégie de mise sur le marché
Le marché français est plus large que le segment initial. L'Apec projette pour 2026 une concentration des recrutements cadres dans l'informatique, les études-R&D et le commercial-marketing, tout en maintenant un volume important en finance/comptabilité/audit. La stratégie doit donc organiser plusieurs verticales métiers sous une expérience produit commune plutôt que multiplier les plateformes. Source : Apec, Prévisions 2026 par fonction, https://corporate.apec.fr/files/live/sites/corporate/files/Nos%20etudes/PDF/Previsions-de-recrutements-de-cadres-2026.pdf.

Pour les jeunes talents, JobTeaser cible explicitement les étudiants Bac+4/5 en stage/alternance et les jeunes diplômés d'écoles de commerce, d'ingénieurs et d'universités. Cela confirme qu’il existe un marché spécifique, mais la différenciation de notre produit doit être la preuve de compétences réutilisable et le matching à deux axes, pas une copie d’un job board étudiant. Source : https://recruiter.jobteaser.com/fr/site-recrutement/.

## Priorisation
1. Élargir les profils, taxonomie métier et offres stage/alternance.
2. Étendre les tests de connaissances à des domaines transversaux et métiers.
3. Créer les évaluations pratiques sécurisées.
4. Construire Mission Labs avec preuves et compensation.
5. Créer un workspace recruteur comparant profils et preuves.
6. Refaire la marque, le design system et la landing page une fois le périmètre stabilisé.

## Limites actuelles
La version 1.9.0-alpha.7 enrichit la taxonomie, la bibliothèque de connaissances et les champs d'offre. Elle ne fournit pas encore d'exécution de code isolée, de test psychométrique validé, de moteur de recommandation prédictif, de gestion contractuelle de stage/alternance, ni de vérification juridique des obligations propres à chaque contrat.
