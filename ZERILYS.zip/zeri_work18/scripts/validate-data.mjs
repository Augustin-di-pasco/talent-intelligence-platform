import fs from "node:fs";
import path from "node:path";
import { inspectStore } from "../src/data-integrity.js";
const dataDir=path.resolve(process.env.ZERIHLINK_DATA_DIR||"./data"),file=path.join(dataDir,"zerihlink.json");
if(!fs.existsSync(file)){console.error(`No ZERILYS store found at ${file}`);process.exit(2);}
let state;
try{state=JSON.parse(fs.readFileSync(file,"utf8"));}catch(e){console.error("Store JSON cannot be parsed:",e.message);process.exit(2);}
const report=inspectStore(state);
console.log(JSON.stringify(report,null,2));
if(!report.ok)process.exit(1);
