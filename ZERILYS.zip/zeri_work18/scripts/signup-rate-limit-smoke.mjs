import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
const probe=createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
const data=await mkdtemp(path.join(tmpdir(),'zerihlink-signup-rate-')),base=`http://127.0.0.1:${port}`;
const server=spawn(process.execPath,['src/server.js'],{cwd:process.cwd(),env:{...process.env,NODE_ENV:'production',HOST:'127.0.0.1',PORT:String(port),ZERIHLINK_DATA_DIR:data,ZERIHLINK_SESSION_SECRET:'signup-rate-limit-secret-at-least-32-characters',ZERIHLINK_BETA_LEGAL_APPROVED:'true',ZERIHLINK_ALLOW_SIGNUP:'true',ZERIHLINK_TRUST_PROXY:'true'},stdio:'ignore'});
try{
 let ready=false;for(let i=0;i<200;i++){try{if((await fetch(base+'/api/health')).ok){ready=true;break}}catch{}await delay(100)}assert.ok(ready,'server failed to start');
 const config=await fetch(base+'/api/config'),cfg=await config.json(),cookie=config.headers.get('set-cookie').split(';')[0];
 const headers={'Content-Type':'application/json','X-CSRF-Token':cfg.csrfToken,Cookie:cookie,'X-Forwarded-For':'198.51.100.44'};
 for(let i=0;i<20;i++){const r=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Invalid signup',email:`not-an-email-${i}`,password:'A-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(r.status,400);assert.equal((await r.json()).error,'INVALID_EMAIL');}
 const blocked=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Twenty-first signup',email:'twenty-first@example.test',password:'A-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(blocked.status,429);assert.equal((await blocked.json()).error,'RATE_LIMITED');
 console.log('ZERILYS signup rate-limit smoke: PASS — 20 registration attempts per client/minute accepted for validation; the 21st attempt is throttled before account creation.');
}finally{server.kill('SIGTERM');await new Promise(r=>{if(server.exitCode!==null)r();else server.once('exit',r)});await rm(data,{recursive:true,force:true});}
