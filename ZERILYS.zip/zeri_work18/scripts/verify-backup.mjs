import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const dir=path.resolve(process.env.ZERIHLINK_DATA_DIR||"./data");
const backupDir=path.join(dir,"backups");
let target=process.env.ZERIHLINK_BACKUP_FILE;
if(!target){
  if(!fs.existsSync(backupDir)){console.error("No backup directory found.");process.exit(1);}
  const candidates=fs.readdirSync(backupDir).filter(n=>n.endsWith(".json")&&!n.endsWith(".manifest.json")&&fs.existsSync(path.join(backupDir,n+".manifest.json"))).sort().reverse();
  if(!candidates.length){console.error("No backup files found.");process.exit(1);}
  target=path.join(backupDir,candidates[0]);
}
try{
  const bytes=fs.readFileSync(target),manifest=JSON.parse(fs.readFileSync(target+".manifest.json","utf8"));
  const actual=crypto.createHash("sha256").update(bytes).digest("hex");
  if(actual!==manifest.sha256||bytes.length!==manifest.bytes)throw new Error("Checksum or size mismatch");
  const parsed=JSON.parse(bytes.toString("utf8"));
  if(!parsed||!Array.isArray(parsed.users)||!Array.isArray(parsed.sessions))throw new Error("Invalid store shape");
  const avatars=parsed.users.filter(u=>typeof u.avatarDataUrl==="string"),embedded=avatars.length,embeddedBytes=avatars.reduce((sum,u)=>{const m=u.avatarDataUrl.match(/^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);if(!m)throw new Error("Invalid embedded profile photo");return sum+Buffer.from(m[1],"base64").length;},0);
  if(manifest.mediaCount!==undefined&&embedded!==manifest.mediaCount)throw new Error("Backup avatar count does not match manifest");
  if(manifest.mediaBytes!==undefined&&embeddedBytes!==manifest.mediaBytes)throw new Error("Backup avatar byte count does not match manifest");
  console.log(`Backup verified: ${target}`);
  console.log(`SHA-256: ${actual}`);
}catch(e){console.error("Backup verification failed:",e.message);process.exit(1);}
