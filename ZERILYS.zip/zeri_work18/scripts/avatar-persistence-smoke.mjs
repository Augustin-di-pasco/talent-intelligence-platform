import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';

const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
const dataDir=await mkdtemp(path.join(tmpdir(),'zerihlink-avatar-persist-'));
const base=`http://127.0.0.1:${port}`,secret='avatar-persistence-smoke-secret-more-than-32-characters';
let child,logs='';
function start(){child=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env:{...process.env,PORT:String(port),ZERIHLINK_DATA_DIR:dataDir,ZERIHLINK_SESSION_SECRET:secret,ZERIHLINK_BETA_LEGAL_APPROVED:'true',ZERIHLINK_ALLOW_SIGNUP:'true'},stdio:['ignore','pipe','pipe']});child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);}
async function ready(){for(let i=0;i<80;i++){try{const r=await fetch(base+'/api/health');if(r.ok)return await r.json()}catch{}await delay(100)}throw new Error('Server did not become ready: '+logs)}
async function stop(){if(!child||child.exitCode!==null)return;child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),delay(3000)]);}
try{
  start();const health=await ready();assert.equal(health.version,'1.9.0-alpha.20');
  const cfg=await fetch(base+'/api/config');const csrf=(await cfg.json()).csrfToken;let cookie=cfg.headers.get('set-cookie').split(';')[0];
  const reg=await fetch(base+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf,Cookie:cookie},body:JSON.stringify({name:'Persistent Portrait',email:'portrait@zerihlink.test',password:'A-very-strong-persistence-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(reg.status,201);const registered=await reg.json();const sessionCookie=reg.headers.get('set-cookie').split(';')[0];cookie+='; '+sessionCookie;
  const bytes=Buffer.alloc(160);bytes.set([0xff,0xd8,0xff,0xe0],0);const dataUrl='data:image/jpeg;base64,'+bytes.toString('base64');
  const uploaded=await fetch(base+'/api/me/avatar',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf,Cookie:cookie},body:JSON.stringify({imageDataUrl:dataUrl})});assert.equal(uploaded.status,200);const saved=(await uploaded.json()).user;assert.ok(saved.avatarUrl);
  await stop();start();await ready();
  const me=await fetch(base+'/api/me',{headers:{Cookie:cookie}});assert.equal(me.status,200);const restored=(await me.json()).user;assert.equal(restored.id,registered.user.id);assert.equal(restored.avatarUrl,saved.avatarUrl);
  const media=await fetch(base+restored.avatarUrl,{headers:{Cookie:cookie}});assert.equal(media.status,200);assert.deepEqual(Buffer.from(await media.arrayBuffer()),bytes);
  console.log('ZERILYS avatar persistence smoke: PASS — profile photo and session survive a server restart on the persistent data volume.');
}finally{await stop();await rm(dataDir,{recursive:true,force:true});}
