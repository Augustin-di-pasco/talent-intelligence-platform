import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const dir=path.resolve(process.env.ZERIHLINK_DATA_DIR||"./data");
const target=path.join(dir,"zerihlink.json");
const source=process.env.ZERIHLINK_RESTORE_FILE;
if(process.env.ZERIHLINK_RESTORE_CONFIRM!=="RESTORE"){console.error("Restore blocked. Set ZERIHLINK_RESTORE_CONFIRM=RESTORE to confirm.");process.exit(2);}
if(!source||!fs.existsSync(source)){console.error("Set ZERIHLINK_RESTORE_FILE to an existing backup JSON file.");process.exit(1);}
if(path.resolve(source)===path.resolve(target)){console.error("Restore source and live data file must be different.");process.exit(1);}
let restored;
try{
  const bytes=fs.readFileSync(source),manifest=JSON.parse(fs.readFileSync(source+".manifest.json","utf8"));
  const actual=crypto.createHash("sha256").update(bytes).digest("hex");
  if(actual!==manifest.sha256||bytes.length!==manifest.bytes)throw new Error("Restore source checksum or size mismatch");
  restored=JSON.parse(bytes.toString("utf8"));
  if(!restored||!Array.isArray(restored.users)||!Array.isArray(restored.sessions))throw new Error("Invalid store shape");
}catch(e){console.error("Restore source is not a verified ZERILYS backup:",e.message);process.exit(1);}
if(!fs.existsSync(target)){console.error("Current live data file does not exist; initialize the app before restoring.");process.exit(1);}
const backups=path.join(dir,"backups");fs.mkdirSync(backups,{recursive:true,mode:0o700});
const stamp=new Date().toISOString().replace(/[:.]/g,"-");
const safety=path.join(backups,`pre-restore-${stamp}.json`);
const current=fs.readFileSync(target),currentHash=crypto.createHash("sha256").update(current).digest("hex");
fs.writeFileSync(safety,current,{mode:0o600,flag:"wx"});
fs.writeFileSync(safety+".manifest.json",JSON.stringify({createdAt:new Date().toISOString(),source:"zerihlink.json",backup:path.basename(safety),bytes:current.length,sha256:currentHash,kind:"pre-restore-safety-copy"},null,2),{mode:0o600,flag:"wx"});
const qualificationDir=path.join(dir,"qualification-documents");fs.mkdirSync(qualificationDir,{recursive:true,mode:0o700});
for(const user of restored.users)for(const q of user.qualificationVerifications||[]){
  if(typeof q.documentDataUrl!=="string")continue;
  const m=q.documentDataUrl.match(/^data:(application\/pdf|image\/jpeg|image\/png);base64,([A-Za-z0-9+/]+={0,2})$/);if(!m)throw new Error(`Invalid qualification document in backup for user ${user.id}`);
  const bytes=Buffer.from(m[2],"base64");if(bytes.length<100||bytes.length>650000)throw new Error(`Invalid qualification document size for user ${user.id}`);
  const ext=m[1]==="application/pdf"?"pdf":m[1]==="image/jpeg"?"jpg":"png",valid=ext==="pdf"?bytes.subarray(0,5).toString()==="%PDF-":ext==="jpg"?bytes.subarray(0,3).equals(Buffer.from([255,216,255])):bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));if(!valid)throw new Error(`Qualification document content mismatch for user ${user.id}`);
  const filename=`${crypto.randomUUID()}.${ext}`;fs.writeFileSync(path.join(qualificationDir,filename),bytes,{mode:0o600,flag:"wx"});q.documentFile=filename;q.documentFormat=ext;q.documentBytes=bytes.length;q.documentSha256=crypto.createHash("sha256").update(bytes).digest("hex");delete q.documentDataUrl;
}
const tmp=target+"."+crypto.randomUUID()+".tmp";
fs.writeFileSync(tmp,JSON.stringify(restored,null,2),{mode:0o600,flag:"wx"});
fs.renameSync(tmp,target);
console.log(`Restore completed from: ${source}`);
console.log(`Pre-restore safety copy: ${safety}`);
