import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
const root=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),"zerihlink-preflight-"));
try{
 const r=spawnSync(process.execPath,[path.join(root,"scripts/preflight-beta.mjs")],{cwd:root,encoding:"utf8",env:{...process.env,NODE_ENV:"development",ZERIHLINK_DATA_DIR:dir,ZERIHLINK_SESSION_SECRET:"short",ZERIHLINK_REVIEWER_EMAILS:"",ZERIHLINK_PUBLIC_URL:"",ZERIHLINK_ALLOW_SIGNUP:"false"}});
 assert.equal(r.status,1);
 const report=JSON.parse(r.stdout);
 assert.equal(report.readyForClosedBeta,false);assert.equal(report.readyForPublicLaunch,false);
 for(const key of ["production_mode","session_secret","reviewer_access","deployed_health_check","browser_qa_ack","legal_review_ack","beta_legal_approval","reviewer_coverage_ack","offsite_backup_ack"])assert.ok(report.blockers.some(x=>x.name===key),`expected blocker ${key}`);
 assert.ok(report.checks.some(x=>x.name==="open_registration"&&x.status==="pass"));
 const unsafeSignup=spawnSync(process.execPath,[path.join(root,"scripts/preflight-beta.mjs")],{cwd:root,encoding:"utf8",env:{...process.env,NODE_ENV:"development",ZERIHLINK_DATA_DIR:dir,ZERIHLINK_SESSION_SECRET:"short",ZERIHLINK_REVIEWER_EMAILS:"",ZERIHLINK_PUBLIC_URL:"",ZERIHLINK_ALLOW_SIGNUP:"true",ZERIHLINK_BETA_LEGAL_APPROVED:"false"}});
 const unsafeReport=JSON.parse(unsafeSignup.stdout);assert.ok(unsafeReport.blockers.some(x=>x.name==="open_registration"),"open signup without legal approval must block launch");
 assert.ok(report.warnings.some(x=>x.name==="postgres_runtime"));
 assert.ok(report.blockers.some(x=>x.name==="persistent_data_directory"));
 assert.ok(report.checks.some(x=>x.name==="avatar_media_directory"&&x.status==="pass"));
 assert.ok(report.checks.some(x=>x.name==="avatar_media_integrity"&&x.status==="pass"));
 assert.ok(report.warnings.some(x=>x.name==="public_origin"));
 const ack=spawnSync(process.execPath,[path.join(root,"scripts/preflight-beta.mjs")],{cwd:root,encoding:"utf8",env:{...process.env,NODE_ENV:"development",ZERIHLINK_DATA_DIR:dir,ZERIHLINK_PERSISTENT_DATA_ACK:"true",ZERIHLINK_SESSION_SECRET:"short",ZERIHLINK_REVIEWER_EMAILS:"",ZERIHLINK_PUBLIC_URL:""}});
 const ackReport=JSON.parse(ack.stdout);assert.ok(ackReport.checks.some(x=>x.name==="persistent_data_directory"&&x.status==="pass"));
 console.log("ZERILYS release preflight smoke: PASS — missing launch requirements are reported as blockers, scale/data-source limits as warnings.");
}finally{fs.rmSync(dir,{recursive:true,force:true});}
