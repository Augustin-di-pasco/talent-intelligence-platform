import { spawnSync } from 'node:child_process';
const run=spawnSync(process.execPath,['scripts/preflight-beta.mjs'],{cwd:process.cwd(),env:process.env,encoding:'utf8',maxBuffer:2*1024*1024});
let report;
try{const start=run.stdout.indexOf('{');report=JSON.parse(run.stdout.slice(start));}
catch{process.stderr.write(run.stderr||run.stdout||'Impossible de lire le rapport de préproduction.\n');process.exit(2);}
const labels={
 production_mode:'Le serveur doit être lancé en mode production.',
 session_secret:'Générer une clé de session aléatoire d’au moins 32 caractères, suffisamment diversifiée, et la configurer dans l’hébergement.',
 reviewer_access:'Déclarer au moins une adresse e-mail valide pour l’équipe de modération.',
 open_registration:'Les inscriptions standard sont ouvertes sans code ni invitation obligatoire.',
 trusted_proxy:'Configurer le proxy de confiance uniquement si l’hébergement utilise bien un reverse proxy maîtrisé.',
 persistent_data_directory:'Monter un volume persistant et configurer ZERIHLINK_DATA_DIR vers ce volume.',
 avatar_media_directory:'Vérifier que le volume persistant conserve le dossier avatars/ et autorise l’écriture.',
 render_persistent_disk:'Vérifier la présence du disque persistant et du contrôle de santé dans le blueprint Render.',
 render_trusted_proxy:'Vérifier la configuration du proxy de confiance dans Render.',
 render_legal_switch:'Conserver le verrou juridique explicite dans la configuration de l’hébergement.',
 version_consistency:'Aligner la version du serveur, du fichier VERSION et du package.',
 data_integrity:'Corriger toute erreur d’intégrité dans le fichier de données.',
 avatar_media_integrity:'Corriger les références de photos manquantes ou invalides.',
 local_backup:'Créer une sauvegarde locale vérifiée, incluant les photos et son manifeste.',
 public_origin:'Renseigner l’adresse HTTPS canonique du site pour les liens de profils partagés.',
 deployed_health_check:'Renseigner l’URL réelle du site déployé et vérifier /api/health.',
 browser_qa_ack:'Effectuer les tests humains sur ordinateur et mobile, puis confirmer leur réussite.',
 legal_review_ack:'Faire examiner les conditions, la confidentialité, les durées de conservation et les mentions légales.',
 beta_legal_approval:'Ne lever le verrou d’inscription qu’après validation juridique réelle des documents français.',
 reviewer_coverage_ack:'Nommer les modérateurs et organiser une permanence quotidienne pour les signalements et retours.',
 offsite_backup_ack:'Copier une sauvegarde hors de l’hébergement et tester réellement sa restauration.',
 postgres_runtime:'Le stockage d’exécution reste un fichier JSON sur une instance unique ; acceptable uniquement pour une bêta limitée, pas pour une croissance publique.',
 transactional_email:'Configurer le service d’e-mails transactionnels pour activer les confirmations d’adresse, les invitations et la récupération du mot de passe.',
 market_data_licensing:'Ne pas afficher de cours en direct tant que les droits de redistribution commerciale ne sont pas confirmés.'
};
const blockers=report.blockers||[],warnings=report.warnings||[],signupEnabled=(process.env.ZERIHLINK_ALLOW_SIGNUP??process.env.NEXUS_ALLOW_SIGNUP)==='true',legal=report.checks?.find(x=>x.name==='beta_legal_approval');
console.log(`ZERILYS — CONTRÔLE AVANT OUVERTURE · VERSION ${report.version}`);
console.log('');
console.log(`Configuration des inscriptions sans invitation : ${signupEnabled?'OUVERTE':'FERMÉE PAR DÉFAUT'}`);
console.log(`Inscription effective : ${signupEnabled&&legal?.status==='pass'?'AUTORISÉE':'BLOQUÉE PAR LE VERROU JURIDIQUE OU LA CONFIGURATION'}`);
console.log(`Préparation de la bêta : ${blockers.length===0?'PRÊTE SOUS RÉSERVE DES CONTRÔLES RÉELS':'NON PRÊTE'}`);
console.log(`Points bloquants : ${blockers.length} · Avertissements : ${warnings.length}`);
if(blockers.length){console.log('\nÀ RÉGLER AVANT LA BÊTA');blockers.forEach((item,i)=>console.log(`${i+1}. ${labels[item.name]||item.detail}`));}
if(warnings.length){console.log('\nÀ ANTICIPER');warnings.forEach((item,i)=>console.log(`${i+1}. ${labels[item.name]||item.detail}`));}
console.log('\nIMPORTANT');
console.log('Le code d’invitation n’est pas obligatoire une fois la bêta autorisée. Le verrou juridique bloque effectivement toute inscription tant que les documents français ne sont pas validés.');
console.log('La validation automatique ne remplace pas les tests sur le véritable hébergement et sur de vrais appareils.');
process.exitCode=blockers.length?1:0;
