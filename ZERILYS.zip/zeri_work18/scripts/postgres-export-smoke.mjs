import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
const root=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),"zerihlink-pg-export-"));
const candidate="11111111-1111-4111-8111-111111111111",company="22222222-2222-4222-8222-222222222222";
const skill="33333333-3333-4333-8333-333333333333",evidence="44444444-4444-4444-8444-444444444444";
const offer="55555555-5555-4555-8555-555555555555",app="66666666-6666-4666-8666-666666666666";
const project="77777777-7777-4777-8777-777777777777",projectApp="88888888-8888-4888-8888-888888888888";
const connection="99999999-9999-4999-8999-999999999999",companyMember="aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
const companyInvite="bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",betaInvite="cccccccc-cccc-4ccc-8ccc-cccccccccccc",feedback="dddddddd-dddd-4ddd-8ddd-dddddddddddd";
const state={
 users:[
  {id:candidate,email:"candidate@example.test",accountType:"candidate",passwordHash:"hash1",passwordSalt:"salt1",name:"O'Reilly",about:"Bio with null\u0000byte",visibility:"private",createdAt:"2026-01-01T00:00:00.000Z",updatedAt:"2026-01-01T00:00:00.000Z",skills:[{id:skill,name:"Systems design",level:"advanced",addedAt:"2026-01-01T00:00:00.000Z"}]},
  {id:company,email:"company@example.test",accountType:"company",passwordHash:"hash2",passwordSalt:"salt2",name:"Example Co",companyName:"Example Co",companyIndustry:"Technology",visibility:"public",createdAt:"2026-01-01T00:00:00.000Z",updatedAt:"2026-01-01T00:00:00.000Z",skills:[]}
 ],
 sessions:[{id:"eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee",userId:candidate,tokenHash:"hashed-session",expiresAt:1893456000000}],
 projects:[{id:project,ownerId:candidate,title:"Open project",description:"A long enough description for a project.",skills:["Systems design"],commitment:"part_time",status:"open",createdAt:"2026-01-01T00:00:00.000Z"}],
 applications:[{id:projectApp,projectId:project,userId:company,message:"Interested",status:"pending",createdAt:"2026-01-02T00:00:00.000Z"}],
 evidence:[{id:evidence,userId:candidate,skillId:skill,title:"Architecture project",description:"Designed a system.",status:"verified",createdAt:"2026-01-01T00:00:00.000Z"}],
 connections:[{id:connection,fromUserId:candidate,toUserId:company,reason:"Complementary skills and shared mission.",status:"pending",createdAt:"2026-01-01T00:00:00.000Z"}],
 reports:[{id:"ffffffff-ffff-4fff-8fff-ffffffffffff",reporterId:candidate,targetUserId:company,category:"misleading",reason:"A sufficiently detailed report reason.",status:"open",createdAt:"2026-01-03T00:00:00.000Z"}],
 blocks:[{blockerId:candidate,blockedId:company,createdAt:'2026-01-02T00:00:00.000Z'}],companies:[],offers:[{id:offer,companyId:company,title:"Systems architect",description:"A sufficiently detailed role description.",type:"job",skills:["Systems design"],status:"published",createdAt:"2026-01-01T00:00:00.000Z",updatedAt:"2026-01-01T00:00:00.000Z"}],
 offerApplications:[{id:app,offerId:offer,candidateId:candidate,status:"interest_sent",consentAt:"2026-01-02T00:00:00.000Z",createdAt:"2026-01-02T00:00:00.000Z",updatedAt:"2026-01-02T00:00:00.000Z",statusHistory:[{status:"interest_sent",at:"2026-01-02T00:00:00.000Z",actorType:"candidate"}],privateNotes:[{id:"12121212-1212-4212-8212-121212121212",authorId:company,note:"Internal note.",createdAt:"2026-01-02T00:00:00.000Z"}]}],
 notifications:[{id:"13131313-1313-4313-8313-131313131313",recipientId:candidate,type:"candidate_interest",title:"Interest",body:"A candidate applied.",createdAt:"2026-01-02T00:00:00.000Z"}],
 companyMembers:[{id:companyMember,companyId:company,userId:candidate,role:"recruiter",status:"active",createdAt:"2026-01-01T00:00:00.000Z"}],
 companyInvitations:[{id:companyInvite,companyId:company,email:"accepted@example.test",role:"viewer",status:"accepted",expiresAt:1893456000000,createdAt:"2026-01-01T00:00:00.000Z"}],
 betaInvitations:[{id:betaInvite,email:"pending@example.test",accountType:"candidate",tokenHash:"stored-token-hash",status:"pending",createdBy:candidate,expiresAt:1893456000000,createdAt:"2026-01-01T00:00:00.000Z"}],
 betaFeedback:[{id:feedback,userId:candidate,category:"idea",area:"Profile",message:"Please make this clearer.",status:"open",createdAt:"2026-01-03T00:00:00.000Z"}],
 audit:[{id:"14141414-1414-4414-8414-141414141414",actorId:candidate,action:"profile.updated",targetType:"user",targetId:candidate,metadata:{source:"smoke"},previous:"GENESIS",hash:"a".repeat(64),at:"2026-01-01T00:00:00.000Z"}]
};
fs.writeFileSync(path.join(dir,"zerihlink.json"),JSON.stringify(state));
const output=path.join(dir,"export.sql");
const run=spawnSync(process.execPath,[path.join(root,"scripts","export-postgres.mjs")],{cwd:root,encoding:"utf8",env:{...process.env,ZERIHLINK_DATA_DIR:dir,ZERIHLINK_POSTGRES_EXPORT_FILE:output}});
try{
 assert.equal(run.status,0,run.stderr);assert.ok(fs.existsSync(output));
 const sql=fs.readFileSync(output,"utf8");
 for(const table of ["users","sessions","skills","evidence","projects","project_applications","offers","offer_applications","application_events","application_private_notes","notifications","blocks","reports","connections","company_members","company_invitations","beta_invitations","beta_feedback","audit_events","migration_import_log"])assert.ok(sql.includes(`INSERT INTO ${table}`),`missing table ${table}`);
 assert.ok(sql.includes("legal_consent"));assert.ok(sql.includes("company_verification"));assert.ok(sql.includes("password_reset_tokens"));assert.ok(sql.includes("'password_reset_tokens',0)"));assert.ok(sql.includes("O''Reilly"));assert.ok(!sql.includes("\u0000byte"));assert.ok(sql.includes("ON CONFLICT DO NOTHING"));assert.ok(sql.startsWith("-- ZERILYS PostgreSQL data export"));assert.ok(sql.includes("BEGIN;"));assert.ok(sql.includes("COMMIT;"));
 assert.ok(sql.includes("stored-token-hash"));assert.ok(!sql.includes("raw-personal-invitation-token"));
 assert.match(run.stdout,/Source SHA-256:/);assert.match(run.stdout,/users=2/);
 console.log("ZERILYS PostgreSQL export smoke: PASS — all entity tables, SQL escaping, deterministic event IDs, migration log and source checksum.");
}finally{fs.rmSync(dir,{recursive:true,force:true});}
