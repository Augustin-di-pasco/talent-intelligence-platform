import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
const dataDir=await mkdtemp(path.join(tmpdir(),'zerihlink-remote-smoke-')),base=`http://127.0.0.1:${port}`;let child,logs='';
try{
 child=spawn(process.execPath,['src/server.js'],{cwd:process.cwd(),env:{...process.env,NODE_ENV:'production',HOST:'127.0.0.1',PORT:String(port),ZERIHLINK_DATA_DIR:dataDir,ZERIHLINK_SESSION_SECRET:'remote-smoke-secret-longer-than-thirty-two-characters',ZERIHLINK_BETA_LEGAL_APPROVED:'false',ZERIHLINK_ALLOW_SIGNUP:'true',ZERIHLINK_INVITE_CODE:'remote-beta-smoke-invite-code',ZERIHLINK_TRUST_PROXY:'true',ZERIHLINK_PUBLIC_URL:'https://zerihlink.example'},stdio:['ignore','pipe','pipe']});child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);
 let ready=false;for(let i=0;i<100;i++){try{const r=await fetch(base+'/api/health');if(r.ok){ready=true;break}}catch{}await delay(100)}assert.ok(ready,'local production server did not start: '+logs);
 const check=spawnSync(process.execPath,['scripts/remote-beta-check.mjs'],{cwd:process.cwd(),encoding:'utf8',env:{...process.env,ZERIHLINK_DEPLOYMENT_URL:base,ZERIHLINK_REMOTE_EXPECTED_VERSION:'1.9.0-alpha.20',ZERIHLINK_PUBLIC_URL:'https://zerihlink.example'}});assert.equal(check.status,0,check.stderr||check.stdout);assert.match(check.stdout,/security_headers/);assert.match(check.stdout,/open_registration/);console.log('ZERILYS remote acceptance smoke: PASS — HTTPS/security policy, deployed version, open registration, anonymous privacy and static routes checked against a local production-mode server.');
}finally{if(child&&child.exitCode===null){child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),delay(3000)])}await rm(dataDir,{recursive:true,force:true});}
