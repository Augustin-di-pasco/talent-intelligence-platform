import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, readdir, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';

const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
const dataDir=await mkdtemp(path.join(tmpdir(),'zerihlink-cohort50-')),base=`http://127.0.0.1:${port}`,secret='cohort-50-smoke-secret-with-more-than-32-characters';
let child,logs='';
function start(){child=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env:{...process.env,PORT:String(port),ZERIHLINK_DATA_DIR:dataDir,ZERIHLINK_SESSION_SECRET:secret,ZERIHLINK_BETA_LEGAL_APPROVED:'true',ZERIHLINK_ALLOW_SIGNUP:'true',ZERIHLINK_TRUST_PROXY:'true',ZERIHLINK_REVIEWER_EMAILS:'beta-reviewer@cohort.test',ZERIHLINK_EMAIL_WEBHOOK_URL:'',ZERIHLINK_EMAIL_WEBHOOK_SECRET:'',ZERIHLINK_EMAIL_FROM:'',ZERIHLINK_APP_URL:''},stdio:['ignore','pipe','pipe']});child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);}
async function ready(){for(let i=0;i<100;i++){try{const r=await fetch(base+'/api/health');if(r.ok)return await r.json()}catch{}await delay(100)}throw new Error('Server did not become ready: '+logs)}
async function stop(){if(!child||child.exitCode!==null)return;child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),delay(3000)]);}
function client(index){const ip=`10.10.0.${index+1}`;return{ip,cookie:'',csrf:'',async config(){const r=await fetch(base+'/api/config',{headers:{'X-Forwarded-For':ip}});assert.equal(r.status,200);this.csrf=(await r.json()).csrfToken;this.cookie=r.headers.get('set-cookie').split(';')[0];},async req(route,{method='GET',body}={}){const r=await fetch(base+route,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(method!=='GET'?{'X-CSRF-Token':this.csrf}:{}),Cookie:this.cookie,'X-Forwarded-For':ip},body:body?JSON.stringify(body):undefined});const setCookie=r.headers.get('set-cookie');if(setCookie){const pair=setCookie.split(';')[0];if(pair.startsWith('zerihlink_session='))this.cookie+='; '+pair;}const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(`${method} ${route}: ${r.status} ${JSON.stringify(data)}`);return data;}}}
try{
  start();const health=await ready();assert.equal(health.version,'1.9.0-alpha.20');
  const reviewer=client(0);await reviewer.config();const reviewerConfig=await reviewer.req('/api/config');assert.equal(reviewerConfig.inviteRequired,false);
  const reviewerAccount=await reviewer.req('/api/auth/register',{method:'POST',body:{name:'ZERILYS Beta Reviewer',accountType:'company',companyName:'ZERILYS Beta Operations',companyIndustry:'Technology',companyWebsite:'https://example.com',email:'beta-reviewer@cohort.test',password:'Cohort-reviewer-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true}});assert.equal(reviewerAccount.user.accountType,'company');
  const bulkHeaders={'Content-Type':'application/json','X-CSRF-Token':reviewer.csrf,Cookie:reviewer.cookie,'X-Forwarded-For':reviewer.ip};
  const duplicateBatch=await fetch(base+'/api/review/invitations/bulk',{method:'POST',headers:bulkHeaders,body:JSON.stringify({emails:['duplicate@cohort.test','duplicate@cohort.test']})});assert.equal(duplicateBatch.status,400);
  const invalidBatch=await fetch(base+'/api/review/invitations/bulk',{method:'POST',headers:bulkHeaders,body:JSON.stringify({emails:['not-an-email']})});assert.equal(invalidBatch.status,400);
  const conflictBatch=await fetch(base+'/api/review/invitations/bulk',{method:'POST',headers:bulkHeaders,body:JSON.stringify({emails:['beta-reviewer@cohort.test']})});assert.equal(conflictBatch.status,409);
  assert.equal((await reviewer.req('/api/review/invitations')).invitations.length,0);
  const started=Date.now(),members=Array.from({length:50},(_,i)=>client(i+1)),emails=members.map((_,i)=>`beta-${String(i+1).padStart(2,'0')}@cohort.zerihlink.test`);
  const batch=await reviewer.req('/api/review/invitations/bulk',{method:'POST',body:{emails,accountType:'candidate',validDays:14}});assert.equal(batch.created,50);assert.equal(batch.delivered,0);assert.equal(batch.manual,50);assert.equal(batch.results.length,50);assert.ok(batch.batchId);const pendingOverview=await reviewer.req('/api/review/invitations');assert.equal(pendingOverview.invitations.length,50);assert.equal(pendingOverview.batches[0].total,50);assert.equal(pendingOverview.batches[0].pending,50);
  const invitationTokens=batch.results.map((item,i)=>{assert.equal(item.invitation.email,emails[i]);assert.equal(item.invitation.status,'pending');assert.equal(item.delivery,'manual');assert.ok(item.invitationToken);return item.invitationToken;});
  const invitationMs=Date.now()-started,registrationStart=Date.now();
  for(let i=0;i<members.length;i+=10){const batch=members.slice(i,i+10);await Promise.all(batch.map(async(c,j)=>{const index=i+j;await c.config();const result=await c.req('/api/auth/register',{method:'POST',body:{name:`Beta Tester ${String(index+1).padStart(2,'0')}`,email:`beta-${String(index+1).padStart(2,'0')}@cohort.zerihlink.test`,password:'Cohort-50-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true,betaInvitationToken:invitationTokens[index]}});c.user=result.user;}));}
  const registrationMs=Date.now()-registrationStart;assert.equal(members.length,50);
  const invitationOverview=await reviewer.req('/api/review/invitations');assert.equal(invitationOverview.invitations.length,0);assert.equal(invitationOverview.batches[0].total,50);assert.equal(invitationOverview.batches[0].accepted,50);assert.equal(invitationOverview.batches[0].pending,0);assert.equal(invitationOverview.summary.accepted,50);assert.equal(invitationOverview.summary.total,50);
  const photoBytes=Buffer.alloc(180);photoBytes.set([0xff,0xd8,0xff,0xe0],0);const photoData='data:image/jpeg;base64,'+photoBytes.toString('base64');
  await Promise.all(members.slice(0,10).map(async c=>{const result=await c.req('/api/me/avatar',{method:'POST',body:{imageDataUrl:photoData}});c.avatarUrl=result.user.avatarUrl;assert.ok(c.avatarUrl);}));
  const discoveryStart=Date.now(),allIds=[],pageOne=await members[0].req('/api/discover?limit=20');assert.equal(pageOne.total,49);assert.equal(pageOne.users.length,20);assert.ok(pageOne.hasMore);allIds.push(...pageOne.users.map(x=>x.id));
  let cursor=pageOne.nextCursor,pages=1;while(cursor){const params=new URLSearchParams({limit:'20',cursor});const page=await members[0].req('/api/discover?'+params.toString());assert.ok(page.users.length>0);allIds.push(...page.users.map(x=>x.id));cursor=page.nextCursor;pages++;}
  const discoveryMs=Date.now()-discoveryStart;assert.equal(allIds.length,49);assert.equal(new Set(allIds).size,49);assert.equal(pages,3);assert.ok(members.every(m=>allIds.includes(m.user.id)||m.user.id===members[0].user.id));
  const profileResults=await Promise.all(allIds.map(async id=>members[0].req(`/api/profiles/${id}`)));assert.equal(profileResults.length,49);assert.ok(profileResults.every((p,i)=>p.user.id===allIds[i]));
  const anonymousProfile=await fetch(base+`/api/profiles/${members[1].user.id}`);assert.equal(anonymousProfile.status,404);
  const memberMedia=await fetch(base+members[1].avatarUrl,{headers:{Cookie:members[0].cookie,'X-Forwarded-For':members[0].ip}});assert.equal(memberMedia.status,200);assert.deepEqual(Buffer.from(await memberMedia.arrayBuffer()),photoBytes);
  const anonymousMedia=await fetch(base+members[1].avatarUrl);assert.equal(anonymousMedia.status,404);
  const mediaFiles=await readdir(path.join(dataDir,'avatars'));assert.equal(mediaFiles.length,10);
  const storeFile=await stat(path.join(dataDir,'zerihlink.json'));
  console.log(`ZERILYS 50-member cohort smoke: PASS — 50 one-time invitations created in ${invitationMs} ms; 50 invited candidates registered in ${registrationMs} ms; 49/49 other private profiles discoverable across ${pages} pages in ${discoveryMs} ms; 10 photos stored separately; member/anonymous media access controls verified; store ${storeFile.size} bytes.`);
}finally{await stop();await rm(dataDir,{recursive:true,force:true});}
