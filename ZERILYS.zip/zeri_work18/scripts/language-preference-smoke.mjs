import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';

const probe=createServer();await new Promise(resolve=>probe.listen(0,'127.0.0.1',resolve));const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
const dataDir=await mkdtemp(path.join(tmpdir(),'zerihlink-language-pref-')),base=`http://127.0.0.1:${port}`,secret='language-preference-smoke-secret-more-than-32-characters';
let child,logs='';
function start(){child=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env:{...process.env,NODE_ENV:'production',HOST:'127.0.0.1',PORT:String(port),ZERIHLINK_DATA_DIR:dataDir,ZERIHLINK_SESSION_SECRET:secret,ZERIHLINK_BETA_LEGAL_APPROVED:'true',ZERIHLINK_ALLOW_SIGNUP:'true',ZERIHLINK_TRUST_PROXY:'true',ZERIHLINK_REVIEWER_EMAILS:'language-reviewer@example.test'},stdio:['ignore','pipe','pipe']});child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);}
async function ready(){for(let i=0;i<100;i++){try{const r=await fetch(base+'/api/health');if(r.ok)return await r.json()}catch{}await delay(100)}throw new Error('Server did not become ready: '+logs)}
async function stop(){if(!child||child.exitCode!==null)return;child.kill('SIGTERM');await Promise.race([new Promise(resolve=>child.once('exit',resolve)),delay(3000)]);}
function client(index){const ip=`10.30.0.${index+1}`;return{ip,cookie:'',csrf:'',user:null,async config(){const r=await fetch(base+'/api/config',{headers:{'X-Forwarded-For':ip}});assert.equal(r.status,200);const cfg=await r.json();this.csrf=cfg.csrfToken;this.cookie=r.headers.get('set-cookie').split(';')[0];},async req(route,{method='GET',body}={}){const r=await fetch(base+route,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(method!=='GET'?{'X-CSRF-Token':this.csrf}:{}),Cookie:this.cookie,'X-Forwarded-For':ip},body:body?JSON.stringify(body):undefined});const setCookie=r.headers.get('set-cookie');if(setCookie){const pair=setCookie.split(';')[0];if(pair.startsWith('zerihlink_session='))this.cookie+='; '+pair;}const data=await r.json().catch(()=>({}));return{status:r.status,data};}}}
try{
 start();const health=await ready();assert.equal(health.version,'1.9.0-alpha.20');
 const first=client(0);await first.config();let result=await first.req('/api/auth/register',{method:'POST',body:{name:'Language Preference Tester',email:'language-preference@example.test',password:'Language-preference-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true}});assert.equal(result.status,201);first.user=result.data.user;
 result=await first.req('/api/me/preferences',{method:'PATCH',body:{preferredLanguage:'en'}});assert.equal(result.status,200);assert.equal(result.data.preferredLanguage,'en');
 result=await first.req('/api/me');assert.equal(result.status,200);assert.equal(result.data.user.preferredLanguage,'en');
 result=await first.req('/api/me/preferences',{method:'PATCH',body:{preferredLanguage:'es'}});assert.equal(result.status,400);
 const second=client(1);await second.config();result=await second.req('/api/auth/register',{method:'POST',body:{name:'Second Member',email:'second-language@example.test',password:'Language-preference-strong-password-2026',betaTermsAccepted:true,privacyNoticeAcknowledged:true}});assert.equal(result.status,201);
 result=await second.req(`/api/profiles/${first.user.id}`);assert.equal(result.status,200);assert.equal(Object.hasOwn(result.data.user,'preferredLanguage'),false);
 await stop();start();const restarted=await ready();assert.equal(restarted.version,'1.9.0-alpha.20');
 result=await first.req('/api/me');assert.equal(result.status,200);assert.equal(result.data.user.preferredLanguage,'en');
 console.log('ZERILYS language preference smoke: PASS — account language saved, validated, kept private from other members and retained after server restart.');
}finally{await stop();await rm(dataDir,{recursive:true,force:true});}
