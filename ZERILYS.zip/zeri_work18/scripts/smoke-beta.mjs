import { spawn, spawnSync } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { scryptSync, randomBytes } from 'node:crypto';
import { tmpdir } from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
const probe=createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
const data=await mkdtemp(path.join(tmpdir(),'zerihlink-beta-'));
const legacyId='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',legacySalt=randomBytes(16).toString('hex');
const legacyState={users:[{id:legacyId,name:'Legacy Member',email:'legacy@beta.test',passwordHash:scryptSync('Legacy-strong-password-2026',legacySalt,64).toString('hex'),passwordSalt:legacySalt,accountType:'candidate',skills:[],visibility:'private',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}],sessions:[],projects:[],applications:[],evidence:[],connections:[],reports:[],blocks:[],companies:[],offers:[],offerApplications:[],notifications:[],companyMembers:[],companyInvitations:[],betaInvitations:[],betaFeedback:[],audit:[]};
await writeFile(path.join(data,'zerihlink.json'),JSON.stringify(legacyState));
const env={...process.env,NODE_ENV:'production',HOST:'127.0.0.1',PORT:String(port),ZERIHLINK_DATA_DIR:data,ZERIHLINK_SESSION_SECRET:'a-production-secret-that-is-long-and-unique-for-this-test',ZERIHLINK_INVITE_CODE:'FRIENDS-ONLY-50',ZERIHLINK_REVIEWER_EMAILS:'reviewer@beta.test',ZERIHLINK_TRUST_PROXY:'true',ZERIHLINK_BETA_LEGAL_APPROVED:'true',ZERIHLINK_ALLOW_SIGNUP:'true'};
const child=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env,stdio:['ignore','pipe','pipe']});let logs='';child.stdout.on('data',x=>logs+=x);child.stderr.on('data',x=>logs+=x);
const base=`http://127.0.0.1:${port}`;
const secondProbe=createServer();await new Promise(r=>secondProbe.listen(0,'127.0.0.1',r));const secondPort=secondProbe.address().port;await new Promise(r=>secondProbe.close(r));

try{
 let ready=false;for(let i=0;i<60;i++){try{const r=await fetch(base+'/api/config');if(r.ok){ready=true;break}}catch{}await delay(100)}assert.ok(ready,logs);
 const duplicate=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env:{...env,PORT:String(secondPort)},stdio:['ignore','pipe','pipe']});let duplicateLogs='';duplicate.stdout.on('data',x=>duplicateLogs+=x);duplicate.stderr.on('data',x=>duplicateLogs+=x);
 const duplicateExit=await new Promise(resolve=>{const timer=setTimeout(()=>{duplicate.kill('SIGTERM');resolve(null)},1500);duplicate.once('exit',code=>{clearTimeout(timer);resolve(code)});});
 assert.equal(duplicateExit,1);assert.ok(duplicateLogs.includes('Another ZERILYS instance'));

 const termsPage=await fetch(base+'/beta-terms.html').then(r=>r.text());assert.ok(termsPage.includes('PROJET DE DOCUMENT — NON VALIDÉ JURIDIQUEMENT'));const privacyPage=await fetch(base+'/privacy-notice.html').then(r=>r.text());assert.ok(privacyPage.includes('PROJET DE DOCUMENT — NON VALIDÉ JURIDIQUEMENT'));
 const config=await fetch(base+'/api/config');const cfg=await config.json();assert.equal(cfg.inviteRequired,false);assert.equal(cfg.personalInvitationsEnabled,true);assert.equal(cfg.betaTermsVersion,'0.1');assert.equal(cfg.privacyNoticeVersion,'0.1');assert.equal(cfg.betaLegalApproved,true);assert.equal(cfg.emailDeliveryConfigured,false);
 const csrfCookie=config.headers.get('set-cookie').split(';')[0];
 const headers={'Content-Type':'application/json','X-CSRF-Token':cfg.csrfToken,'Cookie':csrfCookie};
 const legacyLogin=await fetch(base+'/api/auth/login',{method:'POST',headers,body:JSON.stringify({email:'legacy@beta.test',password:'Legacy-strong-password-2026'})});assert.equal(legacyLogin.status,200);
 const legacyCookie=legacyLogin.headers.get('set-cookie').split(';')[0],legacyHeaders={...headers,Cookie:csrfCookie+'; '+legacyCookie};
 const legacyMe=await fetch(base+'/api/me',{headers:legacyHeaders}).then(r=>r.json());assert.equal(legacyMe.consentRequired,true);
 const gated=await fetch(base+'/api/me/readiness',{headers:legacyHeaders});assert.equal(gated.status,428);
 const gatedPatch=await fetch(base+'/api/me',{method:'PATCH',headers:legacyHeaders,body:JSON.stringify({headline:'Must not change before consent'})});assert.equal(gatedPatch.status,428);
 const legacyExport=await fetch(base+'/api/me/export',{headers:legacyHeaders});assert.equal(legacyExport.status,200);

 const consent=await fetch(base+'/api/me/consent',{method:'POST',headers:legacyHeaders,body:JSON.stringify({betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(consent.status,200);
 const acceptedLegacy=await fetch(base+'/api/me',{headers:legacyHeaders}).then(r=>r.json());assert.equal(acceptedLegacy.consentRequired,false);assert.equal(acceptedLegacy.user.legalConsent.termsVersion,'0.1');

 const openSignup=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Open Signup',email:'open@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});if(openSignup.status!==201) throw new Error('open signup failed '+openSignup.status+' '+await openSignup.text());
 const noConsent=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'No Consent',email:'no-consent@beta.test',password:'long-enough-password-123',inviteCode:'FRIENDS-ONLY-50'})});assert.equal(noConsent.status,400);
 const good=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Open Tester',email:'yes@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});if(good.status!==201) throw new Error('valid shared invite failed '+good.status+' '+await good.text());
 const reviewer=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Beta Reviewer',email:'reviewer@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});if(reviewer.status!==201) throw new Error('reviewer registration failed '+reviewer.status+' '+await reviewer.text());
 const reviewerCookie=reviewer.headers.get('set-cookie').split(';')[0];
 const reviewerHeaders={...headers,Cookie:csrfCookie+'; '+reviewerCookie};
 const testerCookie=good.headers.get('set-cookie').split(';')[0];const testerHeaders={...headers,Cookie:csrfCookie+'; '+testerCookie};
 const fakePdf=Buffer.from("%PDF-1.4\n"+"qualification proof test ".repeat(8));
 const submitQualification=async(title)=>fetch(base+"/api/me/qualifications",{method:"POST",headers:testerHeaders,body:JSON.stringify({title,institution:"Université de test",level:"Bac+5",qualificationType:"degree",documentDataUrl:`data:application/pdf;base64,${fakePdf.toString("base64")}`})});
 const candidateQualification=await submitQualification("Master test");assert.equal(candidateQualification.status,201,await candidateQualification.text());
 const privateQueueDenied=await fetch(base+"/api/review/qualifications",{headers:testerHeaders});assert.equal(privateQueueDenied.status,403);
 const qualificationQueue=await fetch(base+"/api/review/qualifications",{headers:reviewerHeaders}).then(r=>r.json());assert.equal(qualificationQueue.qualifications.length,1);const qualificationId=qualificationQueue.qualifications[0].id;
 const privateDocumentDenied=await fetch(base+`/api/review/qualifications/${qualificationId}/document`,{headers:testerHeaders});assert.equal(privateDocumentDenied.status,403);
 const qualificationDocument=await fetch(base+`/api/review/qualifications/${qualificationId}/document`,{headers:reviewerHeaders});assert.equal(qualificationDocument.status,200);assert.equal(qualificationDocument.headers.get("content-type"),"application/pdf");
 const qualificationDecision=await fetch(base+`/api/review/qualifications/${qualificationId}`,{method:"PATCH",headers:reviewerHeaders,body:JSON.stringify({status:"verified",note:"Document contrôlé manuellement et cohérent avec le parcours déclaré."})});assert.equal(qualificationDecision.status,200);
 const qualificationProfile=await fetch(base+"/api/me",{headers:testerHeaders}).then(r=>r.json());assert.equal(qualificationProfile.user.qualificationBadge,true);assert.equal(qualificationProfile.user.qualificationVerifications,undefined);
 const deletedDocument=await fetch(base+`/api/review/qualifications/${qualificationId}/document`,{headers:reviewerHeaders});assert.equal(deletedDocument.status,404);
 const qualificationHistory=await fetch(base+"/api/me/qualifications",{headers:testerHeaders}).then(r=>r.json());assert.equal(qualificationHistory.qualifications[0].status,"verified");
 const deniedHealth=await fetch(base+'/api/review/health',{headers:testerHeaders});assert.equal(deniedHealth.status,403);
 const reviewerHealth=await fetch(base+'/api/review/health',{headers:reviewerHeaders}).then(r=>r.json());
 assert.equal(reviewerHealth.version,'1.9.0-alpha.20');assert.equal(reviewerHealth.storage.backend,'JSON file');assert.equal(reviewerHealth.integrity.ok,true);assert.equal(reviewerHealth.backup.available,false);
 const backupRun=spawnSync(process.execPath,['scripts/backup.mjs'],{cwd:path.resolve('.'),encoding:'utf8',env:{...env}});
 assert.equal(backupRun.status,0,backupRun.stderr);
 const backedHealth=await fetch(base+'/api/review/health',{headers:reviewerHeaders}).then(r=>r.json());
 assert.equal(backedHealth.backup.available,true);assert.equal(backedHealth.backup.verified,true);assert.equal(backedHealth.backup.offsite,false);

 const inviteResponse=await fetch(base+'/api/review/invitations',{method:'POST',headers:reviewerHeaders,body:JSON.stringify({email:'personal@beta.test',accountType:'candidate',validDays:14})});
 if(inviteResponse.status!==201) throw new Error('personal invite creation failed '+inviteResponse.status+' '+await inviteResponse.text());
 const invitation=await inviteResponse.json();assert.ok(invitation.invitationToken);
 const wrongEmail=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Wrong Recipient',email:'wrong@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true,betaInvitationToken:invitation.invitationToken})});assert.equal(wrongEmail.status,403);
 const personalAccept=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Personal Invitee',email:'personal@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true,betaInvitationToken:invitation.invitationToken})});
 if(personalAccept.status!==201) throw new Error('personal invitation failed '+personalAccept.status+' '+await personalAccept.text());
 const replay=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Replay',email:'replay@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true,betaInvitationToken:invitation.invitationToken})});assert.equal(replay.status,403);
 const revokedInvite=await fetch(base+'/api/review/invitations',{method:'POST',headers:reviewerHeaders,body:JSON.stringify({email:'revoked@beta.test',accountType:'candidate'})});
 const revoked=await revokedInvite.json();assert.equal(revokedInvite.status,201);
 const revokeResponse=await fetch(base+`/api/review/invitations/${revoked.invitation.id}`,{method:'DELETE',headers:reviewerHeaders});assert.equal(revokeResponse.status,200);
 const revokedUse=await fetch(base+'/api/auth/register',{method:'POST',headers,body:JSON.stringify({name:'Revoked',email:'revoked@beta.test',password:'long-enough-password-123',betaTermsAccepted:true,privacyNoticeAcknowledged:true,betaInvitationToken:revoked.invitationToken})});assert.equal(revokedUse.status,403);
 const pending=await fetch(base+'/api/review/invitations',{headers:reviewerHeaders}).then(r=>r.json());assert.equal(pending.invitations.length,0);
 const loginHeaders={...headers,'X-Forwarded-For':'192.0.2.1, 198.51.100.23'};
 for(let n=0;n<8;n++){const attempt=await fetch(base+'/api/auth/login',{method:'POST',headers:loginHeaders,body:JSON.stringify({email:'missing@beta.test',password:'wrong-password-123'})});assert.equal(attempt.status,401);}
 const spoofedSameClient=await fetch(base+'/api/auth/login',{method:'POST',headers:{...headers,'X-Forwarded-For':'203.0.113.77, 198.51.100.23'},body:JSON.stringify({email:'missing@beta.test',password:'wrong-password-123'})});assert.equal(spoofedSameClient.status,429);
 const separateClient=await fetch(base+'/api/auth/login',{method:'POST',headers:{...headers,'X-Forwarded-For':'198.51.100.24'},body:JSON.stringify({email:'missing@beta.test',password:'wrong-password-123'})});assert.equal(separateClient.status,401);
 const legalProbe=createServer();await new Promise(r=>legalProbe.listen(0,'127.0.0.1',r));const legalPort=legalProbe.address().port;await new Promise(r=>legalProbe.close(r));
 const legalData=await mkdtemp(path.join(tmpdir(),'zerihlink-legal-lock-'));
 await writeFile(path.join(legalData,'zerihlink.json'),JSON.stringify(legacyState));
 const closedServer=spawn(process.execPath,['src/server.js'],{cwd:path.resolve('.'),env:{...env,PORT:String(legalPort),ZERIHLINK_DATA_DIR:legalData,ZERIHLINK_BETA_LEGAL_APPROVED:'false'},stdio:['ignore','pipe','pipe']});
 try{
  const legalBase=`http://127.0.0.1:${legalPort}`;let legalReady=false,legalConfig,legalCookie;
  for(let i=0;i<60;i++){try{const r=await fetch(legalBase+'/api/config');if(r.ok){legalConfig=await r.json();legalCookie=r.headers.get('set-cookie').split(';')[0];legalReady=true;break}}catch{}await delay(100)}
  assert.ok(legalReady);assert.equal(legalConfig.betaLegalApproved,false);
  const legalLogin=await fetch(legalBase+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':legalConfig.csrfToken,Cookie:legalCookie},body:JSON.stringify({email:'legacy@beta.test',password:'Legacy-strong-password-2026'})});assert.equal(legalLogin.status,200);
  const legalSession=legalLogin.headers.get('set-cookie').split(';')[0],legalAuthHeaders={'Content-Type':'application/json','X-CSRF-Token':legalConfig.csrfToken,Cookie:legalCookie+'; '+legalSession};
  const consentPaused=await fetch(legalBase+'/api/me/consent',{method:'POST',headers:legalAuthHeaders,body:JSON.stringify({betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(consentPaused.status,503);

  const disabled=await fetch(legalBase+'/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':legalConfig.csrfToken,Cookie:legalCookie},body:JSON.stringify({name:'Blocked',email:'blocked@beta.test',password:'long-enough-password-123',inviteCode:'FRIENDS-ONLY-50',betaTermsAccepted:true,privacyNoticeAcknowledged:true})});
  assert.equal(disabled.status,503);
 }finally{closedServer.kill('SIGTERM');await new Promise(resolve=>{if(closedServer.exitCode!==null)resolve();else closedServer.once('exit',resolve)});await rm(legalData,{recursive:true,force:true});}
 const h=await fetch(base+'/api/health');assert.equal((await h.json()).version,'1.9.0-alpha.20');assert.equal(h.headers.get('x-frame-options'),'DENY');assert.ok(h.headers.get('content-security-policy'));
 console.log('ZERILYS beta smoke: PASS — production configuration, legacy consent gating and explicit registration consent, server-side legal launch lock, single-instance storage lock, reviewer-only operations diagnostics, diploma/equivalence document submission, reviewer authorization, badge issuance, document deletion after review, checksummed backup status, proxy-aware per-client rate limiting, open registration without invitation, optional personal invitations, email binding, replay protection, revocation, secure headers and health version.');
}finally{child.kill('SIGTERM');await new Promise(r=>child.once('exit',r));await rm(data,{recursive:true,force:true});}
