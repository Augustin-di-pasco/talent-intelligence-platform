import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const dataDir=path.resolve(process.env.ZERIHLINK_DATA_DIR||"./data");
const source=path.join(dataDir,"zerihlink.json");
if(!fs.existsSync(source)){console.error("No ZERILYS JSON store found.");process.exit(1);}
const sourceBytes=fs.readFileSync(source),state=JSON.parse(sourceBytes.toString("utf8"));
const sourceHash=crypto.createHash("sha256").update(sourceBytes).digest("hex");
const arr=k=>Array.isArray(state[k])?state[k]:[];
const q=v=>v===null||v===undefined?"NULL":"'"+String(v).replace(/\u0000/g,"").replace(/'/g,"''")+"'";
function cleanJson(v){
  if(typeof v==="string")return v.replace(/\u0000/g,"");
  if(Array.isArray(v))return v.map(cleanJson);
  if(v&&typeof v==="object")return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,cleanJson(x)]));
  return v;
}
const jb=v=>q(JSON.stringify(cleanJson(v??{})))+"::jsonb";
const ts=v=>v===null||v===undefined||v===""?"NULL":q(typeof v==="number"?new Date(v).toISOString():v)+"::timestamptz";
const tn=v=>ts(v??new Date().toISOString());
const num=v=>Number.isFinite(Number(v))?String(Math.trunc(Number(v))):"0";
const uid=v=>v?q(v):"NULL";
const users=arr("users"),userIds=new Set(users.map(u=>u.id));
const offers=arr("offers"),offerById=new Map(offers.map(o=>[o.id,o]));
const apps=arr("offerApplications");
const rows={};
function add(table,columns,items,mapper){
  const statements=[];
  for(const item of items){const values=mapper(item);statements.push(`INSERT INTO ${table} (${columns.join(", ")}) VALUES (${values.join(", ")}) ON CONFLICT DO NOTHING;`);}
  rows[table]=items.length;return statements.join("\n");
}
const statements=[];
statements.push(add("users",["id","email","account_type","password_hash","password_salt","profile","visibility","legal_consent","company_verification","created_at","updated_at"],users,u=>{
  const {email,passwordHash,passwordSalt,skills,legalConsent,companyVerification,...profile}=u;
  return [uid(u.id),q(email),q(u.accountType||"candidate"),q(passwordHash),q(passwordSalt),jb(profile),q(u.visibility||"public"),ts(u.createdAt),ts(u.updatedAt)];
}));
statements.push(add("sessions",["id","user_id","token_hash","expires_at","created_at"],arr("sessions").filter(x=>userIds.has(x.userId)),x=>[uid(x.id),uid(x.userId),q(x.tokenHash),ts(x.expiresAt),tn(x.createdAt)]));
const skillRows=users.flatMap(u=>(u.skills||[]).map(s=>({...s,userId:u.id})));
statements.push(add("skills",["id","user_id","name","level","details","created_at"],skillRows,s=>{
  const {id,userId,name,level,addedAt,createdAt,...details}=s;
  return [uid(id),uid(userId),q(name),q(level||null),jb(details),tn(addedAt||createdAt)];
}));
statements.push(add("evidence",["id","user_id","skill_id","payload","status","created_at"],arr("evidence").filter(e=>userIds.has(e.userId)),e=>{
  const {id,userId,skillId,status,createdAt,...payload}=e;
  return [uid(id),uid(userId),uid(skillId),jb(payload),q(status||"self_attested"),ts(createdAt)];
}));
statements.push(add("projects",["id","owner_id","title","description","skills","commitment","status","created_at","closed_at"],arr("projects").filter(p=>userIds.has(p.ownerId)),p=>[
  uid(p.id),uid(p.ownerId),q(p.title),q(p.description),jb(p.skills||[]),q(p.commitment||"part_time"),q(p.status||"open"),tn(p.createdAt),ts(p.closedAt)
]));
statements.push(add("project_applications",["id","project_id","user_id","message","status","created_at","reviewed_at"],arr("applications").filter(a=>userIds.has(a.userId)&&arr("projects").some(p=>p.id===a.projectId)),a=>[
  uid(a.id),uid(a.projectId),uid(a.userId),q(a.message||""),q(a.status||"pending"),tn(a.createdAt),ts(a.reviewedAt)
]));
statements.push(add("offers",["id","company_id","status","offer_type","title","description","payload","created_at","updated_at"],offers.filter(o=>userIds.has(o.companyId)),o=>{
  const {id,companyId,status,type,title,description,createdAt,updatedAt,...payload}=o;
  return [uid(id),uid(companyId),q(status||"published"),q(type||"job"),q(title),q(description),jb(payload),ts(createdAt),ts(updatedAt)];
}));
statements.push(add("offer_applications",["id","offer_id","candidate_id","status","consent_at","created_at","updated_at","withdrawn_at"],apps.filter(a=>userIds.has(a.candidateId)&&offerById.has(a.offerId)),a=>[
  uid(a.id),uid(a.offerId),uid(a.candidateId),q(a.status),tn(a.consentAt),tn(a.createdAt),ts(a.updatedAt),ts(a.withdrawnAt)
]));
const applicationEvents=[];
for(const a of apps.filter(x=>offerById.has(x.offerId)&&userIds.has(x.candidateId))){
  const offer=offerById.get(a.offerId);
  (a.statusHistory||[]).forEach((ev,i)=>{
    const actor=ev.actorType==="candidate"?a.candidateId:ev.actorType==="company"?offer.companyId:null;
    const seed=crypto.createHash("sha256").update(`${a.id}:${i}:${ev.status}:${ev.at}`).digest("hex");
    const eventId=`${seed.slice(0,8)}-${seed.slice(8,12)}-5${seed.slice(13,16)}-a${seed.slice(17,20)}-${seed.slice(20,32)}`;
    applicationEvents.push({id:eventId,applicationId:a.id,actorId:actor,eventType:"status.changed",actorType:ev.actorType||"system",payload:{status:ev.status},createdAt:ev.at});
  });
}
statements.push(add("application_events",["id","application_id","actor_user_id","actor_type","event_type","payload","created_at"],applicationEvents,e=>[
  uid(e.id),uid(e.applicationId),uid(e.actorId),q(["candidate","company","system"].includes(e.actorType)?e.actorType:"system"),q(e.eventType),jb(e.payload),tn(e.createdAt)
]));
const notes=apps.flatMap(a=>(a.privateNotes||[]).filter(n=>userIds.has(n.authorId)).map(n=>({...n,applicationId:a.id,companyUserId:n.authorId})));
statements.push(add("application_private_notes",["id","application_id","company_user_id","note","created_at"],notes,n=>[uid(n.id),uid(n.applicationId),uid(n.companyUserId),q(n.note),tn(n.createdAt)]));
// Outstanding password-reset tokens are intentionally not migrated.
statements.push(add("password_reset_tokens",["id","user_id","token_hash","created_at","expires_at"],[],x=>[]));
statements.push(add("notifications",["id","recipient_id","notification_type","payload","read_at","created_at"],arr("notifications").filter(n=>userIds.has(n.recipientId)),n=>{
  const {id,recipientId,type,readAt,createdAt,...payload}=n;
  return [uid(id),uid(recipientId),q(type||"general"),jb(payload),ts(readAt),ts(createdAt)];
}));
statements.push(add("blocks",["blocker_id","blocked_id","created_at"],arr("blocks").filter(b=>userIds.has(b.blockerId)&&userIds.has(b.blockedId)),b=>[uid(b.blockerId),uid(b.blockedId),tn(b.createdAt)]));
statements.push(add("reports",["id","reporter_id","target_user_id","payload","status","created_at"],arr("reports").filter(r=>userIds.has(r.reporterId)&&userIds.has(r.targetUserId)),r=>{
  const {id,reporterId,targetUserId,status,createdAt,...payload}=r;
  return [uid(id),uid(reporterId),uid(targetUserId),jb(payload),q(status||"open"),ts(createdAt)];
}));
statements.push(add("connections",["id","from_user_id","to_user_id","reason","status","created_at","responded_at"],arr("connections").filter(c=>userIds.has(c.fromUserId)&&userIds.has(c.toUserId)),c=>[
  uid(c.id),uid(c.fromUserId),uid(c.toUserId),q(c.reason),q(c.status),tn(c.createdAt),ts(c.respondedAt)
]));
statements.push(add("company_members",["id","company_id","user_id","role","status","invited_by","created_at"],arr("companyMembers").filter(m=>userIds.has(m.companyId)&&userIds.has(m.userId)),m=>[
  uid(m.id),uid(m.companyId),uid(m.userId),q(m.role),q(m.status),uid(userIds.has(m.invitedBy)?m.invitedBy:null),tn(m.createdAt)
]));
statements.push(add("company_invitations",["id","company_id","email","role","token_hash","status","invited_by","expires_at","accepted_by","accepted_at","created_at"],arr("companyInvitations").filter(i=>userIds.has(i.companyId)),i=>[
  uid(i.id),uid(i.companyId),q(i.email),q(i.role),q(i.tokenHash||null),q(i.status),uid(userIds.has(i.invitedBy)?i.invitedBy:null),tn(i.expiresAt),uid(userIds.has(i.acceptedBy)?i.acceptedBy:null),ts(i.acceptedAt),tn(i.createdAt)
]));
statements.push(add("beta_invitations",["id","email","account_type","token_hash","status","created_by","accepted_by","created_at","expires_at","accepted_at"],arr("betaInvitations"),i=>[
  uid(i.id),q(i.email),q(i.accountType),q(i.tokenHash||null),q(i.status),uid(userIds.has(i.createdBy)?i.createdBy:null),uid(userIds.has(i.acceptedBy)?i.acceptedBy:null),tn(i.createdAt),tn(i.expiresAt),ts(i.acceptedAt)
]));
statements.push(add("beta_feedback",["id","user_id","category","area","message","status","reviewed_by","review_note","created_at","reviewed_at"],arr("betaFeedback").filter(f=>!f.userId||userIds.has(f.userId)),f=>[
  uid(f.id),uid(userIds.has(f.userId)?f.userId:null),q(f.category),q(f.area||""),q(f.message),q(f.status),uid(userIds.has(f.reviewedBy)?f.reviewedBy:null),q(f.reviewNote||null),tn(f.createdAt),ts(f.reviewedAt)
]));
statements.push(add("audit_events",["id","actor_id","action","target_type","target_id","metadata","previous_hash","event_hash","created_at"],arr("audit"),a=>[
  uid(a.id),uid(userIds.has(a.actorId)?a.actorId:null),q(a.action),q(a.targetType),q(a.targetId),jb(a.metadata),q(a.previous||null),q(a.hash),tn(a.at)
]));
const counts=Object.entries(rows).map(([entity,count])=>({entity,count}));
const logRows=counts.map(x=>`INSERT INTO migration_import_log (source_sha256,entity_name,imported_rows) VALUES (${q(sourceHash)},${q(x.entity)},${num(x.count)}) ON CONFLICT DO NOTHING;`);
const stamp=new Date().toISOString().replace(/[:.]/g,"-");
const output=path.resolve(process.env.ZERIHLINK_POSTGRES_EXPORT_FILE||path.join(dataDir,`postgres-export-${stamp}.sql`));
const sql=`-- ZERILYS PostgreSQL data export\n-- Outstanding password reset tokens are intentionally invalidated during migration.\n-- Source SHA-256: ${sourceHash}\n-- Generated: ${new Date().toISOString()}\n-- Review schema.postgresql.sql and import into a disposable database first.\nBEGIN;\n${statements.filter(Boolean).join("\n")}\n${logRows.join("\n")}\nCOMMIT;\n`;
fs.mkdirSync(path.dirname(output),{recursive:true});
fs.writeFileSync(output,sql,{mode:0o600});
console.log(`PostgreSQL export created: ${output}`);
console.log(`Source SHA-256: ${sourceHash}`);
console.log(`Rows: ${counts.map(x=>`${x.entity}=${x.count}`).join(", ")}`);
