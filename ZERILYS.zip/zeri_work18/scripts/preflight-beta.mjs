import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { inspectStore } from "../src/data-integrity.js";
import { emailDeliveryConfig } from "../src/email-delivery.js";
const root=process.cwd(),version=JSON.parse(fs.readFileSync(path.join(root,"package.json"),"utf8")).version;
const checks=[],blockers=[],warnings=[];
const add=(name,ok,detail,{severity="blocker"}={})=>{const item={name,status:ok?"pass":severity==="warning"?"warning":"blocked",detail};checks.push(item);if(!ok&&severity==="blocker")blockers.push(item);if(!ok&&severity==="warning")warnings.push(item);};
const validEmail=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const secret=process.env.ZERIHLINK_SESSION_SECRET||"";
add("production_mode",process.env.NODE_ENV==="production","NODE_ENV must be production.");
const secretEntropyBits=(()=>{if(!secret)return 0;const counts=new Map();for(const char of secret)counts.set(char,(counts.get(char)||0)+1);let entropy=0;for(const count of counts.values()){const probability=count/secret.length;entropy-=probability*Math.log2(probability);}return entropy;})();
add("session_secret",secret.length>=32&&secretEntropyBits>=3.5&&!/change.?me|default|example/i.test(secret),"Session secret must be at least 32 characters with sufficient character diversity; the value is never printed.");
const reviewers=(process.env.ZERIHLINK_REVIEWER_EMAILS||"").split(",").map(x=>x.trim().toLowerCase()).filter(Boolean);
add("reviewer_access",reviewers.length>0&&reviewers.every(validEmail),"At least one valid reviewer email must be configured.");
const signupEnabled=(process.env.ZERIHLINK_ALLOW_SIGNUP??process.env.NEXUS_ALLOW_SIGNUP)==="true";
const legalApprovalEnabled=process.env.ZERIHLINK_BETA_LEGAL_APPROVED==="true";
add("open_registration",!signupEnabled||legalApprovalEnabled,signupEnabled?"Self-service registration is enabled only alongside explicit legal approval.":"Self-service registration is disabled by default; safe while launch validations are pending.");
add("trusted_proxy",process.env.ZERIHLINK_TRUST_PROXY==="true","Trusted proxy mode must be enabled only when deployed behind the configured trusted reverse proxy.");
const configuredDataDir=process.env.ZERIHLINK_DATA_DIR||"";
const dataDir=path.resolve(configuredDataDir||"./data");
let dataWritable=false;try{fs.mkdirSync(dataDir,{recursive:true});fs.accessSync(dataDir,fs.constants.W_OK);dataWritable=true}catch{}
const expectedRenderDataDir=path.resolve("/opt/render/project/src/data"),persistentDataAck=process.env.ZERIHLINK_PERSISTENT_DATA_ACK==="true";
add("persistent_data_directory",!!configuredDataDir&&dataWritable&&(dataDir===expectedRenderDataDir||persistentDataAck),`Configured data directory: ${configuredDataDir||"(unset)"}. Render must use ${expectedRenderDataDir}; another host must set ZERIHLINK_PERSISTENT_DATA_ACK=true only after confirming a persistent volume.`);
const avatarDir=path.join(dataDir,"avatars");let avatarDirWritable=false;try{fs.mkdirSync(avatarDir,{recursive:true,mode:0o700});fs.accessSync(avatarDir,fs.constants.W_OK);avatarDirWritable=true}catch{}
add("avatar_media_directory",dataWritable&&avatarDirWritable,"The persistent data volume must retain a writable avatars/ directory alongside zerihlink.json.");
const yaml=fs.readFileSync(path.join(root,"render.yaml"),"utf8");
add("render_persistent_disk",yaml.includes("mountPath: /opt/render/project/src/data")&&yaml.includes("healthCheckPath: /api/health"),"Render blueprint must include a persistent disk and health check.");
add("render_trusted_proxy",yaml.includes("key: ZERIHLINK_TRUST_PROXY")&&yaml.includes('value: "true"'),"Render blueprint must enable trusted-proxy mode.");
add("render_legal_switch",yaml.includes("key: ZERIHLINK_BETA_LEGAL_APPROVED"),"Render blueprint must expose the legal approval switch, defaulting to false.");
const server=fs.readFileSync(path.join(root,"src/server.js"),"utf8");
const serverVersion=server.match(/const VERSION = "([^"]+)"/)?.[1]||"";
const fileVersion=fs.readFileSync(path.join(root,"VERSION"),"utf8").trim();
add("version_consistency",version===fileVersion&&version===serverVersion,`package=${version}, VERSION=${fileVersion}, server=${serverVersion}`);
const dataFile=path.join(dataDir,"zerihlink.json");
let integrity=null,liveUsers=[];
if(fs.existsSync(dataFile)){
  try{const snapshot=JSON.parse(fs.readFileSync(dataFile,"utf8"));liveUsers=Array.isArray(snapshot.users)?snapshot.users:[];integrity=inspectStore(snapshot);add("data_integrity",integrity.ok,`${integrity.errors.length} error(s), ${integrity.warnings.length} warning(s).`);}
  catch(e){add("data_integrity",false,`Cannot parse or inspect store: ${e.message}`);}
}else add("data_integrity",true,"Fresh installation: no live store file exists yet.",{severity:"warning"});
const missingAvatarRefs=liveUsers.filter(user=>user.avatarFile&&(!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(user.avatarFile)||!fs.existsSync(path.join(avatarDir,user.avatarFile)))).length;
const invalidLegacyAvatars=liveUsers.filter(user=>user.avatarDataUrl&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(user.avatarDataUrl)).length;
add("avatar_media_integrity",missingAvatarRefs===0&&invalidLegacyAvatars===0,`${missingAvatarRefs} missing/unsafe media reference(s), ${invalidLegacyAvatars} invalid legacy embedded photo(s).`);
let backupVerified=false;
try{
 const dir=path.join(dataDir,"backups"),files=fs.readdirSync(dir).filter(n=>n.endsWith(".json")&&!n.endsWith(".manifest.json")&&fs.existsSync(path.join(dir,n+".manifest.json"))).sort().reverse();
 if(files.length){const file=path.join(dir,files[0]),bytes=fs.readFileSync(file),manifest=JSON.parse(fs.readFileSync(file+".manifest.json","utf8")),snapshot=JSON.parse(bytes.toString("utf8")),avatars=Array.isArray(snapshot.users)?snapshot.users.filter(user=>typeof user.avatarDataUrl==="string"):[],embeddedMedia=avatars.length,embeddedBytes=avatars.reduce((sum,user)=>{const match=user.avatarDataUrl.match(/^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);return sum+(match?Buffer.from(match[1],"base64").length:Infinity);},0),mediaCountValid=manifest.mediaCount===undefined||embeddedMedia===manifest.mediaCount,mediaBytesValid=manifest.mediaBytes===undefined||embeddedBytes===manifest.mediaBytes;backupVerified=crypto.createHash("sha256").update(bytes).digest("hex")===manifest.sha256&&bytes.length===manifest.bytes&&mediaCountValid&&mediaBytesValid;}
}catch{}
add("local_backup",backupVerified,"A checksummed local backup must exist, verify and include all profile media recorded in its manifest.");
const publicOrigin=process.env.ZERIHLINK_PUBLIC_URL||"";let publicOriginValid=false;try{const parsed=new URL(publicOrigin);publicOriginValid=parsed.protocol==="https:"&&parsed.pathname==="/"&&!parsed.search&&!parsed.hash;}catch{}
add("public_origin",publicOriginValid,"Set ZERIHLINK_PUBLIC_URL to the canonical HTTPS origin so public profile previews use the correct domain.",{severity:"warning"});
const deploymentUrl=(process.env.ZERIHLINK_DEPLOYMENT_URL||"").replace(/\/$/,"");
let deployed=false,deployDetail="Set ZERIHLINK_DEPLOYMENT_URL to the deployed service base URL.";
if(deploymentUrl){
 try{const response=await fetch(deploymentUrl+"/api/health",{signal:AbortSignal.timeout(5000)});const health=await response.json();deployed=response.ok&&health.ok===true&&health.version===version;deployDetail=`HTTP ${response.status}; reported version ${health.version||"unknown"}.`;}
 catch(e){deployDetail=`Health check failed: ${e.message}`;}
}
add("deployed_health_check",deployed,deployDetail);
add("browser_qa_ack",process.env.ZERIHLINK_BROWSER_QA_ACK==="true","A human must verify desktop/mobile navigation, profile editing, company workflows and reviewer tools.");
add("legal_review_ack",process.env.ZERIHLINK_LEGAL_REVIEW_ACK==="true","Obtain legal/privacy review of terms, privacy notice, retention, brand and beta consent.");
add("beta_legal_approval",process.env.ZERIHLINK_BETA_LEGAL_APPROVED==="true","Registration remains disabled until the approved legal documents are explicitly enabled on the server.");
add("reviewer_coverage_ack",process.env.ZERIHLINK_REVIEWER_COVERAGE_ACK==="true","Confirm named reviewers and a daily moderation/feedback response rota.");
add("offsite_backup_ack",process.env.ZERIHLINK_OFFSITE_BACKUP_ACK==="true","Confirm a manual off-site backup copy and a tested restore procedure.");
const postgresRuntimeEnabled=process.env.ZERIHLINK_STORAGE==="postgres"&&!!process.env.DATABASE_URL;
add("postgres_runtime",postgresRuntimeEnabled,postgresRuntimeEnabled?"PostgreSQL JSONB snapshot persistence is enabled. This is not yet a normalized relational repository; keep one application instance and retain persistent media storage.":"Runtime remains JSON-file based. PostgreSQL snapshot persistence is available but not enabled; do not use this mode for public scale.",{severity:"warning"});
const emailReady=emailDeliveryConfig().configured;
add("transactional_email",emailReady,emailReady?"Transactional email webhook is configured.":"No transactional email webhook is configured; invitations require manual delivery and password reset is unavailable.",{severity:"warning"});
add("market_data_licensing",false,"GLOBAL PULSE must remain without live prices until commercial data redistribution rights are confirmed.",{severity:"warning"});
const report={version,generatedAt:new Date().toISOString(),readyForClosedBeta:blockers.length===0,readyForPublicLaunch:false,blockers,warnings,checks};
const out=process.env.ZERIHLINK_PREFLIGHT_OUTPUT;
if(out){fs.mkdirSync(path.dirname(path.resolve(out)),{recursive:true});fs.writeFileSync(path.resolve(out),JSON.stringify(report,null,2),{mode:0o600});}
console.log(JSON.stringify(report,null,2));
if(blockers.length)process.exit(1);
