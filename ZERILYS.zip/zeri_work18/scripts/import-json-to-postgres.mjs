import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const dataDir = path.resolve(process.env.ZERIHLINK_DATA_DIR || './data');
const source = path.join(dataDir, 'zerihlink.json');
const exportFile = process.env.ZERIHLINK_POSTGRES_EXPORT_FILE
  ? path.resolve(process.env.ZERIHLINK_POSTGRES_EXPORT_FILE)
  : null;
const apply = process.argv.includes('--apply');
const databaseUrl = process.env.DATABASE_URL;

function stop(message) {
  console.error(`Migration interrompue : ${message}`);
  process.exitCode = 1;
}

if (!databaseUrl) {
  stop('DATABASE_URL est absent. Aucune connexion ni modification effectuée.');
} else if (!fs.existsSync(source)) {
  stop(`fichier source introuvable : ${source}`);
} else if (!exportFile || !fs.existsSync(exportFile)) {
  stop('définir ZERIHLINK_POSTGRES_EXPORT_FILE vers un export SQL créé et contrôlé.');
} else if (!process.env.ZERIHLINK_EXPECT_DATABASE) {
  stop('définir ZERIHLINK_EXPECT_DATABASE pour confirmer explicitement le nom de la base cible.');
} else if (!apply) {
  console.log('Précontrôle uniquement. Aucune donnée écrite.');
  console.log(`Source : ${source}`);
  console.log(`Export : ${exportFile}`);
  console.log('Après vérification et sauvegarde de la base cible, relancer avec --apply.');
} else {
  const sourceState = JSON.parse(fs.readFileSync(source, 'utf8'));
  const exportSql = fs.readFileSync(exportFile, 'utf8');
  const schemaSql = fs.readFileSync(path.join(root, 'db/schema.postgresql.sql'), 'utf8');
  if (!exportSql.startsWith('-- ZERILYS PostgreSQL data export')) {
    stop('le fichier SQL ne correspond pas au format d’export attendu.');
  } else if (!schemaSql.includes('CREATE TABLE users') || !schemaSql.includes('CREATE TABLE migration_import_log')) {
    stop('le schéma PostgreSQL attendu est incomplet.');
  } else {
    const { Client } = await import('pg');
    const client = new Client({ connectionString: databaseUrl, ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: true }, connectionTimeoutMillis: 10000 });
    try {
      await client.connect();
      const identity = await client.query('select current_database() as database, current_user as username, version() as version');
      console.log(`Cible PostgreSQL : ${identity.rows[0].database} (${identity.rows[0].username})`);
      if (identity.rows[0].database !== process.env.ZERIHLINK_EXPECT_DATABASE) {
        throw new Error('La base cible ne correspond pas à ZERIHLINK_EXPECT_DATABASE.');
      }
      const existing = await client.query("select to_regclass('public.users') as users_table");
      if (existing.rows[0].users_table) throw new Error('La table users existe déjà. Import refusé : utiliser une base cible vide.');
      await client.query('BEGIN');
      try {
        await client.query(schemaSql);
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(`Application du schéma annulée : ${error.message}`);
      }
      await client.query('BEGIN');
      try {
        const dataSql = exportSql.replace(/^\s*BEGIN;\s*/i, '').replace(/\s*COMMIT;\s*$/i, '');
        await client.query(dataSql);
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw new Error(`Import des données annulé : ${error.message}`);
      }
      const counts = await client.query('select entity_name, imported_rows from migration_import_log order by entity_name');
      const importedUsers = Number(counts.rows.find(row => row.entity_name === 'users')?.imported_rows ?? -1);
      if (importedUsers !== (sourceState.users || []).length) {
        throw new Error(`Contrôle post-import des utilisateurs invalide : ${importedUsers} au lieu de ${(sourceState.users || []).length}.`);
      }
      console.log('Import terminé. Comptages enregistrés :');
      for (const row of counts.rows) console.log(`- ${row.entity_name}: ${row.imported_rows}`);
      console.log('Important : le serveur ZERILYS utilise encore le stockage JSON. Cet import ne bascule pas le runtime sur PostgreSQL.');
    } catch (error) {
      stop(error.message);
    } finally {
      await client.end().catch(() => {});
    }
  }
}
