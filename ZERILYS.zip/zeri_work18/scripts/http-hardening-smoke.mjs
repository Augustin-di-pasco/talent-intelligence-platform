import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';

const root=process.cwd();
const dataDir=await mkdtemp(path.join(os.tmpdir(),'zerihlink-http-'));
const port=await new Promise((resolve,reject)=>{const s=net.createServer();s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});s.on('error',reject);});
const child=spawn(process.execPath,['src/server.js'],{cwd:root,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',NODE_ENV:'test',ZERIHLINK_DATA_DIR:dataDir,ZERIHLINK_SESSION_SECRET:'http-smoke-secret-not-for-production'},stdio:'ignore'});
const base=`http://127.0.0.1:${port}`;
try {
  let ready=false;
  for(let i=0;i<80;i++){
    if(child.exitCode!==null) throw new Error(`Server exited with ${child.exitCode}`);
    try{const r=await fetch(`${base}/api/health`);if(r.ok){ready=true;break;}}catch{}
    await new Promise(r=>setTimeout(r,100));
  }
  assert.equal(ready,true,'server should become healthy');
  const home=await fetch(base+'/');
  assert.equal(home.status,200);
  assert.match(home.headers.get('content-type')||'',/text\/html/);
  const missing=await fetch(base+'/missing-client-asset.js');
  assert.equal(missing.status,404,'missing static resources must not return the application HTML');
  assert.equal(await missing.text(),'Not found');
  const malformed=await fetch(base+'/%E0%A4%A');
  assert.equal(malformed.status,400,'malformed percent-encoding must be rejected without crashing the server');
  const health=await fetch(base+'/api/health');
  assert.equal(health.status,200,'server must remain alive after malformed path input');
  console.log('ZERILYS HTTP hardening smoke: PASS — home route, missing asset 404, malformed URL rejection and server continuity.');
} finally {
  child.kill('SIGTERM');
  await new Promise(resolve=>{if(child.exitCode!==null)return resolve();child.once('exit',resolve);setTimeout(resolve,1000);});
  await rm(dataDir,{recursive:true,force:true});
}
