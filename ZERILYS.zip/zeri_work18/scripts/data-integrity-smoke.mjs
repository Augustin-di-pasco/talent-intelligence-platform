import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import crypto from "node:crypto";
const root=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),"zerihlink-integrity-"));
const user="11111111-1111-4111-8111-111111111111";
const state={users:[{id:user,email:"member@example.test",accountType:"candidate",skills:[]}],sessions:[],projects:[],applications:[],evidence:[],connections:[],reports:[],blocks:[],companies:[],offers:[],offerApplications:[],notifications:[],companyMembers:[],companyInvitations:[],betaInvitations:[],betaFeedback:[],passwordResets:[],audit:[]};
const audit={id:"22222222-2222-4222-8222-222222222222",actorId:user,action:"account.created",targetType:"user",targetId:user,metadata:{},at:"2026-01-01T00:00:00.000Z",previous:"GENESIS"};
audit.hash=crypto.createHash("sha256").update(JSON.stringify(audit)).digest("hex");state.audit.push(audit);
const file=path.join(dir,"zerihlink.json");fs.writeFileSync(file,JSON.stringify(state));
const run=()=>spawnSync(process.execPath,[path.join(root,"scripts","validate-data.mjs")],{cwd:root,encoding:"utf8",env:{...process.env,ZERIHLINK_DATA_DIR:dir}});
try{
 const good=run();assert.equal(good.status,0,good.stderr);assert.equal(JSON.parse(good.stdout).ok,true);
 const bad=structuredClone(state);bad.sessions.push({id:"33333333-3333-4333-8333-333333333333",userId:"44444444-4444-4444-8444-444444444444",tokenHash:"orphan",expiresAt:1893456000000});bad.passwordResets.push({id:"55555555-5555-4555-8555-555555555555",userId:"44444444-4444-4444-8444-444444444444",tokenHash:"a".repeat(64),expiresAt:1893456000000});bad.audit[0].hash="tampered";
 fs.writeFileSync(file,JSON.stringify(bad));const invalid=run();assert.equal(invalid.status,1);const report=JSON.parse(invalid.stdout);
 assert.ok(report.errors.some(e=>e.code==="ORPHAN_SESSION"));assert.ok(report.errors.some(e=>e.code==="AUDIT_HASH_INVALID"));assert.ok(report.errors.some(e=>e.code==="PASSWORD_RESET_USER_INVALID"));
 console.log("ZERILYS data integrity smoke: PASS — clean store accepted; orphan references and audit tampering detected.");
}finally{fs.rmSync(dir,{recursive:true,force:true});}
