import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
const root=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),"zerihlink-backup-smoke-"));
const data=path.join(dir,"zerihlink.json");
const avatarBytes=Buffer.alloc(140);avatarBytes.set([0xff,0xd8,0xff,0xe0],0);
const pdfBytes=Buffer.from("%PDF-1.4\n"+"x".repeat(120));const qualificationFile="22222222-2222-4222-8222-222222222222.pdf";
const initial={users:[{id:"u1",email:"one@example.test",avatarFile:"11111111-1111-4111-8111-111111111111.jpg",qualificationVerifications:[{id:"q1",status:"pending",documentFile:qualificationFile,documentFormat:"pdf"}]}],sessions:[],projects:[],applications:[],evidence:[],connections:[],reports:[],blocks:[],companies:[],offers:[],offerApplications:[],notifications:[],audit:[],companyMembers:[],companyInvitations:[]};
fs.mkdirSync(path.join(dir,"avatars"),{recursive:true});fs.writeFileSync(path.join(dir,"avatars",initial.users[0].avatarFile),avatarBytes);fs.mkdirSync(path.join(dir,"qualification-documents"),{recursive:true});fs.writeFileSync(path.join(dir,"qualification-documents",qualificationFile),pdfBytes);
fs.writeFileSync(data,JSON.stringify(initial));
const run=(script,extra={})=>spawnSync(process.execPath,[path.join(root,"scripts",script)],{cwd:root,encoding:"utf8",env:{...process.env,ZERIHLINK_DATA_DIR:dir,...extra}});
try{
  const b=run("backup.mjs");assert.equal(b.status,0,b.stderr);
  const backupDir=path.join(dir,"backups"),backupName=fs.readdirSync(backupDir).find(n=>n.endsWith(".json")&&!n.endsWith(".manifest.json"));
  assert.ok(backupName);const backup=path.join(backupDir,backupName);
  const backupSnapshot=JSON.parse(fs.readFileSync(backup,"utf8"));assert.match(backupSnapshot.users[0].avatarDataUrl,/^data:image\/jpeg;base64,/);assert.equal(backupSnapshot.users[0].avatarFile,undefined);const backupManifest=JSON.parse(fs.readFileSync(backup+".manifest.json","utf8"));assert.equal(backupManifest.mediaCount,1);assert.equal(backupManifest.mediaBytes,avatarBytes.length);assert.match(backupSnapshot.users[0].qualificationVerifications[0].documentDataUrl,/^data:application\/pdf;base64,/);assert.equal(backupManifest.qualificationDocumentCount,1);
  assert.equal(run("verify-backup.mjs",{ZERIHLINK_BACKUP_FILE:backup}).status,0);
  fs.writeFileSync(data,JSON.stringify({...initial,users:[{id:"u2",email:"changed@example.test"}]}));
  const blocked=run("restore.mjs",{ZERIHLINK_RESTORE_FILE:backup,ZERIHLINK_RESTORE_CONFIRM:"NO"});assert.notEqual(blocked.status,0);
  assert.equal(JSON.parse(fs.readFileSync(data,"utf8")).users[0].id,"u2");
  const restored=run("restore.mjs",{ZERIHLINK_RESTORE_FILE:backup,ZERIHLINK_RESTORE_CONFIRM:"RESTORE"});assert.equal(restored.status,0,restored.stderr);
  const restoredState=JSON.parse(fs.readFileSync(data,"utf8"));assert.equal(restoredState.users[0].id,"u1");assert.ok(restoredState.users[0].avatarDataUrl);
  const {Store}=await import("../src/store.js");const migrated=new Store(dir);assert.ok(migrated.state.users[0].avatarFile);assert.equal(migrated.state.users[0].avatarDataUrl,undefined);assert.ok(fs.existsSync(path.join(dir,"avatars",migrated.state.users[0].avatarFile)));const restoredQualification=migrated.state.users[0].qualificationVerifications[0];assert.ok(restoredQualification.documentFile);assert.ok(fs.existsSync(path.join(dir,"qualification-documents",restoredQualification.documentFile)));
  assert.ok(fs.readdirSync(backupDir).some(n=>n.startsWith("pre-restore-")));
  console.log("ZERILYS backup smoke: PASS — checksum verification, avatar- and qualification-document-inclusive backup, restore confirmation, media migration, pre-restore safety copy and atomic restore.");
}finally{fs.rmSync(dir,{recursive:true,force:true});}
