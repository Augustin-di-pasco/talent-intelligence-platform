import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const dir=path.resolve(process.env.ZERIHLINK_DATA_DIR||"./data");
const source=path.join(dir,"zerihlink.json");
if(!fs.existsSync(source)){console.error("No ZERILYS data file found.");process.exit(1);}
let parsed;
try{parsed=JSON.parse(fs.readFileSync(source,"utf8"));if(!parsed||!Array.isArray(parsed.users)||!Array.isArray(parsed.sessions))throw new Error("Invalid store shape");}
catch(e){console.error("Source data is not valid ZERILYS JSON:",e.message);process.exit(1);}
const backups=path.join(dir,"backups");fs.mkdirSync(backups,{recursive:true,mode:0o700});
const retentionRaw=process.env.ZERIHLINK_BACKUP_RETENTION||"14",retention=Number(retentionRaw);
if(!Number.isSafeInteger(retention)||retention<2||retention>100){console.error("ZERIHLINK_BACKUP_RETENTION must be an integer between 2 and 100.");process.exit(1);}
const stamp=new Date().toISOString().replace(/[:.]/g,"-");
const backup=path.join(backups,`backup-${stamp}-${crypto.randomBytes(3).toString("hex")}.json`);
let mediaCount=0,mediaBytes=0,qualificationDocumentCount=0,qualificationDocumentBytes=0;
for(const user of parsed.users){
  if(user.avatarFile){
    if(!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(user.avatarFile))throw new Error(`Unsafe avatar reference for user ${user.id}`);
    const file=path.join(dir,"avatars",user.avatarFile);
    if(!fs.existsSync(file))throw new Error(`Missing avatar media file: ${user.avatarFile}`);
    const ext=path.extname(file).slice(1),mime=ext==="jpg"?"jpeg":ext;
    const media=fs.readFileSync(file);mediaCount++;mediaBytes+=media.length;
    user.avatarDataUrl=`data:image/${mime};base64,${media.toString("base64")}`;
  } else if(typeof user.avatarDataUrl==="string"){
    const match=user.avatarDataUrl.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
    if(!match)throw new Error(`Invalid embedded avatar for user ${user.id}`);
    mediaCount++;mediaBytes+=Buffer.from(match[2],"base64").length;
  }
  delete user.avatarFile;
  for(const q of user.qualificationVerifications||[]){
    if(!q.documentFile)continue;
    if(!/^[a-f0-9-]{36}\.(pdf|jpg|png)$/.test(q.documentFile))throw new Error(`Unsafe qualification document reference for user ${user.id}`);
    const file=path.join(dir,"qualification-documents",q.documentFile);
    if(!fs.existsSync(file))throw new Error(`Missing qualification document: ${q.documentFile}`);
    const media=fs.readFileSync(file);if(media.length>650000)throw new Error(`Qualification document exceeds allowed size: ${q.documentFile}`);
    qualificationDocumentCount++;qualificationDocumentBytes+=media.length;
    q.documentDataUrl=`data:${q.documentFormat==="pdf"?"application/pdf":q.documentFormat==="jpg"?"image/jpeg":"image/png"};base64,${media.toString("base64")}`;
    delete q.documentFile;
  }
}
const bytes=Buffer.from(JSON.stringify(parsed,null,2)),sha256=crypto.createHash("sha256").update(bytes).digest("hex");
fs.writeFileSync(backup,bytes,{mode:0o600,flag:"wx"});
const manifest={createdAt:new Date().toISOString(),source:"zerihlink.json + avatars + qualification documents",backup:path.basename(backup),bytes:bytes.length,sha256,mediaCount,mediaBytes,qualificationDocumentCount,qualificationDocumentBytes};
fs.writeFileSync(backup+".manifest.json",JSON.stringify(manifest,null,2),{mode:0o600,flag:"wx"});
const candidates=fs.readdirSync(backups).filter(name=>/^backup-.+\.json$/.test(name)&&!name.endsWith(".manifest.json")).sort().reverse();
const complete=candidates.filter(name=>fs.existsSync(path.join(backups,name+".manifest.json"))),keep=new Set(complete.slice(0,retention));let pruned=0;
for(const name of candidates){if(!keep.has(name)){try{fs.unlinkSync(path.join(backups,name));}catch{}try{fs.unlinkSync(path.join(backups,name+".manifest.json"));}catch{}pruned++;}}
for(const name of fs.readdirSync(backups).filter(n=>n.endsWith(".manifest.json"))){const backupName=name.slice(0,-".manifest.json".length);if(!fs.existsSync(path.join(backups,backupName))){try{fs.unlinkSync(path.join(backups,name));pruned++;}catch{}}}
console.log(`Backup created: ${backup}`);
console.log(`SHA-256: ${sha256}`);
console.log(`Backup retention: ${Math.min(complete.length,retention)} kept, ${pruned} pruned.`);
