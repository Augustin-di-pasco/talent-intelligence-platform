import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
const root=process.cwd(),dir=fs.mkdtempSync(path.join(os.tmpdir(),'zerihlink-backup-retention-'));
const data=path.join(dir,'zerihlink.json'),backupDir=path.join(dir,'backups');
fs.mkdirSync(backupDir,{recursive:true});fs.writeFileSync(path.join(backupDir,'backup-orphan.json.manifest.json'),'{}');
fs.writeFileSync(data,JSON.stringify({users:[],sessions:[],projects:[],applications:[],evidence:[],connections:[],reports:[],blocks:[],companies:[],offers:[],offerApplications:[],notifications:[],audit:[],companyMembers:[],companyInvitations:[]}));
function run(script,extra={}){return spawnSync(process.execPath,[path.join(root,'scripts',script)],{cwd:root,encoding:'utf8',env:{...process.env,ZERIHLINK_DATA_DIR:dir,...extra}})}
try{
  for(let i=0;i<3;i++){const r=run('backup.mjs',{ZERIHLINK_BACKUP_RETENTION:'2'});assert.equal(r.status,0,r.stderr);await delay(15);}
  const files=fs.readdirSync(backupDir).filter(n=>n.endsWith('.json')&&!n.endsWith('.manifest.json'));
  assert.equal(files.length,2);assert.ok(files.every(n=>fs.existsSync(path.join(backupDir,n+'.manifest.json'))));assert.equal(fs.existsSync(path.join(backupDir,'backup-orphan.json.manifest.json')),false);
  const latest=files.sort().reverse()[0],verified=run('verify-backup.mjs',{ZERIHLINK_BACKUP_FILE:path.join(backupDir,latest)});assert.equal(verified.status,0,verified.stderr);
  const invalid=run('backup.mjs',{ZERIHLINK_BACKUP_RETENTION:'1'});assert.equal(invalid.status,1);assert.equal(fs.readdirSync(backupDir).filter(n=>n.endsWith('.json')&&!n.endsWith('.manifest.json')).length,2);
  console.log('ZERILYS backup retention smoke: PASS — keeps the configured two newest verified backups, removes older pairs and rejects unsafe retention values.');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
