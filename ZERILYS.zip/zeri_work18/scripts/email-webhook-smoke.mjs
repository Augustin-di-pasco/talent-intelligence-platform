import assert from "node:assert/strict";
import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
const root=process.cwd(),data=await mkdtemp(path.join(os.tmpdir(),"zerihlink-email-"));
const portProbe=createServer();await new Promise(r=>portProbe.listen(0,"127.0.0.1",r));const port=portProbe.address().port;await new Promise(r=>portProbe.close(r));
let failNext=false;const messages=[];
const webhook=createServer(async(req,res)=>{
 let raw="";for await(const chunk of req)raw+=chunk;
 if(req.headers.authorization!=="Bearer test-webhook-secret-0123456789-abcdef") {res.writeHead(401);res.end();return;}
 const body=JSON.parse(raw);messages.push(body);
 if(failNext){failNext=false;res.writeHead(502);res.end(JSON.stringify({error:"mock failure"}));return;}
 res.writeHead(200,{"Content-Type":"application/json"});res.end(JSON.stringify({id:`mock-email-${messages.length}`}));
});
await new Promise(r=>webhook.listen(0,"127.0.0.1",r));const webhookPort=webhook.address().port;
const env={...process.env,NODE_ENV:"development",HOST:"127.0.0.1",PORT:String(port),ZERIHLINK_DATA_DIR:data,ZERIHLINK_SESSION_SECRET:"email-smoke-session-secret-long-enough-32",ZERIHLINK_REVIEWER_EMAILS:"reviewer@email.test",ZERIHLINK_INVITE_CODE:"EMAIL-BETA-ACCESS-50",ZERIHLINK_BETA_LEGAL_APPROVED:"true",ZERIHLINK_ALLOW_SIGNUP:"true",ZERIHLINK_EMAIL_WEBHOOK_URL:`http://127.0.0.1:${webhookPort}/send`,ZERIHLINK_EMAIL_WEBHOOK_SECRET:"test-webhook-secret-0123456789-abcdef",ZERIHLINK_EMAIL_FROM:"beta@zerihlink.test",ZERIHLINK_APP_URL:`http://127.0.0.1:${port}`};
const server=spawn(process.execPath,["src/server.js"],{cwd:root,env,stdio:["ignore","pipe","pipe"]});
let serverLogs="";server.stdout.on("data",x=>serverLogs+=x);server.stderr.on("data",x=>serverLogs+=x);
try{
 const base=`http://127.0.0.1:${port}`;let ready=false;
 for(let i=0;i<80;i++){try{const r=await fetch(base+"/api/health");if(r.ok){ready=true;break}}catch{}await delay(100)}
 assert.ok(ready,"app server failed to start");
 const configResponse=await fetch(base+"/api/config"),cfg=await configResponse.json(),csrfCookie=configResponse.headers.get("set-cookie").split(";")[0];
 assert.equal(cfg.emailDeliveryConfigured,true);assert.equal(cfg.emailVerificationEnabled,true);
 const headers={"Content-Type":"application/json","X-CSRF-Token":cfg.csrfToken,Cookie:csrfCookie};
 const reviewer=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"Email Reviewer",email:"reviewer@email.test",password:"Email-reviewer-password-2026",betaTermsAccepted:true,privacyNoticeAcknowledged:true})});
 assert.equal(reviewer.status,201);const reviewerBody=await reviewer.json();assert.equal(reviewerBody.emailVerification.sent,true);
 const sessionCookie=reviewer.headers.get("set-cookie").split(";")[0],authHeaders={...headers,Cookie:csrfCookie+"; "+sessionCookie};
 assert.equal(messages.length,1);assert.equal(messages[0].to,"reviewer@email.test");assert.equal(messages[0].subject,"Confirmez votre adresse e-mail — ZERILYS");
 const reviewerVerificationToken=messages[0].text.match(/verifyEmail=([A-Za-z0-9_-]+)/)?.[1];assert.ok(reviewerVerificationToken);
 const reviewerConfirm=await fetch(base+"/api/auth/email-verification/confirm",{method:"POST",headers,body:JSON.stringify({token:reviewerVerificationToken})});assert.equal(reviewerConfirm.status,200);
 const reviewerMe=await fetch(base+"/api/me",{headers:authHeaders});assert.equal((await reviewerMe.json()).user.emailVerified,true);
 const invite=await fetch(base+"/api/review/invitations",{method:"POST",headers:authHeaders,body:JSON.stringify({email:"first.tester@email.test",accountType:"candidate",validDays:14})});
 const inviteText=await invite.text();assert.equal(invite.status,201,inviteText+"\n"+serverLogs);const inviteBody=JSON.parse(inviteText);assert.equal(inviteBody.delivery,"email");assert.equal("invitationToken" in inviteBody,false);
 assert.equal(messages.length,2);assert.equal(messages[1].to,"first.tester@email.test");assert.equal(messages[1].from,"beta@zerihlink.test");assert.ok(messages[1].text.includes("one-time invitation token"));
 const inviteToken=messages[1].text.match(/one-time invitation token:\s*([A-Za-z0-9_-]+)/i)?.[1];assert.ok(inviteToken);
 const registration=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"First Tester",email:"first.tester@email.test",password:"First-tester-password-2026",betaInvitationToken:inviteToken,betaTermsAccepted:true,privacyNoticeAcknowledged:true})});
 assert.equal(registration.status,201);const registrationBody=await registration.json();assert.equal(registrationBody.emailVerification.sent,true);
 const inviteeSessionCookie=registration.headers.get("set-cookie").split(";")[0];assert.equal(messages.length,3);assert.equal(messages[2].to,"first.tester@email.test");
 const inviteeVerificationToken=messages[2].text.match(/verifyEmail=([A-Za-z0-9_-]+)/)?.[1];assert.ok(inviteeVerificationToken);
 const inviteeConfirm=await fetch(base+"/api/auth/email-verification/confirm",{method:"POST",headers,body:JSON.stringify({token:inviteeVerificationToken})});assert.equal(inviteeConfirm.status,200);
 const inviteeAuthHeaders={...headers,Cookie:csrfCookie+"; "+inviteeSessionCookie};const alreadyVerified=await fetch(base+"/api/auth/email-verification/request",{method:"POST",headers:inviteeAuthHeaders,body:JSON.stringify({})});assert.equal(alreadyVerified.status,200);assert.equal((await alreadyVerified.json()).alreadyVerified,true);
 const replayVerification=await fetch(base+"/api/auth/email-verification/confirm",{method:"POST",headers,body:JSON.stringify({token:inviteeVerificationToken})});assert.equal(replayVerification.status,400);
 const request=await fetch(base+"/api/auth/password-reset/request",{method:"POST",headers,body:JSON.stringify({email:"first.tester@email.test"})});
 assert.equal(request.status,200);assert.ok((await request.json()).message.includes("If an account exists"));assert.equal(messages.length,4);
 assert.equal(messages[3].subject,"Reset your ZERILYS password");const resetToken=messages[3].text.match(/Password reset token:\s*([A-Za-z0-9_-]+)/i)?.[1];assert.ok(resetToken);
 const reset=await fetch(base+"/api/auth/password-reset/confirm",{method:"POST",headers,body:JSON.stringify({token:resetToken,newPassword:"A-new-strong-password-2026"})});assert.equal(reset.status,200);
 const revokedSession=await fetch(base+"/api/me",{headers:{...headers,Cookie:csrfCookie+"; "+inviteeSessionCookie}});assert.equal(revokedSession.status,401);
 const replay=await fetch(base+"/api/auth/password-reset/confirm",{method:"POST",headers,body:JSON.stringify({token:resetToken,newPassword:"Another-new-password-2026"})});assert.equal(replay.status,400);
 const oldLogin=await fetch(base+"/api/auth/login",{method:"POST",headers,body:JSON.stringify({email:"first.tester@email.test",password:"First-tester-password-2026"})});assert.equal(oldLogin.status,401);
 const newLogin=await fetch(base+"/api/auth/login",{method:"POST",headers,body:JSON.stringify({email:"first.tester@email.test",password:"A-new-strong-password-2026"})});assert.equal(newLogin.status,200);
 const count=messages.length;await fetch(base+"/api/auth/password-reset/request",{method:"POST",headers,body:JSON.stringify({email:"nobody@email.test"})});assert.equal(messages.length,count);
 failNext=true;
 const fallback=await fetch(base+"/api/review/invitations",{method:"POST",headers:authHeaders,body:JSON.stringify({email:"fallback.tester@email.test",accountType:"candidate",validDays:14})});
 assert.equal(fallback.status,201);const fallbackBody=await fallback.json();assert.equal(fallbackBody.delivery,"manual_fallback");assert.ok(fallbackBody.invitationToken);
 const bulk=await fetch(base+"/api/review/invitations/bulk",{method:"POST",headers:authHeaders,body:JSON.stringify({emails:["bulk.one@email.test","bulk.two@email.test"],accountType:"candidate",validDays:14})});assert.equal(bulk.status,201);const bulkBody=await bulk.json();assert.equal(bulkBody.created,2);assert.equal(bulkBody.delivered,2);assert.equal(bulkBody.manual,0);assert.ok(bulkBody.results.every(x=>x.delivery==="email"&&!('invitationToken' in x)));assert.equal(messages.length,7);assert.equal(messages[5].to,"bulk.one@email.test");assert.equal(messages[6].to,"bulk.two@email.test");
 const bulkTokenOne=messages[5].text.match(/one-time invitation token:\s*([A-Za-z0-9_-]+)/i)?.[1],bulkTokenTwo=messages[6].text.match(/one-time invitation token:\s*([A-Za-z0-9_-]+)/i)?.[1];assert.ok(bulkTokenOne&&bulkTokenTwo);
 const wrongEmail=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"Wrong Recipient",email:"bulk.two@email.test",password:"Wrong-recipient-password-2026",betaInvitationToken:bulkTokenOne,betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(wrongEmail.status,403);
 failNext=true;
 const bulkRegistrationOne=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"Bulk Tester One",email:"bulk.one@email.test",password:"Bulk-tester-one-password-2026",betaInvitationToken:bulkTokenOne,betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(bulkRegistrationOne.status,201);const bulkOneBody=await bulkRegistrationOne.json();assert.equal(bulkOneBody.emailVerification.sent,false);
 const bulkOneSession=bulkRegistrationOne.headers.get("set-cookie").split(";")[0],bulkOneHeaders={...headers,Cookie:csrfCookie+"; "+bulkOneSession};
 const resend=await fetch(base+"/api/auth/email-verification/request",{method:"POST",headers:bulkOneHeaders,body:JSON.stringify({})});assert.equal(resend.status,200);assert.equal((await resend.json()).sent,true);const resendMessage=messages.at(-1);assert.equal(resendMessage.to,"bulk.one@email.test");
 const bulkOneVerificationToken=resendMessage.text.match(/verifyEmail=([A-Za-z0-9_-]+)/)?.[1];assert.ok(bulkOneVerificationToken);
 const bulkOneConfirm=await fetch(base+"/api/auth/email-verification/confirm",{method:"POST",headers,body:JSON.stringify({token:bulkOneVerificationToken})});assert.equal(bulkOneConfirm.status,200);
 const replayBulk=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"Bulk Replay",email:"replay@email.test",password:"Bulk-replay-password-2026",betaInvitationToken:bulkTokenOne,betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(replayBulk.status,403);
 const bulkRegistrationTwo=await fetch(base+"/api/auth/register",{method:"POST",headers,body:JSON.stringify({name:"Bulk Tester Two",email:"bulk.two@email.test",password:"Bulk-tester-two-password-2026",betaInvitationToken:bulkTokenTwo,betaTermsAccepted:true,privacyNoticeAcknowledged:true})});assert.equal(bulkRegistrationTwo.status,201);
 console.log("ZERILYS email smoke: PASS — transactional email delivery, single-use email verification links, resend/already-verified behavior, invitation emails, password reset, session revocation, non-enumerating response and manual fallback.");
}finally{
 server.kill("SIGTERM");await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once("exit",resolve)});
 await new Promise(r=>webhook.close(r));await rm(data,{recursive:true,force:true});
}
