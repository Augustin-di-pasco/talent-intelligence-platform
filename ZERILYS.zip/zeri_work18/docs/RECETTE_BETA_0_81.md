# ZERILYS 0.81 — recette opérateur avant les 50 premiers testeurs

Ce document transforme les contrôles techniques existants en séquence d'ouverture vérifiable. Une case ne doit être cochée que sur preuve réelle ; un test automatisé local ne vaut pas validation de production.

## 1. Construire et contrôler l'archive

Depuis la racine du projet :

```bash
npm ci
npm run test:release
npm run launch:check
```

`test:release` doit terminer avec un code de sortie 0. `launch:check` doit afficher `Préparation de la bêta : PRÊTE` avant toute ouverture. En l'état du dépôt, ce dernier contrôle doit échouer tant que les éléments opérateur et juridiques ci-dessous ne sont pas réalisés.

## 2. Préparer l'hébergement sans ouvrir les inscriptions

- Déployer en `NODE_ENV=production` derrière le reverse proxy de confiance réellement configuré.
- Monter le volume persistant sur `ZERIHLINK_DATA_DIR` ; ne pas utiliser le disque éphémère de l'instance.
- Générer un secret unique et aléatoire pour `ZERIHLINK_SESSION_SECRET` (gestionnaire de secrets de l'hébergeur, jamais dans Git ou dans un ticket).
- Définir `ZERIHLINK_REVIEWER_EMAILS` avec les adresses réelles des personnes responsables.
- Renseigner `ZERIHLINK_PUBLIC_URL`, `ZERIHLINK_DEPLOYMENT_URL` et `ZERIHLINK_APP_URL` avec le domaine HTTPS réel.
- Garder `ZERIHLINK_BETA_LEGAL_APPROVED=false`.
- Garder les inscriptions fermées si la configuration de l'hébergement ou la permanence de modération n'est pas prête.

Après déploiement, exécuter `npm run check:remote` depuis un environnement qui peut joindre le domaine. Vérifier également manuellement `/api/health`, la connexion, la déconnexion et la persistance après redémarrage.

## 3. Sauvegardes et restauration

1. Créer une sauvegarde via `npm run backup` sur l'environnement cible.
2. Vérifier le manifeste et les sommes de contrôle via `npm run backup:verify`.
3. Copier l'archive et son manifeste vers un emplacement hors de l'hébergement, avec accès restreint.
4. Effectuer une restauration sur un environnement isolé, jamais directement sur la production pour le test.
5. Vérifier les comptes, les profils, les références de photos et l'intégrité des données après restauration.

Une sauvegarde présente uniquement sur le même volume que l'application n'est pas une sauvegarde hors site.

## 4. Validation humaine obligatoire

Faire exécuter et consigner les scénarios suivants sur au moins un iPhone récent avec Safari et un ordinateur avec Chrome ou Firefox :

- Inscription, consentement, connexion, déconnexion et récupération du compte.
- Complétion du profil puis vérification de la réapparition des données après reconnexion.
- Human Orbit : identité professionnelle, localisation, compétences, réalisations et lisibilité du centre du cercle.
- Navigation dans tous les panneaux : aucun mélange FR/EN visible, y compris les états vides, erreurs, confirmations et fenêtres modales.
- Modification et suppression d'une photo ; vérification de sa persistance.
- Recherche, consultation d'un profil, demande de connexion, réponse et notification.
- Contrôle de visibilité : profil privé non accessible anonymement ; profil public conforme au choix du membre.
- Parcours entreprise et console de modération avec les rôles autorisés.
- Clavier, focus visible, zoom et réduction des animations.

Consigner appareil, navigateur, date, résultat, anomalies et captures expurgées de toute donnée personnelle. Ne pas cocher `ZERIHLINK_BROWSER_QA_ACK` avant la fin de cette recette.

## 5. Validation juridique et données personnelles

Faire examiner par un professionnel compétent les conditions bêta, la notice de confidentialité, l'identité et les coordonnées de l'exploitant, les finalités et bases légales, les durées de conservation, les sous-traitants, les transferts éventuels, les droits des personnes, la suppression et le canal de contact. Vérifier aussi les textes affichés dans l'application et les pratiques réelles de collecte.

Les documents présents dans le dépôt sont des projets et ne constituent pas une validation juridique. Ne pas définir `ZERIHLINK_LEGAL_REVIEW_ACK=true` ni `ZERIHLINK_BETA_LEGAL_APPROVED=true` sur la seule base des tests logiciels.

## 6. Modération et ouverture progressive

- Nommer au moins deux personnes responsables, définir les horaires et un relais en cas d'absence.
- Tester le signalement, la prise en charge, la décision, la traçabilité et la réponse au membre.
- Préparer un canal de support et un message expliquant le caractère expérimental de la bêta.
- Inviter d'abord un petit groupe pilote ; vérifier les retours et les journaux avant d'envoyer les invitations restantes.
- Ne pas collecter de documents confidentiels, données sensibles inutiles ou informations concernant des tiers.

## 7. Décision d'ouverture

L'ouverture aux 50 testeurs est autorisée uniquement lorsque :

- le rapport `launch:check` ne présente aucun blocage ;
- le test distant confirme le bon domaine et la bonne version ;
- la sauvegarde hors site et la restauration sont prouvées ;
- les tests humains ordinateur/mobile sont signés ;
- la validation juridique est obtenue et les documents définitifs publiés ;
- la permanence de modération et le support sont opérationnels.

Le contrôle automatique est une aide à la décision, pas une certification de sécurité, de conformité ou de disponibilité.
