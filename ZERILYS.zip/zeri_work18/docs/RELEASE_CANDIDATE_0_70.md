# ZERILYS 0.70 — release candidate

## Résultat
La version 0.70 poursuit la correction des défauts observés dans la vidéo de test : mélange de langues dans les écrans d’identité, éditeur de profil partiellement anglophone et lisibilité insuffisante de Human Orbit sur les téléphones étroits.

## Modifications
- Couverture française étendue aux panneaux générés dynamiquement, aux libellés, placeholders, aides et actions de l’éditeur.
- Parcours de complétion et états du profil traduits en français naturel.
- Cœur Human Orbit agrandi et non réduit par un facteur global sur mobile ; faits professionnels conservés visibles.
- Focus clavier renforcé sur les cartes d’action et les commandes.
- Version applicative alignée sur 0.70.0.

## Validation automatisée
- 81 tests automatisés : réussis.
- Vérification syntaxique : réussie.
- Smoke applicatif, bêta, cohorte 50, portraits, préférences linguistiques, sauvegardes/restauration, export PostgreSQL, intégrité, pré-vol, e-mails et sécurité HTTP : réussis.

## Limites
Le contrôle de préparation affiche toujours 12 blocages et 4 avertissements. La version n’est pas autorisée à être mise en production avant configuration réelle de l’hébergement, secrets, stockage persistant, sauvegardes externes, e-mails, modération, tests humains et validation juridique.
