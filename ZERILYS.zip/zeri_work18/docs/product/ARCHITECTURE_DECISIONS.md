# Décisions d'architecture — fusion

1. **Socle unique :** conserver l'application Node.js ZERILYS, son API, ses contrôles de sécurité, ses parcours de profil, ses organisations et ses tests.
2. **Pas de fusion runtime avec WORLD INTELLIGENCE V1.92 :** le prototype Python/SQLite reste archivé comme référence. Son schéma et ses flux ne sont pas branchés à l'application principale.
3. **Données de marché des talents :** créer ultérieurement des tables dédiées aux sources, observations, snapshots, compétences canoniques, synonymes, liens entre compétences, dossiers et hypothèses. Les données importées doivent conserver leur provenance.
4. **Recherche :** commencer par une recherche explicable sur données structurées. Ne pas introduire un classement opaque ou un modèle génératif avant d'avoir des jeux de test représentatifs.
5. **Sécurité et séparation des rôles :** candidats, recruteurs, administrateurs et examinateurs ont des droits distincts. Les notes recruteur ne sont jamais exposées au candidat ni aux autres entreprises.
6. **Internationalisation :** français par défaut au lancement, anglais ensuite via les ressources de traduction existantes ; pas de texte français codé en dur dans les nouveaux composants dynamiques.
7. **Scalabilité :** le stockage JSON local existant et le processus unique ne conviennent pas à une exploitation commerciale à grande échelle. La migration vers PostgreSQL et le stockage objet doit précéder la montée en charge.
8. **IA :** l'IA peut aider à normaliser des compétences et à expliquer des correspondances, mais chaque sortie doit être contrôlable, sourcée lorsque nécessaire et non déterminante pour une décision d'embauche.
