# Validation commerciale — plan 30 jours

## Hypothèse à tester
Les cabinets spécialisés, fintechs, banques et équipes de données financières ont une difficulté suffisamment coûteuse à identifier des profils combinant compétences quantitatives, finance et IA pour payer un outil de recherche spécialisé.

## Entretiens à mener
- 8 à 10 recruteurs spécialisés finance / quant / data ;
- 5 responsables de recrutement de fintechs, banques ou sociétés de gestion ;
- 15 à 20 candidats dans les familles de métiers ciblées.

## Questions recruteurs
- Quel poste récent a été le plus difficile à pourvoir ?
- Où avez-vous cherché ? Combien de temps avant une shortlist crédible ?
- Quelles compétences sont les plus difficiles à vérifier ?
- Quelles combinaisons de compétences sont rares ?
- Quel budget dépensez-vous aujourd'hui pour accéder à ces profils ?
- Accepteriez-vous de payer pour une recherche test sur un poste réel ? À quel prix et sous quelles conditions ?

## Test concierge
Avant de construire une grande base de données, proposer à 3 entreprises pilotes une recherche manuelle assistée sur un brief réel, avec candidats ayant consenti à être présentés. Mesurer le temps gagné, la pertinence perçue et la volonté de payer.

## Seuils de décision
- Au moins 3 pilotes actifs avec briefs réels ;
- au moins 2 pilotes prêts à payer ou signer un engagement commercial ;
- 70 % des recherches tests produisent une shortlist jugée exploitable par le recruteur ;
- retours candidats positifs sur la clarté et le contrôle du partage des profils.

Si ces seuils ne sont pas atteints, ajuster la verticale ou le problème avant d'investir dans une couche IA plus coûteuse.
