# Feuille de route — Talent Intelligence

## Phase 0 — Repositionnement Alpha 0.1 (livré dans ce jalon)
- Recentrage de la page d'accueil sur finance, IA et data.
- Navigation principale simplifiée en quatre entrées visibles.
- Présentation honnête du futur module Talent Market Intelligence, sans fausses données.
- Conservation du socle ZERILYS et archivage du prototype WORLD INTELLIGENCE sans sa base de données locale.

## Phase 1 — MVP recrutement spécialisé
- Parcours d'inscription distinct candidat / recruteur / entreprise.
- Onboarding métier : familles de métiers, spécialités, technologies, produits financiers, séniorité, mobilité et disponibilité.
- Recherche structurée avec filtres combinables et explication des correspondances.
- Skill Graph initial, maintenu par un référentiel versionné ; synonymes et relations validés humainement.
- Shortlists privées, notes internes et partage contrôlé.
- Publication d'opportunités avec compétences obligatoires / souhaitées, contexte et fourchette de rémunération facultative.
- Analytics de conversion du funnel de recrutement.

## Phase 2 — Talent Market Memory
- Dossiers de veille sur métiers et compétences.
- Observations datées sur les offres publiques et les demandes des clients pilotes.
- Provenance, date, méthode d'échantillonnage, couverture et limites visibles.
- Historique des évolutions ; séparation explicite des faits, interprétations et hypothèses.
- Alertes seulement après validation de la qualité et du droit de réutilisation des sources.

## Phase 3 — Produit entreprise
- Espaces organisationnels robustes, rôles et permissions.
- Recherche multi-recruteurs, viviers partagés et API documentée.
- Facturation, quotas, gestion des abonnements et support.
- SSO et exigences de sécurité à définir selon les clients.

## Critères de passage entre phases
Aucune phase n'est considérée terminée sur la seule base de tests techniques. Il faut également des tests utilisateurs, une mesure de valeur, une validation sécurité et juridique, et des preuves de demande commerciale.
