# Reverse-proxy-aware rate limiting — 0.22

## Problem addressed
In a reverse-proxy deployment, many users can appear to the Node process as the same socket peer. Keying all rate limits on that peer can cause unrelated testers to share one login/register quota.

## Behavior
- Default: use `req.socket.remoteAddress`; ignore forwarded headers.
- When `ZERIHLINK_TRUST_PROXY=true`: parse `X-Forwarded-For` and use its rightmost syntactically valid IP entry.
- Render blueprint sets this flag because the service is behind the platform reverse proxy.
- Reviewer operations diagnostics disclose only the active mode, never the addresses.

## Security boundary
Only enable trusted-proxy mode behind a proxy that overwrites/appends the real client address in `X-Forwarded-For`. Never enable it when arbitrary clients can connect directly and supply this header themselves. If the hosting proxy chain changes, validate which address position is trustworthy before deployment.

## Limits
Rate-limit buckets are in memory and reset on process restart. The single-instance lock remains required. This is not a distributed rate limiter.
