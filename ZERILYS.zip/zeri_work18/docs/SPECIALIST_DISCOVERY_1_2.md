# Specialist discovery — 1.2.0-alpha.1

## What changed
ZERILYS now has a first curated vocabulary layer for specialist discovery in finance, AI, data and adjacent engineering domains. Searches can match equivalent terms rather than requiring the exact label entered by a member.

Examples include:
- `quant` ↔ quantitative finance / quantitative research
- `credit risk` ↔ risk modelling
- `LLM` ↔ artificial intelligence / generative AI
- `algo trading` ↔ algorithmic trading
- `dbt` / `Spark` ↔ data engineering

## Product and trust boundaries
- Matching is deterministic and based on a maintained synonym dictionary.
- It improves retrieval; it does not assess candidate quality, employability or suitability.
- It does not generate a hidden candidate score.
- Search results remain subject to existing profile visibility and block rules.
- No external labour-market data or AI inference service is connected.

## Next validation
Test with real French specialist vocabulary and recruiter queries. Track zero-result searches, reformulations, relevant profile opens and shortlist creation. Expand the dictionary only from observed demand and reviewed terminology.
