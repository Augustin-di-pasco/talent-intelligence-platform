# ZERILYS — Guide for the first 50 testers

Welcome to the ZERILYS private beta. The goal is to test a new way to discover professional identities: each member has a personal Human Orbit, with their real portrait at the centre and their skills, experience, ambitions and network around them.

## 1. Create your account

1. Open the invitation link or the beta registration page.
2. Use your individual invitation or the private beta code supplied by the team.
3. Complete the consent and privacy notices before using the member network.
4. Use a professional display name. Do not enter confidential information.

## 2. Build your professional identity

1. Open **My profile**.
2. Click the central portrait or **ADD PHOTO** to upload a clear photo of yourself.
3. Add a headline, location, capabilities, experience, interests and what you can offer or are looking for.
4. You can replace or remove your photo at any time.

## 3. Understand profile visibility

- Every signed-in ZERILYS member can discover and consult every other candidate profile.
- **Private** hides your profile from anonymous discovery and public profile links; it does not hide your profile from other signed-in members.
- **Public** additionally enables anonymous discovery and shareable public profile links. Your profile photo is visible on that public profile.
- Blocking another member prevents profile access and interaction between the two accounts.

Choose the setting that matches what you are comfortable sharing. Do not publish personal contact details or sensitive information in profile fields.

## 4. Explore the network

1. Open the **NETWORK** point around your portrait.
2. Search members by name, skill or location.
3. Use **Load more profiles** to continue through the network.
4. Open another member's profile and explore their professional universe.
5. Try a connection request when you see a relevant professional fit.

## 5. Test public sharing

If your profile is set to Public, use **Share public profile** and inspect the preview in a messaging app or social platform. If your profile is Private, the link is member-only and recipients must sign in.

## 6. Send useful feedback

Please report:
- The device and browser (for example, iPhone/Safari or Android/Chrome)
- What you were trying to do
- The exact steps before the issue
- What you expected and what happened
- A screenshot only if it contains no confidential or sensitive information

Use the in-app feedback action for product suggestions and the report action for abusive or inappropriate content. Do not send passwords, invitation codes or private account information in feedback.

## 7. What we especially want tested

- Photo upload, replacement, removal and persistence after signing out/in
- Profile access between members, including Private profiles
- Search by name, skill and location; loading further results
- Public share previews and member-only links
- Connect, block and report actions
- Desktop and mobile navigation, readability and speed

Thank you for helping shape the first ZERILYS cohort.

## Share your professional identity
If your profile is Public, use **Share public profile** to send your ZERILYS identity link. A visitor can see your public profile and join ZERILYS to connect. If your profile is Private, the link is for signed-in members only. A private profile is still visible to every signed-in ZERILYS member.
