# ZERILYS 0.62 — Guide de mise en ligne pour la première bêta française

Ce guide prépare l’ouverture des inscriptions sans invitation pour les premiers utilisateurs. Il ne remplace ni la validation juridique ni les vérifications de l’hébergement.

## 1. Préparer l’hébergement

Le dépôt contient un `render.yaml` prêt à être utilisé comme blueprint Render :
- service Node.js ;
- disque persistant monté sur `/opt/render/project/src/data` ;
- contrôle de santé sur `/api/health` ;
- inscriptions sans invitation ;
- proxy de confiance configuré pour l’environnement Render ;
- verrou juridique désactivé par défaut.

Si un autre hébergeur est utilisé, il doit fournir un volume persistant, conserver ensemble `zerihlink.json` et `avatars/`, et n’exécuter qu’une seule instance avec ce stockage JSON.

## 2. Variables à configurer

Dans le tableau de bord de l’hébergeur, renseigner les variables à partir de `.env.production.example` :
- `NODE_ENV=production` ;
- `ZERIHLINK_SESSION_SECRET` : secret aléatoire unique, 32 caractères minimum ;
- `ZERIHLINK_DATA_DIR` : chemin du volume persistant ;
- `ZERIHLINK_REVIEWER_EMAILS` : adresses des modérateurs ;
- `ZERIHLINK_PUBLIC_URL` et `ZERIHLINK_DEPLOYMENT_URL` : URL HTTPS canonique ;
- `ZERIHLINK_APP_URL` : URL utilisée dans les liens d’e-mails ;
- `ZERIHLINK_TRUST_PROXY=true` uniquement si l’hébergeur est derrière un reverse proxy de confiance qui maîtrise `X-Forwarded-For` ;
- variables du webhook d’e-mail si un fournisseur transactionnel est disponible.

Ne jamais copier un secret réel dans le dépôt ou dans un document partagé.

## 3. Garder le verrou juridique

`ZERIHLINK_BETA_LEGAL_APPROVED=false` doit rester en place tant que les conditions de bêta, la politique de confidentialité, l’identité de l’exploitant, les coordonnées, les durées de conservation, les prestataires et les droits des utilisateurs n’ont pas été vérifiés et approuvés.

Le fait que l’inscription ne nécessite pas d’invitation ne signifie pas que le verrou juridique peut être désactivé sans validation.

## 4. Contrôle avant ouverture

Exécuter localement avec les variables d’environnement de l’hébergement :

```bash
npm run launch:check
```

Le rapport en français distingue les points bloquants des avertissements. Il ne révèle aucune valeur de secret.

Après déploiement, renseigner `ZERIHLINK_DEPLOYMENT_URL` et exécuter :

```bash
npm run check:remote
```

Puis réaliser les contrôles humains sur ordinateur, iOS Safari et Android Chrome : création de compte, photo, Human Orbit, consultation des profils, réseau, candidatures, notifications, espace entreprise et modération.

## 5. Sauvegardes et modération

Avant d’ouvrir les inscriptions :
- créer une sauvegarde locale vérifiée ;
- copier cette sauvegarde hors de l’hébergement ;
- tester la restauration sur une copie ;
- nommer les personnes chargées des signalements et retours ;
- définir un délai de réponse quotidien ;
- documenter la procédure en cas d’incident.

## 6. Ouverture de la bêta

Une fois les validations juridiques et opérationnelles réalisées, le responsable habilité pourra activer `ZERIHLINK_BETA_LEGAL_APPROVED=true` dans l’environnement de production, redéployer et vérifier que `/api/config` annonce les inscriptions ouvertes sans invitation.

Les 50 premiers testeurs peuvent alors rejoindre librement la plateforme. Les invitations individuelles restent facultatives pour des groupes de recherche ciblés.

## Limite de la version

Le stockage d’exécution reste actuellement un fichier JSON sur une instance unique. Cette architecture peut convenir à une bêta limitée avec volume persistant et sauvegardes contrôlées, mais elle doit être remplacée par un stockage transactionnel avant une croissance publique importante.
