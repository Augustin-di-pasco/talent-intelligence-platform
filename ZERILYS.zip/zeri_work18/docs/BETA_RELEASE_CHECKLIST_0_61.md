# ZERILYS 0.61 — Checklist avant ouverture

- [x] Inscription sans invitation obligatoire.
- [x] Cohorte de 50 comptes inscrits sans invitation.
- [x] Limitation des tentatives d’inscription : 20 inscriptions par adresse cliente et par minute, puis HTTP 429.
- [x] Confirmation d’e-mail à usage unique si l’envoi est configuré.
- [ ] Configurer et vérifier le proxy de confiance (`ZERIHLINK_TRUST_PROXY=true` uniquement si les en-têtes sont maîtrisés).
- [ ] Configurer le service d’e-mails transactionnels.
- [ ] Faire valider les documents juridiques français et lever le verrou seulement après validation (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
- [ ] Déployer et exécuter `npm run check:remote`.
- [ ] Réaliser les tests humains sur ordinateur et mobile.
