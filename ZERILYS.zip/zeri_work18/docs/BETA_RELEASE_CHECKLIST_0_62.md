# ZERILYS 0.62 — Préparation de la mise en ligne

- [x] Inscription sans invitation obligatoire au niveau produit.
- [x] Cohorte de 50 comptes testée en inscription ouverte.
- [x] Contrôle de préproduction disponible en français : `npm run launch:check`.
- [x] Guide de déploiement français disponible dans `docs/MISE_EN_LIGNE_FR_0_62.md`.
- [ ] Définir l’hébergement réel et son URL, puis exécuter `npm run check:remote`.
- [ ] Configurer les secrets, les modérateurs, le volume persistant et le proxy de confiance.
- [ ] Configurer l’envoi d’e-mails transactionnels.
- [ ] Faire valider les documents juridiques et renseigner l’exploitant.
- [ ] Effectuer les tests humains sur ordinateur et mobile.
- [ ] Créer une sauvegarde hors site et tester sa restauration.
- [ ] Activer le verrou juridique uniquement après validation réelle (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
