# Project Labs — évolution alpha.18

## Modèle de projet structuré
Les projets peuvent être catégorisés comme projet collectif, pédagogique, de recherche ou défi d'entreprise. Les fiches exposent la durée indicative, l'engagement, la taille maximale de l'équipe, les compétences recherchées, les livrables et les modalités de compensation.

## Protection contre le travail commercial gratuit
Un projet de type `company_challenge` ne peut pas être publié sans compensation explicite (`paid` ou `expenses`). Les projets pédagogiques et d'apprentissage peuvent rester non rémunérés lorsqu'ils sont réellement formatifs et ne constituent pas une prestation productive pour une entreprise.

## Constitution d'équipe
Le créateur occupe une place dans l'effectif maximal. Le serveur refuse une acceptation qui dépasserait la capacité déclarée. La vérification est faite au moment de l'acceptation, et non uniquement à l'affichage de la candidature.

## Limites
Ce jalon structure les annonces et la capacité des équipes. Il ne constitue pas encore un espace de travail complet : tâches, documents partagés, jalons, suivi des contributions et arbitrage restent à construire. Les règles de rémunération, propriété intellectuelle, confidentialité et responsabilité doivent être encadrées juridiquement avant tout défi d'entreprise réel.

Les défis d'entreprise sont réservés aux comptes entreprise. Les membres candidats peuvent publier des projets collectifs, pédagogiques ou de recherche.
