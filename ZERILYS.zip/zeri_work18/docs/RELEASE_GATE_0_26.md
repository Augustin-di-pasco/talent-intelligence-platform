# Release gate bêta — 0.26

## Commandes
- `npm run test:release` — exécute la suite automatisée complète.
- `npm run preflight:beta` — vérifie les paramètres de production et les conditions de lancement.
- `ZERIHLINK_PREFLIGHT_OUTPUT=/path/report.json npm run preflight:beta` — écrit aussi le rapport JSON.

## Conditions bloquantes
Le preflight exige :
- `NODE_ENV=production`.
- `ZERIHLINK_SESSION_SECRET` unique, au moins 32 caractères.
- `ZERIHLINK_REVIEWER_EMAILS` avec au moins un e-mail valide.
- `ZERIHLINK_INVITE_CODE` fort (12 caractères minimum) pour la cohorte privée.
- `ZERIHLINK_BETA_LEGAL_APPROVED=true` uniquement après validation juridique effective des deux documents.
- `ZERIHLINK_TRUST_PROXY=true` derrière le proxy de confiance.
- `ZERIHLINK_DATA_DIR` égal au volume persistant Render configuré.
- Cohérence des versions package/VERSION/server.
- Sauvegarde locale vérifiée.
- URL déployée dont `/api/health` renvoie la version attendue.
- Accusés humains pour QA navigateur desktop/mobile, revue juridique, couverture reviewer et copie hors site + restauration testée.
- Intégrité du store si un fichier de données existe.

## Avertissements non bloquants pour une bêta fermée
- JSON et instance unique : pas de montée en charge multi-instance.
- Pas de PostgreSQL runtime.
- Pas d'e-mail transactionnel ; invitations manuelles.
- GLOBAL PULSE sans données financières live tant que la licence commerciale n'est pas confirmée.

`readyForClosedBeta` n'est vrai que si tous les bloqueurs passent. `readyForPublicLaunch` reste toujours faux dans cette version : une revue commerciale, juridique, technique et des licences de données reste nécessaire.

## État de cette livraison
Aucun déploiement réel, aucune URL publique, aucune QA visuelle navigateur certifiée et aucune revue juridique externe n'ont été effectués par cette livraison. Le preflight est un garde-fou ; il ne remplace pas ces actions.
