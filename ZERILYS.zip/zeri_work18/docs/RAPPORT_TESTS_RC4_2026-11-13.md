# ZERILYS — Rapport d'exécution des tests RC4

Date de contrôle : 13 novembre 2026  
Version contrôlée : `1.0.0-rc.4`  
Environnement : exécution locale, Node.js 22.16.0

## Résultats

| Contrôle | Résultat |
|---|---:|
| Tests unitaires (`npm test`) | 165 réussis, 0 échec |
| Contrôle syntaxique (`npm run check`) | Réussi |
| Chaîne complète (`npm run test:release`) | Code de sortie 0 |
| Smoke test fonctionnel principal | PASS |
| Smoke test bêta / configuration | PASS |
| Persistance des photos après redémarrage | PASS |
| Cohorte de 50 comptes sans invitation | PASS |
| Préférences linguistiques | PASS |
| Limitation du débit d'inscription | PASS |
| Cohorte de 50 comptes sur invitation | PASS |
| Sauvegarde et restauration | PASS |
| Rétention des sauvegardes | PASS |
| Export PostgreSQL | PASS |
| Intégrité des données | PASS |
| Pré-vérification de lancement | PASS (détecte les prérequis manquants) |
| Acceptation distante simulée en local | PASS |
| E-mails transactionnels | PASS |
| Durcissement HTTP | PASS |

## Résultats de charge fonctionnelle observés

- 50 créations de comptes ouvertes : 2 071 ms.
- 49 profils privés sur 49 autres comptes visibles par un membre autorisé, sur 3 pages.
- 50 créations de comptes invités : 2 093 ms.
- 49 profils privés sur 49 autres comptes visibles par un membre autorisé, sur 3 pages.
- Contrôle des accès aux photos anonymes et authentifiés : PASS.

Ces mesures sont des tests fonctionnels locaux, pas un test de charge Internet ni une garantie de capacité en production.

## Décision de mise en service

**NON PRÊT POUR OUVERTURE PUBLIQUE OU INVITATION DE TESTEURS.**

Le contrôle `npm run launch:check` reste volontairement en échec tant que les prérequis réels ne sont pas fournis. Au contrôle du 13 novembre 2026, il signale 13 points bloquants et 4 avertissements.

Principaux éléments non vérifiés :
- hébergement de production réellement créé et configuré ;
- secret de session de production, adresse de modération et proxy correctement configurés ;
- volume persistant réel et sauvegarde hors site restaurée ;
- URL HTTPS réelle et contrôle de santé distant ;
- recette humaine sur navigateurs, ordinateur et téléphone ;
- validation juridique des documents et activation autorisée du verrou ;
- équipe de modération et permanence quotidienne.

## Limites connues

- Stockage JSON sur une instance unique : pilote limité, pas d'ouverture à grande échelle.
- Le test distant a été exécuté contre un serveur local en mode production, pas contre une URL publique.
- Aucune recette visuelle sur appareils physiques n'a été effectuée dans cette exécution.
- Aucun service Render payant n'a été créé et aucun coût d'hébergement n'a été engagé.

## Conclusion

La suite automatisée RC4 est verte. Cela valide les scénarios couverts par les tests, mais ne vaut pas certification de production ni preuve que chaque parcours a été testé par un humain. Le verrou d'inscription doit rester fermé jusqu'à la levée documentée de tous les prérequis.
