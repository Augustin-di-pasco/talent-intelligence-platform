# ZERILYS 0.59 — Checklist avant ouverture

- [x] Inscription ouverte sans invitation obligatoire.
- [x] Cohorte de 50 comptes créée sans invitation en test local.
- [x] Préférence FR / EN enregistrée dans le compte et restaurée après redémarrage.
- [x] Préférence linguistique absente des profils publics.
- [ ] Validation juridique des documents français.
- [ ] Activer le verrou juridique uniquement après validation réelle (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
- [ ] Exécuter `npm run check:remote` sur l’hébergement de production.
- [ ] Déploiement et contrôle de l’hébergement réel.
- [ ] Tests humains sur ordinateur, iOS Safari et Android Chrome.
- [ ] Stockage durable, sauvegardes externes et restauration vérifiée.
- [ ] Organisation de la modération et des réponses aux testeurs.
