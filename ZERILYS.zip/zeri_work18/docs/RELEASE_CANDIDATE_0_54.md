# ZERILYS 0.54 — Private beta release candidate

## Product scope delivered
- Candidate-first compact homepage and futuristic Human Orbit profile centered on the member's real photo.
- Members can add, replace and remove their own profile portrait.
- Every signed-in member can discover and open every other candidate profile, including profiles set to Private.
- Public profiles can be shared anonymously with crawler-readable title, description, canonical URL and real portrait preview; private links require sign-in.
- Anonymous visitors can join from a public profile and return to the profile after registration.
- Network discovery supports server-side cursor pagination without a fixed 50-profile ceiling.
- Reviewer tools support up to 50 individual email-bound invitations in one batch and track registration progress.
- Backup rotation, avatar-inclusive restore, release preflight, remote acceptance checks and reduced-motion/accessibility behavior are included.

## Automated evidence
- 47 unit tests pass.
- Full `npm run test:release` suite passes.
- Synthetic 50-member cohort: 50 individual invitations, 50 registrations, all 49 other private profiles discovered and opened across three pages, 10 profile photos stored separately, anonymous media denial confirmed.
- Avatar and session persistence verified across a server restart.
- Backup checksum, photo inclusion, restore and retention rotation verified.
- Remote acceptance checker verified against a local production-mode server.

## What is not yet verified
- The package has not been deployed to the actual production host from this session.
- The remote acceptance check has not yet run against the actual domain.
- Real social-platform preview caches and real mobile browsers have not been tested.
- Legal review and approval have not been supplied.
- Off-host backup and real restore on the production volume have not been verified.

## Current preflight blockers
The latest local preflight reports 13 blockers that require real hosting configuration or human approval:
1. Production mode.
2. Unique production session secret.
3. Reviewer email allowlist.
4. Private beta invitation code.
5. Trusted reverse-proxy configuration.
6. Confirmed persistent data directory.
7. Verified local backup.
8. Deployed health URL.
9. Desktop/mobile browser QA acknowledgement.
10. Legal review acknowledgement.
11. Actual beta legal approval.
12. Reviewer coverage acknowledgement.
13. Off-site backup acknowledgement.

Warnings also remain for canonical public origin, JSON runtime storage, transactional email and market-data licensing.

## Decision
**Release candidate for controlled staging and final host validation. Not yet cleared for sending invitations to the first 50 external testers.** Follow `BETA_RELEASE_CHECKLIST_0_54.md`; do not bypass blockers by setting acknowledgement variables without completing the underlying work.
