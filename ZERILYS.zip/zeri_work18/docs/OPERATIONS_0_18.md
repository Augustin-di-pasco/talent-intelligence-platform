# Account security and backup operations — 0.18

## Sessions and passwords
- Sessions expire after 14 days and are listed in Data & Privacy without exposing session tokens.
- Maximum 10 active sessions per account; oldest sessions are evicted when a new session is created above the limit.
- Members can revoke every other session while keeping the current session.
- Password changes require the current password and a new password of 12–128 characters. Other sessions are revoked after a successful change.
- Login and password-change endpoints use the existing per-IP rate limiter.

## Backups
- `npm run backup` creates a local JSON snapshot under `data/backups/` (or `$ZERIHLINK_DATA_DIR/backups/`) with a SHA-256 manifest.
- `npm run backup:verify` verifies the newest backup. Set `ZERIHLINK_BACKUP_FILE` to verify a specific snapshot.
- Restore requires both `ZERIHLINK_RESTORE_FILE` and the exact confirmation `ZERIHLINK_RESTORE_CONFIRM=RESTORE`.
- `npm run restore` verifies the source manifest and checksum, creates a pre-restore safety copy, validates JSON shape, then atomically replaces the live store file.
- `npm run smoke:backup` exercises backup, verification, blocked restore without confirmation, safety copy and successful restore using a temporary directory.

## Critical limitations
- Backups remain on the same persistent disk. They are not off-site, encrypted, or protected from loss of the hosting account or disk.
- No automated backup schedule, alerting, restore drill schedule or external backup destination is configured.
- Runtime persistence remains a single JSON file and a single Node process. Do not run multiple application instances against the same file.
- A managed PostgreSQL database, encrypted off-site backups and regular restore drills remain prerequisites for a larger/public launch.
