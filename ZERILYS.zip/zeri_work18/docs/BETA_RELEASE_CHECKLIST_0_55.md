# ZERILYS 0.55 — Open beta release checklist

- [x] Remove shared invite-code requirement from API registration.
- [x] Hide invitation-token fields from ordinary self-service registration.
- [x] Keep optional targeted invitations for research cohorts.
- [x] Keep existing account security, rate limits and explicit consent checks.
- [x] Keep legal approval as an independent server-side launch gate.
- [ ] Complete operator/controller identity, contact and legal disclosures.
- [ ] Obtain qualified review of Terms, Privacy Notice, legal bases, retention and processors.
- [ ] Only after review, set `ZERIHLINK_BETA_LEGAL_APPROVED=true`.
- [ ] Confirm `ZERIHLINK_ALLOW_SIGNUP=true` and remove obsolete `ZERIHLINK_INVITE_CODE` from host settings.
- [ ] Deploy and run `npm run check:remote`.
- [ ] Perform human browser checks on desktop, iOS Safari and Android Chrome.
- [ ] Confirm persistent storage, backups, reviewer coverage and incident response.

Open registration means that anyone may create an account once the legal launch gate is cleared. It does not mean anonymous access to private member data or removal of moderation and security controls.
