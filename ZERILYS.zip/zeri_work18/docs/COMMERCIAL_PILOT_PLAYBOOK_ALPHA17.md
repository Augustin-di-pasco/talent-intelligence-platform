# Pilotes commerciaux — guide d'exécution alpha.17

## Positionnement de départ

ZERILYS ne doit pas se vendre comme un énième site d'annonces. La proposition testable est : aider les recruteurs spécialisés à repérer des candidats pertinents grâce à des compétences explicites, des preuves consultables avec consentement et des évaluations structurées.

## Segment initial recommandé

Commencer par des équipes de recrutement qui embauchent régulièrement des profils junior à confirmé en finance/risque, data/IA et ingénierie. Éviter de lancer simultanément tous les secteurs et tous les types d'opportunités : le catalogue de compétences et la qualité du matching doivent d'abord être validés sur des besoins réels.

## Offre pilote concierge

- Durée : 4 semaines par entreprise.
- Périmètre : 1 à 3 offres réelles et une shortlist préparée avec le recruteur.
- Engagement candidat : participation volontaire, transparence sur les critères et consentement explicite pour chaque preuve partagée.
- Livrables : shortlist motivée, profils avec preuves autorisées, bilan de pertinence et recommandations d'amélioration.
- Pas de promesse de recrutement, de score algorithmique décisif ou de garantie de validité psychométrique.
- Les challenges doivent être simulés et bornés ; tout travail utile à l'activité de l'entreprise doit être rémunéré ou faire l'objet d'un cadre contractuel approprié.

## Mesures à recueillir

1. Délai entre ouverture du besoin et première shortlist.
2. Part des profils jugés pertinents par le recruteur.
3. Taux de consultation des preuves partagées.
4. Taux de réponse et de poursuite du processus côté candidats.
5. Temps passé par le recruteur par rapport à sa méthode habituelle.
6. Incidents, contestations, demandes d'explication et retraits de consentement.
7. Intention de renouvellement et budget réellement accepté.

## Seuils de décision proposés

Après 3 à 5 pilotes, poursuivre seulement si au moins deux entreprises souhaitent payer pour un second cycle, si les recruteurs jugent les shortlists utiles et si les candidats comprennent le partage des preuves. Ces seuils sont des hypothèses de validation commerciale, pas des résultats acquis.

## Tarification à tester, sans l'implémenter encore

Tester deux formats en entretien : forfait pilote fixe par campagne de recrutement et abonnement mensuel limité par nombre d'offres/utilisateurs recruteurs. Ne pas fixer un tarif public avant d'avoir mesuré le coût opérationnel réel de la présélection assistée et le consentement à payer.

## Conditions préalables

- Revue juridique des conditions, confidentialité, bases légales, durées et rôles de responsable/sous-traitant.
- Vérification de sécurité indépendante et procédure de gestion d'incident.
- PostgreSQL réellement exploité avec stratégie de sauvegarde/restauration validée.
- E-mails transactionnels et domaine vérifié.
- Équipe humaine de revue, modération et support.
- Tests utilisateurs desktop/mobile et accessibilité.
