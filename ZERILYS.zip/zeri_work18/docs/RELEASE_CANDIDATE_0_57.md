# ZERILYS 0.57 — French-first language refinement

- Extended native French wording across the remaining candidate orbit, member discovery, connection requests, opportunity applications, company workspace, reviewer operations, prompts and confirmation dialogs.
- Dates and times now follow the selected FR / EN interface locale and visible data panels refresh after a language switch.
- Member-authored names, descriptions, skills and opportunity content remain as entered by their authors.
- Open registration is implemented at the product/API level and requires no invitation. The legal launch gate remains active as an independent production restriction until the actual legal documents are approved.

Validation target: 51 unit tests and the full release smoke suite. This package is not a production launch approval; legal review, real-host validation, persistent storage, backup operations and human desktop/mobile QA remain required.
