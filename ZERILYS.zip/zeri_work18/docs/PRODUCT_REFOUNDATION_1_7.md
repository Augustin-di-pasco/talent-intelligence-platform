# Refonte produit — nouvelle plateforme de talent intelligence

**Statut :** nouvelle direction produit approuvée pour exploration et implémentation progressive.  
**Marque :** à renommer ; ZERILYS est un nom de travail, pas une décision définitive.  
**Marché de lancement :** France, interface française native.  
**Verticales initiales :** finance quantitative, risque, fintech, data, IA/ML et ingénierie logicielle financière.

## 1. Thèse produit

Construire une plateforme spécialisée qui permet aux professionnels de rendre leurs capacités visibles et démontrables, et aux employeurs de découvrir des personnes qu'un tri classique de CV aurait pu écarter.

**Promesse :** « Ne recrutez plus uniquement sur ce qu'une personne a fait. Découvrez ce qu'elle sait réellement faire. »

Le produit ne doit être ni un réseau social généraliste, ni un simple job board, ni un ATS générique, ni une plateforme de tests isolée. C'est une infrastructure de découverte, d'évaluation contextualisée et de preuve des compétences.

## 2. Architecture fonctionnelle cible

### A. Identité professionnelle (Human Orbit — nom de concept)
- Profil vivant : parcours, formations, expériences, réalisations, compétences, intérêts, préférences et disponibilité.
- Chaque information porte une provenance : déclarée, documentée, testée, mission validée ou vérifiée par un tiers.
- Le candidat contrôle la visibilité et le partage de ses éléments.
- Pas de score de valeur humaine ni de classement public des personnes.

### B. Évaluation des compétences (nom de marque à définir)
- Bibliothèque d'évaluations structurées par métier et compétence.
- Trois niveaux : fondamentaux/connaissances ; application pratique ; mise en situation ou mission.
- Résultats réutilisables, datés, versionnés et associés à un barème explicite.
- Une évaluation déjà réalisée peut être réutilisée ; l'employeur voit sa date, sa version et son niveau de couverture.
- Les entreprises peuvent composer et ajuster un parcours d'évaluation pour un poste.
- Une absence d'évaluation signifie « non évalué », jamais zéro.

### C. Missions (Mission Labs — nom de concept)
- Missions individuelles ou collectives sur des problèmes réalistes.
- Cas fictifs/simulés pour les exercices de sélection.
- Toute production exploitable commercialement par l'entreprise doit être rémunérée ou faire l'objet d'un cadre contractuel explicite ; pas de travail productif gratuit déguisé en test.
- Contributions, livrables, méthode, justification, feedback et rôle individuel peuvent devenir des preuves, avec consentement.
- Les missions collectives révèlent les compétences complémentaires et la capacité à travailler en équipe.

### D. Opportunités
- Emplois, stages, alternances, missions rémunérées et collaborations.
- Les opportunités sont contextualisées dans le profil du candidat, sans promettre un emploi ni créer de faux sentiment de certitude.
- Le candidat voit pourquoi une opportunité lui est proposée et peut corriger ses informations.

### E. Intelligence (moteur transversal)
- Relie compétences, évaluations, missions, profils, besoins d'entreprises et opportunités.
- Taxonomie de compétences versionnée avec synonymes et niveaux observables.
- Traçabilité des sources, date, fraîcheur, confiance et limites.
- Les recommandations doivent être explicables et contestables.

### F. Espace employeur
- Création d'un besoin structuré : missions, compétences indispensables/souhaitées, niveau attendu, contexte et critères de réussite.
- Proposition automatique d'une grille de compétences et d'un parcours d'évaluation modifiable par le recruteur.
- Vue candidats avec deux indicateurs séparés, détails, preuves, inconnues et dates.
- Collaboration entre recruteurs et responsables métier, notes contextualisées, étapes de sélection et journal d'activité.

## 3. Les deux correspondances — règle fondatrice

Chaque candidature/opportunité affiche deux dimensions autonomes :

**Match Parcours** — correspondance descriptive entre les informations du parcours et le contexte du poste : compétences déclarées, formations pertinentes, expériences, réalisations. Les années d'expérience ne sont jamais un filtre automatique ni un substitut à la compétence. Un parcours atypique ou junior ne doit pas être mécaniquement pénalisé.

**Match Technique** — résultats observés sur les évaluations et missions pertinentes : niveau obtenu, couverture des compétences demandées, date, version, nombre et nature des preuves.

Règles non négociables :
- Aucun score fusionné opaque par défaut. Les deux résultats restent distincts.
- Une donnée absente ou non évaluée est affichée comme inconnue/non évaluée, pas comme zéro.
- Le niveau de couverture est affiché à côté du score technique.
- Le détail des critères, preuves et pondérations est accessible.
- Le recruteur garde la décision ; aucun rejet automatique sur la base d'un score.
- Les pondérations de poste sont visibles, modifiables et historisées.
- Les résultats ne prétendent pas prédire à eux seuls la performance future.

## 4. Parcours utilisateur cible

### Professionnel
1. Crée son identité et importe/renseigne son parcours.
2. Déclare ses compétences et associe les preuves disponibles.
3. Reçoit des suggestions d'évaluations pertinentes et choisit quand les passer.
4. Conserve un portefeuille de résultats réutilisables, datés et versionnés.
5. Participe à des missions et enrichit son portefeuille de preuves.
6. Explore des opportunités avec Match Parcours et Match Technique distincts.
7. Contrôle les informations partagées avec chaque employeur.

### Employeur
1. Décrit le poste et les résultats attendus.
2. Reçoit une proposition de compétences et d'évaluations à valider/modifier.
3. Publie l'opportunité et invite éventuellement des candidats à compléter une évaluation pertinente.
4. Examine les deux correspondances, leur couverture, les preuves et les inconnues.
5. Organise entretiens, exercices simulés et échanges humains.
6. Suit le processus et donne un retour utile au candidat.

## 5. Principes d'évaluation et d'équité

- Les tests mesurent des compétences définies, pas la personnalité ou la « valeur » d'une personne.
- Conditions, durée, barème, version, langue et aménagements possibles sont annoncés.
- Accessibilité et aménagements raisonnables ; alternatives lorsque le format de test crée un obstacle non pertinent.
- Contrôle humain des contestations et possibilité de refaire/actualiser une évaluation selon une politique claire.
- Mesure régulière des écarts de résultats et des effets d'exclusion ; ne pas inférer de caractéristiques sensibles.
- Limitation des données collectées, durée de conservation définie, consentement et partage granulaire.
- Pas de surveillance biométrique ou comportementale intrusive.
- Pour les missions, distinguer clairement sélection, apprentissage et travail productif rémunéré.

## 6. Positionnement et modèle économique

Acheteur prioritaire : recruteurs spécialisés, cabinets, fintechs, banques, fonds, assureurs et équipes data/IA. Les candidats ont accès gratuitement aux fonctions essentielles de profil, portefeuille de preuves et candidature.

Hypothèses à tester, non tarifs validés :
- Recruteur indépendant : 99–149 €/siège/mois.
- Équipe : 299–499 €/mois.
- Entreprise : offre sur mesure selon volume, gouvernance et intégrations.

Ne pas construire une usine à fonctionnalités avant validation de la volonté de payer. Le premier produit commercial doit résoudre : « trouver rapidement une shortlist de spécialistes crédibles et comparer des preuves pertinentes ».

## 7. Pilote de lancement

Cohorte cible : 50 à 100 professionnels français et 5 à 10 entreprises partenaires. Commencer par un sous-segment étroit, par exemple data/risque/quant en finance, puis élargir à l'IA/ML et fintech.

Métriques : temps jusqu'à la première shortlist pertinente, taux de profils avec preuves, taux de réponse, taux de complétion des évaluations, retour des recruteurs, répétition des recherches, entretiens déclenchés, collaborations/embauches et conversion en pilotes payants.

## 8. Nom de marque

Le nom actuel ZERILYS est abandonné comme décision de marque ; il reste le nom du dépôt technique tant que le renommage n'est pas validé. MATCHCANDIDATE n'est pas retenu, ni comme marque ni comme nom de fonctionnalité.

Le futur nom doit être : distinctif, prononçable en français et en anglais, court, extensible au-delà du recrutement, non descriptif, disponible en domaines pertinents et défendable en classes adaptées. Aucun nom ne sera adopté avant une recherche d'antériorités à l'identique et par similarité (INPI, EUIPO/TMview, OMPI), puis vérification des sociétés et domaines.

## 9. Périmètre technique : ce qui existe et ce qui reste à construire

Le socle actuel comprend identité, compétences déclarées, éléments de preuve, recherche de profils, sociétés, opportunités, candidatures, espace équipe, confidentialité et opérations de revue. Il ne faut pas présenter ces fonctions comme un moteur complet d'évaluation ou de matching double déjà livré.

Cette refonte introduit une première brique isolée de calcul à deux axes (`src/dual-match.js`) avec tests unitaires. Elle n'est pas encore branchée à un catalogue d'évaluations, à des résultats candidats persistés ni à l'interface employeur. Les prochaines étapes sont : taxonomie et modèle de données ; catalogue et versionnement des tests ; stockage des résultats ; workflow Missions ; API de matching ; interface explicable ; audit de sécurité, confidentialité et conformité.

## 10. Décisions de produit à préserver

- Français natif au lancement ; architecture prête pour l'anglais ensuite.
- Marché initial français, spécialistes finance/IA/data/risque/fintech.
- Pas de fil social généraliste.
- Pas de terminal de trading ni d'outils de marché issus de WORLD INTELLIGENCE.
- Pas de score global caché, pas de classement automatique opaque.
- Pas de travail productif gratuit sous couvert d'évaluation.
- Pas de dépenses d'infrastructure ou de lancement sans validation explicite du budget.
