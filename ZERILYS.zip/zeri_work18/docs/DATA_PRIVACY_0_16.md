# Data portability and account deletion — 0.16

## Export
`GET /api/me/export` returns a JSON package with schema version and generation timestamp. It includes the user's profile, evidence, applications, offers (for company owners), company application records (for company owners), project records, connections, notifications, blocks, reports, company memberships/invitations and associated audit events. Candidate exports do not expose company-private notes.

## Account deletion
`DELETE /api/me` requires the exact account email in `confirmEmail`. It removes the user, sessions, evidence, candidate/project applications, owned projects, owned offers, related offer applications and private notes, notifications, blocks, reports, company memberships and invitations. Deleting a company owner also removes that company's offers and the associated applications; invited team members keep their own personal accounts but lose access to that workspace.

Opaque audit events are retained for accountability. They contain internal identifiers and event metadata, not passwords or session tokens. The exact legal basis, retention period, audit minimization and any exceptional retention obligations still require qualified legal review before public launch.

## User interface
The Professional Universe exposes a Data & Privacy panel. It displays the account email and profile visibility, offers JSON export, and requires typing the exact email plus a second confirmation before deletion.

## Limits
This release does not constitute a GDPR compliance certification. There is no formal privacy request workflow, no legal retention schedule, and no independent legal review. The application still uses a JSON file store.
