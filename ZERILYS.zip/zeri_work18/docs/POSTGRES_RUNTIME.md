# PostgreSQL runtime — ZERILYS 1.6 alpha

## What this release changes

The server can now opt into PostgreSQL-backed persistence with `ZERIHLINK_STORAGE=postgres` and `DATABASE_URL`. At startup it creates `zerihlink_runtime_state` if absent, loads the authoritative JSONB state snapshot, and refuses to start if the database cannot be reached. Each application save is awaited by the API route and committed as one atomic row update before the request completes. Writes use an optimistic compare-and-swap on the stored revision. If another process has already written a newer revision, the stale process is rejected instead of overwriting newer data. A failed database write propagates as an API error rather than being silently treated as successful.

The existing JSON store remains the default (`ZERIHLINK_STORAGE=json`) for local development and backward compatibility. PostgreSQL is opt-in; this release does not automatically migrate or switch existing production data.

## Important architecture limitation

This is a PostgreSQL-backed state snapshot adapter, not yet a normalized relational repository. It preserves the existing in-memory domain model to avoid an unsafe rewrite of dozens of business workflows in one step. The normalized SQL schema and JSON-to-PostgreSQL importer remain a separate migration path and must not be run against a live database without a reviewed backup and explicit target confirmation.

Uploaded avatar files remain on the local filesystem under the configured data directory. The existing Render Blueprint mounts that directory on a persistent disk, so the photos survive restarts and deploys when that Blueprint is actually deployed with its disk. This disk-backed approach is single-instance and causes a brief interruption during deploys. For horizontal scaling, move avatars to shared object storage (S3-compatible) before enabling multiple instances. The revision check prevents silent lost updates, but a process with a stale in-memory snapshot fails closed and must be restarted to reload authoritative state; it is not multi-instance coordination. Run one application instance only.

## Controlled activation

1. Create a dedicated, empty PostgreSQL database and retain a tested backup.
2. Export and validate the current JSON data.
3. Review and run the migration/import process against the explicitly confirmed database name.
4. Verify all entity counts and sample account/profile workflows.
5. Only then set `ZERIHLINK_STORAGE=postgres` and `DATABASE_URL` in the deployment environment.
6. Start one application instance and verify `/api/health`, registration, login, profile edit, offers, applications, and audit history.
7. Keep the JSON export and database backup until a documented rollback test passes.

Never commit `DATABASE_URL` or any production secret to Git.
