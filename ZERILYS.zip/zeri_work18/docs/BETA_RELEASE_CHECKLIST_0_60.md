# ZERILYS 0.60 — Checklist avant ouverture

- [x] Inscription standard sans invitation obligatoire.
- [x] Test local de 50 inscriptions ouvertes et consultation des 49 autres profils.
- [x] Préférence FR / EN liée au compte et privée.
- [x] Confirmation d’adresse e-mail à usage unique si le service d’envoi est configuré.
- [x] Renvoi du lien et gestion d’un échec d’envoi.
- [ ] Configurer le service d’e-mails transactionnels en production.
- [ ] Compléter et faire valider les documents juridiques français.
- [ ] Activer le verrou juridique uniquement après validation réelle (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
- [ ] Déployer sur l’hébergement réel et exécuter `npm run check:remote`.
- [ ] Tests humains sur ordinateur, iOS Safari et Android Chrome.
- [ ] Sauvegardes externes, restauration et modération opérationnelles.
