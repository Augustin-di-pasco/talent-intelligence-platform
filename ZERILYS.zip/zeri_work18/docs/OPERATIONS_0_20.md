# Operational readiness — 0.20

## Single-instance storage lock
At startup the application creates `data/.zerihlink.lock`. If another process is using the same data directory, startup fails closed. A stale lock with a dead PID is removed automatically. A malformed lock fails closed and must be inspected manually. Do not delete a lock while a process is still running.

## Reviewer operations diagnostics
`GET /api/review/health` is restricted to `ZERIHLINK_REVIEWER_EMAILS`. It returns the application version, JSON storage mode, file size, high-level user/session/moderation/invitation counts, and the integrity/age of the newest local backup. It does not return credentials, session tokens, email addresses or private message content.

## Remaining limits
- JSON storage still supports one process only; the lock prevents accidental multi-process use.
- Backups are local to the same data volume and are not off-site or encrypted.
- No managed PostgreSQL adapter, automatic backup schedule, monitoring service, alerting or production deployment has been configured.
- A real hosted restore drill and real-browser visual QA remain required before 50 invitations.
