# ZERILYS 0.63 — mode de test local

Cette version permet de tester le parcours d'inscription sans attendre la validation juridique, **uniquement sur un environnement local/non-production**.

## Activer les inscriptions pour un test local

Dans le terminal, avant de démarrer le serveur :

- Windows PowerShell : `$env:ZERIHLINK_LOCAL_BETA_TEST_MODE="true"; npm start`
- macOS/Linux : `ZERIHLINK_LOCAL_BETA_TEST_MODE=true npm start`

Le mode est accepté uniquement lorsque `NODE_ENV` n'est pas égal à `production`. Si `NODE_ENV=production`, cette option est ignorée et le verrou juridique reste actif. En production, seule la variable `ZERIHLINK_BETA_LEGAL_APPROVED=true` peut lever le verrou, après validation juridique réelle.

## Limites

Ce mode est destiné aux essais locaux avec des données de test. Il ne constitue pas une autorisation de lancer publiquement les inscriptions et ne remplace ni les CGU ni l'information RGPD. Ne pas utiliser de vraies données personnelles de testeurs tant que les documents et mesures nécessaires ne sont pas validés.
