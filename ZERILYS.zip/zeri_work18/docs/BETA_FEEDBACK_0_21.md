# Private beta feedback loop — 0.21

## Member workflow
Signed-in members open **Share beta feedback** from the Professional Universe. They choose a category (bug, confusing, idea, other), optionally name the product area, and provide at least 20 characters. They can see their own feedback history and current triage state.

## Reviewer workflow
Authorized reviewers see open feedback in the restricted Trust Operations console. They can mark it reviewed, accept it for follow-up, or decline it, with an optional internal note. The server enforces reviewer authorization and valid state transitions.

## Data and privacy
Feedback is private to its author and authorized reviewers. It is included in the member's account export and removed when that account is deleted. Review notes are internal and not shown in the member's feedback history.

## Operating recommendation
For 50 testers, review new feedback daily, label recurring friction points, and group duplicates before prioritizing fixes. This is a simple triage queue, not a full product analytics or ticketing system.
