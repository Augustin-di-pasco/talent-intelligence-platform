# Data integrity preflight — 0.24

## CLI
Run `npm run validate:data` against `ZERIHLINK_DATA_DIR` (or `./data`). Exit code:
- `0`: no integrity errors (warnings may remain).
- `1`: one or more data integrity errors.
- `2`: missing or unparsable store file.

The validator checks collection shape, duplicate users/skills/entity IDs, user and company references, evidence-to-skill links, application-to-offer/candidate links, withdrawn-application note cleanup, project references, connection/block/report references, team membership and invitation consistency, feedback references, notification recipients and the audit hash chain.

## Reviewer dashboard
The restricted operations endpoint includes the same integrity report. Reviewers see PASS or the number of errors and the first few error details. The endpoint remains protected by the reviewer allowlist.

## Account deletion cleanup
Deleting a member now removes their authored private company notes from other applications and nulls reviewer references on retained evidence/reports/feedback records. This prevents orphaned internal references.

## Limits
The validator is a preflight check, not a repair tool. It does not mutate or auto-correct data. Back up the store before any manual repair. A clean report does not prove PostgreSQL SQL execution, legal compliance or application security.
