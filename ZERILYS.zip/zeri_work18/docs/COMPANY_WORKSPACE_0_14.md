# Company workspace & role model — 0.14

## Roles
- **Owner**: the company account that created the company identity. Owns company profile and team administration.
- **Recruiter**: may publish/close opportunities, view applications, update candidate status and write company-private application notes.
- **Viewer**: read-only access to the company's opportunities and application inbox. Cannot change statuses or add private notes.

## Invitation flow
1. An owner creates an invitation for an email and selects `recruiter` or `viewer`.
2. The API returns a single-use invitation token. This release does not send email; the owner must deliver the token through a trusted channel.
3. The invited person signs in using the exact invited email and accepts the token.
4. The invitation token hash is removed after acceptance. Invitations expire after seven days.
5. The owner can remove an active member. Removed members lose access immediately.

## API
- `POST /api/company/team/invitations` — owner only; `{ "email": "...", "role": "recruiter|viewer" }`
- `POST /api/company/team/accept` — signed-in invited email; `{ "invitationToken": "..." }`
- `GET /api/company/team` — owner or active team member
- `GET /api/company/team?companyId=...` — member access to a specific company workspace
- `DELETE /api/company/team/:userId` — owner only
- `GET /api/me/offers` and `GET /api/company/applications` — owner/recruiter/viewer read access
- Publishing/closing offers, status changes and private notes — owner/recruiter only

## Security and limitations
- Invitation tokens are random, single-use, stored as SHA-256 hashes, and expire after seven days.
- Invitations are not emailed by this release. Do not paste tokens into public channels.
- The JSON store is still single-process and file-backed. It is not a substitute for PostgreSQL or concurrent multi-instance storage.
- Existing company identities remain the workspace owner; there is no transfer-of-ownership workflow.
- The PostgreSQL schema is updated as a target schema only. It has not been applied to a live database, and no DB adapter is active.

## In-product workspace interface (0.15)
The company studio now exposes the team roster and pending invitations. Owners can create invitations and remove members from the interface. Invited members see the workspace in the company studio; members with several company memberships can choose a workspace. The one-time token is displayed to the owner for private manual delivery. There is still no transactional email delivery.
