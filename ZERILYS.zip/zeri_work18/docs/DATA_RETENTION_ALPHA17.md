# Nettoyage des données à durée de vie courte — alpha.17

## Automatisation activée au démarrage

Le serveur purge les éléments d'authentification dont la date d'expiration est dépassée :
- sessions expirées ;
- jetons de vérification d'adresse expirés ;
- jetons de réinitialisation de mot de passe expirés.

Pour les invitations d'entreprise et de bêta :
- le hash du secret est supprimé dès que l'invitation n'est plus utilisable ;
- les métadonnées d'invitation expirées, acceptées ou révoquées sont supprimées après 90 jours ;
- les invitations encore valides sont conservées.

## Données volontairement exclues du nettoyage automatique

Les profils, candidatures, preuves, évaluations, justificatifs de diplômes, signalements et événements d'audit ne sont pas purgés automatiquement. Leur durée de conservation doit être décidée selon les finalités, les obligations applicables, les contrats et les bases légales après revue juridique. Une suppression arbitraire pourrait porter atteinte aux droits des personnes ou à la traçabilité d'une décision de recrutement.

## Export de données — version 1.1

L'export de compte inclut désormais l'historique privé des évaluations, les métadonnées des vérifications de diplôme et les justificatifs encore présents dans le stockage, encodés en Base64 avec leur format et leur empreinte SHA-256. L'export reste une archive JSON ; les fichiers intégrés augmentent sa taille.

## Limites

Ce mécanisme est un nettoyage technique des secrets et jetons expirés, pas une politique complète de conservation RGPD. La durée de 90 jours pour les métadonnées d'invitation est un paramètre produit provisoire à faire valider juridiquement. Le nettoyage est exécuté au démarrage ; aucun ordonnanceur permanent n'est requis. Sur une instance PostgreSQL snapshot, le changement est persisté par le mécanisme normal de sauvegarde.
