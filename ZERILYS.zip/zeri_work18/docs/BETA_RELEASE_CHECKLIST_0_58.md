# ZERILYS 0.58 — Checklist avant ouverture

- [x] Inscriptions standards sans code ni invitation.
- [x] Test réel local de 50 inscriptions ouvertes, sans invitation.
- [x] Vérification de la consultation des 49 autres profils par chaque membre.
- [x] Vérification des photos : accès membre autorisé, visiteur anonyme refusé.
- [ ] Compléter et faire valider les documents juridiques français.
- [ ] Déployer sur l’hébergement de production et exécuter `npm run check:remote`.
- [ ] Vérifier les parcours sur ordinateur, iOS Safari et Android Chrome.
- [ ] Confirmer le stockage persistant, les sauvegardes externes, la restauration et la modération.
- [ ] Activer le verrou juridique uniquement après validation réelle (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
