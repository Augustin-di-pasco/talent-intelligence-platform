# ZERILYS 0.62 — French deployment readiness

- Open registration remains available without an invitation, subject to the independent legal approval gate.
- Added a French-language `npm run launch:check` report for operators.
- The legal launch gate remains active until the actual legal documents are approved.
- Added a Render and generic-host deployment guide in French.
- Clearly separates invitation-free signup from the independent legal approval switch.
- Documents the current JSON single-instance storage limitation and the human checks still required.
