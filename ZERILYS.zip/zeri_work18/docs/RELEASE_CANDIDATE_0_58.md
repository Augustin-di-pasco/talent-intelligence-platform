# ZERILYS 0.58 — Open registration validation

- Open registration is implemented at the product/API level and requires no invitation. Added a full 50-account cohort smoke that uses ordinary open registration with no invitations or shared code. The legal launch gate remains active until the actual documents are reviewed and approved.
- Verified that all 50 accounts register, and every member can discover and open the other 49 private profiles.
- Verified separate avatar storage and authenticated-member / anonymous-visitor media access boundaries.
- Kept a separate invitation-based cohort smoke to validate optional research invitations without making them a registration requirement.

The local smoke sets legal approval only in its disposable test server. Production registration remains subject to completion and qualified review of the actual legal documents.
