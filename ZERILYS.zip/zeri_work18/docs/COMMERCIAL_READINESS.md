# Commercial readiness — go / no-go

## Current decision: NO-GO for public commercial launch

The product is now repositioned and its core candidate/company workflows are retained. The release is suitable for controlled internal testing and structured design-partner validation only, subject to local legal and operational approval.

| Area | Current state | Required before public launch |
|---|---|---|
| Product core | Candidate profiles, discovery, evidence, companies, opportunities, applications, collaborations | User testing and conversion improvements |
| Specialisation | Finance / AI / data positioning and search shortcuts | Validate taxonomy and recruiter search quality with real roles |
| AI skill graph | Not implemented | Build only after validating skill ontology and evidence model |
| Talent market data | No external live labour-market feed | Source licensing, provenance, refresh and quality controls |
| Billing | Not implemented | Payment provider, invoicing, tax, cancellation and entitlement model |
| Legal | Draft terms/privacy; launch gate closed | Qualified GDPR, employment-law and consumer/business contract review |
| Security | Existing controls and local release suite pass | Independent penetration test, dependency monitoring, incident response |
| Data persistence | Local JSON store; Render blueprint uses persistent disk | Production-grade PostgreSQL migration, migration/restore rehearsal, off-site backups |
| Email | Webhook integration and smoke coverage | Real provider, verified sender domain, SPF/DKIM/DMARC and deliverability monitoring |
| Brand | ZERILYS retained as working brand | Trademark, company-name and domain clearance |
| Operations | Reviewer workflows exist | Named moderation/evidence-review coverage, support SLA and monitoring |

## Commercial validation gates
1. Conduct at least 15 structured interviews with specialist recruiters and hiring managers.
2. Conduct at least 30 candidate interviews across quant, fintech, AI/ML and data.
3. Run 3–5 concierge shortlisting pilots with real roles and candidate consent.
4. Measure time-to-shortlist, recruiter relevance rating, candidate response and repeat usage.
5. Obtain at least two paid pilot commitments before building billing and enterprise procurement features.

## Hard safety rule
Do not enable open production registration by changing environment flags until legal approval, security review, data persistence, email delivery, backup recovery and human operations are signed off. The deployment blueprint intentionally defaults registration and legal approval to disabled.
