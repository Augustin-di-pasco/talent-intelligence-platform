# Guided activation — 0.25

## Candidate checklist
1. Professional identity: headline, location and at least 40 characters of professional introduction.
2. Capabilities: at least three skills.
3. Evidence: at least one evidence item linked to a skill.
4. Intentions: at least one of contribution, looking-for or interests.
5. Discoverability: an explicit public/private visibility setting. Public visibility is optional.

## Company checklist
1. Company identity: name, industry and at least 40 characters of description.
2. First opportunity: at least one published structured offer.
3. Required capabilities: at least one published offer with one or more required skills.

## Product principles
- The checklist is guidance, not a ranking, hiring score or assessment of a person's worth.
- All signed-in members can consult every member profile. Private mode only hides a profile from anonymous discovery and public links; public mode enables those as well.
- Every incomplete item offers a direct route to the relevant editor or company workspace.
- Criteria are intentionally simple and explainable for the private beta; they may evolve from tester feedback.
