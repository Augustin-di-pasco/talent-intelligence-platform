# Beta consent and legal notice drafts — 0.27

## Product behavior
- New registrations must explicitly accept the Private Beta Terms and acknowledge the Privacy Notice.
- The server stores the versions and timestamps on the account.
- Existing accounts without the current versions are allowed to view their account record, export data, delete the account or sign out. Other authenticated API operations are blocked with HTTP 428. They can submit updated consent only after the server-side legal approval switch is enabled.
- Consent is private account metadata, excluded from public profiles and included in the user's data export.
- Terms and privacy documents are served at `/beta-terms.html` and `/privacy-notice.html`.

## Draft status
Both public documents are explicitly marked **DRAFT — NOT LEGALLY APPROVED**. They contain placeholders for the controller's legal identity, address, contact, legal bases, retention, subprocessors, transfers and governing law. Do not invite external testers until qualified counsel has completed and approved them.

## Versioning
Current versions: beta terms `0.1`, privacy notice `0.1`. Increment the server constants when either notice changes materially; existing accounts will then be prompted to acknowledge the new versions.

## Server-side launch lock
The Render blueprint sets `ZERIHLINK_BETA_LEGAL_APPROVED=false`. Registration returns HTTP 503 until the operator changes it to `true` after counsel has approved both documents. The UI also disables registration while the switch is false. This server-side lock is independent of the user's consent checkbox.
