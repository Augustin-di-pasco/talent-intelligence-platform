# Invitation email — ZERILYS private beta

**Subject:** You're invited to test ZERILYS — your professional identity, reimagined

Hello [First name],

I'd like to invite you to join the first private beta cohort of **ZERILYS**.

ZERILYS is a new professional network built around your identity: your real portrait at the centre, with your skills, experience, ambitions and connections arranged around you in a clear, interactive space.

**Your personal invitation token:**

`[PASTE THE ONE-TIME TOKEN HERE]`

**How to join**
1. Open [ZERILYS link].
2. Choose **Create account**.
3. Enter the email address that received this invitation.
4. Paste your personal invitation token.
5. Add your photo and complete the key parts of your professional profile.

The token is personal, linked to your email address and can only be used once. Please do not forward it to anyone else.

**What I'd like you to test**
- Add, replace and remove your profile photo.
- Complete your professional identity.
- Discover and open other members' profiles.
- Search by name, skill and location.
- Try a connection request and, if you wish, share your public profile.
- Send feedback through the in-app feedback action if something is confusing, slow or broken.

Your profile is visible to signed-in ZERILYS members. If you switch it to Public, it can also be discovered by visitors who are not signed in, and your profile photo appears on your public page. You can keep it Private while still being visible to other signed-in members.

This is a private test version. Please do not publish confidential information or treat the platform as a production service. Your feedback will help us improve the experience before a wider release.

Thank you for being part of the first 50 testers.

Best,
[Your name]
