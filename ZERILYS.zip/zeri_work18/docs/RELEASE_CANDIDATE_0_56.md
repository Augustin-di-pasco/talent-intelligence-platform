# ZERILYS 0.56 — French-first release candidate

## Product changes
- French is the default product language for the first launch cohort.
- Browser language preferences select French or English on first visit; otherwise French is used. Members can change language manually from the top navigation, and the choice persists on the same browser.
- The translation catalogue covers the landing experience and the main member journeys. Dynamically generated interface strings are translated when inserted into the page.
- The public Beta Terms and Privacy Notice are now presented in French, with explicit draft warnings and completion placeholders retained.
- The product remains candidate-centred: Human Orbit, real member portrait, universal member-to-member profile discovery and a compact homepage are preserved.
- Standard registration remains invitation-free. Open registration is implemented at the API and interface levels, but the legal launch gate remains active until approval.

## Important launch restriction
**This release does not enable registrations on a live service by itself.** The server-side legal approval switch remains false by default and blocks registration until the French legal documents are completed for the actual operator, reviewed by qualified counsel and approved for publication. This restriction is intentional and must not be bypassed.

## Language scope
- Fully selectable languages in this release: French and English.
- First-visit selection uses browser language preferences rather than IP geolocation. A person's country does not reliably indicate their preferred language.
- Member-generated content is not automatically translated.
- Additional languages can be added to the catalogue after native review. English legal documents must be reviewed before English-market onboarding.

## Validation
- Automated unit suite: see `docs/QA_0_56.md` and release test output.
- Syntax checks: server, main client and language layer.
- Full release smoke suite: to be run before packaging.
- Real desktop/mobile browser QA and live-host acceptance remain outstanding.
