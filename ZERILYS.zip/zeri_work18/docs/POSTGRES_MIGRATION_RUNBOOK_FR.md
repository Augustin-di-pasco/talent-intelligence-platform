# Migration PostgreSQL — procédure contrôlée

## État réel

Le runtime actuel de ZERILYS utilise toujours `data/zerihlink.json` et un répertoire local pour les avatars. Le schéma SQL décrit la cible relationnelle. L'importeur ajouté en 1.4 prépare et contrôle un import initial, mais **ne remplace pas encore le stockage utilisé par le serveur**. Ne pas annoncer la bascule PostgreSQL avant la livraison de l'adaptateur runtime et les tests de concurrence.

## Préparer l'import

1. Arrêter les écritures sur l'instance source (mode maintenance).
2. Faire une sauvegarde vérifiée du fichier JSON et du répertoire `avatars/`.
3. Générer l'export SQL : `npm run export:postgres`.
4. Contrôler le fichier SQL et son empreinte SHA-256.
5. Créer une base PostgreSQL vide, distincte de toute base contenant des données utiles.
6. Définir `DATABASE_URL`, `ZERIHLINK_DATA_DIR` et, en garde supplémentaire, `ZERIHLINK_EXPECT_DATABASE`.
7. Faire d'abord un essai sur une base jetable : `npm run migrate:postgres` (précontrôle), puis `npm run migrate:postgres -- --apply`.
8. Comparer les volumes importés et tester les parcours de compte, profils, candidatures, entreprises, invitations, signalements et audit.

## Sécurité et limites

- Ne jamais committer `DATABASE_URL`, les exports SQL ou les sauvegardes.
- L'importeur applique le schéma et les données dans des transactions distinctes. Un échec de l'import annule les insertions de données ; le schéma déjà créé peut rester présent.
- Les jetons de réinitialisation de mot de passe sont volontairement invalidés pendant la migration.
- Le journal d'import permet d'identifier l'empreinte source et les volumes importés.
- Le schéma cible doit être validé contre les données réelles avant la migration de production.
- La bascule runtime reste un chantier séparé : ne pas ouvrir les inscriptions publiques sur la seule base d'un import réussi.
