# ZERILYS 0.69 — release candidate

## Résultat

Le lot 0.69 corrige les défauts d'expérience de profil montrés dans la vidéo : informations peu visibles après sauvegarde, centre de l'orbit trop discret, parcours de complétion peu travaillé et textes anglais résiduels dans l'espace identité.

## Validation automatisée

- 78 tests unitaires et de contrat : réussis.
- Vérification syntaxique Node.js : réussie.
- Smoke applicatif complet : réussi.
- Parcours de sauvegarde/lecture des champs du profil : vérifié par le smoke test.
- Cohorte de 50 comptes : 50 créations et découverte de 49/49 profils par compte de test.
- Sauvegarde/restauration, sécurité HTTP, stockage des portraits, préférences linguistiques et pré-vol de déploiement : réussis dans les scénarios locaux.

## Limites et conditions de partage

Cette archive est un jalon bêta local, pas une autorisation de mise en production. Le contrôle `npm run launch:check` indique encore 12 blocages et 4 avertissements. En particulier : hébergement de production, secrets, modération, stockage persistant, sauvegarde hors site et restauration, revue juridique et tests humains sur appareils réels. Le verrou juridique des inscriptions reste actif en production.
