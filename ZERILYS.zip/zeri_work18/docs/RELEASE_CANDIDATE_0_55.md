# ZERILYS 0.55 — Open registration

## Product change
Standard self-service account creation no longer requires a shared beta code or a personal invitation. The registration UI no longer displays invitation fields. Optional, email-bound personal invitations remain available for targeted research cohorts and company-team workflows remain invitation-based.

The change applies to both API and UI: the server ignores legacy `ZERIHLINK_INVITE_CODE` configuration and reports `inviteRequired: false`. A stale environment variable therefore cannot accidentally close registration.

## Independent launch gate
**Open registration is implemented, but the legal launch gate remains active.** The current Terms and Privacy Notice still visibly identify themselves as drafts and contain mandatory placeholders for the controller identity, contact details, legal bases, processors, retention and other disclosures. The server continues to return HTTP 503 for new registrations until those documents have actually been completed and reviewed and `ZERIHLINK_BETA_LEGAL_APPROVED=true` is set by the operator. This is intentional; this release does not pretend that legal review has occurred.

## Operational notes
- Remove any old `ZERIHLINK_INVITE_CODE` setting from the hosting dashboard (it is now ignored by the application).
- Keep `ZERIHLINK_ALLOW_SIGNUP=true`.
- Do not set `ZERIHLINK_BETA_LEGAL_APPROVED=true` until the legal documents are complete and approved.
- Optional targeted invitations remain available in the reviewer console, but are not a registration prerequisite.
- Existing invite records are preserved; they are not automatically deleted.

## Validation
The release smoke verifies registration without any invitation even when a legacy shared invite code is configured, while separately verifying that the legal launch lock still blocks registration when approval is false.
