# ZERILYS — Closed beta launch runbook (0.54)

This runbook is the operational path from the tested package to a controlled first cohort of 50 members. A green local test suite is necessary, but does not itself authorize registration or establish production readiness.

## 1. Deploy the correct artifact

1. Use `ZERIHLINK_PRIVATE_BETA_0_47.zip` as the source artifact.
2. Deploy the included `render.yaml` blueprint or adapt it explicitly to the actual hosting provider.
3. Keep the service single-instance. The current runtime store is a JSON file and is not safe for multiple app instances sharing the same data volume.
4. Mount persistent storage at `/opt/render/project/src/data` on Render. The volume must preserve both `zerihlink.json` and the `avatars/` directory.
5. Configure `/api/health` as the health-check route.
6. Ensure the reverse proxy overwrites or safely appends the real client IP to `X-Forwarded-For` before enabling `ZERIHLINK_TRUST_PROXY=true`.

## 2. Configure production environment

Copy `.env.production.example` into the hosting provider's environment settings and replace all placeholders.

Required for closed beta:
- `NODE_ENV=production`
- `ZERIHLINK_SESSION_SECRET`: unique random secret, at least 32 characters (e.g. generate locally with `openssl rand -hex 32`; do not send it in chat or commit it)
- `ZERIHLINK_REVIEWER_EMAILS`: one or more monitored reviewer addresses
- `ZERIHLINK_INVITE_CODE`: strong shared gate code of at least 12 characters; distribute it privately
- `ZERIHLINK_TRUST_PROXY=true` only behind the configured trusted reverse proxy
- `ZERIHLINK_DATA_DIR`: actual persistent volume path
- `ZERIHLINK_PUBLIC_URL`: canonical HTTPS origin for profile previews
- `ZERIHLINK_DEPLOYMENT_URL`: deployed service base URL for health validation

Optional but strongly recommended:
- Transactional email webhook URL, secret, sender and app URL. Without this, invitations may need manual delivery and password reset is unavailable.

## 3. Complete the human release gates

Do not set these acknowledgements until they are true:
- `ZERIHLINK_LEGAL_REVIEW_ACK=true`: a qualified reviewer has approved the terms, privacy notice, photo/profile visibility, retention, consent and brand use.
- `ZERIHLINK_BROWSER_QA_ACK=true`: desktop and real mobile-device tests have passed, including profile photo, network, public/private links, company workflows and reviewer tools.
- `ZERIHLINK_REVIEWER_COVERAGE_ACK=true`: named reviewers and a daily response rota are active.
- `ZERIHLINK_OFFSITE_BACKUP_ACK=true`: a backup has been copied off-host and a restore has been tested.
- `ZERIHLINK_BETA_LEGAL_APPROVED=true`: only after the legal review is complete and the approved documents are the deployed ones. The default must remain false until then.

## 4. Verify storage and backups

1. Confirm the live data directory and `avatars/` directory are on the same persistent volume.
2. Create a backup with `npm run backup`.
3. Local backup retention defaults to 14 verified pairs (`ZERIHLINK_BACKUP_RETENTION=14`; allowed range 2–100). Older pairs and orphan files are pruned only after a new backup and manifest have been written.
4. Verify the newest backup with `ZERIHLINK_BACKUP_FILE=/path/to/backup.json npm run backup:verify`.
5. Copy the backup and manifest to a separate off-site location.
6. Restore the backup into a separate test data directory and verify that profile photos migrate back to media files.
7. Never treat a copy of `zerihlink.json` alone as a complete backup after members have uploaded photos.

## 5. Run the release checks

From the deployed release directory:

```bash
npm ci
npm run test:release
npm run preflight:beta
```

The preflight must report `readyForClosedBeta: true` before inviting testers. Any blocker must be resolved, not bypassed by setting acknowledgement variables prematurely. Warnings about JSON runtime storage and market-data licensing remain relevant; live market prices must stay disabled until redistribution rights are confirmed.

## 6. Invite the first 50 members

1. Sign in with an account whose email is in `ZERIHLINK_REVIEWER_EMAILS`.
2. Open the restricted Trust & Safety console and paste up to 50 addresses into **Invite a cohort** (one email per line).
3. Create the batch. The server validates every address before creating any invitation; each token is email-bound and single-use.
4. If transactional email is configured, invitations are sent in small batches. Otherwise, copy the displayed email/token list and deliver it privately. Never publish the tokens.
5. Keep the shared beta code private; personal invitations are preferred for the first cohort.
6. Start with a small internal group, then expand toward 50 after the first feedback cycle.
7. Send `BETA_TESTER_GUIDE_0_47.md` with each invitation.
8. Review feedback and moderation reports every day during the first cohort.
9. Monitor health, disk capacity, backup age, error logs, registration rate limits and photo upload failures.

## 7. Known limits

- Runtime data is still a single-instance JSON store, not a live PostgreSQL deployment.
- Profile photos use separate files on the persistent host volume, not managed object storage.
- Transactional email is optional and may not be configured.
- The 50-member smoke is synthetic local validation, not a production load test.
- This package is a controlled closed-beta candidate, not a public-launch approval.
