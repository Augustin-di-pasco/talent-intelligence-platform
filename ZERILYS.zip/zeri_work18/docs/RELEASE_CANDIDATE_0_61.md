# ZERILYS 0.61 — Open signup abuse controls

- Open registration remains available without an invitation, subject to the separate legal launch gate.
- Added an explicit production-mode test for the per-client registration throttle: twenty registration attempts per minute, then HTTP 429.
- The legal launch gate remains active until the actual legal documents are approved.
- Verified the limit is keyed by the client address, method and endpoint.
- Preserved the proxy trust opt-in and documented the requirement that the reverse proxy controls forwarded IP headers.

Open registration remains invitation-free, with the separate legal approval gate still active.
