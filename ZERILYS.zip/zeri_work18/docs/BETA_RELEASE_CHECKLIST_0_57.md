# ZERILYS 0.57 — Checklist avant ouverture

- [x] Interface française native renforcée sur les principaux parcours candidat, réseau, opportunités, entreprise et modération.
- [x] Dates et heures adaptées à la langue choisie.
- [x] Sélecteur FR / EN conservé et choix mémorisé.
- [x] Inscriptions standard sans invitation obligatoire.
- [ ] Compléter et faire valider les documents juridiques français.
- [ ] Activer le verrou juridique uniquement après validation réelle (`ZERIHLINK_BETA_LEGAL_APPROVED=true`).
- [ ] Déployer sur l’hébergement de production et exécuter `npm run check:remote`.
- [ ] Vérifier les parcours sur ordinateur, iOS Safari et Android Chrome.
- [ ] Confirmer la persistance du volume, les sauvegardes hors site, la procédure de restauration et la modération.
- [ ] Vérifier l’envoi d’e-mails ou documenter les parcours manuels.
