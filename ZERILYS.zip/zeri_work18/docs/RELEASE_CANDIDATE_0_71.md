# ZERILYS 0.71 — release candidate

Cette version complète l’harmonisation française engagée en 0.70 en couvrant les profils publics, les signaux de compétences, les réalisations et les actions de mise en relation. Les parcours de profil public restent soumis aux mêmes règles de visibilité et d’accès que précédemment.

La validation automatisée est exécutée avec `npm run test:release`. Les essais humains sur appareils réels et les prérequis de production restent indispensables.
