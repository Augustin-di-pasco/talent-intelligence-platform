# Company verification — 0.29

## Candidate-facing trust rule
Company accounts begin as `unverified`. Published opportunities from an unverified or pending company are not returned by candidate discovery, the company page exposes no offers, and candidate interest is rejected as not found. The company may prepare and publish structured offers while verification is pending; they remain hidden until approval.

## Submission
The company owner submits:
- A business email address.
- An HTTPS company website already present on the company identity.
- At least 30 characters pointing reviewers to public evidence they can independently inspect.

The submission is private to the company and reviewers. It is not a legal certification or automated identity proof.

## Reviewer decision
Authorized reviewers inspect the company website and submitted public evidence, then approve or reject with a review note of at least 20 characters. Approval makes published offers discoverable. Rejection allows resubmission.

## Revalidation
Changes to company name, industry or website invalidate pending, rejected or verified status. Offers are hidden again until a reviewer completes a new verification.

## Privacy
Business email, proof note, reviewer note and reviewer identity are never included in public company responses. The account owner can see and export their own verification record. Public responses expose only the status and verified boolean.

If the reviewing account is deleted, approvals made by that reviewer are invalidated and the affected company returns to `unverified`; its offers are hidden until another reviewer rechecks it.
