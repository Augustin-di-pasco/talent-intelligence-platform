# Trust & Safety operations — 0.17

## Access control
The reviewer console is rendered only after both reviewer APIs authorize the signed-in account. The server's `ZERIHLINK_REVIEWER_EMAILS` allowlist remains the source of authorization. Client-side visibility is not a security control.

## Report review
Reviewers can inspect report category, reason, reporter and target identity, then mark a report reviewed or dismissed with an optional internal note. The server writes an audit event.

## Evidence review
Reviewers can inspect submitted evidence details and an HTTPS source link, then mark it verified or rejected with an optional note. Only pending evidence can be reviewed; the server enforces this state transition and records an audit event.

## Operating rules
- Keep reviewer access limited to named, trained accounts.
- Review reported harassment, impersonation and safety issues promptly.
- Do not treat a report as proof of wrongdoing.
- Verification means a reviewer assessed the submitted evidence; it does not imply a legal, academic or professional certification unless that exact scope was checked.
- Establish reviewer coverage and an escalation process before inviting 50 testers.
- The current reviewer model is an email allowlist, not a full admin identity system. Reviewer identity management, appeals, suspension workflows and moderation SLAs remain future work.
