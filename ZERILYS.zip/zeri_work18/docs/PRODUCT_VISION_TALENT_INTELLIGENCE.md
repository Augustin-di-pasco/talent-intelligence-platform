# ZERILYS — Talent Intelligence

**Release:** 1.1.0-alpha.1  
**Product language at launch:** French (English selectable)  
**Initial market:** France, then Europe  
**Initial verticals:** quantitative finance, fintech, AI/ML, data and risk technology  
**Status:** functional private-beta product foundation; not approved for public commercial launch.

## Executive proposition

ZERILYS is a specialist talent network and recruiting workspace for finance, AI and data. It helps professionals make their capabilities and work legible, and helps employers discover relevant people through skills, experience, evidence and stated intent.

It is not a general-purpose social network, a CV database clone, a trading terminal or a generic AI chatbot.

## Who it serves

### Professionals
- Build a living professional identity rather than maintain another static CV.
- Describe skills and levels, attach projects, credentials and work samples, and control visibility.
- Discover relevant opportunities and connect with context.
- Distinguish self-described capabilities from evidence reviewed independently.

### Employers and specialist recruiters
- Create a company identity and request company verification.
- Publish structured roles and collaboration opportunities.
- Discover member profiles by skills, experience, location and professional intent.
- Review candidate interest and manage a structured recruitment workflow.
- Invite colleagues into a role-based company workspace.

## Why the initial niche

Start where skills are specialised, combinations matter and hiring mistakes are expensive: quantitative finance, AI/ML, data engineering, fintech software and risk modelling. This creates a coherent talent graph before broadening to adjacent disciplines.

## Product pillars

1. **Professional identity:** profile, trajectory, skills, evidence, intent and privacy controls.
2. **Talent discovery:** searchable member directory, explainable complementarity signals and specialist quick searches.
3. **Opportunities:** structured company roles, candidate interest and application workflow.
4. **Collaboration:** projects and intentional professional connections.
5. **Trust operations:** company review, evidence review, moderation, feedback and audit-oriented controls.
6. **Talent market intelligence (foundation):** a disciplined layer for understanding the skills and roles represented by platform data. External market benchmarks, live demand indicators and automated skill-graph analytics are not yet implemented and must not be marketed as available.

## What was merged — and what was deliberately not

### Retained from ZERILYS
- Candidate-centred Human Orbit identity model.
- Skills, evidence, experience, intent and impact surfaces.
- Member discovery and contextual connections.
- Company identities, verification workflow, opportunities and applications.
- Company team roles, privacy, account security, feedback and reviewer operations.
- French-first interface with an English language option.

### Reused as product principles from WORLD INTELLIGENCE
- Source provenance and explicit confidence boundaries.
- Separation of observed facts, interpretation and hypotheses.
- Time-aware tracking and auditability as design principles.
- Data integrity: never invent a statistic, verification status or external market signal.

### Excluded from the unified product
- Trading terminal, trade manager and portfolio tooling.
- Market indices and price dashboards.
- Geopolitical asset transmission maps.
- Financial risk journal and investment decision workflows.

The original WORLD INTELLIGENCE source archive is retained under `legacy/` for reference. Its application and database are not part of the ZERILYS runtime.

## Navigation and information architecture

Public navigation: **Talents · Opportunités · Collaborations · Intelligence marché**.

Authenticated actions are contextual: professional identity, connections, notifications, company workspace, applications, privacy and account security. Restricted reviewer operations remain permission-gated and are not exposed as public navigation.

## Commercial model — hypotheses to validate

| Plan | Target | Indicative price | Value boundary |
|---|---|---:|---|
| Member | Professionals | Free | Identity, discovery, applications and connections |
| Recruiter | Independent recruiters / small teams | €99–149 per seat/month | Specialist search, shortlist workflow and role management |
| Team | Specialist agencies / growing companies | €299–499/month | Shared workspace, multiple recruiters and collaboration |
| Enterprise | Banks, funds, insurers and large technology groups | Custom | Governance, integrations, support, reporting and procurement requirements |

These prices are hypotheses, not validated willingness-to-pay. Do not activate billing until interviews and paid pilots validate the packaging, conversion and retention.

## Go-to-market wedge

1. Recruit 50–100 high-quality founding professionals in France across quant, AI/ML, data and fintech.
2. Recruit 5–10 design partners: specialist recruitment firms, fintechs, funds, banks and AI/data teams.
3. Manually support the first shortlists to learn which filters and evidence actually influence recruiter decisions.
4. Convert repeated manual work into product capabilities only after usage evidence.
5. Expand to adjacent skill clusters and English-speaking markets once liquidity is visible.

Do not launch as an empty open marketplace. Seed the supply side and employer demand in parallel.

## North-star and operating metrics

- Qualified active specialists with complete, evidence-linked profiles.
- Recruiter searches that produce a relevant shortlist.
- Time from role creation to first qualified shortlist.
- Candidate response rate to relevant opportunities.
- Employer repeat-search and repeat-posting rate.
- Paid pilot conversion and net revenue retention.
- Profile evidence completion and independent review turnaround.

Do not optimise for page views, followers or vanity sign-ups.

## Defensibility thesis

The defensible asset is not the AI label. It is the combination of (a) a dense specialist community, (b) structured skills and evidence, (c) high-quality hiring intent and role data, and (d) trusted workflows that improve as real hiring outcomes are recorded with consent. The network effect only exists if both candidate quality and employer demand become dense in the same niche.

## Responsible AI and trust

- Never make an automated employability, trustworthiness or hiring verdict.
- Show why a profile was surfaced and which profile data supported the suggestion.
- Treat user-entered skills as self-described unless evidence has actually been reviewed.
- Keep evidence status and company verification status explicit.
- Human decision-makers remain accountable for hiring decisions.
- Provide access, correction, export, deletion and visibility controls consistent with applicable law.

## Commercial launch gates

The current build is an alpha/private-beta foundation. Public launch requires all of the following:
- Legal review of terms, privacy notice, data-controller/processor roles, retention, lawful bases and GDPR workflows.
- Confirmed trademark and domain availability for the chosen brand.
- Production database architecture, tested migrations, off-site backups and restore drills.
- Transactional email provider, verified sender domain, SPF, DKIM and DMARC.
- Independent security review, vulnerability management and incident response process.
- Accessibility and cross-browser QA, including mobile screen-reader checks.
- Company and evidence review operations with named human coverage.
- Data-source and licensing review before any external market intelligence is shown.
- Pricing interviews and at least two paid pilot commitments before claiming product-market fit.
- Production monitoring, support process, service objectives and cost controls.

Until the legal and operational launch locks are explicitly approved, registration remains disabled by the deployment configuration. Do not bypass those gates for a demo.
