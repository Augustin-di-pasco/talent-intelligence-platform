# ZERILYS 0.68 — maintenance release candidate

Status: local validation candidate; not approved for public launch.

This release repairs version drift in the smoke-test suite and aligns release metadata at 0.68.0. It does not remove any manual launch gate.

Required gates before inviting the first 50 testers:
- Complete legal review and approve the beta terms and privacy notice.
- Configure unique production secrets and canonical HTTPS URL.
- Verify persistent production storage for account data and portraits.
- Verify off-site backup and a tested restore procedure.
- Complete authenticated browser QA on desktop and mobile.
- Confirm moderation/reviewer coverage and incident response.
- Run `npm run test:release`, `npm run preflight:beta` and the remote acceptance check against the deployed host.
