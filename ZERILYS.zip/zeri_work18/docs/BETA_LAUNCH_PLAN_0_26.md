# Plan de lancement bêta — 50 premiers testeurs

## Objectif
Valider la compréhension du Professional Universe, la qualité des preuves, la pertinence des opportunités, la maîtrise de la visibilité et la confiance dans les échanges. Il ne s'agit pas de mesurer une audience ou de maximiser l'engagement social.

## Déploiement progressif
1. **Cohorte pilote — 5 personnes** : vérifier inscription, profil, visibilité, compétences, preuves, invitations et feedback.
2. **Cohorte d'apprentissage — 15 personnes** : ajouter des entreprises et des opportunités réelles ; observer les premiers intérêts, connexions et retours.
3. **Cohorte bêta — jusqu'à 50 personnes** : ouvrir progressivement les invitations restantes seulement après résolution des incidents bloquants.

La répartition candidats/entreprises doit être choisie selon les premiers testeurs disponibles ; il faut néanmoins suffisamment d'entreprises et d'offres réelles pour tester les deux côtés du produit.

## Indicateurs à suivre
- Taux d'inscription aboutie et erreurs d'inscription.
- Complétion du parcours d'activation.
- Nombre de compétences avec au moins une preuve.
- Compréhension des contrôles de visibilité.
- Consultation d'une opportunité → intérêt explicite → statut communiqué.
- Demandes de connexion acceptées/refusées et qualité des raisons.
- Volume, catégories et délai de traitement des retours bêta.
- Incidents de confidentialité, accès ou perte de données.

Ne pas ajouter de likes, de fil d'actualité ou de classement de popularité pour mesurer la réussite.

## Rythme d'exploitation
- Vérifier chaque jour les signalements, les preuves en attente et les retours.
- Vérifier l'intégrité des données et la sauvegarde avant chaque nouvelle vague.
- Tenir un journal des incidents et des décisions.
- Informer les testeurs des changements qui affectent la visibilité, les candidatures ou les données.
- Suspendre les nouvelles invitations si un incident de confidentialité, de perte de données ou de sécurité reste non résolu.

## Règles pour les testeurs
- Utiliser une invitation personnelle liée à leur adresse e-mail.
- Ne pas saisir de mots de passe tiers, données sensibles ou informations confidentielles d'employeur.
- Choisir consciemment la visibilité du profil.
- Retirer une candidature si le partage du profil n'est plus souhaité.
- Utiliser le formulaire de feedback pour les bugs et difficultés.

## Avant le premier envoi
La bêta ne doit pas être annoncée comme ouverte tant que l'URL déployée, les tests visuels réels, la couverture de modération, la revue juridique et la procédure de sauvegarde hors site ne sont pas confirmés.
