# Privacy-by-default — 0.30

## New accounts
- New personal accounts start with `visibility: private`.
- Private profiles remain visible and discoverable to all signed-in members; they are absent only from anonymous discovery and public profile URLs.
- Candidates can still browse published opportunities.
- Expressing interest in a specific verified opportunity explicitly shares the professional profile with that company for that application only.
- Members may switch to public discoverability from their identity editor at any time, and may switch back to private. This does not remove member-to-member profile access.
- Company identity is separate from personal profile visibility; company pages and opportunities are controlled by company verification.

## Existing accounts
Existing members retain their current visibility choice. The change applies to new registrations only; it does not silently change existing members' settings.

## User interface
Registration explains the private default. The Professional Universe repeats the current privacy state and explains that private mode limits anonymous discovery, not member-to-member access.
