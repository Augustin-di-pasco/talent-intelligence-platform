# ZERILYS Talent Intelligence — 1.1.0-alpha.1

## Included
- Product repositioning around specialist talent in finance, AI and data.
- Public navigation restored across Talents, Opportunités, Collaborations and Intelligence marché.
- Specialist discovery shortcuts wired to the existing live member-search endpoint.
- World Intelligence's trading and general-market modules excluded from the user experience.
- Talent market intelligence section reframed around the platform's actual profile and opportunity data; no simulated market statistics.
- French-first metadata and positioning, with English language selection retained.
- Both original project archives retained under `legacy/`.
- Product vision, commercial model hypotheses, go-to-market wedge, metrics and launch gates documented.

## Validation
- ZERILYS automated unit tests: 166/166 passed.
- ZERILYS release suite (`npm run test:release`): passed, including 50-member cohort, backup/restore, data integrity, HTTP hardening, email workflow and local production-mode remote acceptance.
- JavaScript syntax check: passed.
- WORLD INTELLIGENCE is archived, not integrated into the runtime. Its original Python suite was not used as a release gate for the unified product; the original prototype has known failing tests and remains separate.

## Important limitations
- This is an alpha/private-beta release, not a public commercial launch approval.
- Specialist search shortcuts use the existing text-based discovery endpoint; a semantic skill graph is not yet implemented.
- Talent market intelligence is a product foundation, not a live external labour-market data service.
- No billing, paid plans, ATS/HRIS integrations or external data subscriptions are activated.
- Legal approval, domain/trademark clearance, production database and operational sign-off remain launch blockers.
