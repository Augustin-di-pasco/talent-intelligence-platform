# Controlled beta invitations — 0.19

## Reviewer API
- `POST /api/review/invitations` with `{ email, accountType, validDays }` creates a single-use invitation.
- `GET /api/review/invitations` lists pending invitations without token hashes.
- `DELETE /api/review/invitations/:id` revokes a pending invitation.
- All three endpoints require an authenticated account in `ZERIHLINK_REVIEWER_EMAILS`.

## Registration
A tester may register with the shared `ZERIHLINK_INVITE_CODE` or with a personal `betaInvitationToken`. Personal tokens are random, stored only as SHA-256 hashes, tied to one exact normalized email address, expire after 1–30 days (14 by default), and are consumed once. The invitation's account type is applied to the created account. A wrong email, expired token, revoked token or replay is rejected.

## Delivery and limitations
The reviewer console displays the token once for private manual delivery. No email provider is configured, so reviewers must send the token through a trusted channel and avoid public messages. The shared beta code remains a fallback and should be kept secret. Invitations do not replace email verification or identity verification.
