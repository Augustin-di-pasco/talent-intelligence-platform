# ZERILYS 0.60 — Email confirmation for open signup

- Open registration remains available without an invitation, subject to the separate legal launch gate.
- Added optional email-address confirmation for new accounts when a transactional email provider is configured.
- The legal launch gate remains active until the actual legal documents are approved.
- Confirmation links are single-use, hash-backed and expire after 24 hours.
- Members can resend a confirmation message from account privacy settings.
- Delivery failures preserve the account and allow retry; without a provider, open signup remains available and the UI explains that confirmation is not configured.
- Verification state is private and removed during account deletion.

Email confirmation does not block account creation in this beta build. It is not identity verification. Production requires a configured email webhook and the existing legal and hosting launch gates.
