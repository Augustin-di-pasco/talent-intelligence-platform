# ZERILYS 0.59 — Account language preference

- Open registration remains available without an invitation, subject to the separate legal launch gate.
- The FR / EN selection is now saved to the member account, not only the current browser.
- The legal launch gate remains active until the actual legal documents are approved.
- A member's saved language takes precedence on another browser or device.
- The language preference is kept private from other members and included in the account export.
- Unsupported language codes are rejected.

The open-registration legal gate and all previous 50-member tests remain unchanged.
