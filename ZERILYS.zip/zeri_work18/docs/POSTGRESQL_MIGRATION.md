# PostgreSQL migration foundation — version 0.13

## Current status

The application still runs on its JSON-file store. `db/schema.postgresql.sql` is a target relational schema draft, not an executed migration and not a database adapter. No PostgreSQL connection, data import, backup restore, or production migration has been performed in this release.

## Migration principles

1. Create a PostgreSQL adapter behind the existing store interface; keep route handlers independent of SQL.
2. Use parameterized queries only. Never interpolate user-controlled values into SQL.
3. Preserve candidate consent boundaries: application access is offer-scoped; withdrawal revokes the company's access and deletes company-private notes.
4. Keep private company notes in a separate table and never include them in candidate-facing serializers.
5. Persist status changes as append-only application events. Treat the current status as a projection, not the only record.
6. Preserve audit-event integrity and define retention/archival before removing any records.
7. Use transactions for interest submission, event creation, and notification creation.
8. Add a tested import/export tool with row counts, checksums, dry-run mode, rollback plan, and duplicate detection before switching storage.

## Proposed rollout

- Phase A: approve schema, threat model, data retention, and deletion semantics.
- Phase B: implement and test PostgreSQL adapter locally against a disposable database.
- Phase C: import a copy of the JSON dataset; compare entity counts and critical relationships.
- Phase D: run integration tests against PostgreSQL and exercise restore from backup.
- Phase E: deploy a maintenance-window migration with a verified rollback path.
- Phase F: only after monitoring and reconciliation, make PostgreSQL the production source of truth.

## Operational requirements before production

- Managed PostgreSQL with TLS, least-privilege credentials, private networking, and connection pooling.
- Automated encrypted off-site backups and periodic restore drills.
- Migration version table, repeatable migration process, and documented rollback strategy.
- Monitoring for connection saturation, query latency, failed jobs, and storage growth.
- Explicit retention policy for applications, internal notes, notifications, reports, and audit records.

## Open design decisions

- Whether company notes should be retained after application closure (withdrawal currently clears them).
- Whether candidates may request deletion of application event history under the eventual privacy workflow.
- Company seats now have recruiter/viewer roles in the JSON runtime. The PostgreSQL target schema includes `company_members` and `company_invitations`; the SQL has still not been applied and no PostgreSQL adapter is active.
- Formal legal review of retention, lawful basis, and data-subject rights before launch.


## 0.23 — Complete target schema and JSON export package

The target schema now includes projects, project applications, connections, company memberships/invitations, beta invitations, tester feedback and an import log. `scripts/export-postgres.mjs` generates a transactional SQL file from the current JSON store. It uses SQL string escaping, JSONB payloads, deterministic IDs for synthesized application status events, conflict-safe inserts and a per-entity import log tied to the source SHA-256.

Commands:
- `npm run export:postgres` — generate `data/postgres-export-<timestamp>.sql`.
- `ZERIHLINK_POSTGRES_EXPORT_FILE=/path/to/export.sql npm run export:postgres` — choose an explicit output path.
- `npm run smoke:postgres-export` — generate a synthetic export and check entity coverage, escaping and source checksum.

This is an export/migration preparation tool only. No PostgreSQL server or `psql` binary was available in the build environment; the generated SQL has not been executed against PostgreSQL. The application runtime remains JSON-file based, and no PostgreSQL adapter is active.


## 0.27 — Beta consent records
The users table now includes a dedicated `legal_consent` JSONB field. The SQL exporter removes this field from the general profile JSON and writes it to that column. The record contains the accepted terms/privacy versions and timestamps; it is private to the account owner and included in their data export.


## 0.28 — Password reset tokens
The target schema includes `password_reset_tokens`, but the JSON exporter deliberately imports zero outstanding reset tokens. Reset tokens are credentials; all outstanding tokens must be invalidated at migration cutover and requested again after migration.


## 0.29 — Company verification
Company verification request details are stored in the private `company_verification` JSONB field on users. The SQL exporter removes this object from the general profile JSON and writes it to the dedicated column. Public API responses expose only the status, never the business email or proof note.
