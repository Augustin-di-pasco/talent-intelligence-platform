# ZERILYS 0.56 — Checklist avant ouverture publique

## Produit et langues
- [x] Inscription standard sans code d’invitation obligatoire.
- [x] Français natif comme langue par défaut.
- [x] Détection initiale à partir des préférences du navigateur pour les langues prises en charge.
- [x] Sélecteur français / anglais et mémorisation du choix.
- [x] Traduction des principaux parcours et des contenus d’interface chargés dynamiquement.
- [x] Conditions de bêta et politique de confidentialité rédigées en français, toujours signalées comme projets non validés.
- [x] Human Orbit, photo réelle et consultation des profils membres préservés.

## À terminer avant d’autoriser les inscriptions
- [ ] Renseigner la dénomination juridique et l’adresse de l’exploitant.
- [ ] Renseigner les coordonnées de contact et les mentions légales obligatoires.
- [ ] Confirmer les bases juridiques, durées de conservation, sous-traitants et lieux d’hébergement.
- [ ] Faire relire et approuver les conditions et la politique de confidentialité par un professionnel compétent.
- [ ] Publier les documents approuvés puis seulement activer `ZERIHLINK_BETA_LEGAL_APPROVED=true`.
- [ ] Déployer la version et exécuter `npm run check:remote`.
- [ ] Contrôler les parcours FR / EN sur ordinateur, iOS Safari et Android Chrome.
- [ ] Vérifier le stockage persistant, les sauvegardes hors site, la couverture de modération et la procédure d’incident.

Les inscriptions sont ouvertes sans invitation au niveau fonctionnel, mais restent bloquées tant que le verrou juridique indépendant n’a pas été levé après validation réelle.
