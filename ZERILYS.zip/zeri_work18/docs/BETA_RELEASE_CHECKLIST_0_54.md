# ZERILYS 0.54 — Final checklist before inviting the first 50 testers

Use this checklist with `BETA_LAUNCH_RUNBOOK_0_54.md`. Do not mark a human acknowledgement as complete until the corresponding check has actually been performed.

## Hosting and security
- [ ] Deploy the exact `ZERIHLINK_PRIVATE_BETA_0_54.zip` artifact.
- [ ] Confirm the service runs as one instance against one persistent data volume.
- [ ] Confirm `zerihlink.json` and `avatars/` survive a restart.
- [ ] Configure a unique session secret, reviewer emails and private beta invite code.
- [ ] Configure the trusted reverse proxy and verify per-client rate limiting.
- [ ] Set `ZERIHLINK_PUBLIC_URL` and `ZERIHLINK_DEPLOYMENT_URL` to the real HTTPS origin.
- [ ] Run `npm run check:remote` and resolve every failure.

## Legal and privacy
- [ ] Review the Terms of Service and Privacy Notice with a qualified reviewer.
- [ ] Approve the legal basis, consent wording, photo visibility, retention, deletion and moderation process.
- [ ] Confirm the deployed legal documents match the approved versions.
- [ ] Only then set `ZERIHLINK_LEGAL_REVIEW_ACK=true` and `ZERIHLINK_BETA_LEGAL_APPROVED=true`.

## Operations and support
- [ ] Create a checksummed local backup including profile photos.
- [ ] Copy the backup and manifest off-host.
- [ ] Restore a copy into a separate test data directory.
- [ ] Confirm a named reviewer rota and daily response process.
- [ ] Confirm email webhook delivery or prepare a secure manual invitation-token workflow.
- [ ] Only then set the reviewer-coverage and off-site-backup acknowledgements.

## Real-device QA
- [ ] Test account creation and login on desktop and mobile.
- [ ] Test portrait upload, replacement, deletion and persistence.
- [ ] Test member-to-member access for Private profiles.
- [ ] Test Public profile links, social preview and anonymous photo access.
- [ ] Test search, pagination, connection requests, blocking and reporting.
- [ ] Test keyboard-only navigation, screen reader labels and reduced motion.
- [ ] Only then set `ZERIHLINK_BROWSER_QA_ACK=true`.

## Cohort launch
- [ ] Create a small internal invitation batch first.
- [ ] Verify invitation delivery, redemption, expiry and revocation.
- [ ] Create the 50-person batch from the reviewer console.
- [ ] Send `BETA_TESTER_GUIDE_0_54.md` and the invitation email template.
- [ ] Monitor errors, disk capacity, backups, invitation redemption and feedback daily.

## Known constraints
- The live application still uses a single-instance JSON runtime store; PostgreSQL runtime migration has not been completed.
- The synthetic 50-member test is not a production load test.
- Market data must remain disabled until redistribution rights are confirmed.
- This checklist is a controlled private-beta gate, not a public-launch approval.
