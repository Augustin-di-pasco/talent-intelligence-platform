# Politique d'utilisation de l'IA par offre

Chaque entreprise choisit et affiche une politique pour les évaluations associées à une opportunité :

- `allowed` — l'utilisation de l'IA est autorisée ; le candidat peut être invité à expliquer comment il l'a utilisée et à vérifier ses résultats.
- `prohibited` — l'utilisation de l'IA est interdite pendant les évaluations explicitement concernées par l'offre. L'entreprise doit décrire le périmètre, les outils concernés et les conditions équitables de passation.
- `expected` — l'utilisation de l'IA fait partie de l'exercice ; le candidat est évalué sur sa capacité à formuler des demandes pertinentes, vérifier les sorties, corriger les erreurs et justifier ses décisions.

La politique et la note de l'employeur sont visibles sur les offres avant candidature. Une copie de la politique en vigueur au moment de la candidature est conservée dans le dossier de candidature afin d'éviter qu'une modification ultérieure ne réécrive l'information initialement présentée.

## Limites et garanties

Cette préférence est une règle de transparence et de cadrage. Elle ne constitue pas un mécanisme technique de détection ou de blocage de l'IA. Une politique « non autorisée » ne doit être appliquée qu'à une évaluation clairement identifiée, avec des modalités proportionnées, accessibles et annoncées à l'avance. Aucun signal automatisé isolé ne doit conduire à conclure à une fraude ou à écarter automatiquement un candidat. Les cas litigieux nécessitent une revue humaine et une possibilité de réponse.

Les évaluations de connaissances personnelles déjà réalisées dans le profil candidat ne changent pas de statut rétroactivement : la politique de l'offre s'applique aux évaluations liées à cette offre.
