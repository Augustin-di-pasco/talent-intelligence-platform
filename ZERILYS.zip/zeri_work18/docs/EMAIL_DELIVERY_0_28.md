# Transactional email and account recovery — 0.28

## Configuration
Set all four variables:
- `ZERIHLINK_EMAIL_WEBHOOK_URL` — HTTPS webhook endpoint in production.
- `ZERIHLINK_EMAIL_WEBHOOK_SECRET` — bearer secret, minimum 32 characters.
- `ZERIHLINK_EMAIL_FROM` — verified sender email address.
- `ZERIHLINK_APP_URL` — public HTTPS application base URL in production.

The webhook receives a JSON body with `from`, `to`, `subject`, `text` and `html`, plus `Authorization: Bearer <secret>`. It should return a 2xx response and may return a JSON `id`. Never log the authorization header or raw tokens. A local HTTP webhook is allowed only outside production for automated tests.

## Invitation delivery
- If email is configured, reviewer-created beta invitations are sent and the raw token is not returned by the API.
- If email is not configured, delivery remains manual and the reviewer receives the one-time token.
- If the webhook fails, the invitation remains pending and the API returns a manual fallback token. The reviewer should deliver it through a trusted channel.
- Tokens remain single-use and email-bound.

## Password recovery
- `POST /api/auth/password-reset/request` always returns the same generic message to avoid account enumeration.
- A token is created only when the email exists and delivery is configured.
- Tokens are stored as SHA-256 hashes, expire after 30 minutes, and are single-use.
- Successful reset changes the password, invalidates all active sessions and deletes pending reset tokens.
- Outstanding reset tokens are intentionally not exported during PostgreSQL migration; users must request a new token after cutover.
- Without email configuration, password reset is unavailable; the request endpoint still returns the generic response.

## Limits
This is a generic webhook adapter, not a direct integration with a specific email vendor. The operator must configure, verify and monitor the chosen delivery service and sender domain.
