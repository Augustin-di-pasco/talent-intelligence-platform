# Project Labs — espace de travail alpha.20

## Parcours couvert
- Le formulaire de création est structuré et bilingue ; il collecte titre, description, type, engagement, durée, capacité, compétences, livrables et compensation conditionnelle des défis commerciaux.
- Les projets ouverts sont consultables depuis la page publique.
- L'ouverture d'une fiche projet affiche ses objectifs, son type, sa durée et la taille d'équipe.
- Le propriétaire peut consulter les candidatures reçues et accepter ou refuser chaque demande.
- Le candidat accepté et le propriétaire accèdent au tableau de tâches privé.
- Une tâche comprend un titre, une description, un responsable et une échéance ; son état peut évoluer entre « à faire », « en cours » et « terminé ».
- Le propriétaire peut réattribuer les tâches ; les membres autorisés peuvent mettre à jour l'état des tâches qu'ils gèrent.

## Contrôles d'accès
- `GET /api/projects/:id/applications` est réservé au propriétaire du projet.
- `GET /api/projects/:id/tasks` et les mutations de tâches exigent une appartenance à l'équipe (propriétaire ou candidature acceptée).
- Les tâches restent exclues des listes publiques de projets.
- Les contenus utilisateurs sont échappés avant affichage.
- Les décisions d'acceptation et les mutations de tâches sont journalisées.

## Limites connues
- Il s'agit d'un premier espace de coordination : pas encore de messagerie d'équipe, stockage documentaire collaboratif, notifications temps réel, gestion de versions de livrables ni export de portfolio collectif.
- Le stockage suit encore le modèle persistant actuel de l'application ; la migration PostgreSQL de production n'est pas achevée.
- La validation automatisée ne remplace pas des essais utilisateurs sur ordinateur et mobile.
