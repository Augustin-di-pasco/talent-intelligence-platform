# ZERILYS — mise à jour de marque

La plateforme adopte désormais officiellement le nom **ZERILYS** et la signature **BEYOND THE CV.**

Cette mise à jour couvre le site public, les métadonnées, les titres de page, les parcours de profil et de compte, les e-mails et textes traduits, les documents bêta, les guides opérateurs, les tests, les métadonnées du package et les noms de ressources Render.

Les clés d’environnement historiques `ZERIHLINK_*`, le nom de fichier de stockage `zerihlink.json` et l’événement interne de langue sont volontairement conservés pour assurer la compatibilité des déploiements et données existants. Ils ne constituent pas la marque visible du produit.

La version applicative reste `1.9.0-alpha.20`. Les 250 tests unitaires/contrat, `npm run check` et les smoke tests principaux ont été exécutés avec succès après le changement de marque.

Le déploiement distant et le transfert vers un nouveau dépôt GitHub ne sont pas inclus dans cette archive locale.
